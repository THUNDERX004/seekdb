param(
  [Parameter(Mandatory=$true)][string]$Variant,
  [Parameter(Mandatory=$true)][string]$OutputDir,
  [Parameter(Mandatory=$true)][string]$SourceSha,
  [Parameter(Mandatory=$true)][string]$HeaderSha
)
$ErrorActionPreference = 'Stop'
$arbVs = 'C:\Program Files\Microsoft Visual Studio\2022\BuildTools'
Import-Module (Join-Path $arbVs 'Common7\Tools\Microsoft.VisualStudio.DevShell.dll')
Enter-VsDevShell -VsInstallPath $arbVs -SkipAutomaticLocation -DevCmdArguments '-arch=amd64 -host_arch=amd64 -vcvars_ver=14.44 -winsdk=10.0.26100.0'
& 'C:\Users\11946\Documents\ChatGPT\OceanBase比赛\.venv\Scripts\python.exe' -X utf8 (Join-Path $PSScriptRoot 'build_native.py') --variant $Variant --output-dir $OutputDir --expected-source-sha256 $SourceSha --expected-header-sha256 $HeaderSha --expected-cases 5304 --build
exit $LASTEXITCODE
