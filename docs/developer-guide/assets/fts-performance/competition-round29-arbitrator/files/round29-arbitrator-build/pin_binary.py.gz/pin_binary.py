"""Freeze the exact tested arbitration candidate executable and runtime files."""
from pathlib import Path
import hashlib
import json
import shutil

HERE = Path(__file__).resolve().parent
ROOT = Path('D:/Projects/OceanBase/seekdb')
BUILD = ROOT / 'build_fts_competition/src/observer'
OUT = ROOT / 'build/fts-round29-arbitrator-candidate'
assert hashlib.sha256((ROOT / 'src/storage/fts/ik/ob_ik_arbitrator.cpp').read_bytes()).hexdigest() == 'cb9d730455159a2c2e0c1ddfc3b6d96a2631a047ce0cf19c867df0d9ac0d8b24'
assert not OUT.exists()
OUT.mkdir()
files = {}
for source in [BUILD/'seekdb.exe', BUILD/'seekdb.pdb', *sorted(BUILD.glob('*.dll'))]:
    raw_hash = hashlib.sha256(source.read_bytes()).hexdigest()
    shutil.copy2(source, OUT / source.name)
    assert hashlib.sha256((OUT / source.name).read_bytes()).hexdigest() == raw_hash
    files[source.name] = dict(bytes=source.stat().st_size, sha256=raw_hash)
with (HERE / 'binary.json').open('x') as f:
    json.dump(dict(output=str(OUT), files=files), f, indent=2)
print('PINNED', files['seekdb.exe']['sha256'])
