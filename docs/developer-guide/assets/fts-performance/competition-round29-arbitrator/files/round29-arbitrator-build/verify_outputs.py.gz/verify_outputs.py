"""Verify full original/candidate native outputs independently of the runner."""
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent
raws = {}
for variant in ('control', 'candidate'):
    directory = HERE / (variant + '-run1')
    receipt = json.loads((directory / 'run.json').read_bytes())
    raw = (directory / 'stdout.log').read_bytes()
    assert receipt['native'] == receipt['output_validation'] == 'PASS' and receipt['exit_code'] == 0
    assert receipt['test_sha256'] == '808f48820c97281559347e5f66e4690abc97949e658ff646e3865ece48925e2e'
    assert hashlib.sha256(raw).hexdigest() == receipt['logs_sha256']['stdout.log']
    assert (directory / 'stderr.log').read_bytes() == b''
    lines = raw.splitlines()
    assert sum(x.startswith(b'CASE\t') for x in lines) == 5304
    assert [x for x in lines if x.startswith(b'PASS\t')] == [b'PASS\tcases=5304']
    raws[variant] = raw
assert raws['control'] == raws['candidate']
result = dict(status='PASS', cases=5304, full_stdout_equal=True, both_stderr_empty=True,
    T_records=sum(x.startswith(b'T\t') for x in raws['control'].splitlines()),
    stdout_sha256=hashlib.sha256(raws['control']).hexdigest(),
    scope='Public actual-production arbitration; generic no-chain and whole-token checks plus full differential chain transcript. Finite Windows matrix, not Linux or all allocation failures.')
with (HERE / 'parent-output-verification.json').open('x') as f:
    json.dump(result, f, indent=2)
print(json.dumps(result))
