"""Reject the unproven decode shortcut and restore its exact production source."""
from pathlib import Path
from datetime import datetime
import hashlib
import json

HERE = Path(__file__).resolve().parent
ROOT = Path('D:/Projects/OceanBase/seekdb')
SOURCE = ROOT / 'src/storage/fts/ik/ob_ik_arbitrator.cpp'
TEST = ROOT / 'unittest/storage/fts/test_arbitrator_decode.cpp'
old, new = (HERE/'original.cpp').read_bytes(), (HERE/'candidate.cpp').read_bytes()
assert hashlib.sha256(old).hexdigest() == 'c59ea5dead8183a9728087dcea403e8418398a2040b2d50e560ac0e6e5897d17'
assert hashlib.sha256(new).hexdigest() == 'cb9d730455159a2c2e0c1ddfc3b6d96a2631a047ce0cf19c867df0d9ac0d8b24'
assert SOURCE.read_bytes() == new
assert TEST.read_bytes() == (HERE/'test_arbitrator_decode.cpp').read_bytes()
assert hashlib.sha256(TEST.read_bytes()).hexdigest() == '808f48820c97281559347e5f66e4690abc97949e658ff646e3865ece48925e2e'
comparison = HERE.parent/'round29-arbitrator-evidence/arbitrator-comparison-2pair.json'
result = json.loads(comparison.read_bytes())
assert result['completed_pairs'] == 2
rates = {m['metric']: m['improvement'] for m in result['aggregate']['metrics']}
assert rates['tokenize_ik_avg_ms'] < 0
receipt = dict(decision='REJECTED_RESTORED_EXACT', timestamp=datetime.now().astimezone().isoformat(),
    original_sha256=hashlib.sha256(old).hexdigest(), candidate_sha256=hashlib.sha256(new).hexdigest(),
    native_test_sha256=hashlib.sha256(TEST.read_bytes()).hexdigest(),
    comparison_sha256=hashlib.sha256(comparison.read_bytes()).hexdigest(),
    aggregate=result['aggregate'],
    reason='Target IK tokenize regresses and two-pair aggregate is only +0.146133%; unrelated query variation is not convincing causal benefit.',
    native='5304 actual-production cases PASS, exact complete output match',
    sql='casecopy/BMP/seven existing suites PASS; full receipt preserved',
    test_disposition='Focused TU retained exactly in auxiliary evidence, removed from established tests because optimization rejected',
    rebuild='SEPARATE PENDING', production_promotion='NONE')
assert not (HERE/'rejection-restoration.json').exists()
SOURCE.write_bytes(old)
assert SOURCE.read_bytes() == old
TEST.unlink()
with (HERE/'rejection-restoration.json').open('x') as f:
    json.dump(receipt, f, indent=2)
print('REJECTED; exact production source restored; unpromoted TU preserved only in evidence')
