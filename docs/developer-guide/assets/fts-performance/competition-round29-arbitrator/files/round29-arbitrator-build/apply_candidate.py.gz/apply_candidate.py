"""Apply the one verified arbitration hunk and preserve both exact sources."""
from pathlib import Path
import hashlib
import json
import re

HERE = Path(__file__).resolve().parent
ROOT = Path('D:/Projects/OceanBase/seekdb')
REL = 'src/storage/fts/ik/ob_ik_arbitrator.cpp'
PROPOSAL = HERE.parent / 'round29-arbitrator-decode-proposal'
old = (ROOT / REL).read_bytes()
patch = (PROPOSAL / 'arbitrator-decode.patch').read_bytes()
assert hashlib.sha256(old).hexdigest() == 'c59ea5dead8183a9728087dcea403e8418398a2040b2d50e560ac0e6e5897d17'
assert hashlib.sha256(patch).hexdigest() == '01e2c64503c25dd8b20958f8d1e7b14a6ea085b30974c094f5c0de668cb1c353'
lines = patch.splitlines(keepends=True)
assert lines[0] == b'--- a/' + REL.encode() + b'\n'
assert lines[1] == b'+++ b/' + REL.encode() + b'\n'
match = re.fullmatch(rb'@@ -(\d+),(\d+) \+(\d+),(\d+) @@\n', lines[2])
assert match is not None
start, old_count, new_start, new_count = map(int, match.groups())
assert start == new_start
removed, added = [], []
for line in lines[3:]:
    assert line[:1] in (b' ', b'-', b'+')
    if line[:1] in (b' ', b'-'): removed.append(line[1:])
    if line[:1] in (b' ', b'+'): added.append(line[1:])
assert len(removed) == old_count and len(added) == new_count
old_lines = old.splitlines(keepends=True)
assert old_lines[start-1:start-1+old_count] == removed
new = b''.join(old_lines[:start-1] + added + old_lines[start-1+old_count:])
assert hashlib.sha256(new).hexdigest() == 'cb9d730455159a2c2e0c1ddfc3b6d96a2631a047ce0cf19c867df0d9ac0d8b24'
assert not (HERE / 'application.json').exists()
(HERE / 'original.cpp').write_bytes(old)
(HERE / 'candidate.cpp').write_bytes(new)
(ROOT / REL).write_bytes(new)
assert (ROOT / REL).read_bytes() == new
with (HERE / 'application.json').open('x') as f:
    json.dump(dict(status='APPLIED', source=REL,
        original_sha256=hashlib.sha256(old).hexdigest(), candidate_sha256=hashlib.sha256(new).hexdigest(),
        patch_sha256=hashlib.sha256(patch).hexdigest(), scope='Exact one-hunk outer decode only'), f, indent=2)
print('APPLIED exact one-hunk arbitration decode candidate')
