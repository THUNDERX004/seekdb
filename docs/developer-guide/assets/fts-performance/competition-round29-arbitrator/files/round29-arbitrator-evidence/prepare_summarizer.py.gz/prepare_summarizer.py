"""Derive strict local comparison utility; no workloads or source edits."""
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent
BASE = HERE.parent / 'round28-ascii-evidence/summarize.py'
old = BASE.read_bytes()
text = old.decode('utf-8').replace('round28', 'round29').replace('r28-ascii-', 'r29-arbitrator-'
    ).replace('ASCII-span', 'IK arbitration decode').replace('ascii-comparison-', 'arbitrator-comparison-'
    ).replace('seekdb-fts-round29-', 'seekdb-fts-round29-'
    ).replace('f10e0fea8fa6d09b2e36388ee3f145fd0e9096a5c614eca0f91e9fa461ab17b0',
              'be1782650efcb51604b170ad8420f7070cb487751662d180292399ca243b4def'
    ).replace('c110239a7+round29-ascii', 'c110239a7+round29-arbitrator')
new = text.encode('utf-8')
with (HERE / 'summarize.py').open('xb') as f: f.write(new)
with (HERE / 'summarizer-provenance.json').open('x') as f:
    json.dump(dict(base=str(BASE), base_sha256=hashlib.sha256(old).hexdigest(),
        actual_sha256=hashlib.sha256(new).hexdigest(),
        scope='Only experiment labels/source/binary identity; strict metric/parameter/affinity/hit logic retained'), f, indent=2)
print('PREPARED strict unchanged-workload comparison')
