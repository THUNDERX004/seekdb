"""Archive exact round29 evidence and prepend its rejected-result reports."""
from pathlib import Path
import gzip
import hashlib
import json

HERE = Path(__file__).resolve().parent
FTS = HERE.parent
ROOT = Path('D:/Projects/OceanBase/seekdb')
DEST = ROOT/'docs/developer-guide/assets/fts-performance/competition-round29-arbitrator'
sha = lambda b: hashlib.sha256(b).hexdigest()
assert not DEST.exists()
assert sha((ROOT/'src/storage/fts/ik/ob_ik_arbitrator.cpp').read_bytes()) == 'c59ea5dead8183a9728087dcea403e8418398a2040b2d50e560ac0e6e5897d17'
assert not (ROOT/'unittest/storage/fts/test_arbitrator_decode.cpp').exists()
decision = json.loads((FTS/'round29-arbitrator-build/rejection-restoration.json').read_bytes())
assert decision['decision'] == 'REJECTED_RESTORED_EXACT'
comparison = json.loads((HERE/'arbitrator-comparison-2pair.json').read_bytes())
assert comparison['completed_pairs'] == 2
assert b'Linking CXX executable' in (FTS/'round29-arbitrator-rejection-restoration-build.log').read_bytes()
selected = set()
allowed = {'.py','.ps1','.json','.cpp','.md','.patch','.log','.rsp','.txt'}
def add(p):
    assert p.is_file() and p.is_relative_to(FTS) and p.suffix in allowed
    selected.add(p)
for name in ('round29-arbitrator-decode-proposal','round29-arbitrator-native',
             'round29-arbitrator-build','round29-arbitrator-evidence'):
    for p in (FTS/name).iterdir():
        if p.is_file() and p.suffix in allowed: add(p)
for name in ('control-build1','candidate-build1'):
    for filename in ('receipt.json','compile.log','link.log','compile.rsp','link-inputs.rsp'):
        add(FTS/'round29-arbitrator-build'/name/filename)
for name in ('control-run1','candidate-run1'):
    for filename in ('run.json','build-receipt.json','stdout.log','stderr.log','tuples.log'):
        add(FTS/'round29-arbitrator-build'/name/filename)
for label in ('r29-arbitrator-control-a1','r29-arbitrator-candidate-a1',
              'r29-arbitrator-control-a2','r29-arbitrator-candidate-a2',
              'r29-arbitrator-candidate-regression-a1'):
    matches=list(FTS.glob(label+'-*'))
    assert matches
    for p in matches:
        if p.is_file(): add(p)
for name in ('round29-arbitrator-candidate-build.log','round29-arbitrator-rejection-restoration-build.log',
             'round16-row-native/prepare_fts_lazy_rows.py','round19-evidence/summarize-template.py',
             'round27-root-evidence/experiment-with-exit.py'):
    add(FTS/name)
a=comparison['aggregate']
table='| Metric | Control mean | Rejected mean | Time reduction |\n| --- | ---: | ---: | ---: |\n'
for m in a['metrics']:
    table+='| {} | {:.6f} | {:.6f} | {:+.6f}% |\n'.format(m['metric'],m['control'],m['candidate'],100*m['improvement'])
rates={k:100*v for k,v in a['category_improvements'].items()}
rates['overall']=100*a['overall_improvement']
rates['ik']=100*next(m['improvement'] for m in a['metrics'] if m['metric']=='tokenize_ik_avg_ms')
en="""## Round 29 IK output decode — REJECTED and restored (2026-11-05)

**REJECTED; no production or unit-test promotion.** Two complete immediate local pairs against accepted C7 show build {build:+.6f}%, tokenize {tokenize:+.6f}%, query {query:+.6f}%, equal-category overall {overall:+.6f}% time reduction. Target IK tokenize time reduction is {ik:+.6f}%. Small overall variation and unrelated query gains do not establish useful causal benefit. This is not a cumulative result, formal score, full score or statistical significance claim.

The one-hunk proposal attempts positive UTF8 decode/classification at later outer arbitration offsets, preserving offset-zero charset initialization, nonpositive-decode fallback and the inner gap loop. Exact original CPP restoration and its rebuild/link passed. The native TU remains archive-only.

{table}

Actual production-linked original and candidate both PASS 5,304 cases with byte-identical complete stdout (SHA256 7134ac2b0fa16f8ca2fb0594df0a30625aa17debcc443c5d9c0b83b51e17c64b), empty stderr and 19,662 T records. Identical TU SHA256: 808f48820c97281559347e5f66e4690abc97949e658ff646e3865ece48925e2e. Public APIs, independent generic no-chain expectations, whole-token assertions and complete differential chain/gap records cover three retained collations and both modes. This finite Windows matrix does not prove Linux, sanitizer, all allocation failures or all public states.

Candidate SQL PASS: case-copy 16,359 (including 924 SQL errors), BMP 2,488 and all seven existing suites. All four timing runs retain fresh directories, WARN, verified affinity 15, parameters 20000/500/3000/200/3/30/SKIP_LOAD=0 and hits 8001/11000/7332/20. Negative values and both pairs are retained without sample removal or timing correction. Hit counts do not replace semantic checks.

Control source label f56ddd03e66826919d8d9192bc4c0afece8843dd, binary c7fcc8676875246a38bc4135f29e6f52b85a9d29a9563679003d5b6140666b01; candidate label c110239a7+round29-arbitrator, binary be1782650efcb51604b170ad8420f7070cb487751662d180292399ca243b4def. Actual source snapshots and compile/link receipts govern identity; raw report checkout labels are not binary-source attestation.

The [exact-byte archive](../assets/fts-performance/competition-round29-arbitrator/manifest.json) preserves proposal, native TU/helpers/full streams, SQL logs, all timings, immutable summaries and restoration records. Historical restoration JSON still says rebuild pending; the later successful build log is separate. Binary products, runtime/data, secrets, earlier measurements and other candidates are excluded. Official evaluation files remain unchanged.

""".format(**rates,table=table)
zh="""## 第 29 轮 IK 输出解码：拒绝并恢复（2026-11-05）

**拒绝；没有晋升生产修改或单元测试。** 两组紧邻完整本地对照：构建耗时下降 {build:+.6f}%，分词 {tokenize:+.6f}%，查询 {query:+.6f}%，三类等权综合 {overall:+.6f}%。目标 IK 分词耗时下降 {ik:+.6f}%。综合微小变化与无关查询波动不足以证明有效收益；这不是累计提升、正式成绩、满分或统计显著性结论。

候选只在仲裁外层后续字符尝试 UTF8 解码和分类，保留首字符初始化、非正解码结果的原始回退及内层补字逻辑。生产 CPP 已精确恢复，重编译及链接通过；native TU 仅归档。

{table}

真实生产代码链接的对照和候选均通过 5,304 项 native 用例；完整 stdout 字节相同，SHA256 为 7134ac2b0fa16f8ca2fb0594df0a30625aa17debcc443c5d9c0b83b51e17c64b，stderr 为空，包含 19,662 条 T 记录。相同 TU 的 SHA256 为 808f48820c97281559347e5f66e4690abc97949e658ff646e3865ece48925e2e。公开 API 测试包含无链单字的独立通用预期、整词断言和完整链/间隙差分记录，覆盖三个保留字符集及两种模式。有限 Windows 矩阵不证明 Linux、sanitizer、全部分配失败或全部公开状态行为。

候选 SQL 通过 case-copy 16,359 项（含 924 个 SQL 错误）、BMP 2,488 项及七组既有回归。四次计时各用新目录、WARN、核实亲和掩码 15、参数 20000/500/3000/200/3/30/SKIP_LOAD=0；命中数保持 8001/11000/7332/20。保留两组全部负值，不删样本、不修正计时；命中数不替代语义验证。

控制源标签 f56ddd03e66826919d8d9192bc4c0afece8843dd / 二进制 c7fcc8676875246a38bc4135f29e6f52b85a9d29a9563679003d5b6140666b01；候选标签 c110239a7+round29-arbitrator / 二进制 be1782650efcb51604b170ad8420f7070cb487751662d180292399ca243b4def。真实源码快照、编译链接凭证用于核对身份；原始报告 checkout 标签不证明二进制源码版本。

[精确字节归档](../assets/fts-performance/competition-round29-arbitrator/manifest.json) 保留提案、native TU/工具/完整输出、SQL 日志、四次计时、不可变汇总和恢复记录。历史恢复 JSON 仍写重编译待运行，后续成功日志单独保留。未打包二进制、运行数据、凭据、早期测量或其他候选；官方评测文件保持不变。

""".format(**rates,table=table)
for name,text in [('report.en.md',en),('report.zh-CN.md',zh)]:
    p=HERE/name
    with p.open('x',encoding='utf-8',newline='\n') as f: f.write(text)
    add(p)
DEST.mkdir()
files=[]
for p in sorted(selected,key=lambda p:p.as_posix()):
    rel=p.relative_to(FTS).as_posix()
    raw=p.read_bytes()
    packed=gzip.compress(raw,mtime=0)
    out=DEST/'files'/(rel+'.gz')
    out.parent.mkdir(parents=True,exist_ok=True)
    with out.open('xb') as f: f.write(packed)
    files.append(dict(source=rel,path='files/'+rel+'.gz',raw_bytes=len(raw),raw_sha256=sha(raw),
        packed_bytes=len(packed),packed_sha256=sha(packed)))
manifest=dict(experiment='round29-arbitrator-decode-rejected',decision=decision['decision'],completed_pairs=2,files=files)
raw=(json.dumps(manifest,indent=2)+'\n').encode()
(DEST/'manifest.json').write_bytes(raw)
(DEST/'COMPLETE.json').write_text(json.dumps(dict(status='COMPLETE',file_count=len(files),manifest_sha256=sha(raw)),indent=2)+'\n',encoding='utf-8')
documents=[]
for language,text in [('en',en),('zh-CN',zh)]:
    p=ROOT/'docs/developer-guide'/language/'fts-performance.md'
    old=p.read_bytes()
    prefix,rest=old.split(b'\n\n',1)
    new=prefix+b'\n\n'+text.encode()+rest
    p.write_bytes(new)
    documents.append(dict(path=p.relative_to(ROOT).as_posix(),preimage_sha256=sha(old),postimage_sha256=sha(new)))
with (HERE/'publication.json').open('x') as f:
    json.dump(dict(status='PUBLISHED',file_count=len(files),manifest_sha256=sha(raw),documents=documents),f,indent=2)
print(json.dumps(dict(status='PUBLISHED',file_count=len(files),manifest_sha256=sha(raw))))
