# Round 29: arbitrator outer-character decode proposal

Source-only proposal, frozen 2026-11-04T16:11:42+00:00. This directory contains one unified patch, this report, and `source-pins.json`. The patch affects only `src/storage/fts/ik/ob_ik_arbitrator.cpp`: one hunk, +19/-2 lines. It has not been applied, compiled, linked, or executed. Performance is unmeasured. No Git, worktree, SQL, service, build, benchmark, or native test operation was performed.

## Proposed behavior

At the outer scan in `src/storage/fts/ik/ob_ik_arbitrator.cpp:110`, retain the original `first_valid_char` then `classify_first_char` pair at byte offset zero. At a later offset, attempt `ob_charset_decode_unicode<CHARSET_UTF8MB4>` only for `CS_TYPE_UTF8MB4_GENERAL_CI`, `CS_TYPE_UTF8MB4_BIN`, or `CS_TYPE_UTF8MB4_UNICODE_CI`. Only a positive decode length commits `char_len` and the result of the existing public `classify_unicode<CHARSET_UTF8MB4>`. Every zero or negative decode result executes the original pair in its original order.

The implementation is an inline block with one per-iteration boolean and temporary decode values. A local lambda would move the existing fallback into another scope; a shared context API would require exposing or refactoring private cursor-specific code. Neither is needed for this single pair. Existing includes already expose both templates through `ob_ik_processor.h` and `ob_ik_char_util.h`; no header/API, allocation, persistent state, array, cache, or additional scan is introduced.

## Placement, initialization, errors, and lifetimes

`src/storage/fts/ob_ik_ft_parser.cpp:257` creates the context from the parser parameter's document pointer and byte length, then calls `ctx_->init()`. `src/storage/fts/ik/ob_ik_processor.cpp:61` first prepares a character using the original path, and enables its accepted UTF8 path only after success. `src/storage/fts/ik/ob_ik_processor.cpp:109` is the model for the positive-length decode rule; its current-character fields are unsuitable here because arbitration starts its independent `current` at zero.

`src/storage/fts/ob_ik_ft_parser.cpp:161` resets lists, processes characters, and calls arbitration/output only after successful processing or `OB_ITER_END`. The context cursor can already be at a later batch or document end. The proposal therefore uses the existing outer scan offset and full document length, not the cursor or batch end. It preserves the existing rescan behavior and token order.

`output_result` is also public. Its own offset-zero pair remains generic even without a prior `ctx.init()`: `src/oblib/lib/charset/ob_charset.cpp:1728` validates the collation, obtains/initializes the charset, checks the pointer/length, and validates the character before classification. `src/oblib/lib/charset/ob_charset.cpp:2062` performs lazy initialization. Reaching a later outer iteration requires that this first pair succeeded, so the shortcut cannot bypass the first charset initialization, its failure, or its logging. Empty/nonpositive document lengths still skip the loop. No new validation or reinterpretation of the existing invalid-input contract is added.

On a speculative failure, the temporary length and Unicode value do not change `ret`, `char_len`, or `type`; the original pair sets them exactly as before. The successful path assigns the same length/type while the loop's existing success status remains unchanged. Hash lookup, allocator/list failures, ignore-single-CJK calls, and all output mutations remain in their existing order. No new pointer is stored or escapes: tokens continue to borrow the original document pointer, and the decode end is exactly `ctx.fulltext() + ctx.fulltext_len()`.

## Decode equivalence and required fallback

The three allowed collations map to `CHARSET_UTF8MB4` in `src/oblib/lib/charset/ob_charset.cpp:1355` and have backing charset records in `src/oblib/lib/charset/ob_charset.cpp:2087`. Their records in `ob_ctype_utf8.cc` and `ob_ctype_uca.cc` use the same `ob_charset_utf8mb4_handler`, whose validator is `src/oblib/lib/charset/ob_ctype_utf8.cc:58`. The guard deliberately does not infer support from a charset name or broaden to UTF8MB3, binary, UTF16, or unretained enum values.

`src/oblib/lib/charset/ob_charset_string_helper.h:92` calls the range-checked, MB4-capable template in `src/oblib/lib/charset/mb_wc.h:102`. For each positive result: ASCII (including NUL) has length one; a two-byte result requires C2..DF plus a continuation; a three-byte result requires two continuations, no overlong result, and no surrogate; a four-byte result requires valid continuations and U+10000..U+10FFFF. Each is accepted with the same byte length by the original one-character validator. The original classification then uses this same template in `src/storage/fts/ik/ob_ik_char_util.h:177` and the same Unicode classification function via `src/storage/fts/ik/ob_ik_char_util.h:469` and `src/storage/fts/ik/ob_ik_char_util.h:448`. No ctype-table substitution, normalization, case conversion, or new classification policy is involved.

The distinction between positive and nonpositive is essential. `OB_CS_ILSEQ` is zero (`ob_ctype.h:56`). The validator can accept three-byte surrogate encodings such as ED A0 80, while the decode template writes the surrogate code point and returns zero; the existing character utility regards only negative decode sizes as errors. The proposal does not reinterpret that behavior: at offset zero it stays wholly generic, and at later offsets a zero result falls through to the exact generic pair. Invalid leads/continuations, overlong sequences, out-of-range four-byte sequences, and truncated tails likewise retain the original validator/classifier error and output behavior.

## Deliberately preserved inner loop

The gap-filling loop at `src/storage/fts/ik/ob_ik_arbitrator.cpp:168` still calls only `first_valid_char` and reuses the outer `type`. It is not reclassified. Its existing ignored `push_back` return values and all other control flow are unchanged. Byte comparison confirms that everything from the outer `USELESS` branch through end-of-file is identical. This proposal does not attempt to repair those existing semantics.

## Static evidence and remaining validation

Read the selected checkout's `AGENTS.md` and `.agents/skills/code-review/SKILL.md`, and traced the affected caller, charset initialization/mapping/handler, decoder, classifier, and borrowed document/token lifetime. No concrete Major or Blocker behavior difference was established by this source review. This is source evidence, not native correctness or performance evidence.

A standalone in-memory unified-hunk reader reconstructed the complete candidate byte-for-byte and reversed it to the exact preimage. It checked hunk line counts and exact CRLF context bytes. The source before the edited top pair and all bytes after it are unchanged. All pinned checkout files were reread and matched their initial hashes before freezing. No candidate source file was written outside the patch artifact. Patch headers/hunk markers use LF, and source context/removal/addition lines preserve the checkout's CRLF bytes; apply without normalizing away those source-line carriage returns when requiring the pinned candidate hash.

Focused parent validation, after its serial work permits application: link the same public-API native fixture against actual original/candidate code; compare return codes, ordered tokens, bytes/lengths/offsets/character counts/types, partial outputs, and unchanged end/error sentinels. Include all three retained collations; first-only and later ASCII/NUL/BMP/supplementary characters; exact end boundaries; surrogate fallback; invalid and truncated encodings at zero and after valid text; binary/unretained/invalid collations; separate contexts; both arbitration modes; chain/no-chain and gaps which expose the existing outer-type reuse; repeated output/batch calls; and existing output-allocation error propagation where the fixture supports it. Exercise output directly without context initialization for first-character behavior. Preserve exact readable document bounds in each fixture. Actual compiler/link and SQL regression results remain for the parent. No speedup, workload benefit, or score is asserted here.

Preimage SHA-256: `c59ea5dead8183a9728087dcea403e8418398a2040b2d50e560ac0e6e5897d17`  
In-memory candidate SHA-256 (CRLF): `cb9d730455159a2c2e0c1ddfc3b6d96a2631a047ce0cf19c867df0d9ac0d8b24`  
Patch SHA-256: `01e2c64503c25dd8b20958f8d1e7b14a6ea085b30974c094f5c0de668cb1c353`
