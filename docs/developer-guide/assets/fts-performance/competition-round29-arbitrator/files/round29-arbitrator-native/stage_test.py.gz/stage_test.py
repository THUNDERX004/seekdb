"""Place the exact focused native regression in the selected source checkout."""
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent
ROOT = Path('D:/Projects/OceanBase/seekdb')
source = HERE / 'test_arbitrator_decode.cpp'
target = ROOT / 'unittest/storage/fts/test_arbitrator_decode.cpp'
raw = source.read_bytes()
assert not target.exists()
with target.open('xb') as f:
    f.write(raw)
assert target.read_bytes() == raw
with (HERE / 'staging.json').open('x') as f:
    json.dump(dict(source=str(source), target=str(target), sha256=hashlib.sha256(raw).hexdigest(),
        expected_cases=5304, intent='Focused public production arbitration regression; not yet executed'), f, indent=2)
print('STAGED exact focused native TU in selected checkout')
