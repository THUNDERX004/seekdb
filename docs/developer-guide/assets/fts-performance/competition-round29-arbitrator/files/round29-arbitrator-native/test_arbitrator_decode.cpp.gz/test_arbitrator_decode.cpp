/* Copyright (c) 2026. Licensed under the Apache License, Version 2.0. */
// Link this identical TU to each actual production variant.
#include <cstdio>
#include <cstring>
#include <optional>
#include <stdexcept>
#include <string>
#include <vector>
#include "lib/allocator/page_arena.h"
#include "lib/charset/ob_charset.h"
#include "lib/oblog/ob_log.h"
#include "lib/rc/context.h"
#include "storage/fts/ik/ob_ik_arbitrator.h"
#include "storage/fts/ik/ob_ik_processor.h"

using namespace oceanbase;
using namespace oceanbase::common;
using namespace oceanbase::storage;

namespace {
int cases = 0;
constexpr int kExpectedCases = 5304;
void need(bool ok, const char *what) { if (!ok) throw std::runtime_error(what); }
std::string utf8(uint32_t cp)
{
  need(cp <= 0x10ffff && !(cp >= 0xd800 && cp <= 0xdfff), "invalid scalar");
  std::string s;
  if (cp < 0x80) s += char(cp);
  else if (cp < 0x800) { s += char(0xc0 | (cp >> 6)); s += char(0x80 | (cp & 63)); }
  else if (cp < 0x10000) {
    s += char(0xe0 | (cp >> 12)); s += char(0x80 | ((cp >> 6) & 63)); s += char(0x80 | (cp & 63));
  } else {
    s += char(0xf0 | (cp >> 18)); s += char(0x80 | ((cp >> 12) & 63));
    s += char(0x80 | ((cp >> 6) & 63)); s += char(0x80 | (cp & 63));
  }
  return s;
}
void hex(const char *p, int64_t length)
{
  for (int64_t i = 0; i < length; ++i) std::printf("%02x", static_cast<unsigned char>(p[i]));
}
class ContextScope final {
public:
  ContextScope()
  {
    lib::ContextParam p;
    p.set_mem_attr("R29Arb", ObCtxIds::DEFAULT_CTX_ID).set_properties(lib::USE_TL_PAGE_OPTIONAL);
    need(CURRENT_CONTEXT->CREATE_CONTEXT(context_, p) == OB_SUCCESS && context_ != nullptr,
         "CREATE_CONTEXT");
    flow_.emplace(context_);
    if (flow_->init() != OB_SUCCESS) {
      flow_.reset(); DESTROY_CONTEXT(context_); context_ = nullptr; need(false, "Flow::init");
    }
  }
  ~ContextScope()
  {
    if (flow_) { flow_->deinit(); flow_.reset(); }
    if (context_ != nullptr) DESTROY_CONTEXT(context_);
  }
private:
  lib::MemoryContext context_ = nullptr;
  std::optional<lib::Flow> flow_;
};
struct Result {
  int ret;
  std::vector<ObIKToken> tokens;
};
// Independent generic reference for the no-chain single-character contract.
Result generic_singles(ObCollationType collation, const std::string &doc)
{
  Result result{OB_SUCCESS, {}};
  for (int64_t offset = 0; result.ret == OB_SUCCESS && offset < int64_t(doc.size());) {
    int64_t length = 0;
    ObFTCharUtil::CharType type = ObFTCharUtil::CharType::USELESS;
    result.ret = ObCharset::first_valid_char(collation, doc.data() + offset, doc.size() - offset, length);
    if (result.ret == OB_SUCCESS)
      result.ret = ObFTCharUtil::classify_first_char(collation, doc.data() + offset, length, type);
    bool emit = type == ObFTCharUtil::CharType::CHINESE;
    if (result.ret == OB_SUCCESS && type == ObFTCharUtil::CharType::OTHER_CJK) {
      bool ignored = false;
      result.ret = ObFTCharUtil::is_ignore_single_cjk(collation, doc.data() + offset, length, ignored);
      emit = !ignored;
    }
    if (result.ret == OB_SUCCESS) {
      need(length > 0 && length <= int64_t(doc.size()) - offset, "generic progress");
      if (emit) result.tokens.push_back(ObIKToken{doc.data(), offset, length, 1,
          type == ObFTCharUtil::CharType::CHINESE ? ObIKTokenType::IK_CHINESE_TOKEN
                                               : ObIKTokenType::IK_OTHER_CJK_TOKEN});
      offset += length;
    }
  }
  return result;
}
void run(ObCollationType collation, const std::string &doc, bool smart, int shape)
{
  ++cases;
  std::printf("CASE\t%d\tcoll=%d\tsmart=%d\tshape=%d\tdoc=", cases, int(collation), int(smart), shape);
  hex(doc.data(), doc.size()); std::printf("\n");
  ObArenaAllocator allocator(ObMemAttr("R29Case"));
  TokenizeContext ctx(collation, allocator, doc.data(), doc.size(), smart);
  const int init = ctx.init();
  std::printf("T\t%d\tinit\t%d\n", cases, init);
  if (init != OB_SUCCESS) {
    int64_t length = 0;
    need(doc.empty() || ObCharset::first_valid_char(collation, doc.data(), doc.size(), length) != OB_SUCCESS,
         "unexpected context initialization failure");
    return;
  }
  if (shape == 1) {
    need(ctx.add_token(doc.data(), 0, doc.size(), 1, ObIKTokenType::IK_MIX_TOKEN) == OB_SUCCESS,
         "whole token add");
  } else if (shape == 2) {
    need(doc.size() >= 9, "chain fixture size");
    need(ctx.add_token(doc.data(), 0, 3, 1, ObIKTokenType::IK_CHINESE_TOKEN) == OB_SUCCESS, "first token");
    need(ctx.add_token(doc.data(), doc.size() - 3, 3, 1, ObIKTokenType::IK_CHINESE_TOKEN) == OB_SUCCESS,
         "last token");
  }
  ObIKArbitrator arbitrator;
  const int process = arbitrator.process(ctx);
  need(process == OB_SUCCESS, "process failed");
  const int output = arbitrator.output_result(ctx);
  std::printf("T\t%d\tprocess\t%d\toutput\t%d\tcount=%lld\n", cases, process, output,
      static_cast<long long>(ctx.result_list().size()));
  Result expected = shape == 0 ? generic_singles(collation, doc) : Result{output, {}};
  if (shape == 0) need(output == expected.ret, "single output return differs from generic");
  size_t number = 0;
  for (auto it = ctx.result_list().begin(); it != ctx.result_list().end(); ++it, ++number) {
    const auto &token = *it;
    need(token.ptr_ == doc.data() && token.offset_ >= 0 && token.length_ >= 0
        && token.offset_ <= int64_t(doc.size()) && token.length_ <= int64_t(doc.size()) - token.offset_,
         "invalid output slice");
    std::printf("T\t%d\ttoken\t%zu\toffset=%lld\tlength=%lld\tchars=%lld\ttype=%d\tbytes=",
        cases, number, static_cast<long long>(token.offset_), static_cast<long long>(token.length_),
        static_cast<long long>(token.char_cnt_), int(token.type_));
    hex(token.ptr_ + token.offset_, token.length_); std::printf("\n");
    if (shape == 0) {
      need(number < expected.tokens.size(), "unexpected single token");
      const auto &e = expected.tokens[number];
      need(token.offset_ == e.offset_ && token.length_ == e.length_
          && token.char_cnt_ == e.char_cnt_ && token.type_ == e.type_, "generic single token mismatch");
    }
  }
  if (shape == 0) need(number == expected.tokens.size(), "missing single token");
  if (shape == 1) {
    need(output == OB_SUCCESS && number == 1, "whole token result");
    const auto &t = ctx.result_list().get_first();
    need(t.offset_ == 0 && t.length_ == int64_t(doc.size()) && t.type_ == ObIKTokenType::IK_MIX_TOKEN,
         "whole token changed");
  }
}
} // namespace

int main()
{
  try {
    OB_LOGGER.set_log_level("ERROR");
    ContextScope scope;
    std::vector<uint32_t> points;
    for (uint32_t cp = 0; cp < 256; ++cp) points.push_back(cp);
    for (uint32_t cp : {0x3000U,0x3001U,0x3002U,0x3005U,0x303fU,0x3040U,0x3041U,0x309fU,
        0x30a0U,0x30a1U,0x30ffU,0x3100U,0x31bfU,0x31f0U,0x31ffU,0x3400U,0x4dbfU,0x4e00U,
        0x4e2dU,0x9fffU,0xac00U,0xd7afU,0xe000U,0xf900U,0xfaffU,0xfeffU,0xff00U,0xff61U,
        0xff9fU,0xffa0U,0xffdcU,0x10000U,0x1f600U,0x20000U,0x10ffffU}) points.push_back(cp);
    need(points.size() == 291, "codepoint corpus count");
    for (auto collation : {CS_TYPE_UTF8MB4_GENERAL_CI, CS_TYPE_UTF8MB4_BIN, CS_TYPE_UTF8MB4_UNICODE_CI}) {
      need(ObCharset::get_charset(collation) != nullptr, "charset unavailable");
      for (bool smart : {false, true}) {
        for (auto cp : points) {
          const std::string doc = utf8(0x4e2d) + utf8(cp) + std::string(" A\0 B", 5) + utf8(0x6587);
          for (int shape = 0; shape < 3; ++shape) run(collation, doc, smart, shape);
        }
        run(collation, "", smart, 0);
        run(collation, " \t\r\n", smart, 0);
        run(collation, utf8(0x65e5) + utf8(0x672c) + utf8(0x8a9e), smart, 0);
        for (const auto &suffix : {std::string("\x80",1), std::string("\xc0\xaf",2),
            std::string("\xc2",1), std::string("\xe2\x82",2), std::string("\xed\xa0\x80",3),
            std::string("\xf0\x90\x80",3), std::string("\xf4\x90\x80\x80",4), std::string("\xff",1)})
          run(collation, utf8(0x4e2d) + suffix, smart, 0);
      }
    }
    need(cases == kExpectedCases, "incomplete fixed corpus");
    std::printf("PASS\tcases=%d\n", cases);
    return std::fflush(stdout) == 0 && !std::ferror(stdout) ? 0 : 1;
  } catch (const std::exception &e) {
    std::fprintf(stderr, "FAIL\tcase=%d\t%s\n", cases, e.what()); return 1;
  }
}
