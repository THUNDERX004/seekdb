"""Prepare native link helpers without modifying production or executing tools."""
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent
FTS = HERE.parent
OUT = FTS / 'round29-arbitrator-build'
OUT.mkdir(exist_ok=False)
changes = {}
for source_name, dest_name in [
    ('round27-dat-root-build/build_native.py', 'build_native.py'),
    ('round27-dat-root-build/build.ps1', 'build.ps1'),
    ('round28-token-stream-build/run_native.py', 'run_native.py')]:
    old = (FTS / source_name).read_bytes()
    text = old.decode('utf-8').replace('src/storage/fts/dict/ob_ft_dat_dict.cpp',
        'src/storage/fts/ik/ob_ik_arbitrator.cpp').replace('src/storage/fts/dict/ob_ft_dat_dict.h',
        'src/storage/fts/ik/ob_ik_arbitrator.h').replace('test_dat_root', 'test_arbitrator_decode'
        ).replace('test_whitespace_spans', 'test_arbitrator_decode').replace('16416', '5304'
        ).replace('DAT reader', 'IK arbitrator').replace('$datVs', '$arbVs')
    new = text.encode('utf-8')
    (OUT / dest_name).write_bytes(new)
    changes[dest_name] = dict(base=source_name, base_sha256=hashlib.sha256(old).hexdigest(),
        actual_sha256=hashlib.sha256(new).hexdigest())
test = (HERE / 'test_arbitrator_decode.cpp').read_bytes()
(OUT / 'test_arbitrator_decode.cpp').write_bytes(test)
with (OUT / 'preparation.json').open('x') as f:
    json.dump(dict(test_sha256=hashlib.sha256(test).hexdigest(), expected_cases=5304,
        helpers=changes, execution='Prepared only; no build/native/runtime/SQL'), f, indent=2)
print('PREPARED same-TU production-linked arbitrator helpers')
