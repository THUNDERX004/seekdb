# Focused additions to the parent's existing count/fallback gate

Not executed. Keep all scored SQL/input/timing untouched. Use an isolated small table with an FTS index and ordinary stored `id`, nullable `v`, text `body`; compare complete results and errors, including retained failures. Do not derive tied-row expectations from IDs without proving the fixture's actual tie membership.

| Case family | Bounded checks |
|---|---|
| Actual target | Exact scored COUNT-over-LIMIT SQL and renamed-table equivalent. EXPLAIN must show guard reachability: no synthesized MATCH DESC/top-K, unchanged ordinary LIMIT/OFFSET, relevance still true. Check index-back independently with/without R32. |
| Cardinality/batches | 0/1/19/20/21/257 hits; LIMIT 0/1/20; OFFSET 0/1/20/beyond end. Check the final partial batch and exhausted offset. Preserve full result even when underlying chosen IDs differ. |
| Prepared arguments | Plain search/limit/offset question marks; repeated prepared executions changing each argument. Compare NULL, zero, invalid/negative/out-of-range bindings and errors as supported. Assert no hidden calculable/dynamic-evaluation parameter enters the exception. |
| Pure MATCH variants | Empty/no-hit, overlapping/duplicate words, and bounded natural queries near the 256-token DaaT/TAAT boundary. Ordinary full predicates remain scored. |
| Observable ordering/ties | Explicit MATCH DESC and explicit ID order must remain. WITH TIES tied-score fixtures, FETCH/PERCENT, existing pagination-synthesized order and window/QUALIFY inputs fall back. Verify rank output as well as COUNT for explicit-order queries. |
| Effects/errors | Additional WHERE condition, scalar/volatile/UDF search text, user variables, UDF/error/scalar-subquery projection, generated columns, SQL_CALC_FOUND_ROWS, locking/SKIP LOCKED and sampling/snapshot forms fall back. Preserve accepted side effects/errors. |
| Parent identity | COUNT(v), COUNT(DISTINCT v), outer WHERE/HAVING/join, nested/correlated scalar COUNT, CTE/lateral/subquery forms fall back. A COUNT(*) in another query block is insufficient. |
| Modes and hints | Boolean/ES/expansion/boosted MATCH; NO_REWRITE/global disable hint; array binding; old and new outlines. Other modes retain order/scoring behavior. Original no-order query projection does not justify deleting any explicit order. |

If the exact target falls back due to parameter representation, query-context calculable items, or prior pagination preservation, retain that result and stop; do not silently broaden this frozen guard. A missing syntax variant should be reported as unsupported, not rewritten into a different test. Full scored timing, further score elision and profiler work are outside this artifact.
