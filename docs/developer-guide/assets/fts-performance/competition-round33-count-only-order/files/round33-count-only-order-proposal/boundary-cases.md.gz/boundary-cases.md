# R33 additional prepared-boundary cases

Source-only list; no SQL executed. Keep the frozen patch, existing report, fixture and benchmark unchanged. Reuse the parent's isolated small FTS fixture with stored `id`, text `body`, at least 21 hits for one ordinary natural-language search, and a no-hit search. Adapt only the fixture identifier and its known hit term.

Prepare this statement once through the existing test harness (ordinary scalar parameter binding, not array binding):

```sql
SELECT COUNT(*)
FROM (
  SELECT id
  FROM <existing_isolated_fixture>
  WHERE MATCH(body) AGAINST (?)
  LIMIT ? OFFSET ?
) t
```

`hit` below means the same valid search string each time. Bind numeric values as signed integers and NULL as SQL NULL. Execute the following 16 tuples in order on each actual original/control/candidate. Keep the same prepared handle after any error; do not reprepare to hide reuse failures.

| Execution | Search | LIMIT | OFFSET | Check |
|---|---|---|---|---|
| 1 | hit | 20 | 0 | Baseline, count 20 on the specified fixture |
| 2 | hit | 0 | 0 | Successful count 0 |
| 3 | hit | 0 | 1 | Successful count 0 |
| 4 | hit | 0 | 20 | Successful count 0 |
| 5 | NULL | 20 | 0 | Compare original result/error |
| 6 | NULL | 0 | 0 | Compare original result/error and zero-limit evaluation boundary |
| 7 | empty string | 0 | 0 | Compare original result/error |
| 8 | hit | NULL | 0 | Compare original result/error |
| 9 | hit | 20 | NULL | Compare original result/error |
| 10 | hit | -1 | 0 | Compare original error/result |
| 11 | hit | 20 | -1 | Compare original error/result |
| 12 | hit | 0 | -1 | Compare original validation order at zero limit |
| 13 | hit | NULL | NULL | Compare original result/error |
| 14 | NULL | NULL | 0 | Compare original validation/evaluation order |
| 15 | hit | 1 | 0 | Successful count 1 after invalid/NULL executions |
| 16 | hit | 20 | 0 | Baseline count 20 again on the same handle |

For every execution retain the complete result (including metadata), server error number, SQLSTATE, message and warnings; an error must not terminate the remaining sequence. NULL and negative parameter behavior is intentionally taken from the real original rather than a guessed SQL oracle. If the original rejects preparation or a binding form, retain that failure and compare it directly. An unsupported form must not be replaced with different syntax and reported as covered.

For executions 1 and 2, also compare the equivalent literal query on the same fixture and inspect the candidate EXPLAIN separately: did the guard fire, was only implicit MATCH DESC/top-K removed, and did LIMIT plus relevance remain? Prepared execution may fail closed because of AST parameterization or query-context calculable items. Record that as non-reachability; do not widen the frozen guard.

The existing `is_happened` handling is unchanged. Before the new skip point, each successful producer already ORs its value into `trans_happened`; repeating that OR on a skipped call cannot add a previously unrecorded change. No reset or unrelated cleanup is included.
