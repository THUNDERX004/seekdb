"""C-only R33 archive preparation; freezing requires a later parent release."""
from pathlib import Path, PurePosixPath
import argparse
import gzip
import hashlib
import json

HERE = Path(__file__).resolve().parent
FTS = HERE.parent
PACKAGE = HERE / 'package'
DIRECTORIES = ('round33-count-only-order-proposal', 'round33-count-only-order-build',
               'round33-count-only-order-review')
EXACT = ('round33-count-only-order-candidate-build.log',
         'round33-bounded-count-only-order-build.log',
         'round19-evidence/summarize-template.py')
DENIED_SUFFIXES = {'.exe', '.pdb', '.dll', '.obj', '.lib', '.ilk', '.exp', '.pyc', '.tmp', '.dmp'}
DENIED_PARTS = {'.git', '.secrets', 'secrets', 'runtime', 'data', 'temp', 'tmp', '__pycache__'}
MAX_FILE = 16 * 1024 * 1024
MAX_TOTAL = 64 * 1024 * 1024


def need(ok, message):
    if not ok:
        raise RuntimeError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def load(path):
    return json.loads(path.read_bytes())


def save(path, value):
    with path.open('xb') as stream:
        stream.write((json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n').encode('utf-8'))


def relative_path(value):
    rel = PurePosixPath(value)
    need(not rel.is_absolute() and '..' not in rel.parts and ':' not in value and '\\' not in value,
         'Expected safe FTS-relative path: ' + value)
    need(rel.parts and (rel.parts[0].startswith('round33-') or rel.parts[0].startswith('r33-')
                        or value in EXACT), 'Outside R33 selection scope: ' + value)
    path = FTS / str(rel)
    need(path.resolve().is_relative_to(FTS) and not path.is_symlink(), 'Input escapes FTS')
    return path


def omission_reason(path):
    parts = [part.lower() for part in path.relative_to(FTS).parts]
    if any(part in DENIED_PARTS or part.startswith(('r34-', 'round34-')) for part in parts):
        return 'runtime/data/secrets/temp/R34 excluded'
    if path.suffix.lower() in DENIED_SUFFIXES:
        return 'binary/build intermediate excluded'
    if path.name.lower() in {'connection.json', '.env', 'credentials.json'}:
        return 'credentials excluded'
    return None


def discover(extra_sources=()):
    """Inventory names/stat sizes only. No raw reads, hashes, writes or pins."""
    paths = {relative_path(name) for name in EXACT}
    for name in DIRECTORIES:
        root = FTS / name
        need(root.is_dir() and not root.is_symlink(), 'Missing/unsafe evidence directory: ' + name)
        paths.update(path for path in root.rglob('*') if path.is_file())
    paths.update(path for path in FTS.iterdir() if path.is_file() and path.name.startswith('r33-'))
    paths.update(relative_path(name) for name in extra_sources)
    included, omitted = [], []
    for path in sorted(paths, key=lambda p: p.relative_to(FTS).as_posix()):
        rel = path.relative_to(FTS).as_posix()
        need(not path.is_symlink() and path.resolve().is_relative_to(FTS), 'Unsafe input: ' + rel)
        reason = omission_reason(path)
        if reason:
            omitted.append(dict(source=rel, reason=reason))
            continue
        need(path.is_file(), 'Missing required input: ' + rel)
        need(path.stat().st_size <= MAX_FILE, 'Large input requires explicit scope review: ' + rel)
        included.append(path)
    return included, omitted


def history_gates():
    """Read only after release. These are artifact checks, not new SQL runs."""
    build = FTS / 'round33-count-only-order-build'
    proposal = FTS / 'round33-count-only-order-proposal'
    original = (build / 'original.cpp').read_bytes()
    old = (build / 'candidate.cpp').read_bytes()
    bounded = (build / 'bounded-candidate.cpp').read_bytes()
    applied, fixed = load(build / 'application.json'), load(build / 'bounded-application.json')
    need(sha(original) == applied['original_sha256'] and sha(old) == applied['candidate_sha256']
         == fixed['preimage_sha256'] and sha(bounded) == fixed['candidate_sha256'], 'Source chain mismatch')
    need(sha((proposal / 'proposal.patch').read_bytes()) == applied['patch_sha256']
         and sha((proposal / 'bounded-limits.delta.patch').read_bytes()) == fixed['patch_sha256'], 'Patch identity mismatch')
    pins = load(proposal / 'bounded-limits-pins.json')
    for name, pin in pins['artifacts'].items():
        raw = (proposal / name).read_bytes()
        need(len(raw) == pin['bytes'] and sha(raw) == pin['sha256'], 'Bounded proposal artifact changed')
    reference = load(FTS / 'r33-count-only-order-official-regression-a1-boundaries.json')
    failed = load(FTS / 'r33-count-only-order-candidate-boundaries-a2-boundaries.json')
    need(len(reference['records']) == len(failed['records']) == 54, 'Missing old 54-record differential')
    differences = [i for i, (a, b) in enumerate(zip(reference['records'], failed['records'])) if a != b]
    need(failed['status'] == 'FAIL_DIFFERENTIAL' and differences == [10, 11, 30, 31]
         == [item['index'] for item in failed['differences']], 'Old observed discrepancies changed')
    official = load(FTS / 'r33-bounded-official-boundaries-a1-boundaries.json')
    candidate = load(FTS / 'r33-bounded-candidate-regression-a2-boundaries.json')
    need(official['status'] == candidate['status'] == 'PASS'
         and len(official['records']) == 104 and official['records'] == candidate['records']
         and not candidate['differences'], 'Bounded 104 complete result/error records mismatch')
    failure = (FTS / 'r33-bounded-candidate-regression-a1-counted-boundaries.log').read_bytes()
    need(b'FileNotFoundError:' in failure and b'setup\\fts\\r33-bounded-official-boundaries-a1-boundaries.json' in failure,
         'Missing relative-reference harness failure')
    receipt = load(FTS / 'r33-bounded-candidate-regression-a1-experiment.json')
    need(any(a['action'] == 'counted-boundaries' and a['exit_code'] == 1 for a in receipt['actions']),
         'Missing failed harness action receipt')
    return dict(source_sha256=dict(original=sha(original), initial_candidate=sha(old), bounded_candidate=sha(bounded)),
                initial_differential=dict(records=54, differing_indices=differences),
                bounded_differential=dict(records=104, comparison='complete records only; plans/stdout hashes can differ'),
                harness_failure='Initial bounded a1 relative-reference FileNotFoundError is retained; subsequent a2 PASS is separate.')


def release_gates(path):
    need(path.parent.resolve() == HERE and path.is_file(), 'Release must be a new local R33 auxiliary JSON')
    release = load(path)
    need(release.get('status') == 'READY_PARENT_AUTHORIZED'
         and release.get('parent_authorized_archive') is True
         and release.get('all_input_files_final') is True
         and release.get('decision') in ('RETAIN', 'REJECT'), 'Await parent final decision; do not freeze while pairs run')
    need(release.get('final_tests') and release.get('receipt_checks'), 'Final test snapshots and receipt checks required')
    extra = [release['final_comparison'], *release['final_tests']]
    required_receipts = [release['decision_receipt']]
    required_receipts.append(release['commit_receipt'] if release['decision'] == 'RETAIN' else release['restoration_receipt'])
    for name in required_receipts:
        need(isinstance(name, str) and name, 'Missing final commit/restoration receipt')
        need(any(check['source'] == name and check.get('equals') for check in release['receipt_checks']),
             'Receipt requires explicit actual-field predicates: ' + name)
    for check in release['receipt_checks']:
        raw = load(relative_path(check['source']))
        need(check.get('equals') and all(raw.get(key) == value for key, value in check['equals'].items()),
             'Parent receipt field mismatch: ' + check['source'])
        extra.append(check['source'])
    comparison = load(relative_path(release['final_comparison']))
    need(comparison['status'] == 'COMPLETE' and comparison['completed_pairs'] == 3
         and len(comparison['pairs']) == 3 and len(comparison['records']) == 6, 'Final three complete pairs required')
    need(set(comparison['records']) == {f'r33-bounded-{kind}-a{number}'
         for kind in ('control', 'candidate') for number in (1, 2, 3)}, 'Unexpected final timing labels')
    need(comparison['parameters'] == dict(rows=20000, batch=500, rounds=3000, query_rounds=200,
                                        samples=3, warmup=30, skip_load=0), 'Fixed benchmark parameters differ')
    for name, pin in comparison['input_hashes'].items():
        need(PurePosixPath(name).name == name and name.startswith('r33-'), 'Unexpected comparison input')
        raw = relative_path(name).read_bytes()
        need(sha(raw) == pin['sha256'] and len(raw) == pin['bytes'], 'Final comparison input changed: ' + name)
    for label, record in comparison['records'].items():
        receipt = record['receipt']
        need(receipt['label'] == label and receipt['affinity_mask_verified'] == 15
             and receipt['owned_server_exit_before_cleanup'] is None
             and all(a['exit_code'] == 0 for a in receipt['actions']), 'Incomplete final timing receipt')
    extra.extend(release.get('extra_sources', []))
    return release, extra, dict(history=history_gates(), comparison=comparison,
                               provenance='Parent receipts only; no Git, binary hashing or new runtime validation.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--preview', action='store_true', help='Names/stat sizes only, no output files or evidence hashes')
    mode.add_argument('--execute', action='store_true', help='Only after parent final notification and release.json')
    parser.add_argument('--release', type=Path, default=HERE / 'release.json')
    args = parser.parse_args()
    if args.preview:
        paths, omitted = discover()
        print(json.dumps(dict(status='PREPARATION_ONLY_NOT_FROZEN', observed_files=len(paths),
             observed_bytes=sum(p.stat().st_size for p in paths),
             sources=[p.relative_to(FTS).as_posix() for p in paths], omissions=omitted,
             note='Volatile inventory only; no evidence hashes, selection.json, manifest or package written.'), indent=2))
        return
    need(HERE.name == 'round33-archive' and not PACKAGE.exists(), 'Fixed fresh C package required')
    release, extras, gates = release_gates(args.release.resolve())
    paths, omitted = discover(extras)
    need({relative_path(name) for name in extras}.issubset(set(paths)), 'Required parent input was excluded')
    paths += [HERE / name for name in ('archive.py', 'verify_archive.py', 'README.md', 'status.json',
                                       'release.template.json', 'syntax-check.json')]
    paths.append(args.release.resolve())
    paths += [path for path in HERE.glob('report.*.md') if path.is_file()]
    paths = sorted(set(paths), key=lambda p: p.relative_to(FTS).as_posix())
    snapshots = []
    for path in paths:
        need(path.is_file() and not path.is_symlink() and path.resolve().is_relative_to(FTS), 'Unsafe source')
        raw = path.read_bytes()
        need(len(raw) <= MAX_FILE, 'Oversize raw input')
        snapshots.append((path, len(raw), sha(raw)))
    need(sum(n for _, n, _ in snapshots) < MAX_TOTAL, 'Raw package budget exceeded')
    # Creation starts only after final readiness/history checks and all snapshots.
    PACKAGE.mkdir()
    entries = []
    for path, length, digest in snapshots:
        raw = path.read_bytes()
        need(len(raw) == length and sha(raw) == digest, 'Input changed during archive; no completion marker')
        packed = gzip.compress(raw, compresslevel=9, mtime=0)
        need(gzip.decompress(packed) == raw, 'Gzip exact-byte check failed')
        relative = path.relative_to(FTS).as_posix()
        target = PACKAGE / 'files' / (relative + '.gz')
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as stream:
            stream.write(packed)
        entries.append(dict(source=relative, path='files/' + relative + '.gz', raw_bytes=length,
                            raw_sha256=digest, packed_bytes=len(packed), packed_sha256=sha(packed)))
    need(all(path.stat().st_size == length and sha(path.read_bytes()) == digest
             for path, length, digest in snapshots), 'Input changed before finalization')
    for name, pin in gates['comparison']['input_hashes'].items():
        need(any(path == FTS / name and length == pin['bytes'] and digest == pin['sha256']
                 for path, length, digest in snapshots), 'Comparison inputs changed after final gates')
    need(load(args.release.resolve()) == release and load(relative_path(release['final_comparison'])) == gates['comparison']
         and history_gates() == gates['history'], 'Final gate evidence changed during packing')
    labels = sorted(path.name.removesuffix('-experiment.json') for path, _, _ in snapshots
                    if path.parent == FTS and path.name.endswith('-experiment.json'))
    manifest = dict(schema=1, experiment='round33-count-only-order', decision=release['decision'],
                    parent_release=release, gates=gates, labels=labels, files=entries,
                    omissions=omitted, limits=['Local measurements only; no formal/cumulative/full score claim.',
                    'Historical failures and pending metadata retained without rewriting.',
                    'No R34/native fixture, live binary/source, runtime/data or credentials included.',
                    'Inherited binary pins are receipts, not freshly verified binary identities.'])
    save(PACKAGE / 'manifest.json', manifest)
    complete = dict(status='COMPLETE', file_count=len(entries),
                    manifest_sha256=sha((PACKAGE / 'manifest.json').read_bytes()),
                    raw_bytes=sum(i['raw_bytes'] for i in entries), packed_bytes=sum(i['packed_bytes'] for i in entries))
    save(PACKAGE / 'COMPLETE.json', complete)
    save(HERE / 'archive-summary.json', dict(complete, package=str(PACKAGE), execution='Offline C-only archive; no build/SQL/runtime/Git/publication'))
    print(json.dumps(complete, indent=2))


if __name__ == '__main__':
    main()
