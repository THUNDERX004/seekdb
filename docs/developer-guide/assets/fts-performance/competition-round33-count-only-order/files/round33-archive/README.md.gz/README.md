# R33 retained archive — final release authorized

Parent accepted bounded R33 and committed/pushed production, test v2 and the
official fixture as f1f93b43176bf62f3a883d082ee86eb9d68f867a. release.json
records final authorization. The initial status/template/syntax receipt and
*.preparation.* helper/doc copies preserve the earlier pending stage unchanged.
Reports explain the final state separately. No experiment or commit helper is
executed by this archiver, and no live D production/test source is copied.

Final scope includes all three R33 proposal/build/review folders, every r33-*
flat artifact, both build logs, v1/v2 test and fixture, all12 incremental and
cumulative timings, final positive/negative gates, parent checks and commit
helper/receipt. The exact imported strict-summary utility source is included.
Packed/raw/source hashes preserve original bytes, including compressed fixture
bytes; original line endings are never normalized for packing. LF normalization
is used only to compare C test identity with the parent's committed-test pin.
The first offline archive gate failed before package creation by treating v1's
raw CRLF preimage pin as an LF pin. archive-attempt-1.json and the prior syntax
receipt preserve that preparation error; only the archive comparison changed.
Both test sources and all experimental inputs remain exact original bytes.

Test v1's assertion Major, source fix v2, initial relative-reference failure,
old54 differential, bounded104 results, defective-candidate21-difference failure
and empty-reference failure are kept as distinct historical events. Parent
reports v2-opt-a1 did NOT enable optimization; v2-opt-a2 used PYTHONOPTIMIZE=1.
Run receipts omit environment/sys.flags.optimize, so mode attribution comes
from parent execution instructions and the promotion receipt, not labels.
Cache-hit and allocation-failure coverage are not established.

Final commands, once each from the workspace root:

```powershell
.venv/Scripts/python.exe -B -X utf8 setup/fts/round33-archive/archive.py --execute
.venv/Scripts/python.exe -B -X utf8 setup/fts/round33-archive/verify_archive.py --receipt local-verification.json
.venv/Scripts/python.exe -B -X utf8 setup/fts/round33-archive/publish.py --publish
.venv/Scripts/python.exe -B -X utf8 setup/fts/round33-archive/verify_archive.py --package D:/Projects/OceanBase/seekdb/docs/developer-guide/assets/fts-performance/competition-round33-count-only-order --repo-docs D:/Projects/OceanBase/seekdb/docs/developer-guide --receipt published-verification.json
```

Publish requires tool-level authorized D access and writes only the new R33
assets plus en/zh-CN competition-round33.md; both historical fts-performance.md
files remain unchanged. publication.json lists every D path. Verification and
final status receipts stay outside the immutable package. Parent owns independent
verification and docs commit/push. No Git/build/SQL/server/native execution,
R34/R35/publicresearch work, binary hashing or live-cleanliness claim occurs.
Local incremental and cumulative measurements are not a new formal/full score
or a statistical-stability result. All signed reports remain unchanged.

<details>
<summary>Historical preparation instructions (before final decision)</summary>

# R33 archive preparation — not frozen

Current scope is C-only preparation. The parent is still running three full
pairs and has not given a final performance decision. No selection.json,
evidence input hash capture, package, manifest, publication, or final report
is created now. R32 and all historical inputs remain untouched.

`archive.py --preview` inventories names/stat sizes only and writes nothing.
It discovers files afresh, so later reports, receipts, final tests and commit
evidence can be included after the parent notifies completion. Preview output
is a changing inventory, not a frozen selection or completeness claim.

Selection at future execution covers:

- round33-count-only-order-{proposal,build,review}, recursively;
- all flat r33-* artifacts, including failed runs and subsequent repetitions;
- round33-count-only-order-candidate-build.log and
  round33-bounded-count-only-order-build.log;
- the actual imported round19-evidence/summarize-template.py utility source;
- explicit later parent disposition/comparison/commit-or-restoration receipts,
  final C test snapshots and additional R33 helper sources.

Preserve the initial candidate, its failed boundary runs, all54 records and
four actual differences at indices10/11/30/31. Keep bounded correction source,
patches, independent review and all104 official/candidate result/error records.
The original bounded a1 FileNotFoundError is a relative-reference harness
failure; its receipt remains failed, and successful a2 is a distinct event.
Old proposal/review pending text must not be rewritten as a later PASS.
Plans include runtime addresses: complete result/error record equality does
not imply equal plan text or equal whole-file/stdout hashes. No R33 native
fixture coverage is asserted; R34 native evidence is excluded.

Only after parent final notification, create separate `release.json` from
`release.template.json`, filling actual decision, final filenames, final test
snapshots and receipt field predicates. Keep the template and initial status
unchanged as historical preparation records. The execute gate requires three
complete fixed-parameter pairs and their exact report/receipt hashes, verified
affinity15, preserved failure history, and source/patch identities. RETAIN
requires the actual commit receipt; REJECT requires actual restoration receipt.
The gate performs offline artifact checks; it never invokes an archived helper
or imports a harness, runs SQL, hashes binaries, or inspects Git/live D source.

Commands from C:/Users/11946/Documents/ChatGPT/OceanBase比赛:

```powershell
# Safe current preparation: no files, evidence hashes or freezing.
.venv/Scripts/python.exe -B -X utf8 setup/fts/round33-archive/archive.py --preview

# FUTURE ONLY, after parent final notification and real release.json:
.venv/Scripts/python.exe -B -X utf8 setup/fts/round33-archive/archive.py --execute
.venv/Scripts/python.exe -B -X utf8 setup/fts/round33-archive/verify_archive.py
```

Future output is only C round33-archive/package, refusing an existing package.
Every original byte stream is gzip-compressed with mtime0, with raw and packed
SHA-256/lengths. Files are checked again before completion. Unexpected large
inputs stop packing rather than being silently omitted. Binaries/PDB/DLL,
objects/libraries/intermediates, runtime/data/temp, credentials and R34 are
excluded with omission reasons. This helper has no publishing or Git mode.
Local performance evidence cannot establish a new formal, cumulative, full
score or statistical-stability claim. The final decision remains pending.

</details>
