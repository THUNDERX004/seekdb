"""Read-only complete packed/raw/source verification of a future C R33 package."""
from pathlib import Path, PurePosixPath
import gzip
import hashlib
import json

HERE = Path(__file__).resolve().parent


def need(ok, message):
    if not ok:
        raise RuntimeError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    root = HERE / 'package'
    raw = (root / 'manifest.json').read_bytes()
    manifest = json.loads(raw)
    complete = json.loads((root / 'COMPLETE.json').read_bytes())
    need(manifest['experiment'] == 'round33-count-only-order' and manifest['decision'] in ('RETAIN', 'REJECT'), 'Wrong archive')
    need(complete['status'] == 'COMPLETE' and complete['manifest_sha256'] == sha(raw), 'Missing/mismatched completion')
    expected, sources = {'manifest.json', 'COMPLETE.json'}, set()
    raw_total = packed_total = 0
    for item in manifest['files']:
        rel = PurePosixPath(item['source'])
        need(not rel.is_absolute() and '..' not in rel.parts and ':' not in str(rel) and '\\' not in str(rel), 'Unsafe path')
        need(item['path'] == 'files/' + str(rel) + '.gz' and item['path'] not in expected
             and str(rel) not in sources, 'Duplicate/mismatched artifact path')
        target = root / item['path']
        need(target.resolve().is_relative_to(root.resolve()), 'Packed path escapes package')
        packed = target.read_bytes()
        need(len(packed) == item['packed_bytes'] and sha(packed) == item['packed_sha256'], 'Packed mismatch')
        data = gzip.decompress(packed)
        need(len(data) == item['raw_bytes'] and sha(data) == item['raw_sha256'], 'Raw mismatch')
        source = HERE.parent / str(rel)
        need(source.resolve().is_relative_to(HERE.parent) and source.read_bytes() == data, 'Original source mismatch')
        expected.add(item['path']); sources.add(str(rel))
        raw_total += len(data); packed_total += len(packed)
    need({p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()} == expected, 'Missing/extra archive files')
    need(len(sources) == complete['file_count'] and raw_total == complete['raw_bytes']
         and packed_total == complete['packed_bytes'], 'Aggregate counts mismatch')
    print(json.dumps(dict(status='PASS', file_count=len(sources), manifest_sha256=sha(raw),
                         packed_raw_source='ALL MATCH', execution='Read-only offline verification'), indent=2))


if __name__ == '__main__':
    main()
