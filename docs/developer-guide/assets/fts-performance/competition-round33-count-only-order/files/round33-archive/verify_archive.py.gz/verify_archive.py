"""Read-only complete packed/raw/source verification of a future C R33 package."""
from pathlib import Path, PurePosixPath
import argparse
import gzip
import hashlib
import json

HERE = Path(__file__).resolve().parent


def need(ok, message):
    if not ok:
        raise RuntimeError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--package', type=Path, default=HERE / 'package')
    parser.add_argument('--repo-docs', type=Path)
    parser.add_argument('--receipt', type=Path, help='Optional new receipt filename inside this C helper directory')
    args = parser.parse_args()
    root = args.package.resolve()
    raw = (root / 'manifest.json').read_bytes()
    manifest = json.loads(raw)
    complete = json.loads((root / 'COMPLETE.json').read_bytes())
    need(manifest['experiment'] == 'round33-count-only-order' and manifest['decision'] in ('RETAIN', 'REJECT'), 'Wrong archive')
    need(complete['status'] == 'COMPLETE' and complete['manifest_sha256'] == sha(raw), 'Missing/mismatched completion')
    expected, sources = {'manifest.json', 'COMPLETE.json'}, set()
    raw_total = packed_total = 0
    for item in manifest['files']:
        rel = PurePosixPath(item['source'])
        need(not rel.is_absolute() and '..' not in rel.parts and ':' not in str(rel) and '\\' not in str(rel), 'Unsafe path')
        need(item['path'] == 'files/' + str(rel) + '.gz' and item['path'] not in expected
             and str(rel) not in sources, 'Duplicate/mismatched artifact path')
        target = root / item['path']
        need(target.resolve().is_relative_to(root.resolve()), 'Packed path escapes package')
        packed = target.read_bytes()
        need(len(packed) == item['packed_bytes'] and sha(packed) == item['packed_sha256'], 'Packed mismatch')
        data = gzip.decompress(packed)
        need(len(data) == item['raw_bytes'] and sha(data) == item['raw_sha256'], 'Raw mismatch')
        source = HERE.parent / str(rel)
        need(source.resolve().is_relative_to(HERE.parent) and source.read_bytes() == data, 'Original source mismatch')
        expected.add(item['path']); sources.add(str(rel))
        raw_total += len(data); packed_total += len(packed)
    need({p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()} == expected, 'Missing/extra archive files')
    need(len(sources) == complete['file_count'] and raw_total == complete['raw_bytes']
         and packed_total == complete['packed_bytes'], 'Aggregate counts mismatch')
    if args.repo_docs:
        for language, name in (('en', 'report.en.md'), ('zh-CN', 'report.zh-CN.md')):
            need((args.repo_docs / language / 'competition-round33.md').read_bytes() == (HERE / name).read_bytes(), 'Published report mismatch')
    result = dict(status='PASS', file_count=len(sources), manifest_sha256=sha(raw), raw_bytes=raw_total, packed_bytes=packed_total,
                  packed_raw_source='ALL MATCH', published_reports='MATCH' if args.repo_docs else 'NOT REQUESTED',
                  execution='Offline verification; optional C receipt only; no build/SQL/native/runtime/Git')
    if args.receipt:
        target = (HERE / args.receipt).resolve()
        need(target.parent == HERE and not target.exists(), 'Receipt must be a new C helper file')
        with target.open('xb') as stream:
            stream.write((json.dumps(result, indent=2) + '\n').encode())
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
