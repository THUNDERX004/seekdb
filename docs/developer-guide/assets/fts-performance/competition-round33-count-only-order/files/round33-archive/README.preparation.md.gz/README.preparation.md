# R33 archive preparation — not frozen

Current scope is C-only preparation. The parent is still running three full
pairs and has not given a final performance decision. No selection.json,
evidence input hash capture, package, manifest, publication, or final report
is created now. R32 and all historical inputs remain untouched.

`archive.py --preview` inventories names/stat sizes only and writes nothing.
It discovers files afresh, so later reports, receipts, final tests and commit
evidence can be included after the parent notifies completion. Preview output
is a changing inventory, not a frozen selection or completeness claim.

Selection at future execution covers:

- round33-count-only-order-{proposal,build,review}, recursively;
- all flat r33-* artifacts, including failed runs and subsequent repetitions;
- round33-count-only-order-candidate-build.log and
  round33-bounded-count-only-order-build.log;
- the actual imported round19-evidence/summarize-template.py utility source;
- explicit later parent disposition/comparison/commit-or-restoration receipts,
  final C test snapshots and additional R33 helper sources.

Preserve the initial candidate, its failed boundary runs, all54 records and
four actual differences at indices10/11/30/31. Keep bounded correction source,
patches, independent review and all104 official/candidate result/error records.
The original bounded a1 FileNotFoundError is a relative-reference harness
failure; its receipt remains failed, and successful a2 is a distinct event.
Old proposal/review pending text must not be rewritten as a later PASS.
Plans include runtime addresses: complete result/error record equality does
not imply equal plan text or equal whole-file/stdout hashes. No R33 native
fixture coverage is asserted; R34 native evidence is excluded.

Only after parent final notification, create separate `release.json` from
`release.template.json`, filling actual decision, final filenames, final test
snapshots and receipt field predicates. Keep the template and initial status
unchanged as historical preparation records. The execute gate requires three
complete fixed-parameter pairs and their exact report/receipt hashes, verified
affinity15, preserved failure history, and source/patch identities. RETAIN
requires the actual commit receipt; REJECT requires actual restoration receipt.
The gate performs offline artifact checks; it never invokes an archived helper
or imports a harness, runs SQL, hashes binaries, or inspects Git/live D source.

Commands from C:/Users/11946/Documents/ChatGPT/OceanBase比赛:

```powershell
# Safe current preparation: no files, evidence hashes or freezing.
.venv/Scripts/python.exe -B -X utf8 setup/fts/round33-archive/archive.py --preview

# FUTURE ONLY, after parent final notification and real release.json:
.venv/Scripts/python.exe -B -X utf8 setup/fts/round33-archive/archive.py --execute
.venv/Scripts/python.exe -B -X utf8 setup/fts/round33-archive/verify_archive.py
```

Future output is only C round33-archive/package, refusing an existing package.
Every original byte stream is gzip-compressed with mtime0, with raw and packed
SHA-256/lengths. Files are checked again before completion. Unexpected large
inputs stop packing rather than being silently omitted. Binaries/PDB/DLL,
objects/libraries/intermediates, runtime/data/temp, credentials and R34 are
excluded with omission reasons. This helper has no publishing or Git mode.
Local performance evidence cannot establish a new formal, cumulative, full
score or statistical-stability claim. The final decision remains pending.
