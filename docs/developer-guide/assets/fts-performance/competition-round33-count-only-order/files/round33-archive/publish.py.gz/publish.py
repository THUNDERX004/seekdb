"""Publish only the new R33 assets and two new R33 reports after verification."""
from pathlib import Path
import argparse
import hashlib
import json

HERE = Path(__file__).resolve().parent
ROOT = Path('D:/Projects/OceanBase/seekdb')
DOCS = ROOT / 'docs/developer-guide'
DEST = DOCS / 'assets/fts-performance/competition-round33-count-only-order'


def need(ok, message):
    if not ok:
        raise RuntimeError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--publish', action='store_true')
    args = parser.parse_args()
    need(args.publish, 'Explicit --publish required')
    package = HERE / 'package'
    raw = (package / 'manifest.json').read_bytes()
    manifest = json.loads(raw)
    complete = json.loads((package / 'COMPLETE.json').read_bytes())
    verified = json.loads((HERE / 'local-verification.json').read_bytes())
    need(manifest['experiment'] == 'round33-count-only-order' and manifest['decision'] == 'RETAIN', 'Wrong archive')
    need(complete['status'] == 'COMPLETE' and verified['status'] == 'PASS'
         and complete['manifest_sha256'] == verified['manifest_sha256'] == sha(raw), 'Local verification required')
    need(not DEST.exists(), 'New asset target already exists')
    reports = [(DOCS / language / 'competition-round33.md', HERE / name)
               for language, name in (('en', 'report.en.md'), ('zh-CN', 'report.zh-CN.md'))]
    need(all(not target.exists() and target.parent.is_dir() for target, source in reports), 'New reports required')
    expected = {'manifest.json', 'COMPLETE.json'} | {item['path'] for item in manifest['files']}
    need({p.relative_to(package).as_posix() for p in package.rglob('*') if p.is_file()} == expected, 'Unexpected/missing package file')
    historical = {DOCS / language / 'fts-performance.md': sha((DOCS / language / 'fts-performance.md').read_bytes())
                  for language in ('en', 'zh-CN')}
    DEST.mkdir()
    written = []
    for relative in sorted(expected):
        target = DEST / relative
        need(target.resolve().is_relative_to(DEST.resolve()), 'Destination escapes asset directory')
        target.parent.mkdir(parents=True, exist_ok=True)
        stream_raw = (package / relative).read_bytes()
        with target.open('xb') as stream:
            stream.write(stream_raw)
        need(target.read_bytes() == stream_raw, 'Published stream mismatch')
        written.append(target.relative_to(ROOT).as_posix())
    for target, source in reports:
        data = source.read_bytes()
        with target.open('xb') as stream:
            stream.write(data)
        need(target.read_bytes() == data, 'Published document mismatch')
        written.append(target.relative_to(ROOT).as_posix())
    need(all(sha(path.read_bytes()) == digest for path, digest in historical.items()), 'Historical reports changed')
    result = dict(status='PUBLISHED_NEW_FILES_ONLY', manifest_sha256=sha(raw), file_count=complete['file_count'],
                  changed_repository_paths=written,
                  historical_reports_unchanged={path.relative_to(ROOT).as_posix(): digest for path, digest in historical.items()},
                  execution='Offline authorized docs/assets copy only; no production/test/build/runtime/Git mutation')
    with (HERE / 'publication.json').open('xb') as stream:
        stream.write((json.dumps(result, indent=2) + '\n').encode())
    print(json.dumps({k: v for k, v in result.items() if k != 'changed_repository_paths'}, indent=2))


if __name__ == '__main__':
    main()
