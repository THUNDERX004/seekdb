R33 independent bounded review — November 5, 2026

Reviewed the actual addition against frozen `proposal.patch`, `report.md`, and `source-pins.json`, following the checkout’s AGENTS.md and code-review skill. The 104 added lines match exactly: normalized candidate SHA256 `581f2e4aa961370c6fc430b790490086939f9624804c0427e998c76319ac81a2`; removing them reproduces the pinned preimage. R32 is outside this diff. The contract permits suppressing only synthesized MATCH DESC for an immediate root COUNT(*) over the restricted limited view, while preserving observable results and errors.

**Major — ordinary question marks bypass legacy LIMIT/OFFSET rejection.** At [ob_transform_pre_process.cpp:53](D:/Projects/OceanBase/seekdb/src/sql/rewrite/ob_transform_pre_process.cpp:53), every nondynamic `T_QUESTIONMARK` is accepted without a value bound. The LIMIT/OFFSET checks at [line 104](D:/Projects/OceanBase/seekdb/src/sql/rewrite/ob_transform_pre_process.cpp:104) therefore allow prepared INT64_MAX bindings to reach the new skip at line 285. Being a plain parameter does not establish validation equivalence between the old top-K and new ordinary DaaT routes.

The parent’s actual prepared statement is:

```sql
SELECT COUNT(*) FROM (
  SELECT id FROM docs WHERE MATCH(body) AGAINST(?) LIMIT ? OFFSET ?
) counted
```

On its 513-row FULLTEXT fixture, bind search text `common`:

| LIMIT | OFFSET | Official | Candidate |
|---|---|---|---|
| 9223372036854775807 | 0 | error 1210 | count 513 |
| 20 | 9223372036854775807 | error 1210 | count 0 |

Both differences repeat on the same prepared handle. I independently compared the saved candidate and reference records: exactly indices 10, 11, 30, and 31 differ among 54 records, matching the saved differences in [the a2 evidence](C:/Users/11946/Documents/ChatGPT/OceanBase比赛/setup/fts/r33-count-only-order-candidate-boundaries-a2-boundaries.json). These are observed error-to-success changes, not a guessed oracle for invalid bindings.

**Code proof:** top-K pushdown requires the MATCH prefix sort key ([ob_log_plan.cpp:12735](D:/Projects/OceanBase/seekdb/src/sql/optimizer/ob_log_plan.cpp:12735)); omitting synthesis removes that prerequisite. The legacy merge computes `limit + offset` ([line 1173](D:/Projects/OceanBase/seekdb/src/observer/composition/retrieval/ob_das_legacy_tr_merge_iter.cpp:1173)) and selects BMW in top-K mode. BMW rejects negative top-K counts and initializes `id_cache_` with the requested count ([ob_sparse_bmw_iter.cpp:46](D:/Projects/OceanBase/seekdb/src/storage/retrieval/ob_sparse_bmw_iter.cpp:46)); [ObFixedArray::init:181](D:/Projects/OceanBase/seekdb/src/oblib/lib/container/ob_fixed_array.h:181) rejects capacities above UINT32_MAX with OB_INVALID_ARGUMENT. This directly explains rejection of LIMIT=INT64_MAX, OFFSET=0. Ordinary DaaT instead applies counter-based LIMIT/OFFSET ([cache_result:392](D:/Projects/OceanBase/seekdb/src/storage/retrieval/ob_sparse_daat_iter.cpp:392)), bypassing that cache validation. The OFFSET discrepancy is independently established by the captured executions; its precise legacy error site was not instrumented.

**Smallest correction:** fail closed where legacy bound/error equivalence is unproven, or preserve equivalent validation. A decision based on current bindings also needs plan-reuse constraints; checking only the first execution is insufficient. Retain the two failing tuples and subsequent normal executions on the same handle as focused regressions. This finding does not require a broad runtime redesign.

No additional concrete Major/Blocker finding emerged in the remaining requested scope. The unchanged `has_limit()` score guard still retains relevance; saved ordinary-limit plans show `calc_relevance=true`. Gaps: no independent execution, binary/source attestation, or outline/cache replay after a fix. The parent-reported 399 focused, ranked 432, and key-type 192 passes do not resolve these four failures; final seven-suite results were not revalidated here. Only this review directory was written; no D: writes, Git, build, runtime, SQL, or large-file hashing was performed. No formal evaluation or performance claim.
