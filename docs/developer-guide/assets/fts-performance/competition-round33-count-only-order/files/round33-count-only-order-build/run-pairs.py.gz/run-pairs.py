"""Three serial, full-input, balanced-order R33/R32 local pairs."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

HERE=Path(__file__).resolve().parent
ROOT=Path('D:/Projects/OceanBase/seekdb')
PYTHON=Path(__file__).resolve().parents[3]/'.venv/Scripts/python.exe'
configs={
    'control':('build/fts-round32-projection-candidate/seekdb.exe','544fa53367442995a8fe0349dcfa5b13606621a53560d646e2e44c3cffa02e47','5cc947bad132c7705e07da461089ff666dc63e60'),
    'candidate':('build/fts-round33-bounded-count-only-order-candidate/seekdb.exe','596b93cd688e9ab47449391db1dfeb5acfd56095cee558b064f8d5a4a03f7437','55b0ddc224d3b1ea85c46474468c527727f6184b+round33-bounded-count-only-order')}
for binary,digest,source in configs.values():
    assert hashlib.sha256((ROOT/binary).read_bytes()).hexdigest()==digest
order=[('control',1),('candidate',1),('candidate',2),('control',2),('control',3),('candidate',3)]
for kind,n in order:
    binary,digest,source=configs[kind]
    label=f'r33-bounded-{kind}-a{n}'
    base=Path('C:/Users/11946/AppData/Local/Temp')/('seekdb-'+label)
    assert not base.exists()
    args=[str(PYTHON),'-B','-X','utf8',str(HERE/'experiment-v2.py'),'--binary',str(ROOT/binary),'--label',label,'--source',source,'--base-dir',str(base),'--affinity-mask','15','--benchmark']
    print('PAIR RUN',label,flush=True)
    subprocess.run(args,check=True)
    receipt=json.loads((HERE.parent/(label+'-experiment.json')).read_text(encoding='utf-8'))
    assert receipt['binary_sha256']==digest and receipt['affinity_mask_verified']==15
    assert all(a['exit_code']==0 for a in receipt['actions'])
print('COMPLETE all six full-input measurements',flush=True)
