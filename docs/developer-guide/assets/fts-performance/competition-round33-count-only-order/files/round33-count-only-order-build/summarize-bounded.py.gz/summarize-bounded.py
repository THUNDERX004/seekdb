"""Strict complete fixed-input R33 pairs; signed equally weighted categories."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
from statistics import mean

HERE=Path(__file__).resolve().parent
FTS=HERE.parent
helper=FTS/'round19-evidence/summarize-template.py'
assert hashlib.sha256(helper.read_bytes()).hexdigest()=='0aca605abda2fea4ab7b32335c5fe04302895748e8f63a6ce46887b04b822035'
spec=importlib.util.spec_from_file_location('strict_pairs',helper)
u=importlib.util.module_from_spec(spec);spec.loader.exec_module(u)

def main():
    p=argparse.ArgumentParser();p.add_argument('--pairs',type=int,choices=(1,2,3),required=True)
    a=p.parse_args()
    out=HERE/('bounded-comparison-'+str(a.pairs)+'pair.json')
    assert not out.exists()
    u.PINS={'control':'544fa53367442995a8fe0349dcfa5b13606621a53560d646e2e44c3cffa02e47',
            'candidate':'596b93cd688e9ab47449391db1dfeb5acfd56095cee558b064f8d5a4a03f7437'}
    sources={'control':'5cc947bad132c7705e07da461089ff666dc63e60',
             'candidate':'55b0ddc224d3b1ea85c46474468c527727f6184b+round33-bounded-count-only-order'}
    records={};inputs={};raws={};bases=set();runs={'control':[],'candidate':[]};pairs=[]
    def compare(old,new):
        result=u.comparison(old,new);result.pop('incremental_score_equivalents');return result
    for number in range(1,a.pairs+1):
        for variant in runs:
            label='r33-bounded-'+variant+'-a'+str(number)
            report=FTS/(label+'-report.txt')
            r=u.receipt(u.read_input(FTS/(label+'-experiment.json'),inputs,raws),label,variant,report)
            assert r['source_commit']==sources[variant] and r['owned_server_exit_before_cleanup'] is None
            base=Path(r['base_dir']);assert base.name=='seekdb-r33-bounded-'+variant+'-a'+str(number)
            assert str(base) not in bases;bases.add(str(base))
            d=u.report(u.read_input(report,inputs,raws),label)
            records[label]=dict(receipt=r,**d);runs[variant].append(d['values'])
        pairs.append(dict(pair=number,**compare(runs['control'][-1],runs['candidate'][-1])))
    averages={variant:{key:mean(run[key] for run in values) for key in u.METRICS} for variant,values in runs.items()}
    result=dict(status='COMPLETE',completed_pairs=a.pairs,binary_pins=u.PINS,source_labels=sources,parameters=u.PARAMS,
                expected_hits=u.HITS,records=records,input_hashes=inputs,pairs=pairs,metric_means=averages,
                aggregate=compare(averages['control'],averages['candidate']),
                interpretation='Local incremental vs accepted R32; not a formal or cumulative score. Negative rates retained, arithmetic per-category means then equal3-category mean. No excluded runs or SELECT1 subtraction.')
    for path,raw in raws.items():assert u.snapshot(path)==raw
    with out.open('x',encoding='utf-8') as stream:
        json.dump(result,stream,indent=2,allow_nan=False);stream.write('\n')
    print(json.dumps(dict(output=str(out),aggregate=result['aggregate']),indent=2))

if __name__=='__main__':main()
