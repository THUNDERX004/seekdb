"""Commit only verified R33 production/test paths and immediately push."""
import hashlib
import json
from pathlib import Path
import subprocess

HERE=Path(__file__).resolve().parent
ROOT=Path('D:/Projects/OceanBase/seekdb')
FTS=HERE.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args,capture=False):
    p=subprocess.run(['git',*args],cwd=ROOT,check=True,capture_output=capture,text=True,encoding='utf-8')
    return p.stdout.strip() if capture else None
assert git('rev-parse','HEAD',capture=True)=='55b0ddc224d3b1ea85c46474468c527727f6184b'
assert git('branch','--show-current',capture=True)=='codex/fts-performance-competition'
assert not git('diff','--cached','--name-only',capture=True)
git('merge-base','--is-ancestor','5bce9e06d1281347ad61344e4b01fab9158c58a2','HEAD')
assert not git('diff','--name-only','5bce9e06d1281347ad61344e4b01fab9158c58a2','--','tools/benchmark','.github','CMakeLists.txt','cmake','build.sh',capture=True)
paths={
 'src/sql/rewrite/ob_transform_pre_process.cpp':'408fac5f05ca084168b3d1f45df567c33cbadfe42317df5b008d019461b544ac',
 'unittest/storage/fts/test_counted_limit_order.py':'800cecebf41834341e2e3102b6041b8f11ac4e70fdef3d9a9c902e16eef40f8d',
 'unittest/storage/fts/counted_limit_order_expected.json.gz':'e007496af907b30d8abea7ac53b50a929da1c8cfb78236feb96b10fb5d35285c',
}
preserve={
 'src/data_plane/api/data_plane/fts/ob_fts_struct.h':'1ec2e61b38494c772cac48457eb823de821447580ba77bf0196da3c4a16747f1',
 'src/storage/fts/ik/ob_ik_arbitrator.h':'7beef2116a44e589c3b96c294c44bc746711976b299a8a9fce47703f1affa1e4',
 'unittest/storage/fts/stopword_ascii_initial_expected.json':'052c5fbeaddc642bd5e711b886c900e668292d1cae14110e7d2679a4c1417f10',
}
for rel,digest in {**paths,**preserve}.items():assert sha(ROOT/rel)==digest,rel
for name in ['bounded-comparison-3pair.json','cumulative-comparison-3pair.json']:
    c=json.loads((HERE/name).read_text(encoding='utf-8'))
    assert c['completed_pairs']==3 and c['aggregate']['overall_improvement']>0
assert json.loads((HERE/'parent-plan-verification.json').read_text(encoding='utf-8'))['status']=='PASS'
def result(label):return json.loads((FTS/(label+'-counted-order-final.json')).read_text(encoding='utf-8'))
official=result('r33-bounded-official-final-test-v2-a1')
candidate=result('r33-bounded-candidate-final-test-v2-opt-a2')
negative=result('r33-unbounded-negative-final-test-v2-opt-a1')
assert official['status']==candidate['status']=='PASS'
assert official['records']==candidate['records'] and len(official['records'])==104
assert negative['status']=='FAIL_DIFFERENTIAL' and len(negative['differences'])==21
assert 'Expected exactly 104 actual and reference records' in (FTS/'r33-bounded-empty-reference-opt-a1-counted-order-final.log').read_text(encoding='utf-8')
for label in ['r33-bounded-candidate-regression-a2','r33-bounded-official-final-test-v2-a1','r33-bounded-candidate-final-test-v2-opt-a2']:
    r=json.loads((FTS/(label+'-experiment.json')).read_text(encoding='utf-8'))
    assert all(a['exit_code']==0 for a in r['actions'])
r=json.loads((FTS/'r33-bounded-candidate-regression-a1-experiment.json').read_text(encoding='utf-8'))
assert [a['action'] for a in r['actions'][:3]]==['ranked','keytypes','counted-limit']
assert all(a['exit_code']==0 for a in r['actions'][:3])
git('add','--',*paths)
assert set(git('diff','--cached','--name-only',capture=True).splitlines())==set(paths)
git('diff','--cached','--check')
git('commit','-m','perf(sql): avoid unobserved full-text ordering for counted limits')
git('push','origin','codex/fts-performance-competition')
head=git('rev-parse','HEAD',capture=True)
remote=git('ls-remote','origin','refs/heads/codex/fts-performance-competition',capture=True).split()[0]
assert head==remote
for rel,digest in preserve.items():assert sha(ROOT/rel)==digest,rel
with (HERE/'production-commit.json').open('x',encoding='utf-8') as f:
    json.dump(dict(status='COMMITTED_AND_PUSHED',head=head,remote=remote,paths=paths,final_regression_cases=104,negative_control_differences=21,pythonoptimize_1='correct candidate passes; defective candidate and empty reference fail',performance='3 full incremental pairs and 3 full cumulative pairs, all signed; local only'),f,indent=2);f.write('\n')
print('VERIFIED REMOTE',head)
