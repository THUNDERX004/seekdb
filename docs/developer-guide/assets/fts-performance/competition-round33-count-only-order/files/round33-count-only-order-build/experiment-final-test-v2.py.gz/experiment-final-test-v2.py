"""Local, isolated competition experiments; never changes official workloads."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import socket
import subprocess
import tempfile
import time

ROOT = Path(r'D:\Projects\OceanBase\seekdb')
HERE = Path(__file__).resolve().parent.parent
PYTHON = Path(r'C:\Users\11946\Documents\ChatGPT\OceanBase比赛\.venv\Scripts\python.exe')

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--binary', required=True)
    p.add_argument('--label', required=True)
    p.add_argument('--source', required=True)
    p.add_argument('--base-dir', help='Optional unique temporary server data directory')
    p.add_argument('--log-level', choices=['WARN', 'DEBUG'], default='WARN')
    p.add_argument('--sort-metadata', action='store_true')
    p.add_argument('--record-sort-metadata', action='store_true')
    p.add_argument('--stopword-ascii', action='store_true')
    p.add_argument('--record-stopword-ascii', action='store_true')
    p.add_argument('--port', type=int, default=2891)
    p.add_argument('--benchmark', action='store_true')
    p.add_argument('--counted-boundaries', action='store_true')
    p.add_argument('--counted-order-final', action='store_true')
    p.add_argument('--counted-order-plans', action='store_true')
    p.add_argument('--counted-order-reference')
    p.add_argument('--boundary-reference')
    p.add_argument('--boundary-plans', action='store_true')
    p.add_argument('--counted-limit', action='store_true')
    p.add_argument('--counted-limit-plans', action='store_true')
    p.add_argument('--tests', action='store_true')
    p.add_argument('--query-materialization', action='store_true')
    p.add_argument('--count-union-accounting', action='store_true')
    p.add_argument('--record-query-materialization', action='store_true')
    p.add_argument('--materialization-diagnostic', action='store_true')
    p.add_argument('--casecopy', action='store_true')
    p.add_argument('--record-casecopy', action='store_true')
    p.add_argument('--record-bmp', action='store_true')
    p.add_argument('--bmp', action='store_true')
    p.add_argument('--record-ranked', action='store_true')
    p.add_argument('--ranked', action='store_true')
    p.add_argument('--sortkey-probe', action='store_true')
    p.add_argument('--keytypes', action='store_true')
    p.add_argument('--record-keytypes', action='store_true')
    p.add_argument('--plans', action='store_true')
    p.add_argument('--micro', action='store_true')
    p.add_argument('--etw', action='store_true')
    p.add_argument('--profile', action='append', choices=['ik', 'beng', 'query-cn', 'query-beng', 'query-limit', 'build'])
    p.add_argument('--symbols')
    p.add_argument('--cycle-profile', action='append', choices=['query-cn', 'query-beng', 'build'])
    p.add_argument('--cycle-query-rounds', type=int, default=8000)
    p.add_argument('--cycle-min-samples', type=int, default=1000)
    p.add_argument('--cycle-max-samples', type=int, default=50000)
    p.add_argument('--cycle-interval-ms', type=float, default=1.0)
    p.add_argument('--cycle-pdb')
    p.add_argument('--cycle-dbghelp')
    p.add_argument('--affinity-mask', type=int)
    a = p.parse_args()
    if a.cycle_profile and a.port != 2891:
        p.error('Cycle diagnostics require the dedicated port 2891')
    assert all(c.isalnum() or c in '-_' for c in a.label)
    binary = Path(a.binary).resolve()
    metadata_path = HERE / (a.label + '-experiment.json')
    if metadata_path.exists():
        raise RuntimeError('Refusing to overwrite experiment: ' + str(metadata_path))
    with socket.socket() as s:
        if s.connect_ex(('127.0.0.1', a.port)) == 0:
            raise RuntimeError('Dedicated SQL port already occupied')
    env = os.environ.copy()
    env.update(PYTHONUTF8='1', PYTHONIOENCODING='utf-8')
    env.pop('SEEKDB_TEST_PASSWORD', None)
    base = (Path(a.base_dir).resolve() if a.base_dir else
            Path(tempfile.gettempdir()) / ('seekdb-fts-competition-' + ('baseline' if a.source.startswith('5bce9') else 'candidate')))
    cmd = [str(binary), '--nodaemon', '--base-dir=' + str(base), '--port='+str(a.port),
           '--parameter', 'rpc_port='+str(a.port+1), '--parameter', 'cpu_count=4',
           '--parameter', 'memory_budget=2G', '--parameter', 'log_disk_size=2G', '--log-level='+a.log_level]
    meta = dict(label=a.label, binary=str(binary), source_commit=a.source,
                binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(), log_level=a.log_level, base_dir=str(base), actions=[])
    def run(name, args):
        print('START ' + name, flush=True)
        start = time.perf_counter()
        with (HERE / (a.label + '-' + name + '.log')).open('w', encoding='utf-8') as out:
            result = subprocess.run(args, cwd=ROOT, env=env, stdout=out, stderr=subprocess.STDOUT)
        meta['actions'].append(dict(action=name, exit_code=result.returncode, seconds=time.perf_counter()-start))
        print(('PASS ' if result.returncode == 0 else 'FAIL ') + name, flush=True)
        if result.returncode:
            raise RuntimeError(name + ' failed; see log')
    with (HERE / (a.label + '-server.log')).open('w') as out:
        proc = subprocess.Popen(cmd, cwd=ROOT, stdout=out, stderr=subprocess.STDOUT,
                                creationflags=subprocess.CREATE_NO_WINDOW)
        try:
            if a.affinity_mask is not None:
                import ctypes
                kernel = ctypes.WinDLL('kernel32', use_last_error=True)
                kernel.SetProcessAffinityMask.argtypes = [ctypes.c_void_p, ctypes.c_size_t]
                kernel.SetProcessAffinityMask.restype = ctypes.c_int
                if a.affinity_mask <= 0 or not kernel.SetProcessAffinityMask(int(proc._handle), a.affinity_mask):
                    raise OSError(ctypes.get_last_error(), 'SetProcessAffinityMask')
                kernel.GetProcessAffinityMask.argtypes = [ctypes.c_void_p,
                    ctypes.POINTER(ctypes.c_size_t), ctypes.POINTER(ctypes.c_size_t)]
                kernel.GetProcessAffinityMask.restype = ctypes.c_int
                actual_mask, system_mask = ctypes.c_size_t(), ctypes.c_size_t()
                if not kernel.GetProcessAffinityMask(int(proc._handle), ctypes.byref(actual_mask), ctypes.byref(system_mask)):
                    raise OSError(ctypes.get_last_error(), 'GetProcessAffinityMask')
                if actual_mask.value != a.affinity_mask:
                    raise RuntimeError('Actual process affinity differs from requested mask')
                meta['affinity_mask'] = a.affinity_mask
                meta['affinity_mask_verified'] = actual_mask.value
            import pymysql
            for _ in range(120):
                if proc.poll() is not None:
                    raise RuntimeError('Server exited: ' + str(proc.returncode))
                try:
                    with pymysql.connect(host='127.0.0.1', port=a.port, user='root', connect_timeout=1) as conn:
                        with conn.cursor() as cur:
                            cur.execute('SELECT 1')
                            assert cur.fetchone() == (1,)
                    break
                except (OSError, pymysql.MySQLError):
                    time.sleep(1)
            else:
                raise RuntimeError('Server startup timeout')
            print('READY pid=' + str(proc.pid), flush=True)
            if a.sort_metadata or a.record_sort_metadata:
                args = [str(PYTHON), '-X', 'utf8', str(ROOT/'unittest/sql/engine/sort/test_sort_metadata.py'),
                        '--port', str(a.port), '--plans', str(HERE/(a.label+'-sort-plans.json'))]
                if a.record_sort_metadata:
                    assert a.source == '5bce9e06d1281347ad61344e4b01fab9158c58a2'
                    assert meta['binary_sha256'] == 'bae4a3b9e1b4662d4021b28d5adc085764beb6cf02122eacd57b8e16b6fe1762'
                    args += ['--record', str(ROOT/'unittest/sql/engine/sort/sort_metadata_expected.json.gz'),
                             '--record-source-commit', a.source, '--record-source-binary-sha256', meta['binary_sha256']]
                run('sort-metadata', args)
            if a.stopword_ascii or a.record_stopword_ascii:
                args = [str(PYTHON), '-X', 'utf8', str(ROOT/'unittest/storage/fts/test_stopword_ascii.py'), '--port', str(a.port)]
                if a.record_stopword_ascii:
                    assert a.source == '5bce9e06d1281347ad61344e4b01fab9158c58a2'
                    assert meta['binary_sha256'] == 'bae4a3b9e1b4662d4021b28d5adc085764beb6cf02122eacd57b8e16b6fe1762'
                    args += ['--record', str(ROOT/'unittest/storage/fts/stopword_ascii_expected.json'),
                             '--baseline-revision', a.source, '--baseline-binary-sha256', meta['binary_sha256']]
                run('stopword-ascii', args)
            if a.materialization_diagnostic:
                run('materialization-diagnostic', [str(PYTHON), '-X', 'utf8', str(HERE/'diagnose-materialization.py'), '--port', str(a.port)])
            if a.count_union_accounting:
                run('count-union-accounting', [str(PYTHON), '-X', 'utf8',
                    str(ROOT/'unittest/storage/fts/test_count_union_accounting.py'), '--port', str(a.port)])
            if a.query_materialization or a.record_query_materialization:
                args = [str(PYTHON), '-X', 'utf8', str(ROOT/'unittest/storage/fts/test_query_materialization.py'), '--port', str(a.port)]
                if a.record_query_materialization:
                    assert a.source == '5bce9e06d1281347ad61344e4b01fab9158c58a2', 'Fixtures require official original'
                    assert meta['binary_sha256'] == 'bae4a3b9e1b4662d4021b28d5adc085764beb6cf02122eacd57b8e16b6fe1762'
                    args += ['--record', str(ROOT/'unittest/storage/fts/query_materialization_expected.json.gz'),
                             '--record-source-commit', a.source, '--record-source-binary-sha256', meta['binary_sha256']]
                run('query-materialization', args)
            if a.casecopy or a.record_casecopy:
                args = [str(PYTHON), '-X', 'utf8', str(ROOT/'unittest/storage/fts/test_casecopy.py'), '--port', str(a.port)]
                if a.record_casecopy:
                    assert a.source.startswith('5bce9'), 'Fixtures require official original'
                    args += ['--record', str(ROOT/'unittest/storage/fts/casecopy_expected.json.gz')]
                run('casecopy', args)
            if a.record_bmp or a.bmp:
                args = [str(PYTHON), '-X', 'utf8', str(ROOT/'unittest/storage/fts/test_dictionary_bmp.py'), '--port', str(a.port)]
                if a.record_bmp:
                    assert a.source.startswith('5bce9'), 'Fixtures require official original'
                    args += ['--record', str(ROOT/'unittest/storage/fts/dictionary_bmp_expected.json')]
                run('bmp', args)
            if a.record_ranked or a.ranked:
                args = [str(PYTHON), '-X', 'utf8', str(ROOT/'unittest/storage/fts/test_ranked_batches.py'), '--port', str(a.port)]
                if a.record_ranked:
                    assert a.source.startswith('5bce9'), 'Fixtures require official original'
                    args += ['--record', str(ROOT/'unittest/storage/fts/ranked_batches_expected.json.gz')]
                run('ranked', args)
            if a.keytypes or a.record_keytypes:
                args = [str(PYTHON), '-X', 'utf8', str(ROOT/'unittest/storage/fts/test_ranked_key_types.py'), '--port', str(a.port)]
                if a.record_keytypes:
                    assert a.source.startswith('5bce9'), 'Fixtures require official original'
                    args += ['--record', str(ROOT/'unittest/storage/fts/ranked_key_types_expected.json.gz')]
                run('keytypes', args)
            if a.counted_limit:
                args = [str(PYTHON), '-X', 'utf8', str(ROOT/'unittest/storage/fts/test_counted_limit_projection.py'),
                        '--port', str(a.port), '--plans', str(HERE/(a.label+'-counted-limit-plans.json'))]
                if a.counted_limit_plans:
                    args.append('--check-plans')
                run('counted-limit', args)
            if a.counted_order_final:
                args=[str(PYTHON),'-B','-X','utf8',str(ROOT/'unittest/storage/fts/test_counted_limit_order.py'),'--port',str(a.port),'--output',str(HERE/(a.label+'-counted-order-final.json'))]
                if a.counted_order_plans:
                    args.append('--check-plans')
                if a.counted_order_reference:
                    args += ['--reference',a.counted_order_reference]
                run('counted-order-final',args)
            if a.counted_boundaries:
                boundary_output = HERE / (a.label + '-boundaries.json')
                args = [str(PYTHON), '-X', 'utf8', str(HERE/'round33-count-only-order-build/run-boundaries-v2.py'),
                        '--port', str(a.port), '--output', str(boundary_output)]
                if a.boundary_reference:
                    args += ['--reference', a.boundary_reference]
                if a.boundary_plans:
                    args += ['--check-plans']
                run('counted-boundaries', args)
            if a.tests:
                for test in ['test_hot_path.py', 'test_tokenize_config.py', 'test_collation.py',
                             'test_match_batches.py', 'test_map_concurrency.py',
                             'test_stopword_concurrency.py', 'test_dictionary_prefixes.py']:
                    args = [str(PYTHON), '-X', 'utf8', str(ROOT / 'unittest/storage/fts' / test), '--port', str(a.port)]
                    if test == 'test_hot_path.py' and not a.source.startswith('5bce9'):
                        args.append('--check-plans')
                    run(test, args)
            if a.benchmark:
                report = HERE / (a.label + '-report.txt')
                if report.exists():
                    raise RuntimeError('Refusing to append to existing benchmark report')
                client = (ROOT / 'build/fts-native-client/mysql-native.exe').as_posix()
                env.update(MYSQL=client+' -h127.0.0.1 -P'+str(a.port)+' -uroot -N -s -A --default-character-set=utf8mb4',
                           MYSQL_VERBOSE=client+' -h127.0.0.1 -P'+str(a.port)+' -uroot -A --default-character-set=utf8mb4',
                           LABEL=a.label, ROWS='20000', BATCH='500', ROUNDS='3000', QUERY_ROUNDS='200',
                           SAMPLES='3', WARMUP='30', SKIP_LOAD='0', OUTPUT=report.as_posix())
                run('benchmark', [r'C:\Program Files\Git\bin\bash.exe', 'tools/benchmark/fts_large_bench.sh'])
                run('input-validation', [str(PYTHON), '-X', 'utf8', 'tools/benchmark/fts_large_bench_score.py', str(report)])
                meta['report'] = str(report)
            if a.plans:
                run('plans', [str(PYTHON), '-X', 'utf8', str(HERE/'explain-competition.py'), '--port', str(a.port)])
            if a.etw:
                assert a.port == 2891
                run('etw', [str(PYTHON), '-X', 'utf8', str(HERE/'trace-competition.py'), '--label', a.label])
            if a.micro:
                assert a.port == 2891
                run('micro', [str(PYTHON), '-X', 'utf8', str(HERE/'micro-competition.py'), '--label', a.label])
            if a.sortkey_probe:
                assert a.port == 2891
                run('sortkey-probe', [str(PYTHON), '-X', 'utf8', str(HERE/'probe-sortkeys.py')])
            for workload in a.profile or []:
                assert a.port == 2891
                args = [str(PYTHON), '-X', 'utf8', str(HERE/'sample-competition.py'),
                        str(proc.pid), workload, '--binary', str(binary), '--label', a.label]
                if a.symbols:
                    args += ['--symbols', a.symbols]
                run('profile-'+workload, args)
            for workload in a.cycle_profile or []:
                pdb = Path(a.cycle_pdb).resolve() if a.cycle_pdb else binary.with_suffix('.pdb')
                output = HERE / (a.label + '-cycle-' + workload + '.json')
                args = [str(PYTHON), '-X', 'utf8', str(HERE/'round18-cycle-profile/sample-competition.py'),
                        str(proc.pid), workload, '--binary', str(binary), '--pdb', str(pdb),
                        '--output', str(output), '--query-rounds', str(a.cycle_query_rounds),
                        '--min-samples', str(a.cycle_min_samples), '--max-samples', str(a.cycle_max_samples),
                        '--interval-ms', str(a.cycle_interval_ms)]
                if workload == 'build':
                    args += ['--diagnostic-database', 'fts_cycle_r18_' + a.label.replace('-', '_')]
                if a.cycle_dbghelp:
                    args += ['--dbghelp', str(Path(a.cycle_dbghelp).resolve())]
                run('cycle-'+workload, args)
        finally:
            meta['owned_server_pid'] = proc.pid
            meta['owned_server_exit_before_cleanup'] = proc.poll()
            if proc.poll() is None:
                proc.terminate()
                try:
                    proc.wait(timeout=20)
                except subprocess.TimeoutExpired:
                    proc.kill()
                    proc.wait()
            meta['owned_server_exit_after_cleanup'] = proc.returncode
            metadata_path.write_text(json.dumps(meta, indent=2)+'\n', encoding='utf-8')
    print('COMPLETE '+a.label, flush=True)

if __name__ == '__main__':
    main()
