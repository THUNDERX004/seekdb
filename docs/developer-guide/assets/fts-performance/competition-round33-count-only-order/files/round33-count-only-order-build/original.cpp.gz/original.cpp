/*
 * Copyright (c) 2025 OceanBase.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#define USING_LOG_PREFIX SQL_REWRITE
#include "sql/rewrite/ob_transform_pre_process.h"
#include "sql/optimizer/ob_optimizer_util.h"
#include "sql/engine/expr/ob_expr_arg_case.h"
#include "sql/resolver/dml/ob_select_resolver.h"
#include "sql/rewrite/ob_expand_aggregate_utils.h"
#include "sql/pl/ob_pl_resolver.h"
#include "sql/engine/expr/ob_expr_align_date4cmp.h"
#include "query/vector/ob_vector_index_util.h"

using namespace oceanbase::common;
using namespace oceanbase::share;
using namespace oceanbase::share::schema;
namespace oceanbase
{
using namespace common;
namespace sql
{
int ObTransformPreProcess::transform_one_stmt(common::ObIArray<ObParentDMLStmt> &parent_stmts,
                                              ObDMLStmt *&stmt,
                                              bool &trans_happened)
{
  int ret = OB_SUCCESS;
  trans_happened = false;
  bool is_happened = false;
  ObDMLStmt *limit_stmt = NULL;
  if (OB_ISNULL(stmt) || OB_ISNULL(ctx_) || OB_ISNULL(ctx_->allocator_)) {
    ret = OB_INVALID_ARGUMENT;
  } else if (OB_FAIL(ObTransformUtils::right_join_to_left(stmt))) {
  } else if (OB_FAIL(stmt->adjust_duplicated_table_names(*ctx_->allocator_, is_happened))) {
  } else if (OB_FAIL(THIS_WORKER.check_status())) {
  } else {
    trans_happened |= is_happened;
    OPT_TRACE("adjust duplicated table name", is_happened);

    if (OB_SUCC(ret)) {
      if (OB_FAIL(flatten_conditions(stmt, is_happened))) {
      } else {
        trans_happened |= is_happened;
        OPT_TRACE("flatten condition:", is_happened);
      }
    }  
    if (OB_SUCC(ret)) {
      if (OB_FAIL(try_gen_straight_join_leading(stmt, is_happened))) {
      } else {
        trans_happened |= is_happened;
        OPT_TRACE("generate straight join leading", is_happened);
      }
    }  
    if (OB_SUCC(ret) && parent_stmts.empty()) {
      if (OB_FAIL(expand_correlated_cte(stmt, is_happened))) {
      } else {
        trans_happened |= is_happened;
        OPT_TRACE("expand correlated cte", is_happened);
      }
    }
    if (OB_SUCC(ret)) {
      if (OB_FAIL(transform_json_object_expr_with_star(parent_stmts, stmt, is_happened))) {
      } else {
        trans_happened |= is_happened;
        OPT_TRACE("transform for udt columns", is_happened);
      }
    }
    if (OB_SUCC(ret)) {
      if (!stmt->has_vec_approx() && OB_FAIL(transform_semantic_vector_dis_expr(stmt, is_happened))) {
      } else {
        trans_happened |= is_happened;
        OPT_TRACE("transform hybrid semantic vector distance expr:", is_happened);
      }
    }
    if (OB_SUCC(ret)) {
      if (OB_FAIL(add_all_rowkey_columns_to_stmt(stmt, is_happened))) {
      } else {
        trans_happened |= is_happened;
        OPT_TRACE("add all rowkey columns:", is_happened);
      }
    }
    if (OB_SUCC(ret)) {
      if (OB_FAIL(eliminate_having(stmt, is_happened))) {
      } else {
        trans_happened |= is_happened;
        OPT_TRACE("eliminating having statement:", is_happened);
      }
    }
    if (OB_SUCC(ret)) {
      if (OB_FAIL(transform_special_expr(stmt, is_happened))) {
      } else {
        trans_happened |= is_happened;
        OPT_TRACE("transform_special_expr:", is_happened);
      }
    }
    if (OB_SUCC(ret)) {
      if (OB_FAIL(transform_outerjoin_exprs(stmt, is_happened))) {
      } else {
        trans_happened |= is_happened;
        OPT_TRACE("transform outer join exprs:", is_happened);
      }
    }
    if (OB_SUCC(ret)) {
      if (OB_FAIL(transform_for_batch_stmt(stmt, is_happened))) {
      } else {
        trans_happened |= is_happened;
        OPT_TRACE("transform for batch stmt:", is_happened);
      }
    }
    if (OB_SUCC(ret)) {
      if (OB_FAIL(transform_exprs(stmt, is_happened))) {
      } else {
        trans_happened |= is_happened;
        OPT_TRACE("transform exprs:", is_happened);
      }
    }
    /*transform_for_nested_aggregate, transformer_aggr_expr two functions are strongly dependent, must ensure the order of rewriting both*/
    if (OB_SUCC(ret)) {
      if (OB_FAIL(transform_for_nested_aggregate(stmt, is_happened))) {
      } else {
        trans_happened |= is_happened;
        OPT_TRACE("transform for nested aggregate:", is_happened);
      }
      if (OB_SUCC(ret)) {
        if (OB_FAIL(transformer_aggr_expr(stmt, is_happened))) {
        } else {
          trans_happened |= is_happened;
          OPT_TRACE("transform aggr expr:", is_happened);
        }
      }
    }
    if (OB_SUCC(ret)) {
      if (OB_FAIL(transform_full_outer_join(stmt, is_happened))) {
      } else {
        trans_happened |= is_happened;
        OPT_TRACE("transform full outer join:", is_happened);
      }
    }

    if (OB_SUCC(ret)) {
      if (OB_FAIL(preserve_order_for_pagination(NULL == limit_stmt ? stmt : limit_stmt, is_happened))) {
      } else {
        trans_happened |= is_happened;
        OPT_TRACE("preserve order for pagination:", is_happened);
      }
    }

     if (OB_SUCC(ret)) {
      if (OB_FAIL(preserve_order_for_gby(stmt, is_happened))) {
      } else {
        trans_happened |= is_happened;
        OPT_TRACE("preserve order for groupby:", is_happened);
      }
    }

    if (OB_SUCC(ret)) {
      if (OB_FAIL(transform_rollup_exprs(stmt, is_happened))) {
      } else {
        trans_happened |= is_happened;
      }
    }
    if (OB_SUCC(ret)) {
      if (OB_FAIL(transform_for_last_insert_id(stmt, is_happened))) {
      } else {
        trans_happened |= is_happened;
      }
    }
    if (OB_SUCC(ret)) {
      if (stmt->get_match_exprs().count() > 0 &&
          OB_FAIL(preserve_order_for_fulltext_search(stmt, is_happened))) {
      } else {
        trans_happened |= is_happened;
      }
    }
    if (OB_SUCC(ret) && OB_FAIL(reset_view_base(stmt))) {
    }
    if (OB_SUCC(ret)) {
     if (OB_FAIL(stmt->formalize_stmt(ctx_->session_info_))) {
      }
    }
  }
  return ret;
}

int ObTransformPreProcess::need_transform(const common::ObIArray<ObParentDMLStmt> &parent_stmts,
                                          const int64_t current_level,
                                          const ObDMLStmt &stmt,
                                          bool &need_trans)
{
  UNUSED(parent_stmts);
  UNUSED(current_level);
  UNUSED(stmt);
  need_trans = true;
  return OB_SUCCESS;
}

int ObTransformPreProcess::add_all_rowkey_columns_to_stmt(ObDMLStmt *stmt, bool &trans_happened)
{
  int ret = OB_SUCCESS;
  if (OB_ISNULL(stmt) || OB_ISNULL(ctx_) || OB_ISNULL(ctx_->schema_checker_)
      || OB_ISNULL(ctx_->expr_factory_) || OB_ISNULL(ctx_->session_info_)) {
    ret = OB_ERR_UNEXPECTED;
  } else {
    ObIArray<TableItem*> &tables = stmt->get_table_items();
    TableItem *table_item = NULL;
    const ObTableSchema *table_schema = NULL;
    ObSEArray<ColumnItem, 16> column_items;
    for (int64_t i = 0; OB_SUCC(ret) && i < tables.count(); ++i) {
      if (OB_ISNULL(table_item = tables.at(i))) {
        ret = OB_ERR_UNEXPECTED;
      } else if (!table_item->is_basic_table()) {
        /* do nothing */
      } else if (OB_FAIL(ctx_->schema_checker_->get_table_schema(
                                                                 table_item->ref_id_,
                                                                 table_schema))) {
      } else if (OB_ISNULL(table_schema)) {
        ret = OB_ERR_UNEXPECTED;
        LOG_WARN("get invalid table schema", K(table_schema));
      } else if (OB_FAIL(add_all_rowkey_columns_to_stmt(*table_schema, *table_item,
                                                        *ctx_->expr_factory_,
                                                        *stmt,
                                                        column_items))) {
      }
    }

    if (OB_SUCC(ret) && !column_items.empty()) {
      ObIArray<ColumnItem> &orign_column_items = stmt->get_column_items();
      for (int i = 0; OB_SUCC(ret) && i < orign_column_items.count(); ++i) {
        if (OB_ISNULL(orign_column_items.at(i).expr_)) {
          ret = OB_ERR_UNEXPECTED;
        } else if (!orign_column_items.at(i).expr_->is_rowkey_column() &&
                   OB_FAIL(column_items.push_back(orign_column_items.at(i)))) {
        }
      }
      if (OB_SUCC(ret)) {
        if (OB_FAIL(stmt->get_column_items().assign(column_items))) {
        } else {
          trans_happened = true;
        }
      }
    }
  }
  return ret;
}

int ObTransformPreProcess::add_all_rowkey_columns_to_stmt(const ObTableSchema &table_schema,
                                                          const TableItem &table_item,
                                                          ObRawExprFactory &expr_factory,
                                                          ObDMLStmt &stmt,
                                                          ObIArray<ColumnItem> &column_items)
{
  int ret = OB_SUCCESS;
  const ObRowkeyInfo &rowkey_info = table_schema.get_rowkey_info();
  const ObColumnSchemaV2 *column_schema = NULL;
  uint64_t column_id = OB_INVALID_ID;
  ColumnItem *exists_col_item = NULL;
  ObColumnRefRawExpr *rowkey = NULL;
  for (int col_idx = 0; OB_SUCC(ret) && col_idx < rowkey_info.get_size(); ++col_idx) {
    if (OB_FAIL(rowkey_info.get_column_id(col_idx, column_id))) {
    } else if (NULL != (exists_col_item = stmt.get_column_item_by_id(table_item.table_id_,
                                                                     column_id))) {
      if (OB_FAIL(column_items.push_back(*exists_col_item))) {
      }
    } else if (OB_ISNULL(column_schema = (table_schema.get_column_schema(column_id)))) {
      ret = OB_ERR_UNEXPECTED;
    } else if (OB_FAIL(ObRawExprUtils::build_column_expr(expr_factory, *column_schema,
                                                         ctx_->session_info_, rowkey))) {
    } else if (OB_ISNULL(rowkey)) {
      ret = OB_ERR_UNEXPECTED;
    } else {
      ColumnItem column_item;
      rowkey->set_ref_id(table_item.table_id_, column_schema->get_column_id());
      rowkey->set_column_attr(table_item.get_table_name(), column_schema->get_column_name_str());
      rowkey->set_database_name(table_item.database_name_);
      if (!table_item.alias_name_.empty()) {
        rowkey->set_table_alias_name();
      }
      column_item.expr_ = rowkey;
      column_item.table_id_ = rowkey->get_table_id();
      column_item.column_id_ = rowkey->get_column_id();
      column_item.base_tid_ = table_item.ref_id_;
      column_item.base_cid_ = rowkey->get_column_id();
      column_item.column_name_ = rowkey->get_column_name();
      column_item.set_default_value(column_schema->get_cur_default_value());
      if (OB_FAIL(stmt.add_column_item(column_item))) {
      } else if (OB_FAIL(column_items.push_back(column_item))) {
      } else if (FALSE_IT(rowkey->clear_explicited_referece())) {
      } else if (OB_ISNULL(ctx_)) {
        ret = OB_ERR_UNEXPECTED;
      } else if (OB_FAIL(rowkey->formalize(ctx_->session_info_))) {
      } else if (OB_FAIL(rowkey->pull_relation_id())) {
      }
    }
  }
  return ret;
}

int ObTransformPreProcess::formalize_limit_expr(ObDMLStmt &stmt)
{
  int ret = OB_SUCCESS;

  ObRawExpr *limit_expr = stmt.get_limit_expr();
  ObRawExpr *offset_expr = stmt.get_offset_expr();
  ObRawExpr *percent_expr = stmt.get_limit_percent_expr();
  ObSEArray<ObRawExpr *, 4> params;
  bool transed_zero = false;
  ObConstRawExpr *one_expr = NULL;
  ObConstRawExpr *zero_expr = NULL;
  if (OB_ISNULL(ctx_) || OB_ISNULL(ctx_->exec_ctx_) || OB_ISNULL(ctx_->exec_ctx_->get_physical_plan_ctx())
      || OB_ISNULL(ctx_->allocator_)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (limit_expr != NULL) {
    bool is_null_value = false;
    int64_t limit_value = 0;
    ObRawExpr *cmp_expr = NULL;
    if (OB_FAIL(ObTransformUtils::get_expr_int_value(limit_expr,
                                                  &ctx_->exec_ctx_->get_physical_plan_ctx()->get_param_store(),
                                                  ctx_->exec_ctx_,
                                                  ctx_->allocator_,
                                                  limit_value,
                                                  is_null_value))) {
    } else if (OB_FAIL(ObRawExprUtils::build_const_int_expr(*ctx_->expr_factory_,
                                                            ObIntType,
                                                            1,
                                                            one_expr))) {
    } else if (OB_FAIL(ObRawExprUtils::build_const_int_expr(*ctx_->expr_factory_,
                                                            ObIntType,
                                                            0,
                                                            zero_expr))) {
    } else if (OB_FAIL(ObRawExprUtils::create_double_op_expr(*ctx_->expr_factory_, ctx_->session_info_, T_OP_GE, 
                                                            cmp_expr, limit_expr, one_expr))) {
    } else if (!is_null_value && limit_value >= 1) {
      if (OB_FAIL(ObTransformUtils::add_param_bool_constraint(ctx_, cmp_expr, true))) {
      }
    } else {
      stmt.set_limit_offset(zero_expr, NULL);
      transed_zero = true;
      if (OB_FAIL(params.push_back(cmp_expr))) {
      }
    }
  } else if (percent_expr != NULL) {
    bool is_null_value = false;
    double limit_value = 0;
    ObRawExpr *cmp_expr = NULL;
    ObConstRawExpr *double_zero_expr = NULL;
    if (OB_FAIL(ObTransformUtils::get_percentage_value(percent_expr,
                                                       &stmt,
                                                       &ctx_->exec_ctx_->get_physical_plan_ctx()->get_param_store(),
                                                       ctx_->exec_ctx_,
                                                       ctx_->allocator_,
                                                       limit_value,
                                                       is_null_value))) {
    } else if (OB_FAIL(ObRawExprUtils::build_const_double_expr(*ctx_->expr_factory_,
                                                               ObDoubleType,
                                                               0,
                                                               double_zero_expr))) {
    } else if (OB_FAIL(ObRawExprUtils::build_const_int_expr(*ctx_->expr_factory_,
                                                            ObIntType,
                                                            0,
                                                            zero_expr))) {
    } else if (OB_FAIL(ObRawExprUtils::create_double_op_expr(*ctx_->expr_factory_, ctx_->session_info_, T_OP_GT, 
                                                             cmp_expr, percent_expr, double_zero_expr))) {
    } else if (!is_null_value && limit_value > 0) {
      if (OB_FAIL(ObTransformUtils::add_param_bool_constraint(ctx_, cmp_expr, true))) {
      }
    } else {
      stmt.set_limit_percent_expr(NULL);
      stmt.set_limit_offset(zero_expr, NULL);
      transed_zero = true;
      if (OB_FAIL(params.push_back(cmp_expr))) {
      }
    }
  }

  if (OB_FAIL(ret)) {
  } else if (offset_expr != NULL) {
    bool is_null_value = false;
    int64_t offset_value = 0;
    ObRawExpr *cmp_expr = NULL;
    if (OB_FAIL(ObTransformUtils::get_expr_int_value(offset_expr,
                                                  &ctx_->exec_ctx_->get_physical_plan_ctx()->get_param_store(),
                                                  ctx_->exec_ctx_,
                                                  ctx_->allocator_,
                                                  offset_value,
                                                  is_null_value))) {
    } else if (zero_expr == NULL && OB_FAIL(ObRawExprUtils::build_const_int_expr(*ctx_->expr_factory_,
                                                            ObIntType,
                                                            0,
                                                            zero_expr))) {
    } else if (OB_FAIL(ObRawExprUtils::create_double_op_expr(*ctx_->expr_factory_, ctx_->session_info_, T_OP_GE, 
                                                              cmp_expr, offset_expr, zero_expr))) {
    } else if (offset_value >= 0) {
      if (OB_FAIL(ObTransformUtils::add_param_bool_constraint(ctx_, cmp_expr, true))) {
      }
    } else if (is_null_value) {
      stmt.set_limit_offset(zero_expr, NULL);
      transed_zero = true;
      ObRawExpr *new_cond = NULL; 
      if (OB_FAIL(ObRawExprUtils::build_is_not_null_expr(*ctx_->expr_factory_, offset_expr,
                                                     true, new_cond))) {
      } else if (OB_FAIL(params.push_back(new_cond))) {
      }
    } else {
      stmt.set_limit_offset(stmt.get_limit_expr(), zero_expr);
      transed_zero = true;
      if (OB_FAIL(ObTransformUtils::add_param_bool_constraint(ctx_, cmp_expr, false))) {
      }
    }
  } 


  if (OB_SUCC(ret) && params.count() > 0 && transed_zero) {
    ObRawExpr* and_expr = NULL;
    if (OB_FAIL(ObRawExprUtils::build_and_expr(*ctx_->expr_factory_, params, and_expr))) {
    } else  if (OB_FAIL(and_expr->formalize(ctx_->session_info_))) {
    } else if (OB_FAIL(ObTransformUtils::add_param_bool_constraint(ctx_, and_expr, false))) {
    }
  }

  if (OB_SUCC(ret)) {
    ObSEArray<ObSelectStmt *, 2> child_stmts;
    if (OB_FAIL(stmt.get_child_stmts(child_stmts))) {
    }
    for (int64_t i = 0; OB_SUCC(ret) && i < child_stmts.count(); i++) {
      if (OB_ISNULL(child_stmts.at(i))) {
        ret = OB_ERR_UNEXPECTED;
      } else if (OB_FAIL(SMART_CALL(formalize_limit_expr(*child_stmts.at(i))))) {
      }
    }
  }
  return ret;
}


int ObTransformPreProcess::is_subquery_correlated(const ObSelectStmt *stmt,
                                                  hash::ObHashSet<uint64_t> &param_set,
                                                  bool &is_correlated)
{
  int ret = OB_SUCCESS;
  ObArray<ObRawExpr *> relation_exprs;
  ObArray<ObSelectStmt *> child_stmts;
  if (OB_FAIL(stmt->get_relation_exprs(relation_exprs))) {
  } else if (OB_FAIL(stmt->get_child_stmts(child_stmts))) {
  }
  for (int64_t i = 0; OB_SUCC(ret) && !is_correlated && i < relation_exprs.count(); ++i) {
    if (OB_FAIL(has_new_exec_param(relation_exprs.at(i), param_set, is_correlated))) {
    }
  }
  if (OB_SUCC(ret) && !is_correlated && OB_FAIL(add_exec_params(*stmt, param_set))) {
  }
  for (int64_t i = 0; OB_SUCC(ret) && !is_correlated && i < child_stmts.count(); ++i) {
    if (OB_FAIL(SMART_CALL(is_subquery_correlated(child_stmts.at(i), 
                                                  param_set, 
                                                  is_correlated)))) {
    }
  }
  return ret;
}

int ObTransformPreProcess::add_exec_params(const ObSelectStmt &stmt,
                                           hash::ObHashSet<uint64_t> &param_set)
{
  int ret = OB_SUCCESS;
  for (int64_t i = 0; OB_SUCC(ret) && i < stmt.get_subquery_expr_size(); ++i) {
    ObQueryRefRawExpr *query_ref = stmt.get_subquery_exprs().at(i);
    if (OB_ISNULL(query_ref)) {
      ret = OB_ERR_UNEXPECTED;
    }
    for (int64_t j = 0; OB_SUCC(ret) && j < query_ref->get_exec_params().count(); ++j) {
      ObExecParamRawExpr *exec_param = query_ref->get_exec_param(j);
      uint64_t key = reinterpret_cast<uint64_t>(exec_param);
      if (OB_FAIL(param_set.set_refactored(key))) {
        if (OB_HASH_EXIST == ret) {
          ret = OB_SUCCESS;
        } else {
        }
      }
    }
  }
  
  return ret;
}

int ObTransformPreProcess::has_new_exec_param(const ObRawExpr *expr,
                                              const hash::ObHashSet<uint64_t> &param_set,
                                              bool &has_new)
{
  int ret = OB_SUCCESS;
  if (OB_ISNULL(expr)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (expr->is_exec_param_expr()) {
    uint64_t key = reinterpret_cast<uint64_t>(expr);
    int tmp_ret = param_set.exist_refactored(key);
    if (OB_HASH_NOT_EXIST == tmp_ret) {
      has_new = true;
    } else if (OB_UNLIKELY(OB_HASH_EXIST != tmp_ret)) {
      ret = tmp_ret;
    }
  } else if (expr->has_flag(CNT_DYNAMIC_PARAM)) {
    for (int64_t i = 0; OB_SUCC(ret) && !has_new && i < expr->get_param_count(); ++i) {
      if (OB_FAIL(SMART_CALL(has_new_exec_param(expr->get_param_expr(i),
                                                param_set,
                                                has_new)))) {
      }
    }
  }
  return ret;
}


int ObTransformPreProcess::calc_grouping_in_grouping_sets(const ObIArray<ObRawExpr*> &groupby_exprs,
                                                          const ObIArray<ObRawExpr*> &rollup_exprs,
                                                          ObAggFunRawExpr *expr,
                                                          ObRawExpr *&new_expr)
{
  int ret = OB_SUCCESS;
  new_expr = NULL;
  ObConstRawExpr *one_expr = NULL;
  ObSysFunRawExpr *cast_expr = NULL;
  if (OB_ISNULL(expr) ||
      OB_ISNULL(ctx_) ||
      OB_ISNULL(ctx_->expr_factory_) ||
      OB_ISNULL(ctx_->session_info_) ||
      expr->get_expr_type() != T_FUN_GROUPING) {
    ret = OB_ERR_UNEXPECTED;
  } else if (OB_UNLIKELY(expr->get_param_count() != 1)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (ObOptimizerUtil::find_item(groupby_exprs, expr->get_param_expr(0)) ||
             ObOptimizerUtil::find_item(rollup_exprs, expr->get_param_expr(0))) {
    /*do nothing*/
  } else if (OB_FAIL(ObRawExprUtils::build_const_int_expr(*ctx_->expr_factory_,
                                                          ObIntType,
                                                          1,
                                                          one_expr))) {
  } else if (OB_FAIL(ObRawExprUtils::create_cast_expr(*ctx_->expr_factory_,
                                                      one_expr,
                                                      expr->get_result_type(),
                                                      cast_expr,
                                                      ctx_->session_info_))) {
  } else if (OB_FAIL(cast_expr->add_flag(IS_INNER_ADDED_EXPR))) {
  } else {
    new_expr = cast_expr;
  }
  return ret;
}

int ObTransformPreProcess::calc_group_type_aggr_func(const ObIArray<ObRawExpr*> &groupby_exprs,
                                                     const ObIArray<ObRawExpr*> &rollup_exprs,
                                                     const ObIArray<ObGroupbyExpr> &groupby_exprs_list,
                                                     const int64_t cur_index,
                                                     const int64_t origin_groupby_num,
                                                     ObAggFunRawExpr *expr,
                                                     ObRawExpr *&new_expr)
{
  int ret = OB_SUCCESS;
  new_expr = NULL;
  if (OB_ISNULL(expr)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (T_FUN_GROUPING == expr->get_expr_type() &&
             OB_FAIL(calc_grouping_in_grouping_sets(groupby_exprs, rollup_exprs, expr, new_expr))) {
  } else if (T_FUN_GROUPING_ID == expr->get_expr_type()) {
    ret = OB_NOT_SUPPORTED;
    LOG_USER_ERROR(OB_NOT_SUPPORTED, "grouping_id is not supported");
  } else if (T_FUN_GROUP_ID == expr->get_expr_type()) {
    ret = OB_NOT_SUPPORTED;
    LOG_USER_ERROR(OB_NOT_SUPPORTED, "group_id is not supported");
  }
  return ret;
}

/*@brief, ObTransformPreProcess::convert_select_having_in_groupby_stmt:
 * if the expr not in group by expr except in aggr, the expr will replaced with NULL; eg:
 *  select c1, c2, max(c1), max(c2) from t1 group by grouping sets(c1,c2) having c1 > 1 or c2 > 1 or sum(c1) > 2 or sum(c2) > 2;
 * <==>
 *  select c1, NULL, max(c1), max(c1) from t1 group by c1 having c1 > 1 or NULL > 1 or sum(c1) > 2 or sum(c2) > 2
 * union all
 *  select NULL, c2, max(c1), max(c1) from t1 group by c2 having NULL > 1 or c2 > 1 or sum(c1) > 2 or sum(c2) > 2;
 *
 *  select nvl(c1,1),c3 from t1 group by grouping sets(nvl(c1,1),c3);
 * <==>
 *  select nvl(c1,1), NULL from t1 group by nvl(c1,1)
 * union all
 *  select NULL, c3 from t1 group by c3;
 *
 * select nvl(c1,1) + c3 from t1 group by grouping sets(nvl(c1,1),c3);
 *
 */


int ObTransformPreProcess::eliminate_having(ObDMLStmt *stmt, bool &trans_happened)
{
  int ret = OB_SUCCESS;
  trans_happened = false;
  if (OB_ISNULL(stmt)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (!stmt->is_select_stmt()) {
    // do nothing
  } else {
    ObSelectStmt *select_stmt = static_cast<ObSelectStmt *>(stmt);
    if (!select_stmt->has_group_by() && !select_stmt->get_having_exprs().empty()) {
      if (OB_FAIL(append(select_stmt->get_condition_exprs(), select_stmt->get_having_exprs()))) {
      } else {
        select_stmt->get_having_exprs().reset();
        trans_happened = true;
      }
    }
  }
  return ret;
}

int ObTransformPreProcess::transform_special_expr(ObDMLStmt *&stmt, bool &trans_happened)
{
  int ret = OB_SUCCESS;
  trans_happened = false;
  if (OB_ISNULL(stmt) || OB_ISNULL(ctx_)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (OB_ISNULL(ctx_->session_info_)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (ObSQLSessionInfo::USER_SESSION == ctx_->session_info_->get_session_type()) {
    ObInsertStmt *ins_stmt = dynamic_cast<ObInsertStmt*>(stmt);
    if (OB_SUCC(ret) && NULL != ins_stmt) {
      // value exprs for insert stmt is not included in relation expr array.
      ObIArray<ObRawExpr*> &value_vectors = ins_stmt->get_values_vector();
      for (int64_t i = 0; OB_SUCC(ret) && i < value_vectors.count(); ++i) {
        ObRawExpr *expr = value_vectors.at(i);
        bool is_happened = false;
        if (OB_FAIL(transform_expr(*ctx_->expr_factory_,
                                   *ctx_->session_info_,
                                   expr,
                                   is_happened))) {
        } else if(OB_ISNULL(expr)) {
          ret = OB_ERR_UNEXPECTED;
        } else {
          value_vectors.at(i) = expr;
          trans_happened |= is_happened;
        }
      }
    }
  }
  return ret;
}
// Recursively collect all TableItem from from_item, used for subsequent query rewriting
int ObTransformPreProcess::collect_all_tableitem(ObDMLStmt *stmt,
                                                 TableItem *table_item,
                                                 common::ObArray<TableItem*> &table_item_list)
{
  int ret = OB_SUCCESS;
  bool is_stack_overflow = false;
  if (OB_ISNULL(table_item)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (OB_FAIL(check_stack_overflow(is_stack_overflow))) {
  } else if (is_stack_overflow) {
    ret = OB_SIZE_OVERFLOW;
  } else {
    if (table_item->is_joined_table()) {
      JoinedTable *joined_table_item = static_cast<JoinedTable *>(table_item);
      if (OB_FAIL(SMART_CALL(collect_all_tableitem(stmt, joined_table_item->left_table_,
                                                   table_item_list)))) {
      } else if (OB_FAIL(SMART_CALL(collect_all_tableitem(stmt, joined_table_item->right_table_,
                                                          table_item_list)))) {
      }
    } else if (table_item->is_basic_table() &&
               OB_FAIL(add_var_to_array_no_dup(table_item_list, table_item))) {
    }
  }
  return ret;
}

int ObTransformPreProcess::get_inner_aggr_exprs(
    ObSelectStmt *sub_stmt,
    common::ObIArray<ObAggFunRawExpr*>& inner_aggr_exprs)
{
  int ret = OB_SUCCESS;
  if (OB_ISNULL(sub_stmt)) {
    ret = OB_ERR_UNEXPECTED;
  } else {
    common::ObIArray<ObAggFunRawExpr*> &aggr_exprs = sub_stmt->get_aggr_items();
    for (int64_t i = 0; OB_SUCC(ret) && i < aggr_exprs.count(); ++i) {
      if (OB_ISNULL(aggr_exprs.at(i))) {
        ret = OB_ERR_UNEXPECTED;
      } else if (aggr_exprs.at(i)->in_inner_stmt()) {
        /*do nothing.*/
        if (OB_FAIL(add_var_to_array_no_dup(inner_aggr_exprs,
                                            aggr_exprs.at(i)))) {
        } 
      } 
    }
  }
  return ret;
}

int ObTransformPreProcess::get_first_level_output_exprs(
    ObSelectStmt *sub_stmt,
    common::ObIArray<ObRawExpr*>& inner_aggr_exprs)
{
  int ret = OB_SUCCESS;
  if (OB_ISNULL(sub_stmt)) {
    ret = OB_ERR_UNEXPECTED;
  } else {
    common::ObIArray<ObAggFunRawExpr*> &aggr_exprs = sub_stmt->get_aggr_items();
    for (int64_t i = 0; OB_SUCC(ret) && i < aggr_exprs.count(); ++i) {
      if (OB_ISNULL(aggr_exprs.at(i))) {
        ret = OB_ERR_UNEXPECTED;
      } else if (aggr_exprs.at(i)->in_inner_stmt()) {
        /*do nothing.*/
      } else {
        // outer aggr
        int64_t N = aggr_exprs.at(i)->get_param_count();
        for (int64_t j = 0; OB_SUCC(ret) && j < N; ++j) {
          if (OB_ISNULL(aggr_exprs.at(i)->get_param_expr(j))) {
            ret = OB_ERR_UNEXPECTED;
          } else if (aggr_exprs.at(i)->get_param_expr(j)->is_const_expr()) {
            //do nothing
          } else if (OB_FAIL(add_var_to_array_no_dup(inner_aggr_exprs,
                                                     aggr_exprs.at(i)->get_param_expr(j)))) {
          } else { /*do nothing.*/ }
        }
      }
    }
  }
  return ret;
}

int ObTransformPreProcess::generate_child_level_aggr_stmt(ObSelectStmt *select_stmt,
                                                          ObSelectStmt *&sub_stmt)
{
  int ret = OB_SUCCESS;
  ObSEArray<ObRawExpr*, 4> complex_aggr_exprs;
  ObSEArray<ObAggFunRawExpr*, 4> inner_aggr_exprs;

  if (OB_ISNULL(ctx_) || OB_ISNULL(ctx_->stmt_factory_) || OB_ISNULL(ctx_->expr_factory_)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (OB_FAIL(ctx_->stmt_factory_->create_stmt<ObSelectStmt>(sub_stmt))) {
  } else if (FALSE_IT(sub_stmt->set_query_ctx(select_stmt->get_query_ctx()))) {
  } else if (OB_FAIL(sub_stmt->deep_copy(*ctx_->stmt_factory_,
                                         *ctx_->expr_factory_,
                                         *select_stmt))) {
  } else if (OB_FAIL(sub_stmt->adjust_statement_id(ctx_->allocator_,
                                                   ctx_->src_qb_name_,
                                                   ctx_->src_hash_val_))) {
  } else if (OB_FAIL(get_first_level_output_exprs(sub_stmt, complex_aggr_exprs))) {
  } else if (OB_FAIL(get_inner_aggr_exprs(sub_stmt, inner_aggr_exprs)) ) {
  } else {
    sub_stmt->get_aggr_items().reset();
    sub_stmt->get_select_items().reset();
    sub_stmt->get_order_items().reset();
  }
  
  for (int64_t j = 0; OB_SUCC(ret) && j < inner_aggr_exprs.count(); ++j) {
    if (OB_FAIL(add_var_to_array_no_dup(sub_stmt->get_aggr_items(), inner_aggr_exprs.at(j)))) {
    }
  }

  for (int64_t j = 0; OB_SUCC(ret) && j < complex_aggr_exprs.count(); ++j) {
    if (OB_FAIL(ObTransformUtils::create_select_item(*ctx_->allocator_,
                                                            complex_aggr_exprs.at(j),
                                                            sub_stmt))) {
    } else { /*do nothing.*/ }
  }

  return ret;
}

int ObTransformPreProcess::remove_nested_aggr_exprs(ObSelectStmt *stmt)
{
  int ret = OB_SUCCESS;
  if (OB_ISNULL(stmt)) {
    ret = OB_ERR_UNEXPECTED;
  } else {
    ObSEArray<ObAggFunRawExpr *, 4> aggr_exprs;
    for (int64_t i = 0; OB_SUCC(ret) && i < stmt->get_aggr_items().count(); i++) {
      if (OB_ISNULL(stmt->get_aggr_items().at(i))) {
       ret = OB_ERR_UNEXPECTED;
      } else if (stmt->get_aggr_items().at(i)->in_inner_stmt()) {
       /*do nothing.*/
      } else if (OB_FAIL(aggr_exprs.push_back(stmt->get_aggr_items().at(i)))) {
      } else { /*do nothing.*/ }
    }
    if (OB_SUCC(ret)) {
      if (OB_FAIL(stmt->get_aggr_items().assign(aggr_exprs))) {
      }
    }
  }
  return ret;
}

int ObTransformPreProcess::construct_column_items_from_exprs(
    const ObIArray<ObRawExpr*> &column_exprs,
    ObIArray<ColumnItem> &column_items)
{
  int ret = OB_SUCCESS;
  for (int64_t i = 0; OB_SUCC(ret) && i < column_exprs.count(); ++i) {
    ColumnItem column_item;
    ObColumnRefRawExpr* expr = static_cast<ObColumnRefRawExpr*>(column_exprs.at(i));
    column_item.expr_ = expr;
    column_item.table_id_ = expr->get_table_id();
    column_item.column_id_ = expr->get_column_id();
    column_item.column_name_ = expr->get_expr_name();
    if (OB_FAIL(column_items.push_back(column_item))) {
    } else { /*do nothing.*/ }
  }
  return ret;
}

int ObTransformPreProcess::generate_parent_level_aggr_stmt(ObSelectStmt *&select_stmt,
                                                           ObSelectStmt *sub_stmt)
{
  int ret = OB_SUCCESS;
  TableItem *view_table_item = NULL;
  ObSEArray<ObRawExpr *, 4> old_exprs;
  ObSEArray<ObRawExpr *, 4> new_exprs;
  ObSEArray<ColumnItem, 4> column_items;
  if (OB_ISNULL(select_stmt)) {
    ret = OB_ERR_UNEXPECTED;
  } else {
    select_stmt->get_table_items().reset();
    select_stmt->get_joined_tables().reset();
    select_stmt->get_from_items().reset();
    select_stmt->get_column_items().reset();
    select_stmt->get_condition_exprs().reset();
    select_stmt->get_part_exprs().reset();
    select_stmt->get_check_constraint_items().reset();
    select_stmt->get_group_exprs().reset();
    select_stmt->get_rollup_exprs().reset();
    select_stmt->get_having_exprs().reset();
    select_stmt->get_order_items().reset();

    if (OB_FAIL(get_first_level_output_exprs(select_stmt,
                                             old_exprs))) {
    } else if (OB_FAIL(remove_nested_aggr_exprs(select_stmt))) {
    } else if (OB_FAIL(ObTransformUtils::add_new_table_item(ctx_,
                                                            select_stmt,
                                                            sub_stmt,
                                                            view_table_item))) {
    } else if (OB_FAIL(select_stmt->add_from_item(view_table_item->table_id_))) {
    } else if (OB_FAIL(ObTransformUtils::create_columns_for_view(ctx_,
                                                                 *view_table_item,
                                                                 select_stmt,
                                                                 new_exprs))) {
    } else if (OB_FAIL(construct_column_items_from_exprs(new_exprs, column_items))) {
    } else if (OB_FAIL(replace_group_id_in_stmt(select_stmt))) {
    } else if (OB_FAIL(select_stmt->replace_relation_exprs(old_exprs, new_exprs))) {
    } else if (OB_FAIL(select_stmt->get_column_items().assign(column_items))) {
    } else if (OB_FAIL(select_stmt->rebuild_tables_hash())) {
    } else if (OB_FAIL(select_stmt->update_column_item_rel_id())) {
    } else if (OB_FAIL(select_stmt->formalize_stmt(ctx_->session_info_))) {
    } else { /*do nothing.*/ }
  }
  return ret;
}

int ObTransformPreProcess::transform_for_nested_aggregate(ObDMLStmt *&stmt, bool &trans_happened)
{
  int ret = OB_SUCCESS;
  trans_happened = false;
  if (OB_ISNULL(stmt) || OB_ISNULL(ctx_)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (!stmt->is_select_stmt()) {
    /*do nothing.*/
  } else {
    ObSelectStmt *sub_stmt = NULL;
    ObSelectStmt *select_stmt = static_cast<ObSelectStmt *>(stmt);
    /**
     * This function rewrites stmt with nested aggregation into a two-layer stmt
     * select sum(b), max(sum(b)) from t1 group by b;
     * The above SQL can be rewritten as
     * select sum(v.b), max(v.sum_b)
     * from (
     *      select b, sum(b) as sum_b
     *      from t1
     *      group by b
     *      ) v
     * where generate_child_level_aggr_stmt function generates view v
     * generate_parent_level_aggr_stmt generates the outer stmt
     */
    if (!select_stmt->contain_nested_aggr()) {
      /*do nothing.*/
    } else if (OB_FAIL(generate_child_level_aggr_stmt(select_stmt,
                                                      sub_stmt))) {
    } else if (OB_FAIL(generate_parent_level_aggr_stmt(select_stmt,
                                                       sub_stmt))) {
    } else if (OB_FAIL(select_stmt->formalize_stmt(ctx_->session_info_))) {
    } else {
      trans_happened = true;
      stmt = select_stmt;
    }
  }
  return ret;
}

int ObTransformPreProcess::replace_group_id_in_stmt(ObSelectStmt *stmt)
{
  int ret = OB_SUCCESS;
  if (OB_ISNULL(stmt)) {
    ret = OB_ERR_UNEXPECTED;
  } else {
    // replace group_id in select list;
    ObIArray<SelectItem> &sel_items = stmt->get_select_items();
    for (int64_t i = 0; OB_SUCC(ret) && i < sel_items.count(); i++) {
      if (OB_ISNULL(sel_items.at(i).expr_)) {
        ret = OB_ERR_UNEXPECTED;
      } else if (OB_FAIL(replace_group_id_in_expr_recursive(sel_items.at(i).expr_))) {
      }
    }
    // replace group_id in having exprs;
    for (int64_t i = 0; OB_SUCC(ret) && i < stmt->get_having_expr_size(); i++) {
      if (OB_ISNULL(stmt->get_having_exprs().at(i))) {
        ret = OB_ERR_UNEXPECTED;
      } else if (OB_FAIL(replace_group_id_in_expr_recursive(stmt->get_having_exprs().at(i)))) {
      }
    }
    // replace group_id in order by exprs;
    for (int64_t i = 0; OB_SUCC(ret) && i < stmt->get_order_item_size(); i++) {
      if (OB_ISNULL(stmt->get_order_item(i).expr_)) {
        ret = OB_ERR_UNEXPECTED;
      } else if (OB_FAIL(replace_group_id_in_expr_recursive(stmt->get_order_item(i).expr_))) {
      }
    }
  }
  return ret;
}

int ObTransformPreProcess::replace_group_id_in_expr_recursive(ObRawExpr *&expr)
{
  int ret = OB_SUCCESS;
  if (OB_ISNULL(expr) || OB_ISNULL(ctx_) || OB_ISNULL(ctx_->expr_factory_)) {
    ret = OB_ERR_UNEXPECTED;
  } else {
    if (expr->is_aggr_expr()) {
      if (expr->get_expr_type() == T_FUN_GROUP_ID) {
        // replace group id with 0;
        ObConstRawExpr *c_expr = NULL;
        if (OB_FAIL(ObRawExprUtils::build_const_int_expr(*ctx_->expr_factory_,
                                                         ObIntType,
                                                         0,
                                                         c_expr))) {
        } else if (OB_ISNULL(c_expr)) {
          ret = OB_ERR_UNEXPECTED;
        } else {
          expr = c_expr;
        }
      }
    } else {
      ObRawExpr *tmp_expr = NULL;
      for (int64_t i = 0; OB_SUCC(ret) && i < expr->get_param_count(); i++) {
        if (OB_ISNULL(tmp_expr = expr->get_param_expr(i))) {
          ret = OB_ERR_UNEXPECTED;
        } else if (OB_FAIL(replace_group_id_in_expr_recursive(tmp_expr))) {
        }
      }
    }
  }
  return ret;
}

int ObTransformPreProcess::transform_exprs(ObDMLStmt *stmt, bool &trans_happened)
{
  int ret = OB_SUCCESS;
  if (OB_ISNULL(stmt) || OB_ISNULL(ctx_)
      || OB_ISNULL(ctx_->expr_factory_) || OB_ISNULL(ctx_->session_info_)) {
    ret = OB_ERR_UNEXPECTED;
  } else {
    ObSEArray<ObRawExpr*, 8> relation_exprs;
    ObStmtExprGetter getter;
    getter.set_relation_scope();
    getter.add_scope(SCOPE_BASIC_TABLE);
    ObStmtExprReplacer replacer;
    replacer.set_relation_scope();
    replacer.add_scope(SCOPE_BASIC_TABLE);
    replacer.set_recursive(false);
    if (OB_FAIL(stmt->get_relation_exprs(relation_exprs, getter))) {
    } else {
      for (int i = 0; OB_SUCC(ret) && i < relation_exprs.count(); i++) {
        bool is_happened = false;
        ObRawExpr *old_expr = relation_exprs.at(i);
        ObRawExpr *new_expr = relation_exprs.at(i);
        if (OB_ISNULL(old_expr)) {
          ret = OB_ERR_UNEXPECTED;
        } else if (OB_FAIL(transform_expr(*ctx_->expr_factory_,
                                          *ctx_->session_info_,
                                          new_expr,
                                          is_happened))) {
        } else if (!is_happened) {
          // do nothing
        } else if (OB_FAIL(replacer.add_replace_expr(old_expr, new_expr))) {
        } else {
          trans_happened = true;
        }
      }
      if (OB_SUCC(ret) && trans_happened) {
        if (OB_FAIL(stmt->iterate_stmt_expr(replacer))) {
        }
      }
    }
  }
  return ret;
}

int ObTransformPreProcess::transform_expr(ObRawExprFactory &expr_factory,
                                          const ObSQLSessionInfo &session,
                                          ObRawExpr *&expr,
                                          bool &trans_happened)
{
  int ret = OB_SUCCESS;
  if (OB_ISNULL(expr)) {
    ret = OB_INVALID_ARGUMENT;
  }
  if (OB_SUCC(ret)) {
    // rewrite `c1 in (c2, c3)` to `c1 = c2 or c1 = c3`
    if (OB_FAIL(replace_in_or_notin_recursively(
                expr_factory, session, expr, trans_happened))) {
    }
  }
  if (OB_SUCC(ret)) {
    // rewrite
    //   `cast c1 when c2 then xxx when c3 then xxx else xxx end`
    // to:
    //   `cast when c1 = c2 then xxx when c1 = c3 then xxx else xxx end`
    if (OB_FAIL(transform_arg_case_recursively(
                expr_factory, session, expr, trans_happened))) {
    }
  }
  if (OB_SUCC(ret)) {
    // The rewriting is done for the purpose of MySQL compatibility.
    if (OB_FAIL(replace_align_date4cmp_recursively(expr_factory, session, expr))) {
    }
  }
  if (OB_SUCC(ret)) {
    if (OB_FAIL(replace_inner_row_cmp_val_recursively(expr_factory, session,
                                                      expr, trans_happened))) {
    }
  }
  return ret;
}

int ObTransformPreProcess::transform_in_or_notin_expr_without_row(ObRawExprFactory &expr_factory,
                                                                  const ObSQLSessionInfo &session,
                                                                  const bool is_in_expr,
                                                                  ObRawExpr *&in_expr,
                                                                  bool &trans_happened)
{
  int ret = OB_SUCCESS;
  ObRawExpr *left_expr = in_expr->get_param_expr(0);
  ObRawExpr *right_expr = in_expr->get_param_expr(1);
  ObSEArray<DistinctObjMeta, 4> distinct_types;
  for (int i = 0; OB_SUCC(ret) && i < right_expr->get_param_count(); i++) {
    ObRawExpr *param_expr = right_expr->get_param_expr(i);
    if (OB_ISNULL(param_expr)) {
      ret = OB_INVALID_ARGUMENT;
    } else {
      ObObjType obj_type = param_expr->get_result_type().get_type();
      ObCollationType coll_type = param_expr->get_result_type().get_collation_type();
      ObCollationLevel coll_level = param_expr->get_result_type().get_collation_level();
      ObScale scale = param_expr->get_result_type().get_scale();
      if (param_expr->is_enum_set_with_subschema()) {
        ObObjMeta obj_meta;
        if (OB_FAIL(ObRawExprUtils::extract_enum_set_collation(param_expr->get_result_type(),
                                                               &session,
                                                               obj_meta))) {
        } else {
          coll_type = obj_meta.get_collation_type();
          coll_level = obj_meta.get_collation_level();
        }
      }
      if (OB_FAIL(ret)) {
      } else if (OB_UNLIKELY(obj_type == ObMaxType)) {
        ret = OB_ERR_UNEXPECTED;
      } else if (OB_FAIL(add_var_to_array_no_dup(distinct_types,
                                DistinctObjMeta(obj_type, coll_type, coll_level, scale)))) {
      } else {
      }
    }
  } // for end

  if (OB_FAIL(ret)) {
    // do nothing
  } else if (1 == distinct_types.count()) {
    // only one type contained in right row expr, do not need rewrite
    // set should_deduce_type = true
    ObOpRawExpr *op_raw_expr = dynamic_cast<ObOpRawExpr *>(in_expr);
    if (OB_ISNULL(op_raw_expr)) {
      ret = OB_ERR_UNEXPECTED;
    } else {
      op_raw_expr->set_add_implicit_cast_for_in_param(true);
    }
  } else {
    ObSEArray<ObRawExpr *, 4> transed_in_exprs;
    ObSEArray<ObRawExpr *, 4> same_type_exprs;
    for (int i = 0; OB_SUCC(ret) && i < distinct_types.count(); i++) {
      same_type_exprs.reuse();
      DistinctObjMeta obj_meta = distinct_types.at(i);
      for (int j = 0; OB_SUCC(ret) && j < right_expr->get_param_count(); j++) {
        ObRawExpr *param_expr = right_expr->get_param_expr(j);
        ObObjType obj_type = param_expr->get_result_type().get_type();
        ObCollationType coll_type = param_expr->get_result_type().get_collation_type();
        ObCollationLevel coll_level = param_expr->get_result_type().get_collation_level();
        ObScale scale = param_expr->get_result_type().get_scale();
        if (param_expr->is_enum_set_with_subschema()) {
          ObObjMeta enum_set_obj_meta;
          if (OB_FAIL(ObRawExprUtils::extract_enum_set_collation(param_expr->get_result_type(),
                                                                &session,
                                                                enum_set_obj_meta))) {
          } else {
            coll_type = enum_set_obj_meta.get_collation_type();
            coll_level = enum_set_obj_meta.get_collation_level();
          }
        }
         DistinctObjMeta tmp_meta(obj_type, coll_type, coll_level, scale);
        if (OB_FAIL(ret)) {
        } else if (obj_meta == tmp_meta
            && OB_FAIL(same_type_exprs.push_back(right_expr->get_param_expr(j)))) {
        } else { /* do nothing */ }
      }  // for end
      if (OB_SUCC(ret) && OB_FAIL(create_partial_expr(expr_factory, session, left_expr, same_type_exprs,
                                                      is_in_expr, transed_in_exprs))) {
      }
    } // for end
    if (OB_FAIL(ret)) {
    } else if (OB_FAIL(get_final_transed_or_and_expr(expr_factory,
                                                     session,
                                                     is_in_expr,
                                                     transed_in_exprs,
                                                     in_expr))) {
    } else {
      trans_happened = true;
    }
  }
  return ret;
}

int ObTransformPreProcess::transform_in_or_notin_expr_with_row(ObRawExprFactory &expr_factory,
                                                               const ObSQLSessionInfo &session,
                                                               const bool is_in_expr,
                                                               ObRawExpr *&in_expr,
                                                               bool &trans_happened)
{
  int ret = OB_SUCCESS;
  ObRawExpr *left_expr = in_expr->get_param_expr(0);
  ObRawExpr *right_expr = in_expr->get_param_expr(1);
  int row_dim = T_REF_QUERY != left_expr->get_expr_type() ? left_expr->get_param_count() :
                                    static_cast<ObQueryRefRawExpr*>(left_expr)->get_output_column();
  ObSEArray<ObSEArray<DistinctObjMeta, 4>, 4> distinct_row_types;
  ObSEArray<ObSEArray<DistinctObjMeta, 4>, 4> all_row_types;

  for (int i = 0; OB_SUCC(ret) && i < right_expr->get_param_count(); i++) {
    if (OB_ISNULL(right_expr->get_param_expr(i))) {
      ret = OB_INVALID_ARGUMENT;
    } else if (OB_UNLIKELY(right_expr->get_param_expr(i)->get_param_count() != row_dim)) {
      ret = OB_INVALID_ARGUMENT;
      LOG_WARN("invalid param cnt", K(row_dim),
               K(right_expr->get_param_expr(i)->get_param_count()));
    } else {
      ObSEArray<DistinctObjMeta, 4> tmp_row_type;
      for (int j = 0; OB_SUCC(ret) && j < right_expr->get_param_expr(i)->get_param_count();
           j++) {
        if (OB_ISNULL(right_expr->get_param_expr(i)->get_param_expr(j))) {
          ret = OB_INVALID_ARGUMENT;
        } else {
          const ObRawExpr *param_expr = right_expr->get_param_expr(i)->get_param_expr(j);
          const ObObjType obj_type = param_expr->get_result_type().get_type();
          const ObCollationType coll_type = param_expr->get_result_type().get_collation_type();
          const ObCollationLevel coll_level = param_expr->get_result_type().get_collation_level();
          const ObScale scale = param_expr->get_result_type().get_scale();
          if (OB_UNLIKELY(obj_type == ObMaxType)) {
            ret = OB_ERR_UNEXPECTED;
          } else if (OB_FAIL(tmp_row_type.push_back(
                               DistinctObjMeta(obj_type, coll_type, coll_level, scale)))) {
          } else { /* do nothing */ }
        }
      } // for end
      if (OB_FAIL(ret)) {
        // do nothing
      } else if (OB_FAIL(add_row_type_to_array_no_dup(distinct_row_types, tmp_row_type))) {
      } else if (OB_FAIL(all_row_types.push_back(tmp_row_type))) {
      } else { /* do nothing */ }
    }
  } // for end
  if (OB_FAIL(ret)) {
    // do nothing
  } else if (1 == distinct_row_types.count()) {
    // all rows are same, do nothing
    ObOpRawExpr *op_raw_expr = dynamic_cast<ObOpRawExpr *>(in_expr);
    if (OB_ISNULL(op_raw_expr)) {
      ret = OB_ERR_UNEXPECTED;
    } else {
      op_raw_expr->set_add_implicit_cast_for_in_param(true);
    }
  } else {
    ObSEArray<ObRawExpr *, 4> transed_in_exprs;
    ObSEArray<ObRawExpr *, 4> same_type_exprs;
    for (int i = 0; OB_SUCC(ret) && i < distinct_row_types.count(); i++) {
      same_type_exprs.reuse();
      for (int j = 0; OB_SUCC(ret) && j < all_row_types.count(); j++) {
        if (is_same_row_type(distinct_row_types.at(i), all_row_types.at(j)) &&
            OB_FAIL(same_type_exprs.push_back(right_expr->get_param_expr(j)))) {
        }
      } // for end
      if (OB_SUCC(ret) && OB_FAIL(create_partial_expr(expr_factory, session, left_expr, same_type_exprs,
                                                      is_in_expr, transed_in_exprs))) {
      }
    } // for end
    if (OB_FAIL(ret)) {
    } else if (OB_FAIL(get_final_transed_or_and_expr(
                expr_factory, session, is_in_expr, transed_in_exprs, in_expr))) {
    } else {
      trans_happened = true;
    }
  }
  return ret;
}

int ObTransformPreProcess::create_partial_expr(ObRawExprFactory &expr_factory,
                                               const ObSQLSessionInfo &session,
                                               ObRawExpr *left_expr,
                                               ObIArray<ObRawExpr*> &same_type_exprs,
                                               const bool is_in_expr,
                                               ObIArray<ObRawExpr*> &transed_in_exprs)
{
  int ret = OB_SUCCESS;
  ObOpRawExpr *tmp_expr = NULL;
  ObOpRawExpr *tmp_row_expr = NULL;
  ObRawExpr *tmp_left_expr = left_expr;
  ObRawExpr *tmp_right_expr = NULL;
  if (OB_UNLIKELY(same_type_exprs.empty()) || OB_ISNULL(left_expr)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (left_expr->get_expr_type() == T_OP_ROW &&
             OB_FAIL(ObRawExprCopier::copy_expr_node(expr_factory,
                                                     left_expr,
                                                     tmp_left_expr))) {
    // Comment for T_OP_ROW
    // for T_OP_ROW expr, the cast is not added above the expr
    // it is added on the expr's param.
    // when the expr is used by different predicates
    // we may need add different cast for its param
    // hence, we need to copy the expr node.
    // we do not need to copy its param, the param can be shared used.
  } else if (1 == same_type_exprs.count()) { // = / <>
    if (OB_FAIL(expr_factory.create_raw_expr(is_in_expr ? T_OP_EQ : T_OP_NE, tmp_expr))) {
    } else {
      tmp_right_expr = same_type_exprs.at(0);
    }
  } else if (OB_FAIL(expr_factory.create_raw_expr(is_in_expr ? T_OP_IN : T_OP_NOT_IN, tmp_expr)) // in / not in
             || OB_FAIL(expr_factory.create_raw_expr(T_OP_ROW, tmp_row_expr))) {
  } else if (OB_ISNULL(tmp_row_expr)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (OB_FAIL(tmp_row_expr->set_param_exprs(same_type_exprs))) {
  } else {
    tmp_expr->set_add_implicit_cast_for_in_param(true);
    tmp_right_expr = tmp_row_expr;
  }

  if (OB_FAIL(ret)) {
  } else if (OB_ISNULL(tmp_expr) || OB_ISNULL(tmp_left_expr) || OB_ISNULL(tmp_right_expr)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (OB_FAIL(tmp_expr->set_param_exprs(tmp_left_expr, tmp_right_expr))) {
  } else if (OB_FAIL(tmp_expr->formalize(&session))) {
  } else if (OB_FAIL(transed_in_exprs.push_back(tmp_expr))) {
  } else {
  }
  return ret;
}

int ObTransformPreProcess::transform_arg_case_recursively(
    ObRawExprFactory &expr_factory,
    const ObSQLSessionInfo &session,
    ObRawExpr *&expr,
    bool &trans_happened)
{
  int ret = OB_SUCCESS;
  if (T_OP_ARG_CASE == expr->get_expr_type()) {
    if (OB_FAIL(transform_arg_case_expr(expr_factory, session, expr, trans_happened))) {
    }
  }
  for (int64_t i = 0; OB_SUCC(ret) && i < expr->get_param_count(); ++i) {
    if (OB_FAIL(SMART_CALL(transform_arg_case_recursively(expr_factory,
                           session,
                           expr->get_param_expr(i),
                           trans_happened)))) {
    }
  }
  return ret;
}

// in engine 3.0 transform arg_case_when_expr to simple_case_when_expr
// eg:
// case arg when when1 then then1       case when arg = when1 then then1
//          when when1 then then2  ->        when arg = when2 then then2
//          else else1                       else else1
int ObTransformPreProcess::transform_arg_case_expr(ObRawExprFactory &expr_factory,
                                                   const ObSQLSessionInfo &session,
                                                   ObRawExpr *&expr,
                                                   bool &trans_happened)
{
  int ret = OB_SUCCESS;
  ObCaseOpRawExpr *case_expr = static_cast<ObCaseOpRawExpr*>(expr);
  ObRawExpr *arg_expr = case_expr->get_arg_param_expr();
  ObCaseOpRawExpr *new_case_expr = NULL;
  if (OB_FAIL(expr_factory.create_raw_expr(T_OP_CASE, new_case_expr))) {
  } else if (OB_ISNULL(new_case_expr) || OB_ISNULL(arg_expr)) {
    ret = OB_ERR_UNEXPECTED;
  }
  for (int64_t i = 0; OB_SUCC(ret) && i < case_expr->get_when_expr_size(); ++i) {
    ObRawExpr *when_expr = case_expr->get_when_param_expr(i);
    ObRawExpr *then_expr = case_expr->get_then_param_expr(i);
    ObRawExpr *tmp_arg_expr = arg_expr;
    ObOpRawExpr *equal_expr = NULL;
    if (OB_ISNULL(when_expr) || OB_ISNULL(then_expr)) {
      ret = OB_ERR_UNEXPECTED;
    } else if (T_OP_ROW == arg_expr->get_expr_type() &&
               OB_FAIL(ObRawExprCopier::copy_expr_node(expr_factory,
                                                       arg_expr,
                                                       tmp_arg_expr))) {
      // See the Comment for T_OP_ROW above
    } else if (OB_FAIL(create_equal_expr_for_case_expr(expr_factory,
                                                       session,
                                                       tmp_arg_expr,
                                                       when_expr,
                                                       case_expr->get_extra_calc_meta().get_collation_type(),
                                                       equal_expr))) {
    } else if (OB_FAIL(new_case_expr->add_when_param_expr(equal_expr)) ||
              OB_FAIL(new_case_expr->add_then_param_expr(then_expr))) {
    }
  } // for end
  ObRawExpr* tmp_case_expr = static_cast<ObRawExpr*>(new_case_expr);
  if (OB_SUCC(ret) &&
      !case_expr->is_called_in_sql() &&
      OB_FAIL(ObRawExprUtils::set_call_in_pl(tmp_case_expr))) {
  }
  if (OB_SUCC(ret)) {
    new_case_expr->set_default_param_expr(case_expr->get_default_param_expr());
    if (OB_FAIL(new_case_expr->formalize(&session))) {
    } else {
      expr = static_cast<ObRawExpr*>(new_case_expr);
      trans_happened = true;
    }
  }
  return ret;
}

int ObTransformPreProcess::create_equal_expr_for_case_expr(ObRawExprFactory &expr_factory,
                                                           const ObSQLSessionInfo &session,
                                                           ObRawExpr *arg_expr,
                                                           ObRawExpr *when_expr,
                                                           const ObCollationType cmp_cs_type,
                                                           ObOpRawExpr *&equal_expr)
{
  int ret = OB_SUCCESS;
  ObObjType obj_type = ObMaxType;
  const ObRawExprResType &arg_type = arg_expr->get_result_type();
  const ObRawExprResType &when_type = when_expr->get_result_type();
  ObRawExpr *new_when_expr = NULL; // cast expr may added
  ObRawExpr *new_arg_expr = NULL;
  if (OB_ISNULL(arg_expr) || OB_ISNULL(when_expr)) {
    ret = OB_INVALID_ARGUMENT;
  } else if (OB_FAIL(expr_factory.create_raw_expr(T_OP_EQ, equal_expr))) {
  } else {
    if (OB_FAIL(ObExprArgCase::get_cmp_type(obj_type, arg_type.get_type(),
                                            when_type.get_type(),
                                            ObMaxType))) {
    } else if (ob_is_string_type(obj_type)) {
      // when cmp_type is string, need to use case_res_type.calc_type_.cs_type_ as
      // collation type. it is aggregated by all when_exprs.
      // eg: select case col_utf8_general_ci when col_utf8_general_ci then 'a'
      //                                     when col_utf8_bin then 'b' end from tbl;
      //     use col_utf8_bin to compare(see in ObExprArgCase::calc_result_typeN())
      ObRawExprResType cmp_type;
      cmp_type.set_type(obj_type);
      cmp_type.set_collation_type(cmp_cs_type);
      if (OB_FAIL(ObRawExprUtils::try_add_cast_expr_above(&expr_factory, &session,
                                                          *arg_expr, cmp_type, new_arg_expr)) ||
          OB_FAIL(ObRawExprUtils::try_add_cast_expr_above(&expr_factory, &session,
                                                          *when_expr, cmp_type, new_when_expr))) {
      }
    } else {
      new_arg_expr = arg_expr;
      new_when_expr = when_expr;
    }
  }
  if (OB_SUCC(ret)) {
    if (OB_ISNULL(new_when_expr) || OB_ISNULL(new_arg_expr)) {
      ret = OB_ERR_UNEXPECTED;
    } else if (OB_FAIL(equal_expr->set_param_exprs(new_arg_expr, new_when_expr))) {
    }
  }
  return ret;
}

bool ObTransformPreProcess::is_same_row_type(const ObIArray<DistinctObjMeta> &left,
                                             const ObIArray<DistinctObjMeta> &right)
{
  bool ret_bool = true;
  if (left.count() != right.count()) {
    ret_bool = false;
  }
  for (int i = 0; ret_bool && i < left.count(); i++) {
    ret_bool = (left.at(i) == right.at(i));
  } // for end
  return ret_bool;
}

int ObTransformPreProcess::get_final_transed_or_and_expr(
    ObRawExprFactory &expr_factory,
    const ObSQLSessionInfo &session,
    const bool is_in_expr,
    ObIArray<ObRawExpr *> &transed_in_exprs,
    ObRawExpr *&final_or_expr)
{
  int ret = OB_SUCCESS;
  ObOpRawExpr *transed_or_expr = NULL;
  ObOpRawExpr *tmp_or_expr = NULL;
  ObOpRawExpr *last_or_expr = NULL;
  ObItemType op_type = is_in_expr ? T_OP_OR : T_OP_AND;
  if (OB_FAIL(expr_factory.create_raw_expr(op_type, transed_or_expr))) {
  } else if (OB_ISNULL(transed_or_expr)) {
    ret = OB_INVALID_ARGUMENT;
  } else if (OB_FAIL(transed_or_expr->init_param_exprs(2))) {
  } else if (OB_FAIL(transed_or_expr->add_param_expr(transed_in_exprs.at(0)))) {
  } else {
    last_or_expr = transed_or_expr;
    int cur_idx = 1;
    for (; OB_SUCC(ret) && cur_idx < transed_in_exprs.count() - 1; cur_idx++) {
      if (OB_FAIL(expr_factory.create_raw_expr(op_type, tmp_or_expr))) {
      } else if (OB_ISNULL(tmp_or_expr)) {
        ret = OB_INVALID_ARGUMENT;
      } else if (OB_FAIL(tmp_or_expr->init_param_exprs(2))) {
      } else if (OB_FAIL(last_or_expr->add_param_expr(tmp_or_expr))) {
      } else if (OB_FAIL(tmp_or_expr->add_param_expr(transed_in_exprs.at(cur_idx)))) {
      } else {
        last_or_expr = tmp_or_expr;
      }
    }  // for end
    if (OB_FAIL(ret)) {
      // do nothing
    } else if (OB_FAIL(last_or_expr->add_param_expr(transed_in_exprs.at(cur_idx)))) {
    } else if (OB_FAIL(transed_or_expr->formalize(&session))) {
    } else {
      final_or_expr = transed_or_expr;
    }
  }
  return ret;
}

int ObTransformPreProcess::add_row_type_to_array_no_dup(
                             ObIArray<ObSEArray<DistinctObjMeta, 4>> &row_type_array,
                             const ObSEArray<DistinctObjMeta, 4> &row_type)
{
  int ret = OB_SUCCESS;
  bool founded = false;
  for (int i = 0; OB_SUCC(ret) && !founded && i < row_type_array.count(); i++) {
    if (is_same_row_type(row_type_array.at(i), row_type)) {
      founded = true;
    }
  }
  if (!founded && OB_FAIL(row_type_array.push_back(row_type))) {
  }
  return ret;
}

int ObTransformPreProcess::check_and_transform_in_or_notin(ObRawExprFactory &expr_factory,
                                                           const ObSQLSessionInfo &session,
                                                           ObRawExpr *&in_expr,
                                                           bool &trans_happened)
{
  int ret = OB_SUCCESS;
  if (OB_UNLIKELY(2 != in_expr->get_param_count())) {
    ret = OB_INVALID_ARGUMENT;
  } else if (OB_ISNULL(in_expr->get_param_expr(0)) ||
             OB_ISNULL(in_expr->get_param_expr(1))) {
    ret = OB_INVALID_ARGUMENT;
  } else if (T_OP_ROW == in_expr->get_param_expr(0)->get_expr_type() ||
             (T_REF_QUERY == in_expr->get_param_expr(0)->get_expr_type() &&
              static_cast<ObQueryRefRawExpr*>(in_expr->get_param_expr(0))->get_output_column() > 1)) {
    // (x, y) in ((x0, y0), (x1, y1), ...)
    // (select x, y from ...) in ((x0, y0), (x1, y1), ...))
    ret = transform_in_or_notin_expr_with_row(
        expr_factory, session, T_OP_IN == in_expr->get_expr_type(), in_expr, trans_happened);
  } else {
    // x in (x0, x1, ...)
    ret = transform_in_or_notin_expr_without_row(
        expr_factory, session, T_OP_IN == in_expr->get_expr_type(), in_expr, trans_happened);
  }
  if (OB_SUCC(ret)) {
    ObOpRawExpr *op_raw_expr = dynamic_cast<ObOpRawExpr *>(in_expr);
    if (OB_ISNULL(op_raw_expr)) {
      ret = OB_ERR_UNEXPECTED;
    } else if (OB_FAIL(op_raw_expr->formalize(&session))) {
    } else {
    }
  }
  return ret;
}

int ObTransformPreProcess::replace_in_or_notin_recursively(ObRawExprFactory &expr_factory,
                                                           const ObSQLSessionInfo &session,
                                                           ObRawExpr *&root_expr,
                                                           bool &trans_happened)
{
  int ret = OB_SUCCESS;
  for (int i = 0; OB_SUCC(ret) && i < root_expr->get_param_count(); i++) {
    if (OB_ISNULL(root_expr->get_param_expr(i))) {
      ret = OB_INVALID_ARGUMENT;
    } else if (OB_FAIL(SMART_CALL(replace_in_or_notin_recursively(expr_factory,
                                                        session,
                                                        root_expr->get_param_expr(i),
                                                        trans_happened)))) {
    }
  }
  if (OB_SUCC(ret) &&
    (T_OP_IN == root_expr->get_expr_type() || T_OP_NOT_IN == root_expr->get_expr_type())) {
    if (OB_FAIL(check_and_transform_in_or_notin(
                expr_factory, session, root_expr, trans_happened))) {
    }
  }
  return ret;
}

ObItemType ObTransformPreProcess::reverse_cmp_type_of_align_date4cmp(const ObItemType &cmp_type)
{
  ObItemType new_cmp_type = cmp_type;
  switch (cmp_type) {
    case T_OP_LE: {
      new_cmp_type = T_OP_GE;
      break;
    }
    case T_OP_LT: {
      new_cmp_type = T_OP_GT;
      break;
    }
    case T_OP_GE: {
      new_cmp_type = T_OP_LE;
      break;
    }
    case T_OP_GT: {
      new_cmp_type = T_OP_LT;
      break;
    }
    default: {
      break;
    }
  }
  return new_cmp_type;
}

int ObTransformPreProcess::replace_cast_expr_align_date4cmp(ObRawExprFactory &expr_factory,
                                                            const ObSQLSessionInfo &session,
                                                            const ObItemType &cmp_type,
                                                            ObRawExpr *&expr)
{
  int ret = OB_SUCCESS;
  if (OB_ISNULL(expr)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (expr->get_expr_type() == T_FUN_SYS_CAST) {
    const bool is_implicit_cast = !CM_IS_EXPLICIT_CAST(expr->get_cast_mode());
    ObRawExprResType cast_res_type = expr->get_result_type();
    if (is_implicit_cast && (cast_res_type.is_date() || cast_res_type.is_datetime())) {
      ObRawExpr *cast_child = expr->get_param_expr(0);
      if (OB_ISNULL(cast_child)) {
        ret = OB_ERR_UNEXPECTED;
      } else if (ObExprAlignDate4Cmp::is_align_date4cmp_support_obj_type(cast_child->get_data_type())) {
        // create a new align_date4cmp_expr to replace const_expr
        ObSysFunRawExpr *align_date4cmp_expr = NULL;
        if (OB_FAIL(expr_factory.create_raw_expr(T_FUN_SYS_ALIGN_DATE4CMP, align_date4cmp_expr))) {
        } else if (OB_ISNULL(align_date4cmp_expr)) {
          ret = OB_ERR_UNEXPECTED;
        } else if (OB_FAIL(align_date4cmp_expr->init_param_exprs(3))) {
        } else {
          align_date4cmp_expr->set_data_type(expr->get_data_type());
          align_date4cmp_expr->set_accuracy(expr->get_accuracy());
          align_date4cmp_expr->set_func_name("INTERNAL_FUNCTION");
          // Copy cast_mode to facilitate determining the method of handling invalid_time.
          align_date4cmp_expr->set_cast_mode(expr->get_cast_mode());
          // add first param_expr(just the cast_child) to align_date4cmp_expr
          if (OB_FAIL(align_date4cmp_expr->add_param_expr(cast_child))) {
          } else {
            // create second param_expr (a ObConstRawExpr used to represent cmp_type)
            // and add it to align_date4cmp_expr.
            ObConstRawExpr *cmp_type_expr = NULL;
            if (OB_FAIL(ObRawExprUtils::build_const_int_expr(expr_factory,
                                              ObIntType, cmp_type, cmp_type_expr))) {
            } else if (OB_ISNULL(cmp_type_expr)) {
              ret = OB_ERR_UNEXPECTED;
            } else if (OB_FAIL(align_date4cmp_expr->add_param_expr(cmp_type_expr))){
            } else {
              // create third param_expr (a ObConstRawExpr used to represent res_type)
              // and add it to align_date4cmp_expr.
              ObConstRawExpr *res_type_expr = NULL;
              ObObjType cast_res_type = expr->get_result_type().get_type();
              int64_t cast_res_type_int = cast_res_type;
              if (OB_FAIL(ObRawExprUtils::build_const_int_expr(expr_factory,
                                                  ObIntType, cast_res_type_int, res_type_expr))) {
              } else if (OB_ISNULL(res_type_expr)) {
                ret = OB_ERR_UNEXPECTED;
              } else if (OB_FAIL(align_date4cmp_expr->add_param_expr(res_type_expr))){
              } else if (OB_FAIL(align_date4cmp_expr->formalize(&session))) {
              } else {
                // Change the expr pointer pointing to cast_expr
                // to point to the newly created align_date4cmp_expr.
                expr = align_date4cmp_expr;
              }
            }
          }
        }
      }
    }
  }
  return ret;
}

int ObTransformPreProcess::replace_op_row_expr_align_date4cmp(ObRawExprFactory &expr_factory,
                                                            const ObSQLSessionInfo &session,
                                                            const ObItemType &cmp_type,
                                                            ObRawExpr *&left_row_expr,
                                                            ObRawExpr *&right_row_expr)
{
  int ret = OB_SUCCESS;
  if (left_row_expr->get_expr_type() == T_OP_ROW &&
      right_row_expr->get_expr_type() == T_OP_ROW) {
    int64_t expr_cnt = left_row_expr->get_param_count();
    if (right_row_expr->get_param_count() != expr_cnt) {
      ret = OB_INVALID_ARGUMENT;
    } else {
      int64_t last_expr_idx = expr_cnt - 1;
      ObRawExpr *expr0 = left_row_expr->get_param_expr(last_expr_idx);
      ObRawExpr *expr1 = right_row_expr->get_param_expr(last_expr_idx);
      if (OB_ISNULL(expr0) || OB_ISNULL(expr1)) {
        ret = OB_INVALID_ARGUMENT;
      } else {
        const ObItemType reverse_cmp_type = reverse_cmp_type_of_align_date4cmp(cmp_type);
        if (OB_FAIL(replace_cast_expr_align_date4cmp(expr_factory, session, reverse_cmp_type, expr0))) {
        } else {
          left_row_expr->get_param_expr(last_expr_idx) = expr0;
        }

        if (OB_SUCC(ret)) {
          if (OB_FAIL(replace_cast_expr_align_date4cmp(expr_factory, session, cmp_type, expr1))) {
          } else {
            right_row_expr->get_param_expr(last_expr_idx) = expr1;
          }
        }
      }
    }
  }
  return ret;
}

int ObTransformPreProcess::check_and_transform_align_date4cmp(ObRawExprFactory &expr_factory,
                                                              const ObSQLSessionInfo &session,
                                                              ObRawExpr *&cmp_expr,
                                                              const ObItemType &cmp_type)
{
  int ret = OB_SUCCESS;
  if (OB_UNLIKELY(2 != cmp_expr->get_param_count())) {
    ret = OB_INVALID_ARGUMENT;
  } else {
    ObRawExpr *expr0 = cmp_expr->get_param_expr(0);
    ObRawExpr *expr1 = cmp_expr->get_param_expr(1);
    if (OB_ISNULL(expr0) || OB_ISNULL(expr1)) {
      ret = OB_INVALID_ARGUMENT;
    } else if (OB_FAIL(replace_op_row_expr_align_date4cmp(expr_factory, session,
                                        cmp_type, expr0, expr1))){
    } else {
      // By default, align_date4cmp_expr expects the first parameter to be
      // the value on the right side of the comparison operator.
      // Therefore, if you pass the value on the left side,
      // you need to reverse the comparison operator that is passed in.
      const ObItemType reverse_cmp_type = reverse_cmp_type_of_align_date4cmp(cmp_type);
      if (OB_FAIL(replace_cast_expr_align_date4cmp(expr_factory, session, reverse_cmp_type, expr0))) {
      } else {
        cmp_expr->get_param_expr(0) = expr0;
      }

      if (OB_SUCC(ret)) {
        if (OB_FAIL(replace_cast_expr_align_date4cmp(expr_factory, session, cmp_type, expr1))) {
        } else {
          cmp_expr->get_param_expr(1) = expr1;
        }
      }
    }
  }
  return ret;
}

int ObTransformPreProcess::replace_align_date4cmp_recursively(ObRawExprFactory &expr_factory,
                                                              const ObSQLSessionInfo &session,
                                                              ObRawExpr *&root_expr)
{
  int ret = OB_SUCCESS;
  if (OB_ISNULL(root_expr)) {
    ret = OB_ERR_UNEXPECTED;
  }
  // Traverse all exprs from the root.
  for (int i = 0; OB_SUCC(ret) && i < root_expr->get_param_count(); i++) {
    if (OB_ISNULL(root_expr->get_param_expr(i))) {
      ret = OB_INVALID_ARGUMENT;
    } else if (OB_FAIL(SMART_CALL(replace_align_date4cmp_recursively(expr_factory, session,
                                                        root_expr->get_param_expr(i))))) {
    }
  }
  // If the current expression is cmp_expr, check if align_date4cmp transformation is necessary.
  if (OB_SUCC(ret) && IS_COMMON_COMPARISON_OP(root_expr->get_expr_type())) {
    if (OB_FAIL(check_and_transform_align_date4cmp(
                expr_factory, session, root_expr, root_expr->get_expr_type()))) {
    }
  }
  return ret;
}

int ObTransformPreProcess::replace_inner_row_cmp_val_recursively(ObRawExprFactory &expr_factory,
                                                                 const ObSQLSessionInfo &session,
                                                                 ObRawExpr *&root_expr,
                                                                 bool &trans_happened)
{
  int ret = OB_SUCCESS;
  if (OB_ISNULL(root_expr)) {
    ret = OB_INVALID_ARGUMENT;
  }
  for (int64_t i = 0; OB_SUCC(ret) && i < root_expr->get_param_count(); i++) {
    if (OB_ISNULL(root_expr->get_param_expr(i))) {
      ret = OB_INVALID_ARGUMENT;
    } else if (OB_FAIL(SMART_CALL(replace_inner_row_cmp_val_recursively(expr_factory,
                                                                       session,
                                                                       root_expr->get_param_expr(i),
                                                                       trans_happened)))) {
    }
  }
  if (OB_FAIL(ret)) {
  } else if (T_OP_LE <= root_expr->get_expr_type() && T_OP_GT >= root_expr->get_expr_type()) {
    // For row comparisons that are T_OP_LT/T_OP_LE or T_OP_GT/T_OP_GE expressions, need to check
    // whether the range may be expanded. If so, change it to the corresponding inner expression.
    int row_dim = -1;
    if (OB_FAIL(ObRelationalExprOperator::is_row_cmp(*root_expr, row_dim))) {
    } else if (row_dim > 0) {
      if (OB_FAIL(check_and_transform_inner_row_cmp_val(
                expr_factory, session, root_expr, trans_happened))) {
      }
    }
  } else if (T_OP_SQ_LE <= root_expr->get_expr_type() && T_OP_SQ_GT >= root_expr->get_expr_type()) {
    // We also need to handle the comparison of subqueries, only focus on the op_row part of
    // the subquery comparison.
    if (OB_UNLIKELY(2 != root_expr->get_param_count())) {
      ret = OB_ERR_UNEXPECTED;
    } else if ((T_OP_ROW == root_expr->get_param_expr(0)->get_expr_type() &&
                root_expr->get_param_expr(0)->get_expr_type() > 1) ||
               (T_OP_ROW == root_expr->get_param_expr(1)->get_expr_type() &&
                root_expr->get_param_expr(1)->get_expr_type() > 1)) {
      if (OB_FAIL(check_and_transform_inner_row_cmp_val(
                expr_factory, session, root_expr, trans_happened))) {
      }
    }
  }
  return ret;
}

int ObTransformPreProcess::check_and_transform_inner_row_cmp_val(ObRawExprFactory &expr_factory,
                                                                 const ObSQLSessionInfo &session,
                                                                 ObRawExpr *&row_cmp_expr,
                                                                 bool &trans_happened)
{
  int ret = OB_SUCCESS;
  ObRawExpr *left = NULL;
  ObRawExpr *right = NULL;
  bool row_cmp_trans_happened = false;
  const ObItemType op_type = row_cmp_expr->get_expr_type();
  if (OB_UNLIKELY(2 != row_cmp_expr->get_param_count())) {
    ret = OB_INVALID_ARGUMENT;
  } else if (OB_ISNULL(left = row_cmp_expr->get_param_expr(0)) ||
             OB_ISNULL(right = row_cmp_expr->get_param_expr(1))) {
    ret = OB_INVALID_ARGUMENT;
  } else if (!((T_OP_LE <= op_type && T_OP_GT >= op_type) ||
               (T_OP_SQ_LE <= op_type && T_OP_SQ_GT >= op_type))) {
    ret = OB_INVALID_ARGUMENT;
  } else if (T_OP_ROW != left->get_expr_type() && T_OP_ROW != right->get_expr_type()) {
    ret = OB_INVALID_ARGUMENT;
  } else if (T_OP_ROW == left->get_expr_type() &&
             OB_FAIL(transform_inner_op_row_cmp_for_decimal_int<true>(expr_factory,
                                                                      session,
                                                                      row_cmp_expr,
                                                                      left,
                                                                      row_cmp_trans_happened))) {
  } else if (T_OP_ROW == right->get_expr_type() &&
            OB_FAIL(transform_inner_op_row_cmp_for_decimal_int<false>(expr_factory,
                                                                       session,
                                                                       row_cmp_expr,
                                                                       right,
                                                                       row_cmp_trans_happened))) {
  } else if (row_cmp_trans_happened) {
    ObOpRawExpr *op_raw_expr = dynamic_cast<ObOpRawExpr *>(row_cmp_expr);
    if (OB_ISNULL(op_raw_expr)) {
      ret = OB_ERR_UNEXPECTED;
    } else if (OB_FALSE_IT(op_raw_expr->get_param_expr(0) = left)) {
    } else if (OB_FALSE_IT(op_raw_expr->get_param_expr(1) = right)) {
    } else if (OB_FAIL(op_raw_expr->formalize(&session))) {
    } else {
      trans_happened = row_cmp_trans_happened;
    }
  }
  return ret;
}

template<bool IS_LEFT>
static int get_error_ret(const ObItemType op_type)
{
  int error_ret = OB_SUCCESS;
  switch (op_type) {
    case T_OP_LT:
    case T_OP_SQ_LT: {
      // (c1, c2) < (cast_expr, cast_expr) => (c1, c2) < (cast_up(expr), cast_up(expr))
      error_ret = IS_LEFT ? OB_ERR_MAX_VALUE : OB_ERR_MIN_VALUE;
      break;
    }
    case T_OP_GT:
    case T_OP_SQ_GT: {
      // (c1, c2) > (cast_expr, cast_expr) => (c1, c2) > (cast_down(expr), cast_down(expr))
      error_ret = IS_LEFT ? OB_ERR_MIN_VALUE : OB_ERR_MAX_VALUE;
      break;
    }
    case T_OP_LE:
    case T_OP_SQ_LE: {
      // (c1, c2) <= (case_expr, cast_expr) => (c1, c2) <= (cast_down(expr), cast_down(expr))
      error_ret = IS_LEFT ? OB_ERR_MIN_VALUE : OB_ERR_MAX_VALUE;
      break;
    }
    case T_OP_GE:
    case T_OP_SQ_GE: {
      // (c1, c2) >= (cast_expr, cast_expr) => (c1, c2) < (cast_up(expr), cast_up(expr))
      error_ret = IS_LEFT ? OB_ERR_MAX_VALUE : OB_ERR_MIN_VALUE;
      break;
    }
    default:
      break;
  }
  return error_ret;
}

template<bool IS_LEFT>
int ObTransformPreProcess::transform_inner_op_row_cmp_for_decimal_int(
    ObRawExprFactory &expr_factory,
    const ObSQLSessionInfo &session,
    ObRawExpr *&row_cmp_expr,
    ObRawExpr *&row_expr,
    bool &trans_happened)
{
  int ret = OB_SUCCESS;
  // The inner expression will return the result based on whether param 1 and param 2 are equal.
  // If they are not equal, it means that the original range has been enlarged. At this time,
  // an error code needs to be returned. The rules are as follows:
  // if the input expr is on the left and it is greater than the value of the column,
  // OB_ERR_MIN_VALUE should be returned at this time, otherwise it is the opposite.
  const ObItemType op_type = row_cmp_expr->get_expr_type();
  const int error_ret = -get_error_ret<IS_LEFT>(op_type);
  // save the error code in the extra field of the expression to pass information
  const uint64_t extra = static_cast<uint64_t>(error_ret);
  const int64_t row_count = row_expr->get_param_count();
  ObSEArray<ObRawExpr *, 4> new_params;
  bool trans_happened_in_row_op = false;
  for (int64_t i = 0; OB_SUCC(ret) && i < row_count - 1; ++i) {
    ObRawExpr *param_expr = row_expr->get_param_expr(i);
    ObRawExpr *next_expr = row_expr->get_param_expr(i + 1);
    ObRawExpr *new_expr = next_expr;
    const ObRawExprResType &res_type = param_expr->get_result_type();
    if (OB_ISNULL(param_expr) || OB_ISNULL(next_expr)) {
      ret = OB_INVALID_ARGUMENT;
    } else if (param_expr->get_expr_type() == T_FUN_SYS_CAST &&
        ob_is_decimal_int_tc(res_type.get_type()) &&
        CM_IS_CONST_TO_DECIMAL_INT(param_expr->get_cast_mode())) {
      // try to transform cast expr
      ObRawExpr *input_expr = param_expr->get_param_expr(0);
      ObSysFunRawExpr *inner_row_cmp_expr = NULL;
      if (OB_ISNULL(input_expr)) {
        ret = OB_INVALID_ARGUMENT;
      } else if (ob_is_int_uint_tc(input_expr->get_result_type().get_type()) ||
                 ob_is_temporal_type(input_expr->get_result_type().get_type()) ||
                 ob_is_bit_tc(input_expr->get_result_type().get_type())) {
        // ignore this type as input, because it has no decimals there is no loss of precision
      } else if (ob_is_number_or_decimal_int_tc(input_expr->get_result_type().get_type()) &&
                 input_expr->get_result_type().get_scale() != SCALE_UNKNOWN_YET &&
                 input_expr->get_result_type().get_scale() <= res_type.get_scale()) {
        // there are more decimal places, no precision loss, no conversion required
      } else if (OB_FAIL(ObRawExprUtils::build_inner_row_cmp_expr(expr_factory,
                                                                  &session,
                                                                  param_expr,
                                                                  input_expr,
                                                                  next_expr,
                                                                  error_ret,
                                                                  inner_row_cmp_expr))) {
      } else {
        new_expr = inner_row_cmp_expr;
        trans_happened_in_row_op = true;
      }
    }
    if (OB_SUCC(ret)) {
      // The first parameter does not need to be converted
      if (i == 0 && OB_FAIL(new_params.push_back(param_expr))) {
      } else if (OB_FAIL(new_params.push_back(new_expr))) {
      }
    }
  }
  // replace all params expr to new param exprs if tansform happened
  if (OB_FAIL(ret) || !trans_happened_in_row_op) {
  } else if (new_params.count() != row_count) {
    ret = OB_ERR_UNEXPECTED;
  } else {
    // This vector may have multiple values, such as (C1, C2, C3, ..., C). After conversion,
    // it is (C1, inner(c2), inner(c3), ..., inner(c))
    trans_happened = true;
    for (int64_t i = 0; OB_SUCC(ret) && trans_happened && i < row_count; ++i) {
      row_expr->get_param_expr(i) = new_params.at(i);
    }
  }
  return ret;
}

/*@brief ObTransformPreProcess::transformer_aggr_expr is used to expand some complex aggregate functions into ordinary aggregate operations;
* eg:var_pop(expr) ==> SUM(expr*expr) - SUM(expr)* SUM(expr)/ COUNT(expr)) / COUNT(expr)
* where the ObExpandAggregateUtils class mainly involves related functions for expanding complex aggregate functions:
*   1.ObExpandAggregateUtils::expand_aggr_expr ==> used to handle the ordinary aggr function interface
*   2.ObExpandAggregateUtils::expand_window_aggr_expr  ==> used to handle the aggr function interface in window functions
*
 */
int ObTransformPreProcess::transformer_aggr_expr(ObDMLStmt *stmt,
                                                 bool &trans_happened)
{
  int ret = OB_SUCCESS;
  bool is_expand_aggr = false;
  bool is_expand_window_aggr = false;
  bool is_happened = false;
  // The previous logic ensured the order of nested aggregation and ordinary function rewriting, trans_happened includes information on whether a nested aggregation function rewrite occurred
  bool is_trans_nested_aggr_happened = trans_happened;
  trans_happened = false;
  if (OB_ISNULL(stmt) || OB_ISNULL(ctx_) || OB_ISNULL(ctx_->expr_factory_)) {
    ret = OB_INVALID_ARGUMENT;
  } else {
    ObExpandAggregateUtils expand_aggr_utils(*ctx_->expr_factory_,  ctx_->session_info_);
    if (OB_FAIL(expand_aggr_utils.expand_aggr_expr(stmt, is_expand_aggr))) {
    } else if (OB_FAIL(expand_aggr_utils.expand_window_aggr_expr(stmt, is_expand_window_aggr))) {
    } else if (is_trans_nested_aggr_happened) {
      TableItem *table_item = NULL;
      if (OB_UNLIKELY(stmt->get_table_items().count() != 1) ||
          OB_ISNULL(table_item = stmt->get_table_item(0)) ||
          OB_UNLIKELY(!table_item->is_generated_table())) {
        ret = OB_ERR_UNEXPECTED;
      } else if (OB_FAIL(transformer_aggr_expr(table_item->ref_query_, is_happened))) {
      } else {/*do nothing*/}
    }
  }
  if (OB_SUCC(ret)) {
    trans_happened = is_expand_aggr | is_expand_window_aggr | is_happened;
  }
  return ret;
}

int ObTransformPreProcess::transform_json_object_expr_with_star(const ObIArray<ObParentDMLStmt> &parent_stmts,
                                                                ObDMLStmt *stmt, bool &trans_happened)
{
  INIT_SUCC(ret);
  ObSEArray<ObRawExpr*, 4> replace_exprs;

  JsonObjectStarChecker expr_checker(replace_exprs);
  ObStmtExprGetter visitor;
  visitor.checker_ = &expr_checker;
  if (OB_SUCC(ret) && OB_FAIL(stmt->iterate_stmt_expr(visitor))) {
  }

  //collect query udt exprs which need to be replaced
  for (int64_t i = 0; OB_SUCC(ret) && i < replace_exprs.count(); i++) {
    if (OB_ISNULL(replace_exprs.at(i))) {
      ret = OB_ERR_UNEXPECTED;
    } else {
      ObSysFunRawExpr *func_expr = static_cast<ObSysFunRawExpr*>(replace_exprs.at(i));
      if (OB_FAIL(ObTransformUtils::expand_wild_star_to_columns(ctx_, stmt, func_expr))) {
      } else {
        trans_happened = true;
      }
    }
  }

  return ret;
}

int ObTransformPreProcess::add_semantic_vector_dis_params_to_new_expr(ObDMLStmt *stmt, ObRawExpr *semantic_expr, ObRawExpr *&new_semantic_expr)
{
  int ret = OB_SUCCESS;
  ObRawExpr *expr_0 = semantic_expr->get_param_expr(0);
  ObRawExpr *expr_1 = semantic_expr->get_param_expr(1);

  ObRawExpr *chunk_col_ref = nullptr;
  ObRawExpr *query_vector = nullptr;

  ObColumnRefRawExpr *vector_col_ref = nullptr;
  ObRawExpr *cast_query_vector = nullptr;
  ObRawExpr *dis_type = nullptr;

  ObSchemaGetterGuard *schema_guard = nullptr;
  
  if (OB_ISNULL(expr_0) 
      || OB_ISNULL(expr_1) 
      || OB_ISNULL(ctx_)
      || OB_ISNULL(ctx_->session_info_)
      || OB_ISNULL(ctx_->schema_checker_)
      || OB_ISNULL(schema_guard = ctx_->schema_checker_->get_schema_guard())) {
    ret = OB_ERR_UNEXPECTED;
  } else if (expr_0->get_expr_type() != T_REF_COLUMN && expr_1->get_expr_type() != T_REF_COLUMN) {
    ret = OB_ERR_UNEXPECTED;
    LOG_WARN("none param of semantic_distance is col ref", K(expr_0->get_expr_type()), K(expr_1->get_expr_type()));
  } else {
    chunk_col_ref = expr_0->get_expr_type() == T_REF_COLUMN ? expr_0 : expr_1;
    query_vector = expr_0->get_expr_type() == T_REF_COLUMN ? expr_1 : expr_0;
    ObColumnRefRawExpr *raw_chunk_col_ref = static_cast<ObColumnRefRawExpr*>(chunk_col_ref);

    TableItem *table_item = NULL;
    const share::schema::ObTableSchema *data_table_schema = nullptr;
    
    if (OB_ISNULL(table_item = stmt->get_table_item_by_id(raw_chunk_col_ref->get_table_id()))) {
      ret = OB_ERR_UNEXPECTED;
    } else if (OB_FAIL(schema_guard->get_table_schema( table_item->ref_id_, data_table_schema))) {
    } else if (OB_FAIL(create_embedded_table_vector_col_ref(stmt, table_item, data_table_schema, raw_chunk_col_ref, vector_col_ref))) {
    } else if (OB_FAIL(create_cast_query_vector_expr(query_vector, vector_col_ref, cast_query_vector))) {
    } else if (OB_FAIL(create_distance_type_const_expr(stmt, data_table_schema, raw_chunk_col_ref, dis_type))) {
    } else {
      ObSysFunRawExpr *temp_semantic_expr = nullptr;
      if (OB_FAIL(ctx_->expr_factory_->create_raw_expr(T_FUN_SYS_SEMANTIC_VECTOR_DISTANCE, temp_semantic_expr))) {
      } else if (OB_ISNULL(temp_semantic_expr)) {
        ret = OB_ERR_UNEXPECTED;
      } else if (OB_FAIL(temp_semantic_expr->init_param_exprs(3))) {
      } else if (OB_FAIL(temp_semantic_expr->add_param_expr(vector_col_ref))) {
      } else if (OB_FAIL(temp_semantic_expr->add_param_expr(cast_query_vector))) {
      } else if (OB_FAIL(temp_semantic_expr->add_param_expr(dis_type))) {
      } else if (OB_FAIL(temp_semantic_expr->formalize(ctx_->session_info_))) {
      } else {
        new_semantic_expr = temp_semantic_expr;
      }
    }
  }
  return ret;
}

int ObTransformPreProcess::create_embedded_table_vector_col_ref(
    ObDMLStmt *stmt,
    TableItem *table_item,
    const share::schema::ObTableSchema *data_table_schema,
    ObColumnRefRawExpr *chunk_col_ref,
    ObColumnRefRawExpr *&vector_col_ref)
{
  int ret = OB_SUCCESS;
  vector_col_ref = nullptr;
  ColumnItem *exist_column_item = nullptr;
  
  for (int64_t i = 0; OB_SUCC(ret) && i < data_table_schema->get_column_count() && OB_ISNULL(vector_col_ref); ++i) {
    const ObColumnSchemaV2 *col_schema = data_table_schema->get_column_schema_by_idx(i);
    if (OB_ISNULL(col_schema)) {
      ret = OB_ERR_UNEXPECTED;
    } else if (col_schema->is_hybrid_embedded_vec_column()) {
      // check match to chunk col
      bool is_same_index = false;
      ObSEArray<uint64_t, 4> embedded_cascaded_ids;
      if (OB_FAIL(col_schema->get_cascaded_column_ids(embedded_cascaded_ids))) {
      } else {
         for (int64_t j = 0; !is_same_index && j < embedded_cascaded_ids.count(); ++j) {
            if (embedded_cascaded_ids.at(j) == chunk_col_ref->get_column_id()) {
              is_same_index = true;
            }
         }
      }

      if (is_same_index) {
        if (OB_NOT_NULL(exist_column_item = stmt->get_column_item(table_item->table_id_, col_schema->get_column_id()))) {
          vector_col_ref = exist_column_item->expr_;
        } else if (OB_FAIL(ObRawExprUtils::build_column_expr(*ctx_->expr_factory_, *col_schema,
                                                      ctx_->session_info_, vector_col_ref))) {
        } else if (OB_ISNULL(vector_col_ref)) {
          ret = OB_ERR_UNEXPECTED;
        } else {
          vector_col_ref->set_ref_id(table_item->table_id_, col_schema->get_column_id());
          vector_col_ref->set_column_attr(data_table_schema->get_table_name(), col_schema->get_column_name_str());
          vector_col_ref->set_database_name(chunk_col_ref->get_database_name());
          vector_col_ref->del_column_flag(VIRTUAL_GENERATED_COLUMN_FLAG);
          ColumnItem column_item;
          column_item.expr_ = vector_col_ref;
          column_item.table_id_ = vector_col_ref->get_table_id();
          column_item.column_id_ = vector_col_ref->get_column_id();
          column_item.column_name_ = vector_col_ref->get_column_name();
          if (OB_FAIL(stmt->add_column_item(column_item))) {
          } else if (OB_FAIL(vector_col_ref->formalize(ctx_->session_info_))) {
          }
        }
      }
    }
  }

  if (OB_SUCC(ret) && OB_ISNULL(vector_col_ref)) {
    ret = OB_NOT_SUPPORTED;
    LOG_USER_ERROR(OB_NOT_SUPPORTED, "use semantic_vector_distance without hybrid vector index");
  }

  return ret;
}

int ObTransformPreProcess::create_cast_query_vector_expr(
    ObRawExpr *query_vector,
    ObRawExpr *vector_col_ref,
    ObRawExpr *&cast_query_vector)
{
  int ret = OB_SUCCESS;
  cast_query_vector = nullptr;
  
  if (OB_ISNULL(vector_col_ref)) {
    ret = OB_ERR_UNEXPECTED;
  } else {
    ObExprResType dst_type = vector_col_ref->get_result_type();
    ObSysFunRawExpr *cast_expr = nullptr;
    if (OB_FAIL(ObRawExprUtils::create_cast_expr(
        *ctx_->expr_factory_, query_vector, dst_type, cast_expr, ctx_->session_info_))) {
    } else if (OB_ISNULL(cast_expr)) {
      ret = OB_ERR_UNEXPECTED;
    } else {
      cast_query_vector = cast_expr;
    }
  }
  return ret;
}

int ObTransformPreProcess::create_distance_type_const_expr(
    ObDMLStmt *stmt,
    const share::schema::ObTableSchema *data_table_schema,
    ObColumnRefRawExpr *chunk_col_ref,
    ObRawExpr *&dis_type)
{
  int ret = OB_SUCCESS;
  dis_type = nullptr;

  uint64_t column_id = chunk_col_ref->get_column_id();
  ObSchemaGetterGuard *schema_guard = ctx_->schema_checker_->get_schema_guard();
  int64_t vec_dis_type = ObVectorIndexDistAlgorithm::VIDA_MAX;

  share::ObVectorIndexParam vector_index_param;
  bool param_filled = false;
  if (OB_FAIL(share::ObVectorIndexUtil::get_vector_index_param(
      schema_guard, *data_table_schema, column_id, vector_index_param, param_filled))) {
  } else if (!param_filled) {
    ret = OB_ERR_UNEXPECTED;
  } else if (OB_FAIL(share::ObVectorIndexUtil::get_vec_dis_type_from_dis_algorithm(vector_index_param.dist_algorithm_, vec_dis_type))) {
  } else {
    ObConstRawExpr *const_expr = nullptr;
    if (OB_FAIL(ctx_->expr_factory_->create_raw_expr(T_INT, const_expr))) {
    } else if (OB_ISNULL(const_expr)) {
      ret = OB_ERR_UNEXPECTED;
    } else {
      ObObj obj;
      obj.set_int(static_cast<int64_t>(vec_dis_type));
      const_expr->set_value(obj);

      dis_type = const_expr;
    }
  }
  return ret;
}

int ObTransformPreProcess::transform_semantic_vector_dis_expr(ObDMLStmt *stmt, bool &trans_happened)
{
  int ret = OB_SUCCESS;
  trans_happened = false;
  ObSEArray<ObRawExpr*, 4> semantic_vec_dis_exprs;

  if (OB_ISNULL(stmt)) {
    ret = OB_ERR_UNEXPECTED;
  } else {

    SemanticVectorDistExprChecker expr_checker(semantic_vec_dis_exprs);
    ObStmtExprGetter visitor;
    visitor.checker_ = &expr_checker;
    if (OB_FAIL(stmt->iterate_stmt_expr(visitor))) {
    } else {
      ObSEArray<ObRawExpr*, 4> old_exprs;
      ObSEArray<ObRawExpr*, 4> new_exprs;
      
      for (int64_t i = 0; OB_SUCC(ret) && i < semantic_vec_dis_exprs.count(); ++i) {
        ObRawExpr *semantic_expr = semantic_vec_dis_exprs.at(i);
        if (OB_ISNULL(semantic_expr)) {
          ret = OB_ERR_UNEXPECTED;
        } else if (semantic_expr->get_param_count() != 2) {
          ret = OB_ERR_PARAM_SIZE;
        } else {
          ObRawExpr *new_semantic_expr = nullptr;
          if (OB_FAIL(add_semantic_vector_dis_params_to_new_expr(stmt, semantic_expr, new_semantic_expr))) {
          } else if (OB_ISNULL(new_semantic_expr)) {
            ret = OB_ERR_UNEXPECTED;
          } else {
            if (OB_FAIL(old_exprs.push_back(semantic_expr))) {
            } else if (OB_FAIL(new_exprs.push_back(new_semantic_expr))) {
            } else {
              trans_happened = true;
            }
          }
        }
      }

      if (OB_SUCC(ret) && trans_happened && old_exprs.count() > 0) {
        if (OB_FAIL(stmt->replace_relation_exprs(old_exprs, new_exprs))) {
        }
      }
    }

  }
  return ret;
}

//transform batch update stmt to multiple update with nlj:
// update t1 set b=1 where a=1; update t1 set b=2 where a=2; update t1 set b=3 where a=3;...
//-> update t1, (select 1, 1 from dual ...) v set t1.b=v.b where t1.a=v.a;
// batch delete is as batch update
int ObTransformPreProcess::transform_for_upd_del_batch_stmt(ObDMLStmt *batch_stmt,
                                                            ObSelectStmt *inner_view_stmt,
                                                            bool &trans_happened)
{
  int ret = OB_SUCCESS;
  // create select list
  if (OB_FAIL(mock_select_list_for_upd_del(*batch_stmt, *inner_view_stmt))) {
  } else if (OB_FAIL(formalize_batch_stmt(batch_stmt,
                                          inner_view_stmt,
                                          batch_stmt->get_query_ctx()->ab_param_exprs_,
                                          trans_happened))) {
  }
  return ret;
}

int ObTransformPreProcess::transform_for_insertup_batch_stmt(ObDMLStmt *batch_stmt, bool &trans_happened)
{
  int ret = OB_SUCCESS;
  ObInsertStmt *insert_stmt = NULL;
  ObExecContext *exec_ctx = nullptr;
  ObPhysicalPlanCtx *plan_ctx = nullptr;
  ObSQLSessionInfo *session_info = NULL;
  ObSEArray<ObRawExpr*, 4> assignment_params;
  ObSEArray<ObRawExpr*, 4> params;
  ObSEArray<ObRawExpr*, 4> assignments_exprs;
  ObSEArray<ObRawExpr*, 4> group_param_exprs;
  ObPseudoColumnRawExpr *stmt_id_expr = NULL;
  const ParamStore *param_store = nullptr;

  if (OB_ISNULL(ctx_)
      || OB_ISNULL(exec_ctx = ctx_->exec_ctx_)
      || OB_ISNULL(plan_ctx = exec_ctx->get_physical_plan_ctx())
      || OB_ISNULL(session_info = ctx_->session_info_)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (FALSE_IT(param_store = &plan_ctx->get_param_store())) {
    // do nothing
  } else if (OB_ISNULL(batch_stmt) ||
             OB_UNLIKELY(!batch_stmt->is_insert_stmt())) {
    ret = OB_ERR_UNEXPECTED;
  } else if (FALSE_IT(insert_stmt = static_cast<ObInsertStmt*>(batch_stmt))) {
  } else if (FALSE_IT(batch_stmt->get_query_ctx()->ins_values_batch_opt_ = true)) {
  } else if (OB_FAIL(create_stmt_id_expr(stmt_id_expr))) {
  } else if (FALSE_IT(static_cast<ObDelUpdStmt*>(batch_stmt)->set_ab_stmt_id_expr(stmt_id_expr))) {
  } else if (OB_FAIL(insert_stmt->get_all_assignment_exprs(assignments_exprs))) {
  } else if (OB_FAIL(ObRawExprUtils::extract_params(assignments_exprs, assignment_params))) {
  }

  // 1. record assignment params
  for (int64_t i = 0; OB_SUCC(ret) && i < assignment_params.count(); ++i) {
    ObConstRawExpr *param_expr = static_cast<ObConstRawExpr *>(assignment_params.at(i));
    int64_t param_idx = param_expr->get_value().get_unknown();
    if (param_idx < 0 || param_idx >= param_store->count()) {
      ret = OB_ERR_UNEXPECTED;
    } else if (param_store->at(param_idx).is_batch_parameters()
        && !has_exist_in_array(batch_stmt->get_query_ctx()->ab_param_exprs_,
                               static_cast<ObRawExpr*>(param_expr))) {
      ObPseudoColumnRawExpr *group_param_expr = nullptr;
      //create pseudo column for the sql array param
      if (OB_FAIL(create_params_expr(group_param_expr, param_expr, i))) {
      } else if (OB_FAIL(batch_stmt->get_query_ctx()->ab_param_exprs_.push_back(param_expr))) {
      } else if (OB_FAIL(group_param_exprs.push_back(group_param_expr))) {
      }
    }
  }

  // 2. deduce value_vector params
  if (OB_FAIL(ret)) {

  } else if (OB_FAIL(ObRawExprUtils::extract_params(insert_stmt->get_values_vector(), params))) {
  } else {
    common::ObIArray<ObRawExpr*> &value_vector = insert_stmt->get_values_vector();
    const ParamStore &param_store = plan_ctx->get_param_store();
    for (int64_t i = 0; OB_SUCC(ret) && i < params.count(); ++i) {
      ObConstRawExpr *param_expr = static_cast<ObConstRawExpr *>(params.at(i));
      ObPseudoColumnRawExpr *group_id = NULL;
      int64_t param_idx = param_expr->get_value().get_unknown();
      if (param_idx < 0 || param_idx >= param_store.count()) {
        ret = OB_ERR_UNEXPECTED;
      } else if (!param_store.at(param_idx).is_batch_parameters()) {
        // is not batch params
      } else {
        param_expr->set_is_batch_stmt_parameter();
      }
    }
    // Mark the expression in value_vector with a batch parameter flag.
    // The expression will be cleared eval_flag and re-operated
    // only when the subsequent values ​​operator iterates the parameters.
    for (int64_t i = 0; OB_SUCC(ret) && i < value_vector.count(); ++i) {
      if (OB_FAIL(value_vector.at(i)->formalize(session_info))) {
      }
    }
  }

  if (OB_FAIL(ret)) {
  } else if (!group_param_exprs.empty() &&
      OB_FAIL(batch_stmt->replace_relation_exprs(batch_stmt->get_query_ctx()->ab_param_exprs_, group_param_exprs))) {
  } else if (OB_FAIL(insert_stmt->get_group_param_exprs().assign(group_param_exprs))) {
  }

  return ret;
}

int ObTransformPreProcess::transform_for_ins_batch_stmt(ObDMLStmt *batch_stmt,
                                                        bool &trans_happened)
{
  int ret = OB_SUCCESS;
  ObInsertStmt *insert_stmt = NULL;
  ObExecContext *exec_ctx = nullptr;
  ObPhysicalPlanCtx *plan_ctx = nullptr;
  ObSQLSessionInfo *session_info = NULL;
  ObSEArray<ObRawExpr*, 4> params;
  ObPseudoColumnRawExpr *stmt_id_expr = NULL;

  if (OB_ISNULL(ctx_)
      || OB_ISNULL(exec_ctx = ctx_->exec_ctx_)
      || OB_ISNULL(plan_ctx = exec_ctx->get_physical_plan_ctx())
      || OB_ISNULL(session_info = ctx_->session_info_)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (OB_ISNULL(batch_stmt) ||
             OB_UNLIKELY(!batch_stmt->is_insert_stmt())) {
    ret = OB_ERR_UNEXPECTED;
  } else if (FALSE_IT(insert_stmt = static_cast<ObInsertStmt*>(batch_stmt))) {
  } else if (OB_FAIL(create_stmt_id_expr(stmt_id_expr))) {
  } else if (FALSE_IT(batch_stmt->get_query_ctx()->ins_values_batch_opt_ = true)) {
  } else if (FALSE_IT(static_cast<ObDelUpdStmt*>(batch_stmt)->set_ab_stmt_id_expr(stmt_id_expr))) {
  } else if (OB_FAIL(ObRawExprUtils::extract_params(insert_stmt->get_values_vector(), params))) {
  } else {
    common::ObIArray<ObRawExpr*> &value_vector = insert_stmt->get_values_vector();
    const ParamStore &param_store = plan_ctx->get_param_store();
    for (int64_t i = 0; OB_SUCC(ret) && i < params.count(); ++i) {
      ObConstRawExpr *param_expr = static_cast<ObConstRawExpr *>(params.at(i));
      ObPseudoColumnRawExpr *group_id = NULL;
      int64_t param_idx = param_expr->get_value().get_unknown();
      if (param_idx < 0 || param_idx >= param_store.count()) {
        ret = OB_ERR_UNEXPECTED;
      } else if (!param_store.at(param_idx).is_batch_parameters()) {
        // Not batch parameter, no need to mark
      } else {
        param_expr->set_is_batch_stmt_parameter();
      }
    }
    // Marked all batch parameter expressions, need to re-derive the expressions
    // Here because of the special nature of insert values, so we only need to derive the expressions in value_vector
    for (int64_t i = 0; OB_SUCC(ret) && i < value_vector.count(); ++i) {
      if (OB_FAIL(value_vector.at(i)->formalize(session_info))) {
      }
    }
  }

  return ret;
}

int ObTransformPreProcess::check_contain_param_expr(ObDMLStmt *stmt,
                                                    TableItem *table_item,
                                                    bool &contain_param)
{
  int ret = OB_SUCCESS;
  bool is_stack_overflow = false;
  if (OB_ISNULL(table_item)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (OB_FAIL(check_stack_overflow(is_stack_overflow))) {
  } else if (is_stack_overflow) {
    ret = OB_SIZE_OVERFLOW;
  } else if (contain_param) {
    // break;
  } else {
    if (table_item->is_joined_table()) {
      JoinedTable *joined_table_item = static_cast<JoinedTable *>(table_item);
      if (OB_FAIL(ObRawExprUtils::is_contain_params(joined_table_item->get_join_conditions(), contain_param))) {
      } else if (OB_FAIL(SMART_CALL(check_contain_param_expr(stmt, joined_table_item->left_table_, contain_param)))) {
      } else if (OB_FAIL(SMART_CALL(check_contain_param_expr(stmt, joined_table_item->right_table_, contain_param)))) {
      }
    } else if (table_item->is_generated_table()) {
      ObDMLStmt *ref_query_stmt = NULL;
      if (OB_ISNULL(ref_query_stmt = table_item->ref_query_)) {
        ret = OB_ERR_UNEXPECTED;
      } else if (OB_FAIL(check_stmt_contain_param_expr(ref_query_stmt, contain_param))) {
      }
    }
  }
  return ret;
}

int ObTransformPreProcess::check_stmt_contain_param_expr(ObDMLStmt *stmt, bool &contain)
{
  int ret = OB_SUCCESS;
  ObSEArray<ObRawExpr*, 16> related_exprs;
  if (OB_ISNULL(stmt)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (OB_FAIL(stmt->get_relation_exprs(related_exprs))) {
  } else if (OB_FAIL(ObRawExprUtils::is_contain_params(related_exprs, contain))) {
  }
  return ret;
}

int ObTransformPreProcess::check_stmt_can_batch(ObDMLStmt *batch_stmt, bool &contain_param)
{
  int ret = OB_SUCCESS;
  contain_param = false;
  if (OB_ISNULL(batch_stmt)) {
    ret = OB_ERR_UNEXPECTED;
  } else {
    const common::ObIArray<FromItem> &from_items = batch_stmt->get_from_items();
    for (int64_t i = 0; OB_SUCC(ret) && !contain_param && i < from_items.count(); ++i) {
      TableItem *table_item = NULL;
      const FromItem &from_item = from_items.at(i);
      if (OB_ISNULL(table_item = batch_stmt->get_table_item(from_item))) {
        ret = OB_ERR_UNEXPECTED;
      } else if (OB_FAIL(check_contain_param_expr(batch_stmt, table_item, contain_param))) {
      }
    }
  }

  return ret;
}

int ObTransformPreProcess::create_inner_view_stmt(ObDMLStmt *batch_stmt, ObSelectStmt*& inner_view_stmt)
{
  int ret = OB_SUCCESS;
  ObStmtFactory *stmt_factory = NULL;
  if (OB_ISNULL(batch_stmt) || OB_ISNULL(stmt_factory = ctx_->stmt_factory_)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (OB_FAIL(stmt_factory->create_stmt<ObSelectStmt>(inner_view_stmt))) {
  } else {
    inner_view_stmt->set_stmt_type(stmt::T_SELECT);
    inner_view_stmt->set_query_ctx(batch_stmt->get_query_ctx());
    stmt::StmtType stmt_type = batch_stmt->get_stmt_type();
    if (OB_FAIL(inner_view_stmt->adjust_statement_id(ctx_->allocator_,
                                                     ctx_->src_qb_name_,
                                                     ctx_->src_hash_val_))) {
    }
  }
  return ret;
}

int ObTransformPreProcess::transform_for_batch_stmt(ObDMLStmt *batch_stmt, bool &trans_happened)
{
  int ret = OB_SUCCESS;
  ObSelectStmt* inner_view_stmt = NULL;
  ObExecContext *exec_ctx = nullptr;
  stmt::StmtType stmt_type = batch_stmt->get_stmt_type();
  if (OB_ISNULL(ctx_) ||
      OB_ISNULL(ctx_->allocator_) ||
      OB_ISNULL(exec_ctx = ctx_->exec_ctx_) ||
      OB_ISNULL(batch_stmt)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (!exec_ctx->get_sql_ctx()->is_batch_params_execute()) {
    //rewrite only when stmt is batch multi statement
  } else if (!batch_stmt->is_dml_write_stmt()) {
    // Non-dml_stmt temporarily not processed
  } else if (stmt_type == stmt::T_UPDATE || stmt_type == stmt::T_DELETE) {
    int64_t child_size = 0;
    if (OB_FAIL(batch_stmt->get_child_stmt_size(child_size))) {
    } else if (child_size != 0) {
      ret = OB_BATCHED_MULTI_STMT_ROLLBACK;
    } else if (OB_FAIL(create_inner_view_stmt(batch_stmt, inner_view_stmt))) {
    } else if (OB_FAIL(transform_for_upd_del_batch_stmt(batch_stmt, inner_view_stmt, trans_happened))) {
    }
  } else if (stmt_type == stmt::T_INSERT || stmt_type == stmt::T_REPLACE) {
    // rewrite of insert
    int64_t child_size = 0;
    bool can_batch = false;
    ObInsertStmt *insert_stmt = static_cast<ObInsertStmt *>(batch_stmt);
    if (OB_FAIL(check_insert_can_batch(insert_stmt, can_batch))) {
    } else if (!can_batch) {
      ret = OB_BATCHED_MULTI_STMT_ROLLBACK;
    } else if (!insert_stmt->is_insert_up() &&
        OB_FAIL(transform_for_ins_batch_stmt(batch_stmt, trans_happened))) {
    } else if (insert_stmt->is_insert_up() &&
        OB_FAIL(transform_for_insertup_batch_stmt(batch_stmt, trans_happened))) {
    }
  }
  return ret;
}

bool ObTransformPreProcess::check_insertup_support_batch_opt(ObInsertStmt *insert_stmt, bool &can_batch)
{
  int ret = OB_SUCCESS;
  int64_t child_size = 0;
  ObSQLSessionInfo *session_info = NULL;
  if (OB_ISNULL(session_info = ctx_->session_info_)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (OB_ISNULL(insert_stmt)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (insert_stmt->is_insert_up() || insert_stmt->is_replace()) {
    if (OB_FAIL(insert_stmt->get_child_stmt_size(child_size))) {
    } else if (child_size != 0) {
      // with subquery for insertup/replace/insert can't support batch_optimization
      can_batch = false;
    }
  }
  return ret;
}

int ObTransformPreProcess::check_insert_can_batch(ObInsertStmt *insert_stmt, bool &can_batch)
{
  int ret = OB_SUCCESS;
  ObExecContext *exec_ctx = nullptr;
  bool is_multi_query = false; 
  can_batch = true;
  if (OB_ISNULL(ctx_) ||
      OB_ISNULL(exec_ctx = ctx_->exec_ctx_) ||
      OB_ISNULL(exec_ctx->get_sql_ctx())) {
    ret = OB_ERR_UNEXPECTED;
  } else if (FALSE_IT(is_multi_query = exec_ctx->get_sql_ctx()->multi_stmt_item_.is_batched_multi_stmt())) {
    // do nothing
  } else if (insert_stmt->value_from_select()) {
    can_batch = false;
  } else if (!insert_stmt->is_insert_single_value()) {
    can_batch = false;
  } else if (OB_FAIL(check_insertup_support_batch_opt(insert_stmt, can_batch))) {
  } else if (!can_batch) {
    // with subquery for insertup/replace/insert can't support batch_optimization
    can_batch = false;
  } else {
    common::ObIArray<ObRawExpr*> &value_vector = insert_stmt->get_values_vector();
    for (int64_t i = 0; OB_SUCC(ret) && i < value_vector.count(); i++) {
      if (value_vector.at(i)->has_flag(CNT_SUB_QUERY)) {
        can_batch = false;
      }
    }
  }
  return ret;
}

int ObTransformPreProcess::formalize_batch_stmt(ObDMLStmt *batch_stmt,
                                                ObSelectStmt* inner_view_stmt,
                                                const ObIArray<ObRawExpr *> &other_exprs,
                                                bool &trans_happened)
{
  int ret = OB_SUCCESS;
  TableItem *view_table_item = NULL;
  ObSEArray<ObRawExpr *, 4> view_columns;
  ObSQLSessionInfo *session_info = NULL;
  ObRawExpr *stmt_id_expr = NULL;
  if (OB_ISNULL(session_info = ctx_->session_info_)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (OB_FAIL(ObTransformUtils::add_new_table_item(ctx_,
                                                          batch_stmt,
                                                          inner_view_stmt,
                                                          view_table_item))) {
  } else if (OB_ISNULL(view_table_item)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (OB_FAIL(batch_stmt->add_from_item(view_table_item->table_id_, false))) {
  } else if (OB_FAIL(ObTransformUtils::create_columns_for_view(ctx_,
                                                               *view_table_item,
                                                               batch_stmt,
                                                               view_columns))) {
  } else if (OB_ISNULL(stmt_id_expr = view_columns.at(view_columns.count() - 1))) {
    ret = OB_ERR_UNEXPECTED;
  } else if (FALSE_IT(view_columns.pop_back())) {
    // do nothing
  } else if (OB_FAIL(batch_stmt->replace_relation_exprs(other_exprs, view_columns))) {
  } else if (OB_FAIL(ObTransformUtils::adjust_pseudo_column_like_exprs(*batch_stmt))) {
  } else if (OB_FAIL(batch_stmt->formalize_stmt(session_info))) {
  } else {
    trans_happened = true;
    static_cast<ObDelUpdStmt*>(batch_stmt)->set_ab_stmt_id_expr(stmt_id_expr);
    LOG_DEBUG("debug transform_for_batch_stmt",
             K(batch_stmt->get_query_ctx()->ab_param_exprs_), K(view_columns));
  }
  return ret;
}

int ObTransformPreProcess::create_stmt_id_expr(ObPseudoColumnRawExpr *&stmt_id_expr)
{
  int ret = OB_SUCCESS;
  ObRawExprFactory *expr_factory = NULL;
  if (OB_ISNULL(expr_factory = ctx_->expr_factory_)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (OB_FAIL(expr_factory->create_raw_expr(T_PSEUDO_STMT_ID, stmt_id_expr))) {
  } else if (OB_ISNULL(stmt_id_expr)) {
    ret = OB_ERR_UNEXPECTED;
  } else {
    stmt_id_expr->set_data_type(ObIntType);
    stmt_id_expr->set_accuracy(ObAccuracy::MAX_ACCURACY[ObIntType]);
    stmt_id_expr->set_table_id(OB_INVALID_ID);
    stmt_id_expr->set_explicited_reference();
    stmt_id_expr->set_expr_name(ObString::make_string("stmt_id"));
  }
  return ret;
}

int ObTransformPreProcess::create_params_expr(ObPseudoColumnRawExpr *&pseudo_param_expr,
                                              ObRawExpr *origin_param_expr,
                                              int64_t name_id)
{
  int ret = OB_SUCCESS;
  char *pseudo_name = nullptr;
  ObRawExprFactory *expr_factory = NULL;
  const int64_t buf_len = 64;
  int64_t pos = 0;
  if (OB_ISNULL(expr_factory = ctx_->expr_factory_)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (OB_ISNULL(pseudo_name = static_cast<char*>(ctx_->allocator_->alloc(buf_len)))) {
    ret = OB_ALLOCATE_MEMORY_FAILED;
  } else if (OB_FAIL(databuff_printf(pseudo_name, buf_len, pos,
                                     "group_param_%ld", name_id))) {
  } else if (OB_FAIL(expr_factory->create_raw_expr(T_PSEUDO_GROUP_PARAM, pseudo_param_expr))) {
  } else {
    pseudo_param_expr->set_expr_name(ObString(pos, pseudo_name));
    pseudo_param_expr->set_result_type(origin_param_expr->get_result_type());
    pseudo_param_expr->set_table_id(OB_INVALID_ID);
    pseudo_param_expr->set_explicited_reference();
  }
  return ret;
}


// 1、make value_vector as select_list,then extract_calculable_expr
// 2、after pre_calc, generate the mock select_list for inner_view


int ObTransformPreProcess::mock_select_list_for_upd_del(ObDMLStmt &batch_stmt,
                                                        ObSelectStmt &inner_view)
{
  int ret = OB_SUCCESS;
  const ParamStore *param_store = nullptr;
  ObExecContext *exec_ctx = nullptr;
  ObPhysicalPlanCtx *plan_ctx = nullptr;
  ObSEArray<ObRawExpr*, 4> params;
  ObSEArray<ObRawExpr*, 8> related_exprs;
  ObSEArray<ObRawExpr *, 4> select_list;

  if (OB_ISNULL(ctx_)
      || OB_ISNULL(exec_ctx = ctx_->exec_ctx_)
      || OB_ISNULL(plan_ctx = exec_ctx->get_physical_plan_ctx())) {
    ret = OB_ERR_UNEXPECTED;
  } else if (FALSE_IT(param_store = &plan_ctx->get_param_store())) {
    // do nothing
  } else if (OB_FAIL(batch_stmt.get_relation_exprs(related_exprs))) {
  } else if (OB_FAIL(ObRawExprUtils::extract_params(related_exprs, params))) {
  } else { }

  for (int64_t i = 0; OB_SUCC(ret) && i < params.count(); ++i) {
    ObConstRawExpr *param_expr = static_cast<ObConstRawExpr *>(params.at(i));
    int64_t param_idx = param_expr->get_value().get_unknown();
    if (param_idx < 0 || param_idx >= param_store->count()) {
      ret = OB_ERR_UNEXPECTED;
    } else if (param_store->at(param_idx).is_batch_parameters()
        && !has_exist_in_array(batch_stmt.get_query_ctx()->ab_param_exprs_,
                               static_cast<ObRawExpr*>(param_expr))) {
      ObPseudoColumnRawExpr *group_param_expr = nullptr;
      //create pseudo column for the sql array param
      if (OB_FAIL(create_params_expr(group_param_expr, param_expr, select_list.count()))) {
      } else if (OB_FAIL(batch_stmt.get_query_ctx()->ab_param_exprs_.push_back(param_expr))) {
      } else if (OB_FAIL(select_list.push_back(group_param_expr))) {
      }
    }
  }
  //create stmt id expr with inner view
  if (OB_SUCC(ret)) {
    ObPseudoColumnRawExpr *stmt_id_expr = NULL;
    if (OB_FAIL(create_stmt_id_expr(stmt_id_expr))) {
    } else if (OB_FAIL(select_list.push_back(stmt_id_expr))) {
    }
  }
  if (OB_SUCC(ret)) {
    if (OB_FAIL(ObTransformUtils::create_select_item(*ctx_->allocator_, select_list, &inner_view))) {
    } else if (!batch_stmt.get_query_ctx()->ab_param_exprs_.empty()) {
      inner_view.set_ab_param_flag(true);
    }
  }
  return ret;
}

int ObTransformPreProcess::transform_full_outer_join(ObDMLStmt *&stmt, bool &trans_happened)
{
  int ret = OB_SUCCESS;
  trans_happened = false;
  ObSEArray<JoinedTable*, 4> joined_tables;
  if (OB_ISNULL(stmt)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (OB_FAIL(joined_tables.assign(stmt->get_joined_tables()))) {
  } else {
    bool is_happened = false;
    for (int64_t i = 0; OB_SUCC(ret) && i < joined_tables.count(); ++i) {
      if (OB_ISNULL(joined_tables.at(i))) {
        ret = OB_ERR_UNEXPECTED;
      } else if (OB_FAIL(recursively_eliminate_full_join(*stmt, joined_tables.at(i),
                                                         is_happened))) {
      } else {
        trans_happened |= is_happened;
      }
    }
  }
  return ret;
}

int ObTransformPreProcess::convert_join_preds_vector_to_scalar(JoinedTable &joined_table,
                                                               bool &trans_happened)
{
  int ret = OB_SUCCESS;
  ObSEArray<ObRawExpr*, 16> new_join_cond;
  bool is_happened = false;
  if (OB_ISNULL(ctx_)) {
    ret = OB_ERR_UNEXPECTED;
  } else {
    for (int64_t i = 0; OB_SUCC(ret) && i < joined_table.get_join_conditions().count(); i++) {
      if (OB_FAIL(ObTransformUtils::convert_preds_vector_to_scalar(*ctx_,
                                                           joined_table.get_join_conditions().at(i),
                                                           new_join_cond,
                                                           is_happened))) {
      }
    }
    if (OB_SUCC(ret) && is_happened) {
      trans_happened = true;
      joined_table.get_join_conditions().reset();
      if (OB_FAIL(append(joined_table.get_join_conditions(), new_join_cond))) {
      }
    }
  }
  return ret;
}

int ObTransformPreProcess::recursively_eliminate_full_join(ObDMLStmt &stmt,
                                                           TableItem *table_item,
                                                           bool &trans_happened)
{
  int ret = OB_SUCCESS;
  bool has_euqal = false;
  bool has_subquery = false;
  JoinedTable *joined_table = static_cast<JoinedTable *>(table_item);
  TableItem *view_table = NULL;
  TableItem *from_table = table_item;
  if (OB_ISNULL(table_item) || OB_ISNULL(ctx_)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (!table_item->is_joined_table()) {
    /* do nothing */
  } else if (OB_FAIL(SMART_CALL(recursively_eliminate_full_join(stmt,
                                                                joined_table->left_table_,
                                                                trans_happened)))) {
  } else if (OB_FAIL(SMART_CALL(recursively_eliminate_full_join(stmt,
                                                                joined_table->right_table_,
                                                                trans_happened)))) {
  } else if (!joined_table->is_full_join()) {
    /* do nothing */
  } else if (OB_FAIL(convert_join_preds_vector_to_scalar(*joined_table, trans_happened))) {
  } else if (OB_FAIL(check_join_condition(&stmt, joined_table, has_euqal, has_subquery))) {
  } else if (has_euqal || has_subquery) {
    /* do nothing */
  } else if (OB_FAIL(ObTransformUtils::replace_with_empty_view(ctx_,
                                                               &stmt,
                                                               view_table,
                                                               from_table))) {
  } else if (OB_FAIL(ObTransformUtils::create_inline_view(ctx_,
                                                          &stmt,
                                                          view_table,
                                                          from_table))) {
  } else if (OB_ISNULL(view_table)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (OB_FAIL(expand_full_outer_join(view_table->ref_query_))) {
  } else {
    trans_happened = true;
    view_table->for_update_ = false;
  }
  return ret;
}

int ObTransformPreProcess::check_join_condition(ObDMLStmt *stmt,
                                                JoinedTable *table,
                                                bool &has_equal,
                                                bool &has_subquery)
{
  int ret = OB_SUCCESS;
  has_equal = false;
  has_subquery = false;
  ObSqlBitSet<> left_tables;
  ObSqlBitSet<> right_tables;
  if (OB_ISNULL(stmt) || OB_ISNULL(table) || OB_ISNULL(table->left_table_)
      || OB_ISNULL(table->right_table_)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (OB_FAIL(stmt->get_table_rel_ids(*table->left_table_, left_tables))) {
  } else if (OB_FAIL(stmt->get_table_rel_ids(*table->right_table_, right_tables))) {
  } else {
    ObRawExpr *cond = NULL;
    ObRawExpr *left_param = NULL;
    ObRawExpr *right_param = NULL;
    for (int64_t i = 0; OB_SUCC(ret) && i < table->join_conditions_.count(); i++) {
      if (OB_ISNULL(cond = table->join_conditions_.at(i))) {
        ret = OB_ERR_UNEXPECTED;
      } else if (OB_FALSE_IT(has_subquery |= cond->has_flag(CNT_SUB_QUERY))) {
      } else if (cond->get_relation_ids().is_empty() || !cond->has_flag(IS_JOIN_COND)) {
        /* do nothing */
      } else if (OB_UNLIKELY(cond->get_param_count() != 2) ||
                OB_ISNULL(left_param = cond->get_param_expr(0)) ||
                OB_ISNULL(right_param = cond->get_param_expr(1))) {
        ret = OB_ERR_UNEXPECTED;
      } else if ((left_param->get_relation_ids().is_subset(left_tables) &&
                  right_param->get_relation_ids().is_subset(right_tables)) ||
                (right_param->get_relation_ids().is_subset(left_tables) &&
                  left_param->get_relation_ids().is_subset(right_tables))) {
        has_equal = true;
      }
    }
  }
  return ret;
}

int ObTransformPreProcess::expand_full_outer_join(ObSelectStmt *&ref_query)
{
  int ret = OB_SUCCESS;
  ObSelectStmt *left_stmt = NULL;
  ObSelectStmt *right_stmt = NULL;
  ObSelectStmt *union_stmt = NULL;
  JoinedTable *joined_table = NULL;
  const int64_t sub_num = 1;
  if (OB_ISNULL(left_stmt = ref_query)
      || OB_UNLIKELY(left_stmt->get_joined_tables().count() != 1)
      || OB_ISNULL(joined_table = left_stmt->get_joined_tables().at(0))
      || OB_ISNULL(ctx_) || OB_ISNULL(ctx_->stmt_factory_) || OB_ISNULL(ctx_->expr_factory_)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (OB_FALSE_IT(joined_table->joined_type_ = LEFT_OUTER_JOIN)) {
  } else if (OB_FAIL(ctx_->stmt_factory_->create_stmt(right_stmt))) {
  } else if (OB_FAIL(SMART_CALL(right_stmt->deep_copy(*ctx_->stmt_factory_,
                                                      *ctx_->expr_factory_,
                                                      *left_stmt)))) {
  } else if (OB_FAIL(right_stmt->recursive_adjust_statement_id(ctx_->allocator_,
                                                               ctx_->src_hash_val_,
                                                               sub_num))) {
  } else if (OB_FAIL(right_stmt->update_stmt_table_id(ctx_->allocator_, *left_stmt))) {
  } else if (right_stmt->get_joined_tables().count() != 1) {
    ret = OB_ERR_UNEXPECTED;
  } else if (OB_FAIL(switch_left_outer_to_semi_join(right_stmt,
                                                    right_stmt->get_joined_tables().at(0),
                                                    right_stmt->get_select_items()))) {
  } else if (OB_FAIL(ObTransformUtils::create_set_stmt(ctx_, ObSelectStmt::UNION, false, left_stmt,
                                                       right_stmt, union_stmt))) {
  } else if (OB_ISNULL(union_stmt)) {
    ret = OB_ERR_UNEXPECTED;
  } else {
    ref_query = union_stmt;
  }
  return ret;
}

int ObTransformPreProcess::switch_left_outer_to_semi_join(ObSelectStmt *&sub_stmt,
                                                          JoinedTable *joined_table,
                                                          const ObIArray<SelectItem> &select_items)
{
  int ret = OB_SUCCESS;
  SemiInfo *semi_info = NULL;
  ObSEArray<SelectItem, 4> output_select_items;
  ObSEArray<FromItem, 4> from_items;
  ObSEArray<SemiInfo *, 4> semi_infos;
  ObSEArray<JoinedTable *, 4> joined_tables;
  if (OB_ISNULL(joined_table) || OB_ISNULL(sub_stmt)
      || OB_ISNULL(ctx_) || OB_ISNULL(ctx_->allocator_)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (OB_ISNULL(joined_table->left_table_) || OB_ISNULL(joined_table->right_table_)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (joined_table->left_table_->is_joined_table()) {
    TableItem *view_table = NULL;
    TableItem *push_table = joined_table->left_table_;
    if (OB_FAIL(ObTransformUtils::replace_with_empty_view(ctx_,
                                                          sub_stmt,
                                                          view_table,
                                                          push_table))) {
    } else if (OB_FAIL(ObTransformUtils::create_inline_view(ctx_,
                                                            sub_stmt,
                                                            view_table,
                                                            push_table))) {
    } else {
      joined_table->left_table_ = view_table;
    }
  } 
  if (OB_FAIL(ret)) {
  } else if (OB_ISNULL(semi_info = static_cast<SemiInfo*>(ctx_->allocator_->alloc(
                                                                    sizeof(SemiInfo))))) {
    ret = OB_ALLOCATE_MEMORY_FAILED;
    LOG_ERROR("failed to alloc semi info", K(ret));
  } else if (FALSE_IT(semi_info = new(semi_info)SemiInfo())) {
  } else if (OB_FAIL(semi_infos.push_back(semi_info))) {
  } else if (joined_table->right_table_->type_ == TableItem::JOINED_TABLE &&
      OB_FAIL(joined_tables.push_back(static_cast<JoinedTable*>(joined_table->right_table_)))) {
  } else if (OB_FAIL(create_select_items_for_semi_join(sub_stmt,
                                                       joined_table->left_table_,
                                                       select_items,
                                                       output_select_items))) {
  } else if (OB_FAIL(sub_stmt->get_select_items().assign(output_select_items))) {
  } else if (OB_FAIL(semi_info->semi_conditions_.assign(joined_table->join_conditions_))) {
  } else {
    FromItem from_item;
    TableItem* right_table_item = NULL;
    from_item.is_joined_ = joined_table->right_table_->type_ == TableItem::JOINED_TABLE;
    from_item.table_id_ = joined_table->right_table_->table_id_;
    semi_info->join_type_ = LEFT_ANTI_JOIN;
    semi_info->right_table_id_ = joined_table->left_table_->table_id_;
    semi_info->semi_id_ = sub_stmt->get_query_ctx()->available_tb_id_--;
    if (OB_FAIL(from_items.push_back(from_item))) {
    } else if (OB_ISNULL(right_table_item = sub_stmt->get_table_item_by_id(semi_info->right_table_id_))) {
      ret = OB_ERR_UNEXPECTED;
    } else if (OB_FALSE_IT(right_table_item->for_update_ = false)) {
    } else if (from_item.is_joined_) {
      JoinedTable *table = static_cast<JoinedTable*>(joined_table->right_table_);
      ret = semi_info->left_table_ids_.assign(table->single_table_ids_);
    } else {
      ret = semi_info->left_table_ids_.push_back(from_item.table_id_);
    }
  }
  if (OB_FAIL(ret)) {
  } else if (OB_FAIL(sub_stmt->get_joined_tables().assign(joined_tables))) {
  } else if (OB_FAIL(sub_stmt->get_semi_infos().assign(semi_infos))) {
  } else if (OB_FAIL(sub_stmt->get_from_items().assign(from_items))) {
  } else if (OB_FAIL(sub_stmt->formalize_stmt(ctx_->session_info_))) {
  }
  return ret;
}

int ObTransformPreProcess::create_select_items_for_semi_join(ObDMLStmt *stmt,
                                                            TableItem *table_item,
                                                            const ObIArray<SelectItem> &select_items,
                                                            ObIArray<SelectItem> &output_select_items)
{
  int ret = OB_SUCCESS;
  ObSqlBitSet<> index_left;
  if (OB_ISNULL(stmt) || OB_ISNULL(table_item) ||
      OB_ISNULL(ctx_)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (OB_FAIL(extract_idx_from_table_items(stmt,
                                                  table_item,
                                                  index_left))) {
  } else if (OB_FAIL(output_select_items.assign(select_items))) {
  }
  for (int64_t i = 0; OB_SUCC(ret) && i < output_select_items.count(); i++) {
    if (output_select_items.at(i).expr_->get_relation_ids().overlap(index_left)) {
      ObRawExpr *null_expr = NULL;
      ObRawExpr *cast_expr = NULL;
      if (OB_FAIL(ObRawExprUtils::build_null_expr(*ctx_->expr_factory_,
                                                  null_expr))) {
      } else if (OB_ISNULL(null_expr)) {
        ret = OB_ERR_UNEXPECTED;
      } else if (OB_FALSE_IT(cast_expr = null_expr)) {
      } else if (OB_FAIL(ObTransformUtils::add_cast_for_replace_if_need(*ctx_->expr_factory_, 
                                                                        output_select_items.at(i).expr_, 
                                                                        cast_expr, 
                                                                        ctx_->session_info_))) {
      } else {
        output_select_items.at(i).expr_ = cast_expr;
      }
    } else { /*do nothing.*/ }
  }
  return ret;
}

int ObTransformPreProcess::extract_idx_from_table_items(ObDMLStmt *sub_stmt,
                                                        const TableItem *table_item,
                                                        ObSqlBitSet<> &rel_ids)
{
  int ret = OB_SUCCESS;
  if (OB_ISNULL(table_item) || OB_ISNULL(sub_stmt)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (table_item->is_joined_table()) {
    const JoinedTable *joined_table = static_cast<const JoinedTable*>(table_item);
    if (OB_FAIL(SMART_CALL(extract_idx_from_table_items(sub_stmt,
                                             joined_table->left_table_,
                                             rel_ids)))) {
    } else if (OB_FAIL(SMART_CALL(extract_idx_from_table_items(sub_stmt,
                                                    joined_table->right_table_,
                                                    rel_ids)))) {
    } else {}
  } else {
    if (OB_FAIL(rel_ids.add_member(sub_stmt->get_table_bit_index(table_item->table_id_)))) {
    } else {}
  }
  return ret;
}

int ObTransformPreProcess::transform_rollup_exprs(ObDMLStmt *stmt, bool &trans_happened)
{
  int ret = OB_SUCCESS;
  trans_happened = false;
  ObSelectStmt *sel_stmt = NULL;
  ObSEArray<ObRawExpr*, 4> static_const_exprs;
  ObSEArray<ObRawExpr*, 4> static_remove_const_exprs;
  ObSEArray<ObRawExpr*, 4> exec_param_exprs;
  ObSEArray<ObRawExpr*, 4> exec_param_remove_const_exprs;
  ObSEArray<ObRawExpr*, 4> column_ref_exprs;
  ObSEArray<ObRawExpr*, 4> column_ref_remove_const_exprs;
  ObSEArray<ObRawExpr*, 4> query_ref_exprs;
  ObSEArray<ObRawExpr*, 4> query_ref_remove_const_exprs;
  if (OB_ISNULL(stmt)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (!stmt->is_select_stmt()) {
    //do nothing
  } else if (OB_FALSE_IT(sel_stmt = static_cast<ObSelectStmt*>(stmt))) {
  } else if (!sel_stmt->has_rollup()) {
    //do nothing
  } else if (OB_FAIL(get_rollup_const_exprs(sel_stmt,
                                            static_const_exprs,
                                            static_remove_const_exprs,
                                            exec_param_exprs,
                                            exec_param_remove_const_exprs,
                                            column_ref_exprs,
                                            column_ref_remove_const_exprs,
                                            query_ref_exprs,
                                            query_ref_remove_const_exprs,
                                            trans_happened))) {
  } else if (static_const_exprs.empty() && exec_param_exprs.empty() && query_ref_exprs.empty()) {
    //do nothing
  } else if (OB_FAIL(replace_remove_const_exprs(
                                        sel_stmt,
                                        static_const_exprs,
                                        static_remove_const_exprs,
                                        exec_param_exprs,
                                        exec_param_remove_const_exprs,
                                        column_ref_exprs,
                                        column_ref_remove_const_exprs,
                                        query_ref_exprs,
                                        query_ref_remove_const_exprs))) {
  }
  return ret;
}
 int ObTransformPreProcess::get_rollup_const_exprs(ObSelectStmt *stmt,
                                                  ObIArray<ObRawExpr*> &static_const_exprs,
                                                  ObIArray<ObRawExpr*> &static_remove_const_exprs,
                                                  ObIArray<ObRawExpr*> &exec_param_exprs,
                                                  ObIArray<ObRawExpr*> &exec_params_remove_const_exprs,
                                                  ObIArray<ObRawExpr*> &column_ref_exprs,
                                                  ObIArray<ObRawExpr*> &column_ref_remove_const_exprs,
                                                  ObIArray<ObRawExpr*> &query_ref_exprs,
                                                  ObIArray<ObRawExpr*> &query_ref_remove_const_exprs,
                                                  bool &trans_happened)
{
  int ret = OB_SUCCESS;
  ObSEArray<std::pair<int64_t, ObRawExpr *>, 2> dummy_onetime_exprs;
  ObRawExpr *remove_const_expr = NULL;
  bool is_const = false;
  trans_happened = false;
  if (OB_ISNULL(stmt) || OB_ISNULL(ctx_) ||
      OB_ISNULL(ctx_->expr_factory_) ||
      OB_ISNULL(ctx_->session_info_)) {
    ret = OB_ERR_UNEXPECTED;
  }
  for (int i = 0; OB_SUCC(ret) && i < stmt->get_rollup_expr_size(); ++i) {
    ObRawExpr *expr = stmt->get_rollup_exprs().at(i);
    if (OB_ISNULL(expr)) {
      ret = OB_ERR_UNEXPECTED;
    } else if (expr->has_flag(CNT_VOLATILE_CONST) || (!expr->is_const_expr() && !expr->is_query_ref_expr())) {
      //do nothing
    } else if (expr->is_query_ref_expr()) {
      // In mysql mode, rollup expr can reference subquery which may be transformed to a static const or onetime expr
      // e.g. select (select 1) as field1, sum(id) from t1 GROUP BY field1 with rollup;
      //      select (select count(1) from t1) as field1, sum(id) from t1 GROUP BY field1 with rollup;
      if (ObOptimizerUtil::find_item(query_ref_exprs, expr)) {
        //do nothing, skip dup exprs
      } else if (OB_FAIL(ObRawExprUtils::build_remove_const_expr(
                                        *ctx_->expr_factory_,
                                        *ctx_->session_info_,
                                        expr,
                                        remove_const_expr))) {
      } else if (OB_ISNULL(remove_const_expr)) {
        ret = OB_ERR_UNEXPECTED;
      } else if (OB_FAIL(query_ref_exprs.push_back(expr))) {
      } else if (OB_FAIL(query_ref_remove_const_exprs.push_back(remove_const_expr))) {
      } else {
        stmt->get_rollup_exprs().at(i) = remove_const_expr;
        trans_happened = true;
      }
    } else if (expr->is_static_const_expr()) { //static const expr
      if (ObOptimizerUtil::find_item(static_const_exprs, expr)) {
        //do nothing, skip dup exprs
      } else if (OB_FAIL(ObRawExprUtils::build_remove_const_expr(
                                        *ctx_->expr_factory_,
                                        *ctx_->session_info_,
                                        expr,
                                        remove_const_expr))) {
      } else if (OB_ISNULL(remove_const_expr)) {
        ret = OB_ERR_UNEXPECTED;
      } else if (OB_FAIL(static_const_exprs.push_back(expr))) {
      } else if (OB_FAIL(static_remove_const_exprs.push_back(remove_const_expr))) {
      } else {
        stmt->get_rollup_exprs().at(i) = remove_const_expr;
        trans_happened = true;
      }
    }  else if (ObOptimizerUtil::find_item(exec_param_exprs, expr)) {
      //do nothing, skip dup exprs
    } else if (OB_FAIL(ObRawExprUtils::build_remove_const_expr(
                                      *ctx_->expr_factory_,
                                      *ctx_->session_info_,
                                      expr,
                                      remove_const_expr))) {
    } else if (OB_ISNULL(remove_const_expr)) {
      ret = OB_ERR_UNEXPECTED;
    } else {
      stmt->get_rollup_exprs().at(i) = remove_const_expr;
      trans_happened = true;
      if (expr->is_exec_param_expr()) {
        ObExecParamRawExpr *exec_expr = static_cast<ObExecParamRawExpr *>(expr);
        const ObRawExpr *ref_expr = exec_expr->get_ref_expr();
        if (OB_ISNULL(ref_expr)) {
          ret = OB_ERR_UNEXPECTED;
        } else if (ref_expr->is_column_ref_expr()) {
          if (OB_FAIL(column_ref_exprs.push_back(expr))) {
          } else if (OB_FAIL(column_ref_remove_const_exprs.push_back(remove_const_expr))) {
          }
        }
      }
      if (OB_SUCC(ret)) {
        if (OB_FAIL(exec_param_exprs.push_back(expr))) {
        } else if (OB_FAIL(exec_params_remove_const_exprs.push_back(remove_const_expr))) {
        }
      }
    }
  }
  return ret;
}

int ObTransformPreProcess::replace_remove_const_exprs(ObSelectStmt *stmt,
                                                      ObIArray<ObRawExpr*> &static_const_exprs,
                                                      ObIArray<ObRawExpr*> &static_remove_const_exprs,
                                                      ObIArray<ObRawExpr*> &exec_params,
                                                      ObIArray<ObRawExpr*> &exec_params_remove_const_exprs,
                                                      ObIArray<ObRawExpr*> &column_ref_exprs,
                                                      ObIArray<ObRawExpr*> &column_ref_remove_const_exprs,
                                                      ObIArray<ObRawExpr*> &query_ref_exprs,
                                                      ObIArray<ObRawExpr*> &query_ref_remove_const_exprs)
{
  int ret = OB_SUCCESS;
  ObQueryCtx *query_ctx = NULL;
  ObStmtCompareContext compare_ctx;
  if (OB_ISNULL(stmt) || OB_ISNULL(query_ctx = stmt->get_query_ctx())) {
    ret = OB_ERR_UNEXPECTED;
  } else if (static_const_exprs.count() != static_remove_const_exprs.count() ||
             exec_params.count() != exec_params_remove_const_exprs.count()) {
    ret = OB_ERR_UNEXPECTED;
  } else if (OB_FALSE_IT(compare_ctx.init(&query_ctx->calculable_items_))) {
  } else {
    ObStmtExprReplacer replacer;
    replacer.remove_all();
    replacer.add_scope(SCOPE_HAVING);
    replacer.add_scope(SCOPE_SELECT);
    replacer.add_scope(SCOPE_ORDERBY);
    replacer.set_recursive(false);
    replacer.set_skip_bool_param_mysql(true);
    if (OB_FAIL(replacer.add_replace_exprs(static_const_exprs, static_remove_const_exprs))) {
    } else if (OB_FAIL(replacer.add_replace_exprs(column_ref_exprs, column_ref_remove_const_exprs))) {
    } else if (OB_FAIL(replacer.add_replace_exprs(query_ref_exprs, query_ref_remove_const_exprs))) {
    } else if (OB_FAIL(stmt->iterate_stmt_expr(replacer))) {
    }
  }

  for (int64_t i = 0; OB_SUCC(ret) && i < stmt->get_aggr_item_size(); ++i) {
    ObAggFunRawExpr *agg_expr = NULL;
    if (OB_ISNULL(agg_expr =stmt->get_aggr_item(i))) {
      ret = OB_ERR_UNEXPECTED;
    } else if (T_FUN_GROUPING == agg_expr->get_expr_type() || T_FUN_GROUPING_ID == agg_expr->get_expr_type()) {
      for (int64_t j = 0; j < agg_expr->get_param_count(); ++j) {
        bool replaced = false;
        int64_t pos = OB_INVALID_ID;
        if (OB_ISNULL(agg_expr->get_param_expr(j))) {
          ret = OB_ERR_UNEXPECTED;
        } else if (!agg_expr->get_param_expr(j)->is_const_expr()) {
        } else if (ObOptimizerUtil::find_item(static_const_exprs, agg_expr->get_param_expr(j), &pos)) {
          if (OB_UNLIKELY(pos < 0 || pos >= static_remove_const_exprs.count())) {
            ret = OB_ERR_UNEXPECTED;
          } else {
            agg_expr->get_param_expr(j) = static_remove_const_exprs.at(pos);
          }
        } else if (ObOptimizerUtil::find_item(exec_params, agg_expr->get_param_expr(j), &pos)) {
          if (OB_UNLIKELY(pos < 0 || pos >= exec_params_remove_const_exprs.count())) {
            ret = OB_ERR_UNEXPECTED;
          } else {
            agg_expr->get_param_expr(j) = exec_params_remove_const_exprs.at(pos);
          }
        }
      }
    }
  }
  return ret;
}

int ObTransformPreProcess::transform_outerjoin_exprs(ObDMLStmt *stmt, bool &is_happened)
{
  int ret = OB_SUCCESS;
  int64_t set_size = 32;
  ObStmtExprGetter visitor;
  visitor.set_relation_scope();
  visitor.remove_scope(DmlStmtScope::SCOPE_JOINED_TABLE);
  ObArray<ObRawExpr *> relation_exprs;
  hash::ObHashSet<uint64_t, hash::NoPthreadDefendMode> expr_set;
  bool bypass = false;
  if (OB_ISNULL(stmt)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (stmt->get_joined_tables().empty()) {
    bypass = true;
    OPT_TRACE("[BYPASS] transform outerjoin exprs");
  } else if (OB_FAIL(stmt->get_relation_exprs(relation_exprs, visitor))) {
  } else if (set_size < relation_exprs.count()) {
    set_size = relation_exprs.count();
  }
  if (OB_SUCC(ret) && !bypass) {
    if (OB_FAIL(expr_set.create(set_size, "RewriteExpr", "RewriteExpr"))) {
    }
    for (int64_t i = 0; OB_SUCC(ret) && i < relation_exprs.count(); ++i) {
      if (OB_FAIL(ObTransformUtils::append_hashset(relation_exprs.at(i), expr_set))) {
      }
    }
    for (int64_t i = 0; OB_SUCC(ret) && i < stmt->get_from_item_size(); ++i) {
      JoinedTable *joined_table = NULL;
      if (!stmt->get_from_item(i).is_joined_) {
        // do nothing
      } else if (OB_ISNULL(joined_table = stmt->get_joined_table(stmt->get_from_item(i).table_id_))) {
        ret = OB_ERR_UNEXPECTED;
      } else if (OB_FAIL(remove_shared_expr(stmt, joined_table, expr_set, false))) {
      }
    }
    if (expr_set.created()) {
      int tmp_ret = OB_SUCCESS;
      if (OB_SUCCESS != (tmp_ret = expr_set.destroy())) {
        ret = COVER_SUCC(tmp_ret);
      }
    }
  }
  return ret;
}

int ObTransformPreProcess::remove_shared_expr(ObDMLStmt *stmt,
                                              JoinedTable *joined_table,
                                              hash::ObHashSet<uint64_t, hash::NoPthreadDefendMode> &expr_set,
                                              bool is_nullside)
{
  int ret = OB_SUCCESS;
  TableItem *left = NULL;
  TableItem *right = NULL;
  TableItem *nullside_table = NULL;
  ObArray<ObRawExpr *> padnull_exprs;
  if (OB_ISNULL(joined_table) ||
      OB_ISNULL(left = joined_table->left_table_) ||
      OB_ISNULL(right = joined_table->right_table_)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (joined_table->is_full_join()) {
    nullside_table = joined_table;
  } else if (joined_table->is_left_join()) {
    nullside_table = right;
  } else if (joined_table->is_right_join()) {
    nullside_table = left;
  }
  if (OB_SUCC(ret) && NULL != nullside_table) {
    ObArray<uint64_t> table_ids;
    if (nullside_table->is_joined_table()) {
      if (OB_FAIL(append(table_ids, static_cast<JoinedTable *>(nullside_table)->single_table_ids_))) {
      }
    } else if (OB_FAIL(table_ids.push_back(nullside_table->table_id_))) {
    }
    for (int64_t i = 0; OB_SUCC(ret) && i < table_ids.count(); ++i) {
      if (OB_FAIL(stmt->get_column_exprs(table_ids.at(i), padnull_exprs))) {
      }
    }
  }
  if (!padnull_exprs.empty() || is_nullside) {
    for (int64_t i = 0; OB_SUCC(ret) && i < joined_table->join_conditions_.count(); ++i) {
      bool has = false;
      if (OB_FAIL(do_remove_shared_expr(expr_set,
                                        padnull_exprs,
                                        is_nullside,
                                        joined_table->join_conditions_.at(i),
                                        has))) {
      }
    }
  }
  for (int64_t i = 0; OB_SUCC(ret) && i < joined_table->join_conditions_.count(); ++i) {
    if (OB_FAIL(ObTransformUtils::append_hashset(joined_table->join_conditions_.at(i),
                                                          expr_set))) {
    }
  }
  if (OB_SUCC(ret) && left->is_joined_table()) {
    bool left_is_nullside = is_nullside || (joined_table->is_right_join() ||
                                            joined_table->is_full_join());
    if (OB_FAIL(SMART_CALL(remove_shared_expr(stmt,
                                              static_cast<JoinedTable *>(left),
                                              expr_set,
                                              left_is_nullside)))) {
    }
  }
  if (OB_SUCC(ret) && right->is_joined_table()) {
    bool right_is_nullside = is_nullside || (joined_table->is_left_join() ||
                                             joined_table->is_full_join());
    if (OB_FAIL(SMART_CALL(remove_shared_expr(stmt,
                                              static_cast<JoinedTable *>(right),
                                              expr_set,
                                              right_is_nullside)))) {
    }
  }
  return ret;
}

int ObTransformPreProcess::do_remove_shared_expr(hash::ObHashSet<uint64_t, hash::NoPthreadDefendMode> &expr_set,
                                                 ObIArray<ObRawExpr *> &padnull_exprs,
                                                 bool is_nullside,
                                                 ObRawExpr *&expr,
                                                 bool &has_padnull_column) 
{
  int ret = OB_SUCCESS;
  bool need_copy = false;
  uint64_t key = reinterpret_cast<uint64_t>(expr);
  has_padnull_column = false;
  if (OB_ISNULL(expr)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (expr->is_column_ref_expr()) {
    has_padnull_column = ObOptimizerUtil::find_item(padnull_exprs, expr);
  }
  for (int64_t i = 0; OB_SUCC(ret) && i < expr->get_param_count(); ++i) {
    bool has = false;
    if (OB_FAIL(SMART_CALL(do_remove_shared_expr(expr_set, 
                                                 padnull_exprs, 
                                                 is_nullside,
                                                 expr->get_param_expr(i),
                                                 has)))) {
    } else if (has) {
      has_padnull_column = true;
    }
  }
  if (OB_SUCC(ret) &&
      OB_HASH_EXIST == expr_set.exist_refactored(key) && 
      !expr->is_column_ref_expr() && 
      !expr->is_query_ref_expr() &&
      !expr->is_const_raw_expr() && 
      !expr->is_exec_param_expr() &&
      !expr->is_pseudo_column_expr()) {
    bool bret = false;
    ObRawExpr *new_expr = NULL;
    if (OB_ISNULL(ctx_) || OB_ISNULL(ctx_->expr_factory_)) {
      ret = OB_ERR_UNEXPECTED;
    } else if (padnull_exprs.empty() || !has_padnull_column) {
      // do nothing
    } else if (OB_FAIL(ObTransformUtils::is_null_propagate_expr(expr, padnull_exprs, bret))) {
    } else if (!bret) {
      need_copy = true;
    }
    if (OB_SUCC(ret) && !need_copy && is_nullside) {
      if (OB_FAIL(check_nullside_expr(expr, bret))) {
      } else if (!bret) {
        need_copy = true;
      }
    }
    if (OB_SUCC(ret) && need_copy) {
      if (OB_FAIL(ObRawExprCopier::copy_expr_node(*ctx_->expr_factory_,
                                                  expr,
                                                  new_expr))) {
      } else {
        expr = new_expr;
      }
    }
  }
  return ret;
}

int ObTransformPreProcess::check_nullside_expr(ObRawExpr *expr, bool &bret)
{
  int ret = OB_SUCCESS;
  ObArray<ObRawExpr *> column_exprs;
  bret = false;
  if (OB_FAIL(ObRawExprUtils::extract_column_exprs(expr, column_exprs))) {
  } else if (OB_FAIL(ObTransformUtils::is_null_propagate_expr(expr, column_exprs, bret))) {
  }
  return ret;
}


int ObTransformPreProcess::transform_for_last_insert_id(ObDMLStmt *stmt, bool &trans_happened) {
  int ret = OB_SUCCESS;
  trans_happened = false;
  if (OB_ISNULL(stmt)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (stmt->is_select_stmt()) {
    ObSelectStmt *sel_stmt = static_cast<ObSelectStmt*>(stmt);
    bool is_happened = false;
    if (OB_FAIL(expand_for_last_insert_id(*stmt, sel_stmt->get_having_exprs(), is_happened))) {
    } else {
      trans_happened |= is_happened;
    }
    if (OB_FAIL(ret)) {
    } else if (OB_FAIL(expand_for_last_insert_id(*stmt, sel_stmt->get_condition_exprs(), is_happened))) {
    } else {
      trans_happened |= is_happened;
    }
    for (int64_t i = 0; OB_SUCC(ret) && i < sel_stmt->get_joined_tables().count(); ++i) {
      if (OB_FAIL(expand_last_insert_id_for_join(*stmt, sel_stmt->get_joined_tables().at(i), is_happened))) {
      } else {
        trans_happened |= is_happened;
      }
    }
  } else if (stmt->is_delete_stmt() || stmt->is_update_stmt()) {
    bool is_happened = false;
    if (OB_FAIL(expand_for_last_insert_id(*stmt, stmt->get_condition_exprs(), is_happened))) {
    } else {
      trans_happened |= is_happened;
    }
  }
  return ret;
}

int ObTransformPreProcess::expand_last_insert_id_for_join(ObDMLStmt &stmt, JoinedTable *join_table, bool &has_happened) {
  int ret = OB_SUCCESS;
  bool is_happened = false;
  has_happened = false;
  if (OB_ISNULL(join_table) || OB_ISNULL(join_table->left_table_) || OB_ISNULL(join_table->right_table_)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (OB_FAIL(expand_for_last_insert_id(stmt, join_table->join_conditions_, has_happened))) {
  } else if (join_table->left_table_->is_joined_table() &&
            OB_FAIL(SMART_CALL(expand_last_insert_id_for_join(
                                   stmt, static_cast<JoinedTable*>(join_table->left_table_), is_happened)))) {
  } else if (FALSE_IT(has_happened |= is_happened)) {
  } else if (join_table->right_table_->is_joined_table() &&
            OB_FAIL(SMART_CALL(expand_last_insert_id_for_join(
                                   stmt, static_cast<JoinedTable*>(join_table->right_table_), is_happened)))) {
  } else {
    has_happened |= is_happened;
  }
  return ret;
}

int ObTransformPreProcess::expand_for_last_insert_id(ObDMLStmt &stmt, ObIArray<ObRawExpr*> &exprs, bool &is_happended) {
  int ret = OB_SUCCESS;
  ObSEArray<ObRawExpr *, 4> new_exprs;
  is_happended = false;
  for (int64_t i = 0; OB_SUCC(ret) && i < exprs.count(); ++i) {
    ObRawExpr *expr = exprs.at(i);
    if (OB_ISNULL(expr)) {
      ret = OB_ERR_UNEXPECTED;
    } else if (expr->has_flag(CNT_LAST_INSERT_ID) &&
          (IS_RANGE_CMP_OP(expr->get_expr_type()) || T_OP_EQ == expr->get_expr_type()) &&
          !expr->has_flag(CNT_RAND_FUNC) &&
          !expr->has_flag(CNT_SUB_QUERY) &&
          !expr->has_flag(CNT_DYNAMIC_USER_VARIABLE)) {
      bool removable = false;
      ObRawExpr *left = expr->get_param_expr(0);
      ObRawExpr *right = expr->get_param_expr(1);
      ObRawExpr *check_expr = NULL;
      if (OB_ISNULL(left) || OB_ISNULL(right)) {
        ret = OB_ERR_UNEXPECTED;
      } else if (left->has_flag(CNT_LAST_INSERT_ID) && !left->has_flag(CNT_COLUMN) && right->has_flag(CNT_COLUMN)) {
        check_expr = right;
      } else if (right->has_flag(CNT_LAST_INSERT_ID) && !right->has_flag(CNT_COLUMN) && left->has_flag(CNT_COLUMN)) {
        check_expr = left;
      }
      if (OB_FAIL(ret) || NULL == check_expr) {
        //do nothing
      } else if (OB_FAIL(ObTransformUtils::check_is_index_part_key(*ctx_, stmt, check_expr, removable))) {
      } else if (!removable) {
        //do nothing if the param which does not contain last_insert_id is not a index key with lossless cast or a index key.
      } else if (OB_FAIL(check_last_insert_id_removable(expr, removable))) {
      } else if (removable) {
        ObRawExpr *param_expr = check_expr == left ? right : left;
        ObRawExpr *new_expr = NULL;
        if (OB_FAIL(ObRawExprCopier::copy_expr(
                            *ctx_->expr_factory_,
                            param_expr,
                            param_expr))) {
        } else if (OB_ISNULL(param_expr)) {
          ret = OB_ERR_UNEXPECTED;
        } else if (OB_FAIL(remove_last_insert_id(param_expr))) {
        } else if (OB_FAIL(param_expr->formalize(ctx_->session_info_))) {
        } else if (!param_expr->is_const_expr()) {
          //do nothing
        } else if (OB_FAIL(ObRawExprCopier::copy_expr_node(*ctx_->expr_factory_,
                                                  expr,
                                                  new_expr))) {
        } else if (OB_ISNULL(new_expr)) {
          ret = OB_ERR_UNEXPECTED;
        } else if (new_expr->get_param_expr(0) == check_expr) {
          new_expr->get_param_expr(1) = param_expr;
        } else {
          new_expr->get_param_expr(0) = param_expr;
        }
        if (OB_SUCC(ret) && NULL != new_expr) {
          if (OB_FAIL(new_expr->formalize(ctx_->session_info_))) {
          } else if (OB_FAIL(exprs.push_back(new_expr))) {
          } else {
            is_happended = true;
          }
        }
      }
    }
  }
  return ret;
}

int ObTransformPreProcess::check_last_insert_id_removable(const ObRawExpr *expr, bool &is_removable) {
  int ret = OB_SUCCESS;
  is_removable = true;
  if (OB_ISNULL(expr)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (expr->has_flag(IS_LAST_INSERT_ID)) {
    if (1 != expr->get_param_count()) {
      is_removable = false;
    } else {
      const ObRawExpr *param = expr->get_param_expr(0);
      if (OB_ISNULL(param)) {
        ret = OB_ERR_UNEXPECTED;
      } else if (!param->has_flag(IS_CONST) && !param->has_flag(IS_CONST_EXPR)) {
        is_removable = false;
      }
    }
  } else if (expr->has_flag(CNT_LAST_INSERT_ID)) {
    bool flag = true;
    for (int64_t i = 0; OB_SUCC(ret) && is_removable && i < expr->get_param_count(); ++i) {
      if (OB_FAIL(check_last_insert_id_removable(expr->get_param_expr(i), flag))) {
      } else {
        is_removable = is_removable & flag;
      }
    }
  }
  return ret;
}

int ObTransformPreProcess::remove_last_insert_id(ObRawExpr *&expr) {
  int ret = OB_SUCCESS;
  if (OB_ISNULL(expr)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (expr->has_flag(IS_LAST_INSERT_ID)) {
    if (1 == expr->get_param_count()) {
      ObRawExpr *new_expr = expr->get_param_expr(0);
      if (OB_ISNULL(new_expr)) {
        ret = OB_ERR_UNEXPECTED;
      } else if (new_expr->has_flag(IS_CONST) || new_expr->has_flag(IS_CONST_EXPR)) {
        expr = new_expr;
      }
    }
  } else if (expr->has_flag(CNT_LAST_INSERT_ID)) {
    for (int64_t i = 0; OB_SUCC(ret) && i < expr->get_param_count(); ++i) {
      if (OB_FAIL(remove_last_insert_id(expr->get_param_expr(i)))) {
      }
    }
  } else {}
  return ret;
}

int ObTransformPreProcess::expand_correlated_cte(ObDMLStmt *stmt, bool& trans_happened)
{
  int ret = OB_SUCCESS;
  ObSEArray<ObDMLStmt::TempTableInfo, 8> temp_table_infos;
  if (OB_ISNULL(stmt)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (OB_FAIL(stmt->collect_temp_table_infos(temp_table_infos))) {
  }
  for (int64_t i = 0; OB_SUCC(ret) && i < temp_table_infos.count(); i ++) {
    bool is_correlated = false;
    bool can_expand = true;
    ObSEArray<ObSelectStmt *, 4> dummy;
    ObSelectStmt *temp_query = temp_table_infos.at(i).temp_table_query_;
    if (OB_ISNULL(temp_query)) {
      ret = OB_ERR_UNEXPECTED;
    } else if (OB_FAIL(check_is_correlated_cte(temp_query, dummy, is_correlated))) {
    } else if (!is_correlated) {
      //do nothing
    } else if (OB_FAIL(ObTransformUtils::check_inline_temp_table_valid(temp_table_infos.at(i).temp_table_query_, can_expand))) {
    } else if (OB_FAIL(temp_query->is_query_deterministic(can_expand))) {
    } else if (!can_expand) {
      ret = OB_NOT_SUPPORTED;
      LOG_USER_ERROR(OB_NOT_SUPPORTED, "Correlated CTE");
    } else if (OB_FAIL(ObTransformUtils::inline_temp_table(ctx_, temp_table_infos.at(i)))) {
    } else {
      trans_happened = true;
    }
  }
  return ret;
}

int ObTransformPreProcess::check_exec_param_correlated(const ObRawExpr *expr, bool &is_correlated)
{
  int ret = OB_SUCCESS;
  is_correlated = false;
  if (OB_ISNULL(expr)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (expr->is_exec_param_expr()) {
    if (!expr->has_flag(BE_USED)) {
      is_correlated = true;
    }
  } else if (expr->has_flag(CNT_DYNAMIC_PARAM)) {
    for (int64_t i = 0; OB_SUCC(ret) && !is_correlated && i < expr->get_param_count(); ++i) {
      if (OB_FAIL(SMART_CALL(check_exec_param_correlated(expr->get_param_expr(i), 
                                                        is_correlated)))) {
      }
    }
  }
  return ret;
}

int ObTransformPreProcess::check_is_correlated_cte(ObSelectStmt *stmt, ObIArray<ObSelectStmt *> &visited_cte, bool &is_correlated)
{
  int ret = OB_SUCCESS;
  ObArray<ObSelectStmt *> child_stmts;
  ObArray<ObRawExpr *> relation_exprs;
  is_correlated = false;
  if (OB_ISNULL(stmt)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (OB_FAIL(stmt->get_relation_exprs(relation_exprs))) {
  } else if (OB_FAIL(stmt->get_child_stmts(child_stmts))) {
  }
  for (int64_t i = 0; OB_SUCC(ret) && !is_correlated && i < relation_exprs.count(); ++i) {
    ObRawExpr *expr = relation_exprs.at(i);
    if (OB_FAIL(check_exec_param_correlated(expr, is_correlated))) {
    }
  }
  if (!is_correlated) {
    // add flag to mark the exec param refer the same table
    for (int64_t i = 0; OB_SUCC(ret) && i < stmt->get_table_items().count(); ++i) {
      TableItem *table_item = stmt->get_table_items().at(i);
      if (OB_ISNULL(table_item)) {
        ret = OB_ERR_UNEXPECTED;
      } else if (table_item->is_lateral_table()) {
        for (int64_t j = 0; OB_SUCC(ret) && j < table_item->exec_params_.count(); ++j) {
          ObRawExpr *exec_param = table_item->exec_params_.at(j);
          if (OB_ISNULL(exec_param)) {
            ret = OB_ERR_UNEXPECTED;
          } else if (OB_FAIL(exec_param->add_flag(BE_USED))) {
          }
        }
      }
    }
    for (int64_t i = 0; OB_SUCC(ret) && i < stmt->get_subquery_expr_size(); ++i) {
      ObQueryRefRawExpr *query_ref = stmt->get_subquery_exprs().at(i);
      if (OB_ISNULL(query_ref)) {
        ret = OB_ERR_UNEXPECTED;
      }
      for (int64_t j = 0; OB_SUCC(ret) && j < query_ref->get_exec_params().count(); ++j) {
        ObRawExpr *exec_param = query_ref->get_exec_params().at(j);
        if (OB_ISNULL(exec_param)) {
          ret = OB_ERR_UNEXPECTED;
        } else if (OB_FAIL(exec_param->add_flag(BE_USED))) {
        }
      }
    }

    for (int64_t i = 0; OB_SUCC(ret) && !is_correlated && i < child_stmts.count(); ++i) {
      if (OB_FAIL(SMART_CALL(check_is_correlated_cte(child_stmts.at(i), visited_cte, is_correlated)))) {
      }
    }
    for (int64_t i = 0; OB_SUCC(ret) && i < stmt->get_table_size(); ++i) {
      TableItem *table = stmt->get_table_item(i);
      if (OB_ISNULL(table)) {
        ret = OB_ERR_UNEXPECTED;
      } else if (!table->is_temp_table()) {
        //do nothing
      } else if (ObOptimizerUtil::find_item(visited_cte, table->ref_query_)) {
        //do nothing
      } else if (OB_FAIL(visited_cte.push_back(table->ref_query_))) {
      } else if (OB_FAIL(SMART_CALL(check_is_correlated_cte(table->ref_query_, visited_cte, is_correlated)))) {
      }
    }

    // clear flag
    for (int64_t i = 0; OB_SUCC(ret) && i < stmt->get_table_items().count(); ++i) {
      TableItem *table_item = stmt->get_table_items().at(i);
      if (OB_ISNULL(table_item)) {
        ret = OB_ERR_UNEXPECTED;
      } else if (table_item->is_lateral_table()) {
        for (int64_t j = 0; OB_SUCC(ret) && j < table_item->exec_params_.count(); ++j) {
          ObRawExpr *exec_param = table_item->exec_params_.at(j);
          if (OB_ISNULL(exec_param)) {
            ret = OB_ERR_UNEXPECTED;
          } else if (OB_FAIL(exec_param->clear_flag(BE_USED))) {
          }
        }
      }
    }
    for (int64_t i = 0; OB_SUCC(ret) && i < stmt->get_subquery_expr_size(); ++i) {
      ObQueryRefRawExpr *query_ref = stmt->get_subquery_exprs().at(i);
      if (OB_ISNULL(query_ref)) {
        ret = OB_ERR_UNEXPECTED;
      }
      for (int64_t j = 0; OB_SUCC(ret) && j < query_ref->get_exec_params().count(); ++j) {
        ObRawExpr *exec_param = query_ref->get_exec_params().at(j);
        if (OB_ISNULL(exec_param)) {
          ret = OB_ERR_UNEXPECTED;
        } else if (OB_FAIL(exec_param->clear_flag(BE_USED))) {
        }
      }
    }
  }
  return ret;
}

int ObTransformPreProcess::flatten_conditions(ObDMLStmt *stmt, bool &trans_happened)
{
  int ret = OB_SUCCESS;
  bool flatten_where = false;
  bool flatten_having = false;
  bool flatten_semi_info = false;
  bool flatten_join  = false;
  bool flatten_start_with = false;
  bool flatten_match_condition = false;
  if (OB_ISNULL(stmt)) {
    ret = OB_ERR_UNEXPECTED;
  } else {
    if (OB_FAIL(do_flatten_conditions(stmt, stmt->get_condition_exprs(), flatten_where))) {
    } else {
      //simplify having expr
      if (!stmt->is_select_stmt()) {
        //do nothing
      } else if (OB_FAIL(do_flatten_conditions(stmt, static_cast<ObSelectStmt*>(stmt)->get_having_exprs(), flatten_having))) {
      }
      if (OB_FAIL(ret)) {
        //do nothing
      } else if (stmt->is_insert_stmt()) {
        //do nothing
      } else {
        //simplify semi info
        for (int64_t i = 0; OB_SUCC(ret) && i < stmt->get_semi_infos().count(); ++i) {
          if (OB_ISNULL(stmt->get_semi_infos().at(i))) {
            ret = OB_ERR_UNEXPECTED;
          } else if (OB_FAIL(do_flatten_conditions(stmt, stmt->get_semi_infos().at(i)->semi_conditions_, flatten_semi_info))) {
          }
        }
        //simplify join condition expr
        for (int64_t i = 0; OB_SUCC(ret) && i < stmt->get_joined_tables().count(); i++) {
          if (OB_ISNULL(stmt->get_joined_tables().at(i))) {
            ret = OB_ERR_UNEXPECTED;
          } else if (OB_FAIL(recursive_flatten_join_conditions(stmt, stmt->get_joined_tables().at(i), flatten_join))) {
          }
        }
      }
    }
    if (OB_SUCC(ret)) {
      trans_happened = flatten_where | flatten_having | flatten_start_with |
                       flatten_match_condition | flatten_semi_info| flatten_join;
    }
  }
  return ret;
}

int ObTransformPreProcess::recursive_flatten_join_conditions(ObDMLStmt *stmt, TableItem *table, bool &trans_happened)
{
  int ret = OB_SUCCESS;
  JoinedTable *join_table = NULL;
  trans_happened = false;
  bool cur_happened = false;
  bool left_happened = false;
  bool right_happened = false;
  if (OB_ISNULL(stmt) || OB_ISNULL(table)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (!table->is_joined_table()) {
    /*do nothing*/
  } else if (OB_ISNULL(join_table = static_cast<JoinedTable*>(table)) ||
             OB_ISNULL(join_table->left_table_) || OB_ISNULL(join_table->right_table_)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (OB_FAIL(do_flatten_conditions(stmt, join_table->join_conditions_, cur_happened))) {
  } else if (OB_FAIL(SMART_CALL(recursive_flatten_join_conditions(stmt,
                                                                      join_table->left_table_,
                                                                      left_happened)))) {
  } else if (OB_FAIL(SMART_CALL(recursive_flatten_join_conditions(stmt,
                                                                      join_table->right_table_,
                                                                      right_happened)))) {
  } else {
    trans_happened = cur_happened | left_happened | right_happened;
  }
  return ret;
}

int ObTransformPreProcess::do_flatten_conditions(ObDMLStmt *stmt, ObIArray<ObRawExpr*> &conditions, bool &trans_happened)
{
  int ret = OB_SUCCESS;
  trans_happened = false;
  bool flatten_happend = false;
  if (OB_ISNULL(stmt)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (conditions.count() == 0) {
    //do nothing
  } else if (OB_FAIL(ObTransformUtils::flatten_and_or_xor(ctx_, conditions, &flatten_happend))) {
  } else if (trans_happened) {
    trans_happened =  flatten_happend ;
    OPT_TRACE("   flatten_happend:", flatten_happend);
  }
  return ret;
}

// full-text index queries on a single base table are processed with order preservation. 
// (Order is not preserved in multi-table join scenarios.)
int ObTransformPreProcess::preserve_order_for_fulltext_search(ObDMLStmt *stmt, bool& trans_happened)
{
  int ret = OB_SUCCESS;
  trans_happened = false;
  TableItem *table_item = NULL;
  ObRawExpr *match_expr = nullptr;
  if (OB_ISNULL(stmt)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (stmt->get_table_items().count() != 1 || stmt->get_order_item_size() != 0) {
    // do nothing
  } else if (stmt->is_select_stmt() && 
             (static_cast<ObSelectStmt*>(stmt)->has_order_by() ||
              static_cast<ObSelectStmt*>(stmt)->has_group_by() ||
              static_cast<ObSelectStmt*>(stmt)->has_distinct() ||
              static_cast<ObSelectStmt*>(stmt)->get_aggr_item_size() != 0 ||
              static_cast<ObSelectStmt*>(stmt)->has_window_function() ||
              static_cast<ObSelectStmt*>(stmt)->get_table_items().count() != 1)) {
    // do nothing
  } else if (OB_ISNULL(table_item = stmt->get_table_item(0))) {
    ret = OB_ERR_UNEXPECTED;
  } else if (!table_item->is_basic_table()) {
    // do nothing
  } else if (0 == stmt->get_match_exprs().count()) {
    // do nothing
  } else if (stmt->get_match_exprs().at(0) != nullptr && stmt->get_match_exprs().at(0)->is_es_match()) {
    ObSEArray<ObRawExpr*, 2> relation_exprs;
    if (OB_FAIL(stmt->get_relation_exprs(relation_exprs))) {
    } else {
      ObRawExpr *es_match_expr = nullptr;
      ObRawExpr *es_score_expr = nullptr;
      for (int64_t i = 0; OB_SUCC(ret) && i < relation_exprs.count(); ++i) {
        ObRawExpr *relation_expr = relation_exprs.at(i);
        if (OB_ISNULL(relation_expr)) {
          ret = OB_ERR_UNEXPECTED;
        } else if (relation_expr->has_flag(CNT_MATCH_EXPR) && relation_expr->get_expr_type() == T_OP_ADD) {
          if (relation_expr->get_param_count() != 2) {
            ret = OB_ERR_UNEXPECTED;
          } else {
            es_score_expr = relation_expr;
            ObRawExpr *param_expr0 = relation_expr->get_param_expr(0);
            ObRawExpr *param_expr1 = relation_expr->get_param_expr(1);
            if (OB_ISNULL(param_expr0) || OB_ISNULL(param_expr1)) {
              ret = OB_ERR_UNEXPECTED;
            } else if (param_expr0->has_flag(IS_MATCH_EXPR)) {
              es_match_expr = param_expr0;
            } else if (param_expr1->has_flag(IS_MATCH_EXPR)) {
              es_match_expr = param_expr1;
            } else {
              ret = OB_ERR_UNEXPECTED;
            }
          }
        } else if (relation_expr->has_flag(IS_MATCH_EXPR)) {
          es_match_expr = relation_expr;
        }
      }

      if (OB_FAIL(ret)) {
      } else if (OB_ISNULL(es_match_expr)) {
        ret = OB_NOT_SUPPORTED;
        LOG_USER_ERROR(OB_NOT_SUPPORTED, "no score expr is");
      } else {
        es_score_expr = nullptr == es_score_expr ? es_match_expr : es_score_expr;
        OrderItem item(es_score_expr, default_desc_direction());
        if (OB_FAIL(stmt->add_order_item(item))) {
        } else {
          trans_happened = true;
        }
      }  
    }
  } else {
    const common::ObIArray<ObRawExpr *> &condition_exprs = stmt->get_condition_exprs();
    bool found = false;
    for (int64_t i = 0; OB_SUCC(ret) && !found && i < condition_exprs.count(); ++i) {
      ObRawExpr *filter = nullptr;
      if (OB_ISNULL(filter = condition_exprs.at(i))) {
        ret = OB_ERR_UNEXPECTED;
      } else if (filter->has_flag(IS_MATCH_EXPR)) {
        match_expr = filter;
        found = true;
      } else if (!filter->has_flag(CNT_MATCH_EXPR)
          || filter->has_flag(CNT_OR)) {
        // skip
      } else if (IS_RANGE_CMP_OP(filter->get_expr_type())) {
        ObRawExpr *param_expr0 = filter->get_param_expr(0);
        ObRawExpr *param_expr1 = filter->get_param_expr(1);
        if (OB_ISNULL(param_expr0) || OB_ISNULL(param_expr1)) {
          ret = OB_ERR_UNEXPECTED;
        } else if (param_expr0->is_const_expr() && param_expr1->has_flag(IS_MATCH_EXPR)) {
          match_expr = param_expr1;
          found = true;
        } else if (param_expr1->is_const_expr() && param_expr0->has_flag(IS_MATCH_EXPR)) {
          match_expr = param_expr0;
          found = true;
        }
      } else if (filter->get_expr_type() == T_OP_BOOL) {
        ObRawExpr *param_expr = filter->get_param_expr(0);
        if (OB_ISNULL(param_expr)) {
          ret = OB_ERR_UNEXPECTED;
        } else if (param_expr->has_flag(IS_MATCH_EXPR)) {
          found = true;
          match_expr = param_expr;
        }
      }
    }
  }

  if (OB_FAIL(ret)) {
  } else if (0 == stmt->get_match_exprs().count()) {
    // do nothing
  } else if (stmt->get_match_exprs().at(0) != nullptr && stmt->get_match_exprs().at(0)->is_es_match()) {
    ObSEArray<ObRawExpr*, 2> relation_exprs;
    if (OB_FAIL(stmt->get_relation_exprs(relation_exprs))) {
    } else {
      ObRawExpr *es_match_expr = nullptr;
      for (int64_t i = 0; OB_SUCC(ret) && i < relation_exprs.count(); ++i) {
        ObRawExpr *relation_expr = relation_exprs.at(i);
        if (OB_ISNULL(relation_expr)) {
          ret = OB_ERR_UNEXPECTED;
        } else if (relation_expr->has_flag(CNT_MATCH_EXPR) && relation_expr->get_expr_type() == T_OP_ADD) {
          if (relation_expr->get_param_count() != 2) {
            ret = OB_ERR_UNEXPECTED;
          } else {
            ObRawExpr *param_expr0 = relation_expr->get_param_expr(0);
            ObRawExpr *param_expr1 = relation_expr->get_param_expr(1);
            if (OB_ISNULL(param_expr0) || OB_ISNULL(param_expr1)) {
              ret = OB_ERR_UNEXPECTED;
            } else if (param_expr0->has_flag(IS_MATCH_EXPR)) {
              es_match_expr = param_expr0;
            } else if (param_expr1->has_flag(IS_MATCH_EXPR)) {
              es_match_expr = param_expr1;
            } else {
              ret = OB_ERR_UNEXPECTED;
            }
          }
        } else if (relation_expr->has_flag(IS_MATCH_EXPR)) {
          es_match_expr = relation_expr;
        }
      }

      if (OB_FAIL(ret)) {
      } else if (OB_ISNULL(es_match_expr)) {
        ret = OB_NOT_SUPPORTED;
        LOG_USER_ERROR(OB_NOT_SUPPORTED, "no score expr is");
      }
    }
  }
  if (OB_SUCC(ret) && nullptr != match_expr && !static_cast<ObMatchFunRawExpr*>(match_expr)->is_es_match()) {
    OrderItem item(match_expr, default_desc_direction());
    if (OB_FAIL(stmt->add_order_item(item))) {
    } else {
      trans_happened = true;
    }
  } 
  return ret;
}

int ObTransformPreProcess::preserve_order_for_pagination(ObDMLStmt *stmt, 
                                                         bool &trans_happened)
{
  int ret = OB_SUCCESS;
  trans_happened = false;
  bool is_valid = false;
  ObSEArray<ObSelectStmt*, 2> preserve_order_stmts;
  if (OB_FAIL(check_stmt_need_preserve_order(stmt, 
                                             preserve_order_stmts, 
                                             is_valid))) {
  } else if (!is_valid) {
    //do nothing
  } else {
    bool happened = false;
    for (int64_t i = 0; OB_SUCC(ret) && i < preserve_order_stmts.count(); ++i) {
      if (OB_FAIL(add_order_by_for_stmt(preserve_order_stmts.at(i), happened))) {
      } else {
        trans_happened |= happened;
      }
    }
  }
  return ret;
}

int ObTransformPreProcess::check_stmt_need_preserve_order(ObDMLStmt *stmt, 
                                                          ObIArray<ObSelectStmt*> &preserve_order_stmts, 
                                                          bool &is_valid)
{
  int ret = OB_SUCCESS;
  is_valid = false;
  bool is_hint_enabled = false;
  bool has_hint = false;
  ObSelectStmt *sel_stmt = NULL;
  if (OB_ISNULL(stmt) || OB_ISNULL(ctx_) ||
      OB_ISNULL(ctx_->session_info_)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (OB_FAIL(stmt->get_query_ctx()->get_global_hint().opt_params_.get_bool_opt_param(
              ObOptParamHint::PRESERVE_ORDER_FOR_PAGINATION, is_hint_enabled, has_hint))) {
  } else if (has_hint && !is_hint_enabled) {
    OPT_TRACE("query hint disable preserve order for pagination");
  } else if (OB_FAIL(ctx_->session_info_->is_preserve_order_for_pagination_enabled(is_valid))) {
  } else if (!is_valid && !has_hint) {
    OPT_TRACE("system config disable preserve order for pagination");
  } else if (!stmt->is_select_stmt()) {
    OPT_TRACE("dml query can not preserve order for pagination");
  } else if (OB_FALSE_IT(sel_stmt=static_cast<ObSelectStmt*>(stmt))) {
  } else if (!sel_stmt->has_limit() || NULL != sel_stmt->get_limit_percent_expr()) {
    OPT_TRACE("query do not have normal limit offset");
  } else if (OB_FALSE_IT(is_valid = true)) {
  } else if (sel_stmt->has_order_by() ||
             sel_stmt->has_group_by() || 
             sel_stmt->has_distinct() ||
             sel_stmt->get_aggr_item_size() != 0 || 
             sel_stmt->has_window_function() || 
             1 != sel_stmt->get_table_items().count()) {
    if (OB_FAIL(preserve_order_stmts.push_back(sel_stmt))) {
    }
  } else {
    TableItem *table = sel_stmt->get_table_items().at(0);
    ObSEArray<ObSelectStmt*, 2> view_preserve_order_stmts;
    bool need_preserve = false;
    if (OB_ISNULL(table)) {
      ret = OB_ERR_UNEXPECTED;
    } else if (!table->is_generated_table()) {
      if (OB_FAIL(preserve_order_stmts.push_back(sel_stmt))) {
      }
    } else if (OB_FAIL(check_view_need_preserve_order(table->ref_query_, 
                                                      view_preserve_order_stmts, 
                                                      need_preserve))) {
    } else if (need_preserve && 
               OB_FAIL(append(preserve_order_stmts, view_preserve_order_stmts))) {
    } else if (!need_preserve && 
               OB_FAIL(preserve_order_stmts.push_back(sel_stmt))) {
    }
  }
  return ret;
}

int ObTransformPreProcess::check_view_need_preserve_order(ObSelectStmt* stmt, 
                                                          ObIArray<ObSelectStmt*> &preserve_order_stmts,
                                                          bool &need_preserve)
{
  int ret = OB_SUCCESS;
  need_preserve = false;
  if (OB_ISNULL(stmt)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (stmt->has_order_by() && !stmt->has_limit()) {
    need_preserve = true;
    if (OB_FAIL(preserve_order_stmts.push_back(stmt))) {
    }
  } else if (!stmt->has_order_by() && 
             !stmt->has_limit() && 
             stmt->is_set_stmt() && 
             OB_FAIL(check_set_stmt_need_preserve_order(stmt, 
                                                        preserve_order_stmts, 
                                                        need_preserve))) {
  } else if (!stmt->is_spj()) {
    //do nothing
  } else if (1 != stmt->get_table_items().count()) {
    //do nothing
  } else {
    TableItem *table = stmt->get_table_items().at(0);
    if (OB_ISNULL(table)) {
      ret = OB_ERR_UNEXPECTED;
    } else if (!table->is_generated_table()) {
      //do nothing
    } else if (OB_FAIL(SMART_CALL(check_view_need_preserve_order(table->ref_query_, 
                                                                 preserve_order_stmts, 
                                                                 need_preserve)))) {
    }
  }
  return ret;
}

int ObTransformPreProcess::check_set_stmt_need_preserve_order(ObSelectStmt* stmt, 
                                                              ObIArray<ObSelectStmt*> &preserve_order_stmts, 
                                                              bool &need_preserve)
{
  int ret = OB_SUCCESS;
  need_preserve = false;
  bool force_serial_set_order = false;
  if (OB_ISNULL(stmt) || OB_ISNULL(ctx_) ||
      OB_ISNULL(ctx_->session_info_)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (OB_FAIL(ctx_->session_info_->is_serial_set_order_forced(force_serial_set_order))) {
  } else if (!force_serial_set_order) {
    //do nothing
  } else if (!stmt->is_set_stmt() || 
             stmt->is_set_distinct() || 
             stmt->is_recursive_union()) {
    //do nothing
  } else {
    need_preserve = true;
    int64_t N = stmt->get_set_query().count();
    for (int64_t i = 0; OB_SUCC(ret) && need_preserve && i < N; ++i) {
      ObSelectStmt *set_query = stmt->get_set_query().at(i);
      if (OB_ISNULL(set_query)) {
        ret = OB_ERR_UNEXPECTED;
      } else if (OB_FAIL(SMART_CALL(check_view_need_preserve_order(set_query, 
                                                                   preserve_order_stmts, 
                                                                   need_preserve)))) {
      }
    }
  }
  return ret;
}

int ObTransformPreProcess::add_order_by_for_stmt(ObSelectStmt* stmt, bool &trans_happened)
{
  int ret = OB_SUCCESS;
  bool is_valid = false;
  ObSEArray<ObRawExpr*, 2> select_exprs;
  ObSEArray<ObRawExpr*, 2> order_by_exprs;
  ObSEArray<ObRawExpr*, 2> new_order_by_exprs;
  if (OB_ISNULL(stmt) || OB_ISNULL(ctx_)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (OB_FAIL(stmt->get_order_exprs(order_by_exprs))) {
  } else if (OB_FAIL(ObTransformUtils::check_stmt_unique(stmt, 
                                                         ctx_->session_info_, 
                                                         ctx_->schema_checker_, 
                                                         order_by_exprs,
                                                         true, 
                                                         is_valid))) {
  } else if (is_valid) {
    OPT_TRACE("current order by exprs is unique, do not need add extra order by exprs");
  } else if (OB_FAIL(get_rowkey_for_single_table(stmt, select_exprs, is_valid))) {
  } else if (!is_valid &&
             OB_FAIL(stmt->get_select_exprs_without_lob(select_exprs))) {
  } else if (OB_FAIL(ObOptimizerUtil::except_exprs(select_exprs, 
                                                   order_by_exprs, 
                                                   new_order_by_exprs))) {
  } else {
    for (int64_t i = 0; OB_SUCC(ret) && i < new_order_by_exprs.count(); ++i) {
      OrderItem item(new_order_by_exprs.at(i));
      if (OB_FAIL(stmt->add_order_item(item))) {
      }
    }
    if (OB_SUCC(ret) && !new_order_by_exprs.empty()) {
      trans_happened = true;
    }
  }
  return ret;
}

int ObTransformPreProcess::get_rowkey_for_single_table(ObSelectStmt* stmt, 
                                                       ObIArray<ObRawExpr*> &unique_keys, 
                                                       bool &is_valid)
{
  int ret = OB_SUCCESS;
  is_valid = false;
  TableItem *table = NULL;
  if (OB_ISNULL(stmt) || OB_ISNULL(ctx_)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (1 != stmt->get_table_items().count()) {
    //do nothing
  } else if (OB_ISNULL(table=stmt->get_table_items().at(0))) {
    ret = OB_ERR_UNEXPECTED;
  } else if (!table->is_basic_table()) {
    //do nothing
  } else if (OB_FAIL(ObTransformUtils::generate_unique_key_for_basic_table(ctx_, 
                                                           stmt, 
                                                           table, 
                                                           unique_keys))) {
  } else {
    is_valid = true;
  }
  return ret;
}

int ObTransformPreProcess::preserve_order_for_gby(ObDMLStmt *stmt, 
                                                  bool &trans_happened)
{
  int ret = OB_SUCCESS;
  ObSelectStmt *sel_stmt = NULL;
  bool is_valid = false;
  bool is_hint_enabled = false;
  bool has_hint = false;
  ObSEArray<ObRawExpr*, 4> group_exprs;
  if (OB_ISNULL(stmt) || OB_ISNULL(ctx_) ||
      OB_ISNULL(ctx_->session_info_)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (OB_FAIL(stmt->get_query_ctx()->get_global_hint().opt_params_.get_bool_opt_param(
              ObOptParamHint::PRESERVE_ORDER_FOR_GROUPBY, is_hint_enabled, has_hint))) {
  } else if (has_hint && !is_hint_enabled) {
    OPT_TRACE("query hint disable preserve order for group by");
  } else if (OB_FAIL(ctx_->session_info_->is_preserve_order_for_groupby_enabled(is_valid))) {
  } else if (!is_valid && !has_hint) {
    OPT_TRACE("system config disable preserve order for group by");
  } else if (!stmt->is_select_stmt()) {
    OPT_TRACE("dml query can not preserve order for group by");
  } else if (OB_FALSE_IT(sel_stmt=static_cast<ObSelectStmt*>(stmt))) {
  } else if (sel_stmt->has_order_by()) {
    OPT_TRACE("order by query can not preserve order for group by");
  } else if (!sel_stmt->has_group_by() || sel_stmt->is_scala_group_by()) {
    OPT_TRACE("non normal group by query can not preserve order for group by");
  } else if (OB_FAIL(stmt->get_relation_exprs(group_exprs, SCOPE_GROUPBY))) {
  } else {
    for (int64_t i = 0; OB_SUCC(ret) && i < group_exprs.count(); ++i) {
      OrderItem item(group_exprs.at(i));
      if (OB_FAIL(sel_stmt->add_order_item(item))) {
      }
    }
    if (OB_SUCC(ret) && !group_exprs.empty()) {
      trans_happened = true;
    }
  }
  return ret;
}

int ObTransformPreProcess::try_gen_straight_join_leading(ObDMLStmt *stmt, bool &trans_happened)
{
  int ret = OB_SUCCESS;
  const ObQueryHint *query_hint = NULL;
  if (OB_ISNULL(stmt)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (OB_ISNULL(query_hint = stmt->get_stmt_hint().query_hint_)) {
    ret = OB_ERR_UNEXPECTED;
  } else {
    ObHint *leading_hint = stmt->get_stmt_hint().get_normal_hint(T_LEADING);
    bool exist_leading_hint = query_hint->has_outline_data() ||
                              query_hint->has_user_def_outline() ||
                              OB_NOT_NULL(leading_hint);
    ObSEArray<TableItem*, 4> flattened_tables;

    //if the current qb already has leading hint or outline data, ignore straight_join info.
    if (exist_leading_hint) {
      //do nothing
    } else if (stmt->is_select_stmt() && 
               static_cast<ObSelectStmt*>(stmt)->is_select_straight_join()) {
      if (OB_FAIL(add_ordered_hint(stmt, stmt->get_stmt_hint()))) {
      } else {
        //for straight_join written in the select clause, an ordered hint is added by default.
        trans_happened = true;
      }
    } else if (OB_FAIL(get_flattened_tables_of_pure_straight_join(stmt, flattened_tables))) {
    } else if (flattened_tables.count() < 2) {
      //do nothing
    } else if (OB_FAIL(add_leading_hint_by_flattened_tables(stmt, stmt->get_stmt_hint(), 
                                                            flattened_tables))) {
    } else {
      //for straight_join written in the from clause, generate partial leading info based on 
      //the first pure straight_join table found from left to right.
      trans_happened = true;
    }
  }
  return ret;
}

int ObTransformPreProcess::get_flattened_tables_of_pure_straight_join(ObDMLStmt* stmt, 
                                                ObIArray<TableItem*> &flattened_tables)
{
  int ret = OB_SUCCESS;
  ObSEArray<TableItem*, 4> from_tables;
  if (OB_ISNULL(stmt)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (OB_FAIL(stmt->get_from_tables(from_tables))) {
  } else {
    bool found = false;
    for (int64_t i = 0; OB_SUCC(ret) && !found && i < from_tables.count(); i++) {
      TableItem *table_item = NULL;
      bool is_pure_straight_join = false;
      if (OB_ISNULL(table_item = from_tables.at(i))) {
        ret = OB_ERR_UNEXPECTED;
      } else if (!table_item->is_joined_table()) {
        //do nothing
      } else if (OB_FAIL(check_pure_straight_join_table(table_item, is_pure_straight_join, 
                                                        flattened_tables))) {
      } else if (!is_pure_straight_join) {
        flattened_tables.reuse();
      } else {
        found = true;
      }
    }
  }
  return ret;
}

// If all leaf nodes in the joined table are base tables and the join types within it are straight_join, 
// then it is considered a pure_straight_join_table whose join order is considered to be determined
// (left associative after flattening).
int ObTransformPreProcess::check_pure_straight_join_table(TableItem* table_item, 
                                                          bool &is_pure_straight_join,
                                                          ObIArray<TableItem*> &flattened_tables)
{
  int ret = OB_SUCCESS;
  is_pure_straight_join = false;
  if (OB_ISNULL(table_item)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (table_item->is_basic_table()) {
    is_pure_straight_join = true;
    if (OB_FAIL(flattened_tables.push_back(table_item))) {
    }
  } else if (!table_item->is_joined_table()) {
    is_pure_straight_join = false;
  } else {
    JoinedTable *joined_table = static_cast<JoinedTable*>(table_item);
    bool is_left_pure_sj = false;
    bool is_right_pure_sj = false;
    if (OB_FAIL(SMART_CALL(check_pure_straight_join_table(joined_table->left_table_,
                                                          is_left_pure_sj,
                                                          flattened_tables)))) {
    } else if (OB_FAIL(SMART_CALL(check_pure_straight_join_table(joined_table->right_table_,
                                                                is_right_pure_sj,
                                                                flattened_tables)))) {
    } else if (joined_table->is_straight_join()) {
      is_pure_straight_join = is_left_pure_sj && is_right_pure_sj;
    } else {
      is_pure_straight_join = false;
    }
  }
  return ret;
}

int ObTransformPreProcess::add_ordered_hint(ObDMLStmt* stmt, ObStmtHint &stmt_hint)
{
  int ret = OB_SUCCESS;
  ObJoinOrderHint *join_order_hint = NULL;
  ObString qb_name;
  if (OB_ISNULL(stmt) || OB_ISNULL(ctx_)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (OB_FAIL(stmt->get_qb_name(qb_name))) {
  } else if (OB_FAIL(ObQueryHint::create_hint(ctx_->allocator_, T_ORDERED, join_order_hint))) {
  } else if (OB_FALSE_IT(join_order_hint->set_qb_name(qb_name))) {
  } else if (OB_FAIL(stmt_hint.normal_hints_.push_back(join_order_hint))) {
  }
  return ret;
}

int ObTransformPreProcess::add_leading_hint_by_flattened_tables(ObDMLStmt* stmt, 
                                                                ObStmtHint &stmt_hint, 
                                                                ObIArray<TableItem*> &flattened_tables)
{
  int ret = OB_SUCCESS;
  ObJoinOrderHint *join_order_hint = NULL;
  ObString qb_name;
  if (OB_ISNULL(stmt) || OB_ISNULL(ctx_)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (OB_FAIL(stmt->get_qb_name(qb_name))) {
  } else if (OB_FAIL(ObQueryHint::create_hint(ctx_->allocator_, T_LEADING, join_order_hint))) {
  } else if (OB_ISNULL(join_order_hint)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (OB_FALSE_IT(join_order_hint->set_qb_name(qb_name))) {
  } else if (OB_FAIL(construct_leading_table(stmt, flattened_tables, join_order_hint->get_table()))) {
  } else if (OB_FAIL(stmt_hint.normal_hints_.push_back(join_order_hint))) {
  }
  return ret;
}

int ObTransformPreProcess::construct_leading_table(ObDMLStmt* stmt,
                                                   ObIArray<TableItem*> &flattened_tables,
                                                   ObLeadingTable &leading_table)
{
  int ret = OB_SUCCESS;
  ObLeadingTable *cur_leading_table = NULL;
  if (OB_ISNULL(ctx_) || OB_ISNULL(stmt)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (flattened_tables.count() < 2) {
    ret = OB_ERR_UNEXPECTED;
  } else {
    for (int64_t i = 0; OB_SUCC(ret) && i < flattened_tables.count(); i++) {
      ObLeadingTable *left_leading_table = cur_leading_table;
      ObLeadingTable *right_leading_table = NULL;
      if (OB_ISNULL(cur_leading_table)) {
        if (OB_FAIL(construct_leaf_leading_table(stmt, flattened_tables.at(i), cur_leading_table))) {
        } else if (OB_ISNULL(cur_leading_table)) {
          ret = OB_ERR_UNEXPECTED;
        }
      } else if (OB_FAIL(construct_leaf_leading_table(stmt, flattened_tables.at(i), right_leading_table))) {
      } else if (OB_FAIL(ObQueryHint::create_leading_table(ctx_->allocator_, cur_leading_table))) {
      } else if (OB_ISNULL(cur_leading_table)) {
        ret = OB_ERR_UNEXPECTED;
      } else {
        cur_leading_table->left_table_ = left_leading_table;
        cur_leading_table->right_table_ = right_leading_table;
      }
    }
    if (OB_SUCC(ret) && OB_FAIL(leading_table.assign(*cur_leading_table))) {
    }
  }
  return ret;
}

int ObTransformPreProcess::construct_leaf_leading_table(ObDMLStmt *stmt,
                                                        TableItem *table,
                                                        ObLeadingTable *&leading_table)
{
  int ret = OB_SUCCESS;
  if (OB_ISNULL(ctx_) || OB_ISNULL(stmt)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (OB_FAIL(ObQueryHint::create_leading_table(ctx_->allocator_, leading_table))) {
  } else if (OB_ISNULL(leading_table)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (OB_FAIL(ObQueryHint::create_hint_table(ctx_->allocator_, leading_table->table_))) {
  } else if (OB_ISNULL(leading_table->table_)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (OB_FAIL(stmt->get_qb_name(leading_table->table_->qb_name_))) {
  } else {
    leading_table->table_->db_name_ = table->database_name_;
    leading_table->table_->table_name_ = table->table_name_;
  }
  return ret;
}

int ObTransformPreProcess::reset_view_base(ObDMLStmt *stmt)
{
  int ret = OB_SUCCESS;
  if (OB_ISNULL(stmt)) {
    ret = OB_ERR_UNEXPECTED;
  } else {
    ObIArray<TableItem*> &tables = stmt->get_table_items();
    TableItem *table_item = NULL;
    for (int64_t i = 0; OB_SUCC(ret) && i < tables.count(); ++i) {
      if (OB_ISNULL(table_item = tables.at(i))) {
        ret = OB_ERR_UNEXPECTED;
      } else {
        table_item->view_base_item_ = NULL;
      }
    }
  }
  return ret;
}

} // end namespace sql
} // end namespace oceanbase
