"""Apply the pinned R33 correction without overwriting frozen failed evidence."""
import hashlib
import json
from pathlib import Path
import re

HERE=Path(__file__).resolve().parent
ROOT=Path('D:/Projects/OceanBase/seekdb')
sha=lambda b:hashlib.sha256(b).hexdigest()
proposal=HERE.parent/'round33-count-only-order-proposal'
pins=json.loads((proposal/'bounded-limits-pins.json').read_text(encoding='utf-8'))
patch=(proposal/'bounded-limits.delta.patch').read_bytes()
assert sha(patch)=='3846d55a14edf3d17cc0704fe3b964b7decc69109fab41e950b42ef92ecae4f2'
target=ROOT/'src/sql/rewrite/ob_transform_pre_process.cpp'
raw=target.read_bytes()
assert sha(raw)==pins['delta_preimage']['raw_sha256']
lines=raw.decode('utf-8').replace('\r\n','\n').splitlines(keepends=True)
patch_lines=patch.decode('utf-8').splitlines(keepends=True)
assert patch_lines[0].strip()=='--- a/src/sql/rewrite/ob_transform_pre_process.cpp'
assert patch_lines[1].strip()=='+++ b/src/sql/rewrite/ob_transform_pre_process.cpp'
out=[];position=0;cursor=2
while cursor<len(patch_lines):
    m=re.fullmatch(r'@@ -(\d+),(\d+) \+(\d+),(\d+) @@\n',patch_lines[cursor]);assert m
    old_start,old_count,new_start,new_count=map(int,m.groups())
    assert position<=old_start-1
    out.extend(lines[position:old_start-1]);position=old_start-1
    consumed=produced=0;cursor+=1
    while cursor<len(patch_lines) and not patch_lines[cursor].startswith('@@ '):
        line=patch_lines[cursor];prefix,value=line[0],line[1:]
        assert prefix in (' ','+','-')
        if prefix in (' ','-'):
            assert lines[position]==value
            position+=1;consumed+=1
        if prefix in (' ','+'):
            out.append(value);produced+=1
        cursor+=1
    assert consumed==old_count and produced==new_count
out.extend(lines[position:])
candidate=''.join(out)
assert sha(candidate.encode())==pins['candidate_lf_sha256']
changed=candidate.replace('\n','\r\n').encode('utf-8')
with (HERE/'bounded-candidate.cpp').open('xb') as f:f.write(changed)
target.write_bytes(changed)
with (HERE/'bounded-application.json').open('x',encoding='utf-8') as f:
    json.dump(dict(status='APPLIED_UNPROMOTED',preimage_sha256=sha(raw),candidate_sha256=sha(changed),patch_sha256=sha(patch),source='55b0ddc224d3b1ea85c46474468c527727f6184b+round33-bounded-count-only-order'),f,indent=2);f.write('\n')
print('APPLIED bounded candidate',sha(changed))
