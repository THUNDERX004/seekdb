"""Three serial, full-input, balanced-order R33/official-original local pairs."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

HERE=Path(__file__).resolve().parent
ROOT=Path('D:/Projects/OceanBase/seekdb')
PYTHON=Path(__file__).resolve().parents[3]/'.venv/Scripts/python.exe'
configs={
    'control':('build/fts-competition-baseline/seekdb.exe','bae4a3b9e1b4662d4021b28d5adc085764beb6cf02122eacd57b8e16b6fe1762','5bce9e06d1281347ad61344e4b01fab9158c58a2'),
    'candidate':('build/fts-round33-bounded-count-only-order-candidate/seekdb.exe','596b93cd688e9ab47449391db1dfeb5acfd56095cee558b064f8d5a4a03f7437','55b0ddc224d3b1ea85c46474468c527727f6184b+round33-bounded-count-only-order')}
for binary,digest,source in configs.values():
    assert hashlib.sha256((ROOT/binary).read_bytes()).hexdigest()==digest
order=[('control',1),('candidate',1),('candidate',2),('control',2),('control',3),('candidate',3)]
for kind,n in order:
    binary,digest,source=configs[kind]
    label=f'r33-cumulative-{kind}-a{n}'
    base=Path('C:/Users/11946/AppData/Local/Temp')/('seekdb-'+label)
    assert not base.exists()
    args=[str(PYTHON),'-B','-X','utf8',str(HERE/'experiment-v2.py'),'--binary',str(ROOT/binary),'--label',label,'--source',source,'--base-dir',str(base),'--affinity-mask','15','--benchmark']
    print('PAIR RUN',label,flush=True)
    subprocess.run(args,check=True)
    receipt=json.loads((HERE.parent/(label+'-experiment.json')).read_text(encoding='utf-8'))
    assert receipt['binary_sha256']==digest and receipt['affinity_mask_verified']==15
    assert all(a['exit_code']==0 for a in receipt['actions'])
print('COMPLETE all six full-input measurements',flush=True)
