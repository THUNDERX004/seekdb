# Round19 descriptor-major common spans

FROZEN SOURCE/PATCH. Author performed no build or runtime. Parent independently applied the exact candidate and owns subsequent build/test evidence, separately recorded in round19-span-parent-apply.json and later logs.

- original/src/storage/blocksstable/encoding/ob_string_diff_decoder.cpp: exact 721b922c preimage.
- src/storage/blocksstable/encoding/ob_string_diff_decoder.cpp: complete 6140f8f5 candidate, one CPP only.
- source.patch: one insertion hunk, +14/-0 lines.
- manifest.json: exact full hashes, sizes and status.
- report.md: semantic proof, assumptions, costs and actual-production native gate.

For row_cap >= 2, traverse descriptors once and copy each common span across every output slot at the original stride. Otherwise retain the original loop. No template, initialization, extra allocation/byte writes, descriptor-count/length guard, or diff/hex change. No performance benefit is assumed. Old template proposal remains unchanged.
