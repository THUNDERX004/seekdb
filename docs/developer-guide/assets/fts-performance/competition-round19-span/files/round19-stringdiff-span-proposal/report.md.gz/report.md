# Frozen span proposal

The sole change is ObStringDiffDecoder::batch_decode common initialization, candidate lines 168-181, after the existing allocation and before any payload decoding. Guard: row_cap >= 2. The exact original helper loop remains for row_cap < 2. Scalar decode, null/extend logic, allocation, stride, output publication, raw diff and hex paths are untouched. The source starts from pinned 721b922c, not V1 template code. Manifest pins the full original/candidate/patch bytes.

## Descriptor semantics and byte proof

In inspected ob_string_diff_encoder.h, DiffDesc has one diff bit and seven count bits (35-39); common_data skips descriptors plus the hex alphabet (77-83). LeftToRight invokes MEMCPY(destination,source,count) (42-48). copy_string (164-176) advances fpos for every descriptor and ppos only for the selected descriptors. Its logical_not<uint8_t> specialization selects exactly !diff spans. Encoder.cpp constructs runs/splits at 127 bytes (108-162) and stores common bytes in descriptor order via the reverse helper (231-260).

For descriptor j, let n[j] be count, F[j] the sum of ALL preceding counts, P[j] the sum of preceding COMMON counts, R=row_cap and B=max(string_size,128). For every common j and row slot i in [0,R), both implementations perform exactly:

    MEMCPY(buf + i*B + F[j], header.common_data() + P[j], n[j]);

The candidate's string_offset equals F[j]; its common_data cursor equals the common base plus P[j] and advances only for common spans. It traverses j before i rather than i before j. Thus source bytes, destination intervals, lengths and multiplicity are identical; only write order changes. No diff gap/padding/output-row contents are read as source. No template, zero-fill, extra allocation or extra byte write is introduced. All common writes still finish before any row payload work.

Valid metadata has sum(n)=string_size, readable concatenated common bytes, and disjoint common intervals within each original B-byte slot. Either first flag, two-descriptor C7/D1 or D1/C7, multiple spans and adjacent same-flag descriptors from 127-byte splitting work. No alternating-flag/count/size threshold is assumed. Zero counts preserve the original zero-length MEMCPY behavior and offset advancement; empty descriptor lists perform no copies. All-common/all-diff/zero-size cases can exercise synthetic decoder fixtures, but empty/all-common STRING_DIFF is not normal encoder selection.

## Edge cases and assumptions

- R=0 retains alloc(B*0) and its original allocator-dependent result, with no early return. R=1 uses the exact old helper loop. Invalid negative/overflowing capacities remain outside this unchecked internal caller contract.
- Not-initialized, null/extension-prepass and allocation failures take the original branches. The insertion has no new fallible call or ret modification. Later variable-location errors retain the same fully common-initialized allocation and datum prefix/suffix because all payload operations remain in their original order.
- Common bytes are still copied to every slot, including NULL slots, first-row NULL and all-NULL selections. Fixed/variable helpers retain their existing normalization of every stored extension to null (ob_icolumn_decoder.cpp 107-155); scalar NOP semantics are not substituted for the batch contract.
- Output slot i, row_ids mapping, reorder/duplicates, requested capacity, B stride, allocation count/size, datum pointers/lengths, allocator ownership and lifetime remain unchanged. No pointer into common metadata escapes into output.
- As in the original, metadata must stay valid/stable, allocation must be correctly sized and nonoverlapping with metadata, and output must not be observed concurrently during initialization. Corrupt descriptors, aliasing allocators and invalid bounds are not newly supported.

## Evidence and cost limits

Author static checks matched original raw SHA, reversed the insertion to the complete original, and reconstructed the complete candidate from the unique hunk. No compiler, native execution, SQL, benchmark or Git was invoked by this sidecar. No concrete source-level blocker identified under the above assumptions; native gates remain parent-owned.

Descriptor traversal becomes one pass rather than R passes; MEMCPY count and total copied bytes are unchanged. Destination visits now jump by B for each common span and may revisit many cache lines on subsequent spans. Row striding, cache/TLB locality, tiny-copy overhead and compiler behavior can erase or reverse any gain. No speedup or CPU attribution is claimed.

Parent V1 evidence (build -3.2564%, tokenize +6.6809%, query +3.3688%; query pairs +6.7101%/+5.4167%/-3.5614%) motivates an independent experiment only. Parent also reports original 230 PASS and V1 230 exact raw-stdout/tuple agreement. These do not validate this span candidate. Latest parent update independently reconstructed/applied exact 6140f8f5 candidate and started its build; receipt is ../round19-span-parent-apply.json. This author report does not claim that build finished or that span ran/passed.

## Focused actual-production gate (design only)

1. Link the actual original and candidate decoder objects using the parent's matching native configuration. Compare full raw stdout, normalized datum tuples, every published byte, return codes, allocation count/size and partial-error state. Use actual scalar decode and independent source strings for normal/NULL results; original batch is the NOP/error oracle. Do not test a copied implementation instead of production.
2. Exercise fixed/variable, raw/hex; C7/D1 and D1/C7; C2/D1/C2/D2/C1; adjacent C127/C1/D1 and D1/C127/C1; sizes around 64/128/129; R=0/1/2/7/larger. Assert actual STRING_DIFF selection. Distinguish encoder-produced fixtures from synthetic zero-count/empty/all-common/all-diff shapes.
3. Hex coverage needs odd/even total diff counts and odd nibble boundaries across diff descriptors separated by common spans, with real packer and exact final-byte bounds. Test identity/reversed/duplicate IDs and first/alternating/last/all NULLs with different row-specific diff bytes.
4. Tracking allocator filled with 0xA5 plus a variable-row payload-lookup probe must see exact common bytes in all slots and untouched diff gaps/padding before payload work. Unlike V1, do not expect zero gaps. Account for prepass lookups before allocation. Check canaries, retained batch-A outputs during B, and actual update_pointer relocation.
5. Inject allocation, null-prepass and early/middle/late variable row/cell-location failures; compare return, published prefix and untouched suffix with original. After correctness, parent runs unchanged serial paired full benchmarks. No applicability, performance or score result is supplied here.
