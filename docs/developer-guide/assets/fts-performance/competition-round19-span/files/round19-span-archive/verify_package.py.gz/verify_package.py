"""Read-only accepted-span gzip/raw/source/reference verification; no workloads."""
import argparse
import gzip
import hashlib
import json
from pathlib import Path


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def relative(value):
    path = Path(value)
    require(not path.is_absolute() and '..' not in path.parts and ':' not in value and chr(92) not in value, 'Unsafe relative path')
    return path


def unpack(item, directory):
    packed = (directory / relative(item['path'])).read_bytes()
    require(len(packed) == item['packed_bytes'] and digest(packed) == item['packed_sha256'], 'Packed identity mismatch: ' + item['source'])
    raw = gzip.decompress(packed)
    require(len(raw) == item['raw_bytes'] and digest(raw) == item['raw_sha256'], 'Raw identity mismatch: ' + item['source'])
    return raw


def verify(directory, source_root=None, reference_root=None):
    directory = Path(directory).resolve()
    manifest_raw = (directory / 'manifest.json').read_bytes()
    manifest = json.loads(manifest_raw)
    complete = json.loads((directory / 'COMPLETE.json').read_bytes())
    require(complete['status'] == 'COMPLETE' and complete['manifest_sha256'] == digest(manifest_raw), 'Completion identity mismatch')
    require(manifest['decision'] == 'RETAIN bounded incremental checkpoint (parent)' and manifest['completed_pairs'] == 5, 'Wrong decision/pair count')
    expected = {'manifest.json', 'COMPLETE.json'}
    sources = set()
    raw_total = packed_total = 0
    for item in manifest['files']:
        relative(item['source'])
        require(item['path'] == 'files/' + item['source'] + '.gz', 'Unexpected gzip mapping')
        require(item['source'] not in sources and item['path'] not in expected, 'Duplicate manifest entry')
        require(not any(x in item['source'].lower() for x in ['round20', 'round21', 'r21-']), 'Other experiment included')
        raw = unpack(item, directory)
        if source_root is not None:
            require((Path(source_root) / item['source']).read_bytes() == raw, 'Original source changed: ' + item['source'])
        expected.add(item['path'])
        sources.add(item['source'])
        raw_total += item['raw_bytes']
        packed_total += item['packed_bytes']
    require(len(sources) == complete['file_count'], 'Wrong file count')
    actual = {p.relative_to(directory).as_posix() for p in directory.rglob('*') if p.is_file()}
    require(actual == expected, 'Unlisted/missing archive files')
    refroot = Path(reference_root) if reference_root is not None else directory.parent
    ref_manifests = {}
    for ref in manifest['references_not_duplicated']:
        refdir = refroot / relative(ref['archive'])
        key = ref['archive']
        if key not in ref_manifests:
            raw_manifest = (refdir / 'manifest.json').read_bytes()
            ref_complete = json.loads((refdir / 'COMPLETE.json').read_bytes())
            require(digest(raw_manifest) == ref['manifest_sha256'] == ref_complete['manifest_sha256'], 'Referenced manifest identity mismatch')
            require(ref_complete['status'] == 'COMPLETE', 'Referenced package incomplete')
            ref_manifests[key] = json.loads(raw_manifest)
        matches = [x for x in ref_manifests[key]['files'] if x['source'] == ref['entry']['source']]
        require(matches == [ref['entry']], 'Referenced entry differs')
        raw = unpack(ref['entry'], refdir)
        if source_root is not None:
            require((Path(source_root) / ref['entry']['source']).read_bytes() == raw, 'Referenced auxiliary original changed')
    return {'status': 'PASS', 'file_count': len(sources), 'manifest_sha256': digest(manifest_raw), 'raw_bytes': raw_total, 'packed_bytes': packed_total, 'references_verified': len(manifest['references_not_duplicated']), 'raw_packed_reference_hashes': 'ALL MATCH', 'source_bytes': 'ALL MATCH' if source_root is not None else 'NOT REQUESTED', 'execution': 'Offline bytes only; no build/native/SQL/performance/Git'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--package-dir', required=True, type=Path)
    parser.add_argument('--source-root', type=Path)
    parser.add_argument('--reference-root', type=Path)
    parser.add_argument('--report', type=Path)
    args = parser.parse_args()
    result = verify(args.package_dir, args.source_root, args.reference_root)
    if args.report:
        with args.report.open('xb') as stream:
            stream.write((json.dumps(result, ensure_ascii=False, indent=2) + chr(10)).encode('utf-8'))
    print(json.dumps(result, ensure_ascii=False))


if __name__ == '__main__':
    main()
