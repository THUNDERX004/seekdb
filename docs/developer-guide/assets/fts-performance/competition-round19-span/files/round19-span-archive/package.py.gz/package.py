"""Package explicit, completed span evidence only. Never invoke a workload or Git."""
import gzip
import io
import json
from datetime import datetime, timezone
from pathlib import Path

from verify_package import digest, require, unpack, verify
from publish_docs import insert, protected

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
REPO = Path('D:/Projects/OceanBase/seekdb')
ASSETS = REPO / 'docs/developer-guide/assets/fts-performance'
PRODUCTION = 'src/storage/blocksstable/encoding/ob_string_diff_decoder.cpp'
ORIGINAL = '721b922ca48241c4e8fc05aac115389604a0f1614cb83ad8ed21d21930a7098c'
CANDIDATE = '6140f8f5d70b5108312df925d3f9bba4b2212a94f8c1d32f6c5ebf3c98113499'
PATCH = 'de652b6372bbf47aa028e00e9def717f6dd80f6b7d81ee662d3c44d734a8fb10'
TEST = '0cbd3e08a391b4b2f5ddb88fdfc773d5312589250fb5ab4a97f96632852e73c9'
BUILDER = 'fa34ed893fad0065e8ea0fe4ce6074e07a2940dd7e9f9da519dffb911bede59f'
RUNNER = '0d0331f57da3493376f3217b01618603963724b33b661666eafe149e99254cf3'
SHARED = '30779fbf52372a91bbc37e823b7fde4579eae04850dc784064170758667410f9'
STDOUT = 'f67d52774c96396878ffae09d7df65c7d1c4c670c3f04165900f87e68e5b0221'
RECORDS = '3502db6cf34b46e0c8ae0cee09673d1767c70a6f9885265bdca1d1c03efae7f5'
PINNED_MANIFESTS = {
    'competition-round19-template': '4bd645f547b062a91dfcda96379170fef688542fd82ad047f63c0bd8a953a5ab',
    'competition-round16': 'fca2842dc77110e7930d735e824ecc499e3fe1e8c8f4e72b796db535bd114a4b',
}
BUILD_FILES = [
    'receipt.json', 'compile.log', 'compile.rsp', 'link-inputs.rsp', 'link.log',
    'link-intermediate/embed.manifest', 'link-intermediate/intermediate.manifest',
    'link-intermediate/manifest.rc',
]
RUN_FILES = ['build-receipt.json', 'run.json', 'stdout.log', 'stderr.log', 'tuples.log']
NATIVE = 'round19-stringdiff-native/'
PARAMETERS = dict(rows=20000, batch=500, rounds=3000, query_rounds=200,
                  samples=3, warmup=30, skip_load=0)
BINARIES = {
    'control': 'b271980a025bf9b20086e69f116ec2c24f164d21edd814b4e03d418cadd239fc',
    'candidate': 'c7fcc8676875246a38bc4135f29e6f52b85a9d29a9563679003d5b6140666b01',
}


def load(path):
    return json.loads(path.read_bytes())


def write_new(path, raw):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(raw)


def write_json(name, value):
    write_new(HERE / name, (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))


def identity(raw):
    return dict(bytes=len(raw), sha256=digest(raw))


def references():
    sources = [NATIVE + 'control-extended-build1/' + x for x in BUILD_FILES]
    sources += [NATIVE + 'control-extended-run1/' + x for x in RUN_FILES]
    sources += [NATIVE + x for x in [
        'test_stringdiff_template_extended.cpp', 'build_native.py', 'run_native.py',
        'README.md', 'extended-design.md',
    ]]
    sources += ['experiment-affinity4.py', 'experiment-competition.py',
                'mysql_client.py', 'build-competition.ps1']
    result, content = [], {}
    for archive, selected in [
        ('competition-round19-template', sources),
        ('competition-round16', ['round16-row-native/prepare_fts_lazy_rows.py']),
    ]:
        directory = ASSETS / archive
        manifest_raw = (directory / 'manifest.json').read_bytes()
        require(digest(manifest_raw) == PINNED_MANIFESTS[archive], 'Prior manifest changed')
        require(load(directory / 'COMPLETE.json')['manifest_sha256'] == digest(manifest_raw), 'Prior completion changed')
        manifest = json.loads(manifest_raw)
        for source in selected:
            entries = [x for x in manifest['files'] if x['source'] == source]
            require(len(entries) == 1, 'Missing exact prior entry: ' + source)
            entry = entries[0]
            raw = unpack(entry, directory)
            require((ROOT / source).read_bytes() == raw, 'Prior auxiliary input changed: ' + source)
            content[source] = raw
            result.append(dict(archive=archive, manifest_sha256=digest(manifest_raw), entry=entry))
    require(digest(content[NATIVE + 'test_stringdiff_template_extended.cpp']) == TEST, 'Original 230 source mismatch')
    require(digest(content[NATIVE + 'build_native.py']) == BUILDER, 'Builder pin mismatch')
    require(digest(content[NATIVE + 'run_native.py']) == RUNNER, 'Runner pin mismatch')
    require(digest(content['round16-row-native/prepare_fts_lazy_rows.py']) == SHARED, 'Shared utility pin mismatch')
    return result, content


def compare_native(old):
    new = {x: (ROOT / (NATIVE + 'span-extended-run1/' + x)).read_bytes() for x in RUN_FILES}
    build_raw = (ROOT / (NATIVE + 'span-extended-build1/receipt.json')).read_bytes()
    builds = {'span': json.loads(build_raw),
              'control': json.loads(old[NATIVE + 'control-extended-build1/receipt.json'])}
    runs = {'span': json.loads(new['run.json']),
            'control': json.loads(old[NATIVE + 'control-extended-run1/run.json'])}
    require(new['build-receipt.json'] == build_raw, 'Span build/run receipt differs')
    require(old[NATIVE + 'control-extended-run1/build-receipt.json'] == old[NATIVE + 'control-extended-build1/receipt.json'], 'Control build/run receipt differs')
    for variant in ['span', 'control']:
        build, run = builds[variant], runs[variant]
        require(build['build_succeeded'] and build['compile']['exit_code'] == build['link']['exit_code'] == 0, 'Native build not passing')
        require(build['production_sha256_before'] == build['production_sha256_after'], 'Recorded library pins changed during build')
        require(build['expected_source_sha256'] == (CANDIDATE if variant == 'span' else ORIGINAL), 'Native source pin mismatch')
        require(build['test_sha256'] == run['test_sha256'] == TEST, 'Native test differs')
        require(build['builder_sha256'] == BUILDER and build['helper_sha256'] == SHARED, 'Recorded helper pins differ')
        require(not build['production_source_compiled'], 'Unexpected separately compiled production object')
        require(build['expected_cases'] == run['expected_cases'] == 230, 'Wrong case matrix')
        require(run['native'] == run['output_validation'] == 'PASS' and run['exit_code'] == 0, 'Actual native run not passing')
        require(run['run_helper_sha256'] == RUNNER and run['executable_sha256'] == build['executable_sha256'], 'Native execution provenance mismatch')
        for step in ['compile', 'link']:
            raw = ((ROOT / (NATIVE + 'span-extended-build1/' + step + '.log')).read_bytes()
                   if variant == 'span' else old[NATIVE + 'control-extended-build1/' + step + '.log'])
            require(digest(raw) == build[step]['log_sha256'], 'Native build log differs')
    evidence = {}
    for filename in ['stdout.log', 'stderr.log', 'tuples.log']:
        current = new[filename]
        original = old[NATIVE + 'control-extended-run1/' + filename]
        require(current == original, 'Complete native byte differential failed: ' + filename)
        for run in runs.values():
            expected = run['tuples_sha256'] if filename == 'tuples.log' else run['logs_sha256'][filename]
            require(digest(current) == expected, 'Run output pin differs')
        evidence[filename] = dict(identity(current), exact_complete_bytes_equal=True)
    require(digest(new['stdout.log']) == STDOUT and digest(new['tuples.log']) == RECORDS and not new['stderr.log'], 'Expected output identities differ')
    lines = [x for x in new['stdout.log'].splitlines() if x.startswith((b'CASE\t', b'B\t', b'T\t', b'PASS\t'))]
    require(b'\n'.join(lines) + b'\n' == new['tuples.log'], 'Normalized record extraction differs')
    counts = {prefix: sum(x.startswith(prefix.encode('ascii') + b'\t') for x in lines) for prefix in ['CASE', 'B', 'T', 'PASS']}
    require(counts['CASE'] == 230 and counts['T'] == 12976 and len(lines) == 13649, 'Record counts differ')
    require([x for x in lines if x.startswith(b'PASS\t')] == [b'PASS\tcases=230'], 'Incomplete output')
    return dict(status='PASS (recorded parent runs; offline byte recheck)',
                native_execution_by_archiver='NOT RUN', cases=230,
                deterministic_record_lines=len(lines), record_counts=counts,
                note='Legacy tuple_lines includes CASE/B/T/PASS, not T alone; full stdout is also compared independently.',
                outputs=evidence, builds={
                    v: dict(source_sha256=builds[v]['expected_source_sha256'],
                            executable_sha256=runs[v]['executable_sha256'],
                            recorded_library_inputs=len(builds[v]['production_sha256_before']),
                            compile_link_and_run='PASS', recorded_library_inputs_unchanged=True)
                    for v in builds},
                limits=['Finite synthetic fixtures; no encoder selection proof',
                        'No malformed-metadata, arbitrary read-bound, concurrency or Linux CI proof',
                        'Historical recorded library/binary hashes, not rehashing mutable current build products'])


def main():
    require(not (HERE / 'archive').exists(), 'Existing package is immutable; inspect instead of overwriting')
    state = load(HERE / 'status.json')
    protected(state)
    refs, old = references()
    native = compare_native(old)
    inputs = []
    for variant in ['control', 'candidate']:
        for pair in range(1, 6):
            label = 'r19-span-' + variant + '-a' + str(pair)
            for suffix in ['benchmark.log', 'experiment.json', 'input-validation.log', 'report.txt', 'server.log']:
                rel = label + '-' + suffix
                require((ROOT / rel).is_file(), 'Missing complete run input: ' + rel)
                if suffix == 'server.log':
                    require((ROOT / rel).stat().st_size < 1024 * 1024, 'Unexpected large server log; inspect first')
                inputs.append(rel)
    regressions = ['count-union-accounting.log', 'keytypes.log', 'query-materialization.log',
                   'ranked.log', 'sort-metadata.log', 'sort-plans.json']
    regressions += ['test_' + x + '.py.log' for x in [
        'collation', 'dictionary_prefixes', 'hot_path', 'map_concurrency',
        'match_batches', 'stopword_concurrency', 'tokenize_config']]
    inputs += ['r19-span-candidate-a1-' + x for x in regressions]
    actual_run_names = {p.name for p in ROOT.glob('r19-span-*') if p.is_file()}
    require(actual_run_names == set(inputs), 'Run input inventory changed; inspect rather than recursively include')
    comparison_checks = []
    final = None
    for pairs in range(1, 6):
        rel = 'round19-span-evidence/span-comparison-' + str(pairs) + 'pair.json'
        inputs += [rel, 'round19-span-evidence/summary-' + str(pairs) + 'pair-output.log']
        comparison = load(ROOT / rel)
        require(comparison['completed_pairs'] == pairs and len(comparison['pairs']) == pairs, 'Comparison pair mismatch')
        require(comparison['parameters'] == PARAMETERS and comparison['binary_pins'] == BINARIES, 'Fixed inputs differ')
        require(len(comparison['input_hashes']) == 4 * pairs, 'Comparison input list incomplete')
        for source, pin in comparison['input_hashes'].items():
            raw = (ROOT / source).read_bytes()
            require(identity(raw) == pin, 'Immutable comparison input changed: ' + source)
        comparison_checks.append(dict(source=rel, **identity((ROOT / rel).read_bytes()),
                                      input_hashes_verified=len(comparison['input_hashes']),
                                      performance_recalculation='NOT RUN'))
        final = comparison
    inputs += ['round19-span-evidence/summarize-span-first3.py', 'round19-span-evidence/summarize-span.py']
    for label, record in final['records'].items():
        receipt = load(ROOT / (label + '-experiment.json'))
        require(receipt == record['receipt'], 'Receipt embedded in comparison differs')
        variant = 'candidate' if '-candidate-' in label else 'control'
        require(receipt['binary_sha256'] == BINARIES[variant], 'Recorded benchmark binary differs')
        require(receipt['log_level'] == 'WARN' and receipt['affinity_mask'] == receipt['affinity_mask_verified'] == 15, 'Environment differs')
        require(all(x['exit_code'] == 0 for x in receipt['actions']), 'Incomplete/failed action')
        require(all(record['values'][k] == v for k, v in PARAMETERS.items()), 'Record parameter differs')
        require(all(record['values'][k] == v for k, v in final['expected_hits'].items()), 'Recorded hit count differs')
        if label != 'r19-span-candidate-a1':
            require([x['action'] for x in receipt['actions']] == ['benchmark', 'input-validation'], 'Unexpected regression claim')
    require(len(final['records']) == 10, 'Ten complete runs required')
    prop = 'round19-stringdiff-span-proposal/'
    inputs += [prop + x for x in ['manifest.json', 'README.md', 'report.md', 'source.patch',
                                  'original/' + PRODUCTION, PRODUCTION]]
    proposal = load(ROOT / (prop + 'manifest.json'))
    for key, expected in [('original', ORIGINAL), ('candidate', CANDIDATE), ('patch', PATCH)]:
        raw = (ROOT / prop / proposal[key]['path']).read_bytes()
        require(digest(raw) == expected == proposal[key]['sha256'] and len(raw) == proposal[key]['bytes'], 'Proposal exact identity mismatch')
    live = (REPO / PRODUCTION).read_bytes()
    require(digest(live) == CANDIDATE and live == (ROOT / prop / PRODUCTION).read_bytes(), 'Live committed source differs from span')
    inputs += ['round19-span-parent-apply.json', 'round19-span-candidate-build.log']
    apply = load(ROOT / 'round19-span-parent-apply.json')
    require(apply['status'] == 'APPLIED' and apply['original_sha256'] == ORIGINAL and apply['candidate_sha256'] == CANDIDATE, 'Application receipt differs')
    inputs += [NATIVE + 'span-extended-build1/' + x for x in BUILD_FILES]
    inputs += [NATIVE + 'span-extended-run1/' + x for x in RUN_FILES]
    checkout = {}
    for rel in ['unittest/storage/encoding/test_stringdiff_batch.cpp', 'unittest/storage/encoding/README.md']:
        raw = (REPO / rel).read_bytes()
        if rel.endswith('.cpp'):
            require(digest(raw) == TEST and raw == old[NATIVE + 'test_stringdiff_template_extended.cpp'], 'Established unit source differs from executed source')
        snapshot = HERE / 'checkout' / rel
        write_new(snapshot, raw)
        inputs.append(snapshot.relative_to(ROOT).as_posix())
        checkout[rel] = dict(identity(raw), snapshot=snapshot.relative_to(ROOT).as_posix())
    # Generated immutable receipts and only the new report sections, not full history.
    identities = dict(parent_verified_source_commit=state['parent_verified_source_commit'],
                      production_path=PRODUCTION, original_sha256=ORIGINAL,
                      candidate_sha256=CANDIDATE, patch_sha256=PATCH,
                      live_source_matches_exact_proposal=True, established_unit=checkout,
                      protected_preimages=state['protected_preimages'],
                      protected_reference_paths_absent=state['protected_reference_paths_absent'],
                      baseline_verification=state['baseline_verification'],
                      historical_labels_preserved=True,
                      historical_benchmark_binary_pins=BINARIES)
    write_json('source-identities.json', identities)
    write_json('native-byte-comparison.json', native)
    write_json('comparison-input-verification.json', dict(status='PASS', comparisons=comparison_checks,
               meaning='Existing comparison hash inputs checked only; no summarizer/benchmark rerun'))
    write_json('references.json', refs)
    disposition = dict(decision='RETAIN bounded incremental checkpoint (parent)', completed_pairs=5,
        accepted_source_commit=state['parent_verified_source_commit'],
        aggregate_from_immutable_comparison=final['aggregate_from_metric_run_means'],
        pair_query_improvements=[x['category_improvements']['query'] for x in final['pairs']],
        parent_reason='Four nonnegative query-pair observations plus exact semantic byte agreement; bounded retain only',
        limitations=['Pair 1 slightly negative and pair 4 small; pair 3 control BENG/mixed outlier retained',
                     'No stability/statistical significance claim; build/tokenize fluctuations not causal',
                     'Fixed official benchmark/scoring/data parameters unchanged; negative metrics retained',
                     'No new formal, cumulative or full-score result',
                     'Candidate-a1 regressions only; span controls record benchmark/input-validation only',
                     'Finite SQL/native correctness evidence does not prove exact internal paths or arbitrary input safety'],
        archiver_execution='Offline bytes only; no Git/build/link/native/SQL/performance/profile',
        excluded_experiments='Rejected template V1 raw evidence referenced, not duplicated; unrelated and round21 excluded')
    write_json('disposition.json', disposition)
    rows = '\n'.join('| ' + x['metric'] + ' | ' + format(x['control'], '.6f') +
                     ' | ' + format(x['candidate'], '.6f') + ' | ' +
                     format(100 * x['improvement'], '+.6f') + '% |'
                     for x in final['aggregate_from_metric_run_means']['metrics'])
    pairs_table = '\n'.join('| ' + str(x['pair']) + ' | ' +
                          format(100 * x['category_improvements']['query'], '+.6f') + '% | ' +
                          format(100 * x['overall_improvement'], '+.6f') + '% |' for x in final['pairs'])
    doc_ops = []
    for lang in ['en', 'zh-CN']:
        template = (HERE / ('report-template.' + lang + '.md')).read_bytes().decode('utf-8')
        section = template.replace('§', chr(96)).replace('@@ROWS@@', rows).replace('@@PAIRS@@', pairs_table)
        raw_section = section.replace('\r\n', '\n').encode('utf-8')
        section_name = 'report.' + lang + '.md'
        write_new(HERE / section_name, raw_section)
        rel = 'docs/developer-guide/' + lang + '/fts-performance.md'
        before = (REPO / rel).read_bytes()
        require(identity(before) == dict(bytes=state['documents_preimages'][rel]['bytes'],
                                        sha256=state['documents_preimages'][rel]['sha256']), 'Document preimage changed')
        after = insert(before, raw_section)
        doc_ops.append(dict(path=rel, section=section_name, preimage_sha256=digest(before),
                            section_sha256=digest(raw_section), postimage_sha256=digest(after)))
    write_json('document-identities.json', doc_ops)
    own = ['package.py', 'verify_package.py', 'publish_docs.py', 'README.md',
           'report-template.en.md', 'report-template.zh-CN.md', 'report.en.md', 'report.zh-CN.md',
           'source-identities.json', 'native-byte-comparison.json', 'comparison-input-verification.json',
           'references.json', 'disposition.json', 'document-identities.json', 'selection.json']
    inputs += ['round19-span-archive/' + x for x in own]
    require(len(inputs) == len(set(inputs)), 'Duplicate selected source')
    inputs.sort()
    write_json('selection.json', dict(files=inputs, referenced_files=len(refs),
               method='Explicit allowlist; no recursive new experiment selection',
               excluded=['Binaries/exe/pdb/lib/obj/dll/manifest.res', 'runtime/data/temp/secrets',
                         'Unrelated proposals and round21', 'Raw rejected V1 duplication',
                         'Full bilingual report-history backups', 'Mutable status/publication/verification receipts']))
    archive = HERE / 'archive'
    archive.mkdir()
    entries = []
    for source in inputs:
        path = ROOT / source
        require(path.suffix.lower() not in ['.exe', '.pdb', '.lib', '.obj', '.dll', '.res', '.tmp'], 'Binary product selected')
        raw = path.read_bytes()
        out = io.BytesIO()
        with gzip.GzipFile(fileobj=out, filename='', mode='wb', mtime=0, compresslevel=9) as stream:
            stream.write(raw)
        packed = out.getvalue()
        target = 'files/' + source + '.gz'
        write_new(archive / target, packed)
        entries.append(dict(source=source, path=target, raw_bytes=len(raw), raw_sha256=digest(raw),
                            packed_bytes=len(packed), packed_sha256=digest(packed)))
    manifest = dict(schema_version=1, created_utc=datetime.now(timezone.utc).isoformat(),
        experiment='round19-descriptor-major-common-spans', decision=disposition['decision'], completed_pairs=5,
        source_root=str(ROOT), checkout_root=str(REPO),
        encoding='Per-file gzip of exact raw bytes; empty gzip filename; mtime=0; no newline conversion',
        performance_comparison='round19-span-evidence/span-comparison-5pair.json (verbatim)',
        formal_result='No new formal/cumulative/full-score claim',
        execution_by_archiver='Offline packaging/verification only',
        native_recorded_result='230 cases PASS both variants; complete stdout/stderr/record bytes equal',
        files=entries, references_not_duplicated=refs)
    manifest_raw = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    write_new(archive / 'manifest.json', manifest_raw)
    write_new(archive / 'COMPLETE.json', (json.dumps(dict(status='COMPLETE', file_count=len(entries),
              manifest_sha256=digest(manifest_raw)), indent=2) + '\n').encode('utf-8'))
    write_json('publication-plan.json', dict(repository=str(REPO),
               asset_directory='docs/developer-guide/assets/fts-performance/competition-round19-span',
               manifest_sha256=digest(manifest_raw), documents=doc_ops))
    result = verify(archive, ROOT, ASSETS)
    protected(state)
    require(digest((REPO / PRODUCTION).read_bytes()) == CANDIDATE, 'Production source changed during packaging')
    write_json('verification.json', result)
    print(json.dumps(result, ensure_ascii=True))


if __name__ == '__main__':
    main()
