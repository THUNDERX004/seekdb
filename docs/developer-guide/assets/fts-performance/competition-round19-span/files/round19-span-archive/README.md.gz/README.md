# Accepted round19 descriptor-major span archive

Only the new competition-round19-span asset directory and the top sections of the two existing FTS reports may be published. All C: helper output stays in this new directory. No Git, compiler/linker, server, native executable, SQL, benchmark or profiler is invoked.

Selection is explicit: ten r19-span runs, candidate-a1 regression logs, five immutable comparison snapshots and their five console logs, both summarizer versions, exact span proposal/application/build records, span native build/run text evidence, and the exact committed 230-case unit source/README. Large server logs, binary products, runtime/data/temp, unrelated proposals and round21 are excluded.

The V1 package remains frozen. Its exact control-230 output/build/helper entries and the shared round16 utility are referenced with manifest, packed and raw SHA256 pins. They are not duplicated as new raw V1 evidence. Historical pending proposal text remains unchanged. Parent execution evidence is described separately.

Package once using the workspace Python:

    python -B setup/fts/round19-span-archive/package.py

The publisher verifies source pins, prior-package references and document preimages. It defaults to a read-only plan:

    python -B setup/fts/round19-span-archive/publish_docs.py

Publish the authorized asset directory and two report insertions:

    python -B setup/fts/round19-span-archive/publish_docs.py --execute

Independent verification:

    python -B setup/fts/round19-span-archive/verify_package.py --package-dir D:/Projects/OceanBase/seekdb/docs/developer-guide/assets/fts-performance/competition-round19-span --source-root C:/Users/11946/Documents/ChatGPT/OceanBase比赛/setup/fts

No complete report-history backups are packed: only the inserted report sections and their preimage/postimage hashes are retained. Existing report bytes remain unchanged below the insertion. Mutable status/publication/verification receipts stay outside the immutable manifest. The historical five-pair comparison is archived verbatim, never rerun or overwritten. The third-pair control BENG/mixed outlier, first slight regression and fourth small change are disclosed. No stability, statistical significance, causal untouched-path gain, new formal score, cumulative score or full-score claim is made. Parent owns review, commit and push.
