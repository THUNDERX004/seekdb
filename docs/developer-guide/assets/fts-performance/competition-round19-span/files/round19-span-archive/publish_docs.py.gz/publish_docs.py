"""Publish only accepted span assets and two report insertions; no Git/workloads."""
import argparse
import json
from pathlib import Path
from verify_package import digest, require, verify

HERE = Path(__file__).resolve().parent
REPO = Path('D:/Projects/OceanBase/seekdb')
ASSET_ROOT = REPO / 'docs/developer-guide/assets/fts-performance'
ASSET = ASSET_ROOT / 'competition-round19-span'
DOCS = ['docs/developer-guide/en/fts-performance.md', 'docs/developer-guide/zh-CN/fts-performance.md']


def insert(raw, addition):
    end = raw.index(bytes([10])) + 1
    require(raw[end:end + 1] == bytes([10]), 'Unexpected document title spacing')
    return raw[:end] + bytes([10]) + addition + raw[end + 1:]


def protected(state):
    for rel, pin in state['protected_preimages'].items():
        require(digest((REPO / rel).read_bytes()) == pin['sha256'], 'Protected file changed; stop without touching it')
    for rel in state['protected_reference_paths_absent']:
        require(not (REPO / rel).exists(), 'Previously absent protected reference path changed')
    require(digest((ASSET_ROOT / 'competition-round19-template/manifest.json').read_bytes()) == state['v1_manifest_sha256'], 'Frozen V1 manifest changed')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true')
    args = parser.parse_args()
    plan = json.loads((HERE / 'publication-plan.json').read_bytes())
    state = json.loads((HERE / 'status.json').read_bytes())
    require(plan['repository'] == str(REPO) and plan['asset_directory'] == 'docs/developer-guide/assets/fts-performance/competition-round19-span', 'Publication scope mismatch')
    require([x['path'] for x in plan['documents']] == DOCS, 'Wrong report paths')
    verified = verify(HERE / 'archive', HERE.parent, ASSET_ROOT)
    require(verified['manifest_sha256'] == plan['manifest_sha256'], 'Package changed')
    require(not ASSET.exists(), 'Asset directory exists; inspect rather than overwrite')
    protected(state)
    postimages = {}
    for op in plan['documents']:
        raw = (REPO / op['path']).read_bytes()
        addition = (HERE / op['section']).read_bytes()
        require(digest(raw) == op['preimage_sha256'] and digest(addition) == op['section_sha256'], 'Report or section changed')
        require(b'competition-round19-span/manifest.json' not in raw, 'Span report already inserted')
        result = insert(raw, addition)
        require(digest(result) == op['postimage_sha256'], 'Unexpected report postimage')
        postimages[op['path']] = result
    if not args.execute:
        print(json.dumps({'status': 'PLAN_ONLY', 'manifest_sha256': verified['manifest_sha256'], 'file_count': verified['file_count'], 'documents': DOCS}))
        return
    ASSET.mkdir()
    for source in sorted((HERE / 'archive').rglob('*')):
        if source.is_file():
            target = ASSET / source.relative_to(HERE / 'archive')
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open('xb') as stream:
                stream.write(source.read_bytes())
    for op in plan['documents']:
        target = REPO / op['path']
        require(digest(target.read_bytes()) == op['preimage_sha256'], 'Report changed during publication')
        target.write_bytes(postimages[op['path']])
    protected(state)
    checked = verify(ASSET, HERE.parent, ASSET_ROOT)
    for op in plan['documents']:
        require(digest((REPO / op['path']).read_bytes()) == op['postimage_sha256'], 'Published report mismatch')
    receipt = dict(checked)
    receipt['status'] = 'PUBLISHED_AND_VERIFIED'
    receipt['documents'] = plan['documents']
    receipt['v1_protected_source_test_build_edits'] = 'NONE'
    receipt['git'] = 'NOT RUN'
    with (HERE / 'publication.json').open('xb') as stream:
        stream.write((json.dumps(receipt, ensure_ascii=False, indent=2) + chr(10)).encode('utf-8'))
    print(json.dumps(receipt, ensure_ascii=False))


if __name__ == '__main__':
    main()
