"""Read-only round19 exact-byte archive verification; no workloads or Git."""
import argparse
import gzip
import hashlib
import json
from pathlib import Path


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def relative_path(value):
    path = Path(value)
    require(not path.is_absolute() and '..' not in path.parts, 'Unsafe archive path')
    require(':' not in value and chr(92) not in value, 'Non-relative archive path')
    return path


def verify(directory, source_root=None):
    directory = Path(directory).resolve()
    raw_manifest = (directory / 'manifest.json').read_bytes()
    manifest = json.loads(raw_manifest)
    complete = json.loads((directory / 'COMPLETE.json').read_bytes())
    require(complete['status'] == 'COMPLETE' and complete['manifest_sha256'] == digest(raw_manifest), 'Bad completion/manifest identity')
    require(manifest['decision'] == 'REJECTED (parent)' and manifest['completed_pairs'] == 3, 'Wrong decision or pair count')
    expected = {'manifest.json', 'COMPLETE.json'}
    sources = set()
    raw_total = packed_total = 0
    for item in manifest['files']:
        rel = relative_path(item['path'])
        source_rel = relative_path(item['source'])
        require(item['path'] not in expected and item['source'] not in sources, 'Duplicate archive entry')
        require(item['path'] == 'files/' + item['source'] + '.gz', 'Unexpected gzip mapping')
        require('span' not in item['source'].lower() and 'round20' not in item['source'].lower(), 'Other experiment included')
        target = directory / rel
        require(not target.is_symlink(), 'Symlink in archive')
        packed = target.read_bytes()
        require(len(packed) == item['packed_bytes'] and digest(packed) == item['packed_sha256'], 'Packed bytes mismatch: ' + item['source'])
        raw = gzip.decompress(packed)
        require(len(raw) == item['raw_bytes'] and digest(raw) == item['raw_sha256'], 'Raw bytes mismatch: ' + item['source'])
        if source_root is not None:
            source = Path(source_root) / source_rel
            require(source.is_file() and not source.is_symlink(), 'Missing/linked original: ' + item['source'])
            require(source.read_bytes() == raw, 'Original changed: ' + item['source'])
        expected.add(item['path'])
        sources.add(item['source'])
        raw_total += len(raw)
        packed_total += len(packed)
    actual = {p.relative_to(directory).as_posix() for p in directory.rglob('*') if p.is_file()}
    require(actual == expected, 'Missing or unlisted archive file')
    require(len(sources) == complete['file_count'], 'Wrong completion file count')
    return {'status': 'PASS', 'package_dir': str(directory), 'file_count': len(sources), 'manifest_sha256': digest(raw_manifest), 'raw_bytes': raw_total, 'packed_bytes': packed_total, 'gzip_raw_and_packed_hashes': 'ALL MATCH', 'source_bytes': 'ALL MATCH' if source_root is not None else 'NOT REQUESTED', 'execution': 'Offline byte verification only; no native/build/SQL/performance/Git'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--package-dir', required=True, type=Path)
    parser.add_argument('--source-root', type=Path)
    parser.add_argument('--report', type=Path)
    args = parser.parse_args()
    result = verify(args.package_dir, args.source_root)
    if args.report:
        with args.report.open('xb') as stream:
            stream.write((json.dumps(result, ensure_ascii=False, indent=2) + chr(10)).encode('utf-8'))
    print(json.dumps(result, ensure_ascii=False))


if __name__ == '__main__':
    main()
