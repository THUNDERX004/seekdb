# Round19 rejected template V1 archive helper

Scope: exact-byte evidence packaging and bilingual FTS report insertion only. Native/build/SQL/performance execution and Git are forbidden for this sidecar. Existing parent-run evidence is checked as files; no native result is manufactured or rerun.

The packager uses explicit filenames: the original six native build directories, four run directories and seven allowed root files only. It does not recurse into the native root or discover future/span files. Historical preparation READMEs/manifests remain unchanged. Current live span source is excluded and is not restored or represented as the template source.

Run the offline archive command once with the workspace Python:

    python -B setup/fts/round19-template-archive/package.py

Review the C: staged archive, reports, native-byte-comparison.json and publication-plan.json. The scoped publisher defaults to a read-only plan; --execute writes only the new competition-round19-template assets and the two approved existing report files, after exact preimage checks:

    python -B setup/fts/round19-template-archive/publish_docs.py --execute

Independent verification, with --source-root set to the absolute setup/fts path, checks every original byte stream as well as gzip/raw hashes. Omit --source-root for a standalone archived-byte verification:

    python -B setup/fts/round19-template-archive/verify_package.py --package-dir D:/Projects/OceanBase/seekdb/docs/developer-guide/assets/fts-performance/competition-round19-template --source-root C:/Users/11946/Documents/ChatGPT/OceanBase比赛/setup/fts

Do not rerun the packager or publisher after finalization; they refuse existing outputs. Manifest.json and COMPLETE.json identify the immutable package. Mutable sidecar status/publication/verification receipts remain outside the manifest to avoid self-referential hashes. The helper code, source identities, decision, native offline checks, document preimages and staged postimages are included as exact-byte gzip artifacts. No formal score, full-score claim, causal tokenize gain or stable query benefit is asserted. Parent owns review, commit and push.
