"""Publish only approved round19 assets and two FTS report additions; no Git."""
import argparse
import json
from pathlib import Path
from verify_package import digest, require, verify

HELPER = Path(__file__).resolve().parent
REPO = Path('D:/Projects/OceanBase/seekdb')
ASSET = Path('docs/developer-guide/assets/fts-performance/competition-round19-template')
DOCS = ['docs/developer-guide/en/fts-performance.md', 'docs/developer-guide/zh-CN/fts-performance.md']


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true')
    args = parser.parse_args()
    plan = json.loads((HELPER / 'publication-plan.json').read_bytes())
    require(plan['asset_directory'] == ASSET.as_posix() and plan['repository'] == str(REPO), 'Publication scope mismatch')
    require([x['path'] for x in plan['operations']] == DOCS, 'Unexpected document targets')
    result = verify(HELPER / 'archive', HELPER.parent)
    require(result['manifest_sha256'] == plan['manifest_sha256'], 'Archive changed')
    destination = REPO / ASSET
    require(not destination.exists(), 'Asset directory already exists; inspect rather than overwrite')
    for op in plan['operations']:
        target = REPO / op['path']
        staged = HELPER / op['staged']
        require(digest(target.read_bytes()) == op['preimage_sha256'], 'Existing document changed: ' + op['path'])
        require(digest(staged.read_bytes()) == op['staged_sha256'], 'Staged document changed')
    if not args.execute:
        print(json.dumps({'status': 'PLAN_ONLY', 'asset_directory': str(destination), 'manifest_sha256': result['manifest_sha256'], 'documents': DOCS}, ensure_ascii=False))
        return
    destination.mkdir()
    for source in sorted((HELPER / 'archive').rglob('*')):
        if source.is_file():
            target = destination / source.relative_to(HELPER / 'archive')
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open('xb') as stream:
                stream.write(source.read_bytes())
    for op in plan['operations']:
        target = REPO / op['path']
        require(digest(target.read_bytes()) == op['preimage_sha256'], 'Document changed during publication')
        target.write_bytes((HELPER / op['staged']).read_bytes())
        require(digest(target.read_bytes()) == op['staged_sha256'], 'Published document differs')
    verification = verify(destination, HELPER.parent)
    receipt = {'status': 'PUBLISHED_AND_VERIFIED', 'asset_directory': str(destination), 'manifest_sha256': verification['manifest_sha256'], 'file_count': verification['file_count'], 'documents': [{'path': op['path'], 'sha256': digest((REPO / op['path']).read_bytes())} for op in plan['operations']], 'production_test_build_ci_edits': 'NONE', 'git': 'NOT RUN'}
    with (HELPER / 'publication.json').open('xb') as stream:
        stream.write((json.dumps(receipt, ensure_ascii=False, indent=2) + chr(10)).encode('utf-8'))
    print(json.dumps(receipt, ensure_ascii=False))


if __name__ == '__main__':
    main()
