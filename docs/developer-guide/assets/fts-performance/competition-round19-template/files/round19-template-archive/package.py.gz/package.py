"""Explicit-allowlist round19 rejected-template archive; file operations only."""
import datetime
import gzip
import io
import json
import re
from pathlib import Path
from verify_package import digest, require, verify

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
REPO = Path('D:/Projects/OceanBase/seekdb')
NATIVE = 'round19-stringdiff-native/'
PROPOSAL = 'round19-stringdiff-template-proposal/'
SOURCE = 'src/storage/blocksstable/encoding/ob_string_diff_decoder.cpp'
MAX_FILE = 16 * 1024 * 1024
NL = chr(10)


def create(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(data)


def write_json(path, data):
    create(path, (json.dumps(data, ensure_ascii=False, indent=2) + NL).encode('utf-8'))


def read_json(path):
    return json.loads(path.read_bytes())


def record_native():
    records = {}
    for label in ['control-run1', 'candidate-run1', 'control-extended-run1', 'template-extended-run1']:
        folder = ROOT / NATIVE / label
        receipt = read_json(folder / 'run.json')
        require(receipt['native'] == receipt['output_validation'] == 'PASS' and receipt['exit_code'] == 0, 'Native receipt not passing')
        actual = {}
        for name in ['stdout.log', 'stderr.log', 'tuples.log']:
            data = (folder / name).read_bytes()
            actual[name] = {'bytes': len(data), 'sha256': digest(data)}
            pin = receipt['tuples_sha256'] if name == 'tuples.log' else receipt['logs_sha256'][name]
            require(digest(data) == pin, 'Native log pin mismatch')
        require(len((folder / 'tuples.log').read_bytes().splitlines()) == receipt['tuple_lines'], 'Native tuple count mismatch')
        records[label] = {'receipt': receipt, 'actual_files': actual}
    for control, candidate in [('control-run1', 'candidate-run1'), ('control-extended-run1', 'template-extended-run1')]:
        for name in ['stdout.log', 'stderr.log', 'tuples.log']:
            require((ROOT / NATIVE / control / name).read_bytes() == (ROOT / NATIVE / candidate / name).read_bytes(), 'Native complete bytes differ')
    original_lines = (ROOT / NATIVE / 'control-run1/stdout.log').read_bytes().splitlines(keepends=True)
    extended = (ROOT / NATIVE / 'control-extended-run1/stdout.log').read_bytes()
    require(original_lines[-1].startswith(b'PASS') and extended.startswith(b''.join(original_lines[:-1])), 'Original stdout prefix changed in extended test')
    comparison = read_json(ROOT / NATIVE / 'extended-template-comparison.json')
    require(comparison['status'] == 'PASS' and comparison['cases'] == 230 and comparison['complete_tuple_match'] and comparison['original152_prefix_unchanged'], 'Parent extended comparison differs')
    for label in ['control-extended-run1', 'template-extended-run1']:
        require(comparison['runs'][label] == records[label]['receipt'], 'Immutable parent run receipt differs')
    for source, expected in [('test_stringdiff_template.cpp', records['control-run1']['receipt']['test_sha256']), ('test_stringdiff_template_extended.cpp', records['control-extended-run1']['receipt']['test_sha256'])]:
        require(digest((ROOT / NATIVE / source).read_bytes()) == expected, 'Native test source changed')
    for label in ['control-build1', 'control-build2']:
        receipt = read_json(ROOT / NATIVE / label / 'receipt.json')
        require(digest((ROOT / NATIVE / label / 'test-source-failed.cpp').read_bytes()) == receipt['test_sha256'], 'Failed compile source not exact')
    return {'status': 'PASS_EXISTING_PARENT_EVIDENCE_OFFLINE_VERIFIED', 'original_cases': 152, 'extended_cases': 230, 'complete_stdout_stderr_tuples_equal_within_each_pair': True, 'original152_stdout_prefix_unchanged': True, 'runs': records, 'parent_extended_comparison_sha256': digest((ROOT / NATIVE / 'extended-template-comparison.json').read_bytes()), 'execution_by_archiver': 'NONE; existing output files compared only'}


def section(comparison, language):
    aggregate = comparison['aggregate_from_metric_run_means']
    rows = NL.join('| {quote}{metric}{quote} | {control:.7g} | {candidate:.7g} | {improvement:+.6%} |'.format(quote=chr(96), **row) for row in aggregate['metrics'])
    pairs = NL.join('| {pair} | {query:+.6%} | {overall:+.6%} |'.format(pair=p['pair'], query=p['category_improvements']['query'], overall=p['overall_improvement']) for p in comparison['pairs'])
    template = (HERE / ('report-template.' + language + '.md')).read_text(encoding='utf-8')
    return (template.replace('@@ROWS@@', rows).replace('@@PAIRS@@', pairs).replace('§', chr(96)) + NL).encode('utf-8')


def main():
    require(not (HERE / 'archive').exists(), 'Archive already exists; do not repackage frozen inputs silently')
    state = read_json(HERE / 'status.json')
    comparison_path = ROOT / 'round19-evidence/template-comparison-3pair.json'
    comparison_raw = comparison_path.read_bytes()
    comparison = json.loads(comparison_raw)
    require(comparison['completed_pairs'] == 3, 'Incomplete pairs')
    for name, pin in comparison['input_hashes'].items():
        data = (ROOT / name).read_bytes()
        require(len(data) == pin['bytes'] and digest(data) == pin['sha256'], 'Benchmark input no longer matches immutable comparison')
    for label, record in comparison['records'].items():
        receipt = record['receipt']
        role = 'candidate' if 'candidate' in label else 'control'
        require(receipt['binary_sha256'] == comparison['binary_pins'][role] and receipt['log_level'] == 'WARN', 'Benchmark identity mismatch')
        require(receipt['affinity_mask'] == receipt['affinity_mask_verified'] == 15, 'Affinity mismatch')
        require(all(x['exit_code'] == 0 for x in receipt['actions']), 'Failed benchmark action')
    native = record_native()
    write_json(HERE / 'native-byte-comparison.json', native)
    proposal = read_json(ROOT / PROPOSAL / 'manifest.json')
    item = proposal['files'][0]
    for path, pin in [(ROOT / PROPOSAL / 'original' / SOURCE, item['original']), (ROOT / PROPOSAL / SOURCE, item['candidate']), (ROOT / PROPOSAL / 'source.patch', proposal['patch'])]:
        data = path.read_bytes()
        require(len(data) == pin['bytes'] and digest(data) == pin['sha256'], 'Proposal source/patch mismatch')
    write_json(HERE / 'source-identities.json', {'meaning': 'Exact historical incremental proposal source; no official-original or current-live-source claim', 'original': item['original'], 'candidate': item['candidate'], 'patch': proposal['patch'], 'historical_benchmark_binary_pins': comparison['binary_pins'], 'historical_labels': {k: v['receipt']['source_commit'] for k, v in comparison['records'].items()}, 'later_live_worktree': 'Parent reports separate span source applied; excluded and not captured or restored by archiver', 'production_edits_by_archiver': 'NONE'})
    write_json(HERE / 'disposition.json', {'decision': 'REJECTED (parent)', 'candidate': 'round19 template V1 only', 'completed_pairs': 3, 'aggregate_from_existing_comparison': comparison['aggregate_from_metric_run_means'], 'reason': 'Query pair results inconsistent; build regression; untouched tokenize fluctuation is not a causal decoder gain', 'formal_result': 'NONE NEW; no cumulative score or full-score claim', 'historical_pending_text': 'Preserved unchanged; later actual parent executions documented separately', 'native': {'original_cases': 152, 'extended_cases': 230, 'existing_parent_runs': 'PASS; offline byte pins checked; no new native execution'}, 'parent_baseline_statement': 'Parent reports empty official-file diff and official baseline ancestry exit 0; archiver performs no Git verification', 'archive_execution': 'File inspection/packaging only; no Git, build, runtime, SQL or performance'})
    operations = []
    for language in ['en', 'zh-CN']:
        rel = 'docs/developer-guide/' + language + '/fts-performance.md'
        raw = (REPO / rel).read_bytes()
        require(digest(raw) == state['documents_preimages'][rel]['sha256'], 'Document changed since first inspection')
        require(b'competition-round19-template/manifest.json' not in raw, 'Round19 section already exists')
        marker = raw.index(bytes([10])) + 1
        require(raw[marker:marker + 1] == bytes([10]), 'Unexpected title spacing')
        addition = section(comparison, language)
        create(HERE / ('report.' + language + '.md'), addition)
        create(HERE / 'original-documents' / language / 'fts-performance.md', raw)
        staged = raw[:marker] + bytes([10]) + addition + raw[marker + 1:]
        staged_rel = 'repository-stage/' + rel
        create(HERE / staged_rel, staged)
        require(staged[:marker] == raw[:marker] and staged.endswith(raw[marker + 1:]), 'Existing report bytes changed')
        operations.append({'path': rel, 'preimage_sha256': digest(raw), 'staged': staged_rel, 'staged_sha256': digest(staged), 'inserted_bytes': len(staged) - len(raw)})
    paths = []

    def add(name):
        require(name not in paths, 'Duplicate input ' + name)
        require((ROOT / name).is_file() and not (ROOT / name).is_symlink(), 'Required file missing ' + name)
        paths.append(name)

    for variant in ['control', 'candidate']:
        for i in [1, 2, 3]:
            label = 'r19-template-' + variant + '-a' + str(i)
            for suffix in ['benchmark.log', 'experiment.json', 'input-validation.log', 'report.txt', 'server.log']:
                add(label + '-' + suffix)
            if i == 1:
                for suffix in ['count-union-accounting.log', 'keytypes.log', 'query-materialization.log', 'ranked.log', 'sort-metadata.log', 'sort-plans.json', 'test_collation.py.log', 'test_dictionary_prefixes.py.log', 'test_hot_path.py.log', 'test_map_concurrency.py.log', 'test_match_batches.py.log', 'test_stopword_concurrency.py.log', 'test_tokenize_config.py.log']:
                    add(label + '-' + suffix)
    for name in ['README.md', 'summarize-template.py', 'summary-3pair-output.log', 'template-comparison-2pair.json', 'template-comparison-3pair.json']:
        add('round19-evidence/' + name)
    for name in ['manifest.json', 'native-fixture-design.md', 'README.md', 'report.md', 'source.patch', SOURCE, 'original/' + SOURCE]:
        add(PROPOSAL + name)
    root_native = ['test_stringdiff_template.cpp', 'test_stringdiff_template_extended.cpp', 'README.md', 'extended-design.md', 'build_native.py', 'run_native.py', 'extended-template-comparison.json']
    for name in root_native:
        add(NATIVE + name)
    builds = ['control-build1', 'control-build2', 'control-build3', 'candidate-build1', 'template-extended-build1', 'control-extended-build1']
    for directory in builds:
        for name in ['receipt.json', 'compile.log', 'compile.rsp', 'link-inputs.rsp']:
            add(NATIVE + directory + '/' + name)
        if directory in ['control-build1', 'control-build2']:
            add(NATIVE + directory + '/test-source-failed.cpp')
        else:
            for name in ['link.log', 'link-intermediate/embed.manifest', 'link-intermediate/intermediate.manifest', 'link-intermediate/manifest.rc']:
                add(NATIVE + directory + '/' + name)
        if directory in ['control-build3', 'candidate-build1']:
            add(NATIVE + directory + '/build-helper-original.py')
    runs = ['control-run1', 'candidate-run1', 'template-extended-run1', 'control-extended-run1']
    for directory in runs:
        for name in ['build-receipt.json', 'run.json', 'stdout.log', 'stderr.log', 'tuples.log']:
            add(NATIVE + directory + '/' + name)
        if directory in ['control-run1', 'candidate-run1']:
            add(NATIVE + directory + '/run-helper-original.py')
    for name in ['round19-stringdiff-candidate-build.log', 'round19-template-control-restore-build.log', 'experiment-affinity4.py', 'experiment-competition.py', 'mysql_client.py', 'build-competition.ps1']:
        add(name)
    own = ['package.py', 'verify_package.py', 'publish_docs.py', 'README.md', 'report-template.en.md', 'report-template.zh-CN.md', 'native-byte-comparison.json', 'source-identities.json', 'disposition.json', 'report.en.md', 'report.zh-CN.md', 'original-documents/en/fts-performance.md', 'original-documents/zh-CN/fts-performance.md']
    own += [op['staged'] for op in operations]
    for name in own:
        add(HERE.name + '/' + name)
    exclusions = {'policy': 'Explicit filenames only; no recursive native or future-file discovery', 'native_root_allowlist': root_native, 'native_build_directories': builds, 'native_run_directories': runs, 'excluded': ['All other native directories/root files, including every span experiment', 'exe,pdb,lib,obj,dll,res,pyc and other binary payloads', 'runtime,data,temp directories and large server logs', 'secrets and connection credential files', 'round20 and unfinished/unrelated proposals'], 'server_logs': [{'path': name, 'bytes': (ROOT / name).stat().st_size, 'treatment': 'Retain complete bounded launcher log'} for name in paths if name.endswith('-server.log')], 'referenced_not_duplicated': ['Historical parent_line_evidence profile-source-lines.json referenced by unchanged proposal manifest; no new profiling or symbolization']}
    require(all(x['bytes'] == 314 for x in exclusions['server_logs']), 'Unexpected server launcher log size; inspect before packaging')
    write_json(HERE / 'selection.json', {'files': sorted(paths), 'exclusions': exclusions})
    add(HERE.name + '/selection.json')
    snapshots = {}
    for name in sorted(paths):
        path = ROOT / name
        require(path.stat().st_size <= MAX_FILE, 'Oversized selected file; inspect rather than truncate: ' + name)
        require('span' not in name.lower() and 'round20' not in name.lower(), 'Other experiment selected')
        require(not any(part.lower() in ['.secrets', 'runtime', 'data', 'temp', 'tmp', '__pycache__'] for part in Path(name).parts), 'Forbidden path')
        raw = path.read_bytes()
        require(not raw.startswith(b'MZ') and bytes([0]) not in raw, 'Unexpected binary stream: ' + name)
        require(not re.search(rb'-----BEGIN [A-Z ]*PRIVATE KEY-----|gh[pousr]_[A-Za-z0-9]{24,}|github_pat_[A-Za-z0-9_]{30,}', raw), 'Potential credential literal; inspect without publishing')
        snapshots[name] = raw
    package = HERE / 'archive'
    package.mkdir()
    entries = []
    for name, raw in sorted(snapshots.items()):
        destination = 'files/' + name + '.gz'
        buffer = io.BytesIO()
        with gzip.GzipFile(filename='', mode='wb', compresslevel=9, mtime=0, fileobj=buffer) as stream:
            stream.write(raw)
        packed = buffer.getvalue()
        require(gzip.decompress(packed) == raw, 'Gzip round-trip mismatch')
        create(package / destination, packed)
        entries.append({'source': name, 'path': destination, 'raw_bytes': len(raw), 'raw_sha256': digest(raw), 'packed_bytes': len(packed), 'packed_sha256': digest(packed)})
    for name, raw in snapshots.items():
        require((ROOT / name).read_bytes() == raw, 'Input changed while packaging: ' + name)
    require(comparison_path.read_bytes() == comparison_raw, 'Immutable comparison changed')
    manifest = {'schema_version': 1, 'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'experiment': 'round19 string-diff template V1', 'decision': 'REJECTED (parent)', 'completed_pairs': 3, 'source_root': str(ROOT), 'checkout_root': str(REPO), 'encoding': 'Exact raw bytes in gzip with empty filename/mtime=0; no newline conversion or JSON rewriting', 'comparison': 'Existing immutable parent 3-pair and extended-native comparisons archived verbatim, not recomputed', 'native': 'Existing parent original152 and separate extended230 PASS; full existing outputs checked offline', 'formal_result': 'No new formal result, cumulative score or full-score claim', 'execution_by_archiver': 'Offline file packaging only; no compiler, linker, native runtime, SQL, benchmark, profile or Git', 'later_live_source': 'Separate span source excluded; archive does not claim current worktree restoration', 'exclusions': exclusions, 'files': entries}
    write_json(package / 'manifest.json', manifest)
    manifest_sha = digest((package / 'manifest.json').read_bytes())
    write_json(package / 'COMPLETE.json', {'status': 'COMPLETE', 'file_count': len(entries), 'manifest_sha256': manifest_sha})
    result = verify(package, ROOT)
    write_json(HERE / 'verification.json', result)
    write_json(HERE / 'publication-plan.json', {'repository': str(REPO), 'asset_directory': 'docs/developer-guide/assets/fts-performance/competition-round19-template', 'manifest_sha256': manifest_sha, 'operations': operations})
    print(json.dumps({'status': 'STAGED_AND_VERIFIED', 'file_count': len(entries), 'manifest_sha256': manifest_sha, 'raw_bytes': result['raw_bytes'], 'packed_bytes': result['packed_bytes'], 'docs': [op['path'] for op in operations]}, ensure_ascii=False))


if __name__ == '__main__':
    main()
