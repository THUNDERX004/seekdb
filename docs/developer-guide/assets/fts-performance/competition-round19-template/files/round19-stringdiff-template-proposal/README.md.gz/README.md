# Round19 small-string common template

Status: STAGED / UNTESTED / UNPROMOTED. This preparation performed no production edit, compiler/linker invocation, native execution, SQL, benchmark, service operation, or Git operation.

One candidate changes only `src/storage/blocksstable/encoding/ob_string_diff_decoder.cpp`. After the existing allocation, batches with `row_cap >= 2`, `1 <= string_size <= 64`, and `diff_desc_cnt >= 3` initialize the first output string to zero, fill its common runs once, and copy exactly string_size bytes to every later output slot. All template copies finish before any row's diff payload is decoded. The complete original common-copy loop remains the fallback.

- `original/src/.../ob_string_diff_decoder.cpp`: exact current live decoder preimage.
- `src/.../ob_string_diff_decoder.cpp`: proposed one-file replacement.
- `source.patch` and `manifest.json`: exact source delta, byte hashes, and dependency/profiling provenance pins.
- `report.md`: correctness argument, guard rationale, cost tradeoff, and static self-review.
- `native-fixture-design.md`: concise tests of actual production batch/scalar decoding; design only, no test executable or passing result is claimed.

The round18 hex proposal is unchanged and remains frozen, untested/unpromoted. This statement does not assert that it has never been executed. The new patch contains no hex proposal helper or codec/header/format change. Parent owns preimage checks, separate serial tests, real applicability checks, and matched benchmarks after its accepted-union gate.
