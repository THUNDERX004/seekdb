# Round19: initialized common template for small batch strings

## Evidence and status

STAGED / UNTESTED / UNPROMOTED. Auxiliary preparation only; no production source/header changes, compiler/linker/native execution, SQL, benchmark, service, or Git operations. Exact original/candidate hashes are in `manifest.json`. The current decoder preimage is not independently asserted to be an official-original revision.

Parent supplied exact-source symbolization of its existing control profiles, preserved at `../round18-stringdiff-proposal/profile-source-lines.json`, using the pinned control EXE SHA-256 `ddd423ff4e7b7da6b80ac9cb034dbed8e7c76be24eb41f7b2764c7741a72896a` and PDB SHA-256 `c7d07df36b28e1833bb7061b390b849d3c3455ceb79777555b95f78fa2f06f3a`. Parent reports all 159 decoder IP samples mapped; selected locations were:

| Original decoder location | CN samples / 1814 total IPs | BENG samples / 2188 total IPs |
| --- | --- | --- |
| common-copy lines 169/170 | 44 | 46 |
| non-hex copy line 194 | 13 | 18 |
| hex line 186 | 2 | 2 |
| hex line 187 | 0 | 1 |

These are parent-reported line associations, not stacks, CPU percentages, elapsed-time shares, or proof of template guard coverage. No profiler or symbolizer was run in this task. The old hex proposal is left immutable and frozen untested/unpromoted; no statement about it never having been executed is made.

## One small change

Only the allocation-success branch preceding payload decoding in `ObStringDiffDecoder::batch_decode` changes. The guard is `row_cap >= 2 && string_size > 0 && string_size <= 64 && header_->diff_desc_cnt_ >= 3`.

1. `MEMSET(buf, 0, string_size)` initializes every byte that will be copied.
2. The original `header_->copy_string(LeftToRight, logical_not<uint8_t>, common_data(), buf)` fills the common runs once. Diff positions remain initialized zero.
3. For i=1..row_cap-1, `MEMCPY(buf + i*buf_size, buf, string_size)` initializes the remaining row strings from that template.
4. Only after the entire preparation branch returns does the unchanged fixed/variable payload loop begin; each ordinary row overwrites all its own diff positions.

Every other input takes the byte-identical original common-copy loop, including cap=0/1, zero-length strings, strings longer than 64, and fewer than three descriptors. Both hex and non-hex payload paths, scalar decode, row locating, null helpers, and header/codec definitions are unchanged. There is no extra allocation, cache, member, or pointer lifetime.

## Generic cost rationale, not an asserted win

Let N=row_cap, D=descriptor count, S=string_size, C=common-byte count. The old common initialization scans D descriptors and copies C bytes for each of N slots, including NULL slots. The candidate scans D once, zeroes S once, and copies S bytes to each later slot. It removes (N-1) descriptor traversals but adds store traffic of approximately S+(N-1)*(S-C) bytes relative to the original common-copy writes; payload writes are unchanged. Compiler and memory effects remain unmeasured.

The fixed 64-byte maximum bounds each new contiguous operation, and D>=3 avoids using it for the simplest one/two-descriptor layouts. N>=2 avoids an additional zero-fill when there is no template reuse. These are conservative general heuristics, not benchmark-specific values or a cost-model guarantee. A batch of two rows or a low-common-byte layout may still regress. The line samples do not reveal S or D, so the parent must check actual guard applicability before interpreting performance. Exactly this guard is staged; no alternate 128-byte/two-descriptor candidate is bundled.

## Correctness, errors, and ownership

The proof uses the existing valid-header invariant that descriptor counts partition the output string and common_data contains exactly the concatenated common runs (`ObStringDiffHeader::copy_string` in `ob_string_diff_encoder.h`). At the end of preparation, each slot's common bytes equal the original initialization and every diff byte is a defined zero. The unchanged payload reconstruction then writes the same complete diff sequence into the same positions, leaving identical completed strings. Zero-count descriptors require no special new unpack call; hex nibble state is untouched.

- **No uninitialized-copy source:** zero-fill covers exactly [buf,buf+S) before common fill or any template memcpy. Neither arena padding nor undefined diff bytes are read as a template. No bytes beyond S are copied.
- **First requested row NULL / all NULL:** the template is raw allocator-owned slot zero, not `datums[0].ptr_` or the first decoded document. It is initialized even if row zero will be skipped. Every clone precedes any diff reconstruction. Existing null skips and datum metadata remain unchanged; all-NULL batches keep the existing allocation/preparation behavior.
- **No template corruption by row zero:** its diff payload is decoded only after all other slots have received the initial common template. Later rows never copy the already-decoded row-zero payload.
- **Tight bounds/nonoverlap:** on the new branch S<=64 and buf_size=max(S,128)=128. Source [0,S) and destinations [i*128,i*128+S), i>=1, do not overlap. The final destination ends no later than row_cap*128. Only existing caller-valid allocation arithmetic is assumed. The stride and allocation size are unchanged.
- **Row order/duplicates/capacity:** no row-ID access or datum publication moves. Duplicate IDs still have separate output slots; reordered IDs still use the same input cells. Cap=0 uses the old allocator result and original loop, with no dereference of slot zero introduced. Invalid negative/overflow capacities remain outside the existing internal method contract.
- **Errors:** a null-bit/row-index prepass error bypasses allocation and template work as before. Allocation failure returns the same error. Subsequent variable-row or cell-location failures leave exactly the same published datum prefix and untouched suffix metadata. Unpublished allocator bytes may now be defined zero where they were previously undefined; callers must not treat failed/unpublished slots as valid outputs. No new fallible operation or return code is added.
- **Lifetime/reentrancy:** output remains in the existing ctx allocator, with original pack_, ptr_, and stride. No template pointer escapes separately, and decoding a later batch does not reuse or overwrite the previous batch's allocation.
- **Null/extend semantics:** the same real null helpers are called. As documented in `ob_icolumn_decoder.h`, batch NOP support is absent; helpers currently mark any nonzero stored extension as null. Preserve this baseline behavior, and use the old batch result rather than scalar NOP semantics as that diagnostic's oracle.
- **Byte semantics/fallbacks:** no charset, length, codec, nibble, data format, common-data source, or diff descriptor change. Scalar `decode`, init/reuse/update_pointer, and both complete payload loops are unchanged.

## Static review and parent gates

Static review follows the checkout's code-review skill read earlier in this chat: checked exact changed invariant, data initialization, nonoverlap, NULL-first/all-NULL flow, partial-error publication, allocation lifetime, fallback identity, and the explicit memory-traffic tradeoff. No native correctness result or speedup is claimed.

Parent gates: match live preimage/dependency hashes; independently finish accepted-union work; compile the new decoder in the intended production configuration; run the real batch/scalar fixtures in `native-fixture-design.md`; verify template guard coverage separately from scored runs; then compare serial matched unchanged full benchmarks. No official benchmark, scoring, input, SQL, build, CI, or baseline file is included in the patch.
