# Native actual-batch/scalar fixtures (design only)

No C++ test executable, compilation, or test pass is claimed. This plan calls the real production implementation; it is not a copied decoder or template-only model.

## Link and oracles

Use the parent's existing production-linked native harness approach: a test main compiled with the matching production configuration/generated headers and actual storage objects/archives, excluding observer main. Resolve the containing unity/storage object from real build inputs; do not assume an isolated decoder .obj exists or link duplicate definitions. Record object/source hashes. The fixture includes real `ob_string_diff_decoder.h`, `ob_string_diff_encoder.h`, `ob_raw_decoder.h`, `ob_row_index.h`, and `ob_block_sstable_struct.h`.

Invoke public `ObStringDiffDecoder::init`, the **actual candidate `batch_decode`**, and the unchanged actual production scalar `decode` on the same encoded cells with separate allocator lifetimes. Check return code, null/extension flags, length, and every published payload byte against both scalar results and owned original source strings. For partial-error/NOP diagnostics compare exact original-production versus candidate-production batch tuples in separate matched binaries; scalar and batch do not share NOP capabilities. Never compare allocator-specific absolute pointer values across builds.

## Concrete fixture construction

- Start with a real encoder-produced STRING_DIFF fixture where practical and assert the format/guard fields actually selected; do not silently accept CONST/another encoding. Add explicit well-formed metadata fixtures for threshold and descriptor edge cases.
- A minimal fast-path layout is C2/D1/C2/D2/C1: string_size=8, five descriptors, five common bytes, three diff bytes. Use different per-row diff bytes so accidental copying of row zero's decoded payload is detected. Create both raw-diff and hex-packed variants. In hex mode, pack the entire diff stream with one real `ObHexStringPacker`; an odd final nibble may use a poisoned unused low nibble. Common payload includes embedded NUL/high bytes.
- Fixed fixture storage is real header + descriptors + optional hex map + concatenated common bytes, followed at column_header.length_ by the extension bitmap and row payloads. Set header.length_ to the actual row payload stride. Call real `ctx.fill` with proper column attributes; do not leave cached attributes inconsistent.
- Variable fixtures use real ObFixRowIndex/ObVarRowIndex over actual row-formatted bytes and real ObRawDecoder::locate_cell_data through batch_decode. Include one-var-column and multi-var-column layouts, first/middle/last column positions, and mixed NULLs that vary physical row lengths. Scalar gets the matching real row data/bitstream.
- Use a tracking allocator delegating storage to a real arena, with allocation contents initially 0xA5, exact requested-size accounting, canaries, and one-shot allocation failure. For variable fixtures, a forwarding row index can inspect the tracked allocation at the first payload get() after allocation: assert every slot already contains correct common bytes and zero diff gaps, while bytes [string_size,128) remain 0xA5. Null prepass lookups occur before allocation; do not mistake them for this hook. This directly detects copying before initialization or after row-zero diff mutation.

## Required matrix

| Dimension | Cases / required assertions |
| --- | --- |
| Guard | cap 0/1/2/7/64; S 1/63/64/65/127/128/129; D 1/2/3/5; valid combinations plus a synthetic zero-size header using the unchanged fallback. Real encoder rejects empty strings, so do not describe the S=0 fixture as encoder-produced. |
| Both payloads | Fast-path and fallback with raw diff and packed hex; odd/even diff totals, descriptor gaps, count-zero descriptors, and exact final packed-byte bounds. Original payload code must still supply all bytes. |
| NULL placement | No NULL, first requested row NULL, alternating NULL, last NULL, all NULL; extension bitmap spanning bytes. NULL ptr_ is not a readable output string. Verify unchanged null/len metadata and skipped payload behavior. |
| Row selection | Identity, reversed, and {last,0,middle,0,last}; duplicate IDs must occupy distinct 128-byte slots and match exact expected row bytes. |
| Template ordering | Distinct row-zero/row-one diff bytes; NULL first row; zero diffs inspected before any payload work. All later slots must receive the undecoded template before row zero is reconstructed. |
| Bounds/lifetime | Only S bytes initialized/copied per slot; padding and surrounding datum/cell_datas canaries unchanged; retain batch-A outputs while decoding B in the same arena and verify A remains valid until explicit reset. Exercise real update_pointer on a relocated backing block. |
| Failures | Not initialized; allocation failure; variable index/cell-location failures at first/middle/last payload positions; null-prepass failure before allocation. Compare exact return, allocation count/size, published prefix, and remaining datum metadata with original batch. |
| Extend contract | Normal/NULL supported comparison against scalar; stored NOP diagnostic must match original batch's existing null normalization, while scalar retains its original NOP semantics. |

For fallback identity, a tracking allocator/index probe should observe the original common-copy initialization pattern (common bytes initialized, diff gaps still 0xA5 before payload) when any guard component fails. For the fast path, require initialized zero gaps before payload. These probes do not replace checking full final results. Memory-sanitizer coverage on a supported toolchain supplements canaries; no Windows sanitizer availability is assumed.

After native correctness, parent verifies actual query guard coverage in a separate diagnostic and runs unchanged serial full control/candidate benchmarks. Line sample associations alone are insufficient to assert small sizes or descriptor counts. Keep results attributable to this one-file candidate; no performance improvement is predicted.
