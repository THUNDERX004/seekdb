# Round 19 extended native regression design

Status: prepared by static source inspection only; NOT COMPILED OR EXECUTED.
Parent owns separate original/candidate builds and complete output comparison.
No production files, Git, SQL, benchmark or service operations were performed.
The frozen test_stringdiff_template.cpp and README.md remain unchanged.

## Basis and actual guard

The extended TU copies the frozen 152-case source with SHA256
05f0f907d9723281d1ee557916f3a0bd96d90cf314cc19e8e6e0f7585d1635d6.
Its original 152 cases retain the same selections, assertions and records;
their former final PASS record moves to the end of the extended workload.
The current production predicate is row_cap >= 2, 0 < string_size <= 64,
and diff_desc_cnt >= 3. Counts below describe static eligibility, not measured
execution coverage. No assertion depends on choosing the optimized branch.

## Exactly 230 cases

| Cases | Count | Fixture schedule |
| --- | ---: | --- |
| 1-152 | 152 | Unchanged original workload |
| 153-184 | 32 | Variable lengths16/64, alternating layout2, both packing modes, all four NULL modes, capacities2/64 |
| 185-192 | 8 | Fixed length64, layout2, both packing modes, all four NULL modes, capacity64 |
| 193-224 | 32 | Fixed and variable length65, layout2, both packing modes, all four NULL modes, capacities2/64 |
| 225-230 | 6 | Variable lengths16/64/65, both packing modes, injected get failure after three published rows, then same-array retry |

Added capacity2 cases select rows7/44, whose complete source strings differ,
instead of the original modulo-16-equal pair7/55. Mixed mode now has an actual
NULL selected at capacity2; reversing the second batch also changes the first
row's NULL status. Larger selections retain reordered and duplicate IDs.

All 32 added variable length16/64 cases qualify, including all-NULL batches;
the eight new fixed length64/capacity64 cases also qualify. Length65 cases
exercise fallback immediately above the actual boundary. The four injected
length16/64 cases qualify for both failing and retry calls; the two length65
injections cover the matching fallback behavior. Among calls reaching buffer
initialization, static eligibility is 76 cases and 152 batch invocations,
including the original 32 cases/64 calls. The two original allocation-failure
cases cannot reach initialization and are excluded from these counts.
Of those eligible cases, 24 explicitly use capacity64.

## Real forwarded row-index failure

FailingRowIndex implements the actual ObIRowIndex get and both batch_get
signatures from ob_row_index.h. Both batch_get overloads forward unchanged.
get forwards calls0-2 to the actual ObVarRowIndex and returns
OB_ERR_UNEXPECTED on call3 without changing its output arguments. Assertions
require exactly four get calls and zero batch_get calls, proving the decoder
stops at that failure under the current call contract.

The injected fixture has no extend-value metadata. This intentionally avoids
the complete NULL-preprocessing scan in set_null_datums_from_var_column, so
the failure occurs in the variable diff-decoding loop after allocation and
three published non-NULL rows, rather than before any result is published.
Rows are 7,44,33,22,7,0,55; the first three have different generated strings.

Each output initially references its own 16-byte sentinel with length3-9 and
the actual HAS_LOB_HEADER datum flag. Published rows must match both unchanged
production scalar decode and the independent full source-byte oracle. The
failing slot and all following slots must preserve the exact sentinel pointer,
complete pack/flags, length and bytes. The aggregate return must remain the
injected error. This does not require unpublished allocation contents to match
between implementations: initializing internal diff gaps to zero is permitted.

Retry calls real batch_decode with the real index and the SAME populated datum
array, without clearing its published pointers or sentinel flags. All seven
rows must match scalar/source bytes, acquire new correctly spaced output slots,
and leave the failed call's previously published prefix intact. Both batch
allocations retain boundary and within-slot slack guards. Encoded-input poison
and sentinel checks verify ownership and absence of source/input mutation.

## Complete deterministic records

A successful complete run emits exactly 12,976 T records, 230 CASE records,
442 B records and one PASS record: 13,649 record lines in total, excluding any
production-library logs. The conservative stdout bound is 8 MiB, with no
truncation, normalization, silent error skips or generated expected fixture.

The 78 added cases contribute 8,016 T records: 3,168 variable, 1,536 fixed64,
3,168 boundary65 and 144 injected-error/retry records. Each injected case emits
24 tuples: seven partial-batch, three scalar-prefix, seven retry and seven
scalar-retry. Its partial-batch tuples carry the aggregate error return while
still owning all valid prefix/sentinel bytes; the scalar-prefix records carry
their actual successful scalar return. Thus error records do not conceal
already published output bytes. The output schema otherwise stays unchanged.

Parent must capture original and candidate independently with the same TU and
compare the complete output and successful exit status. Old control PASS152
and its tuple hash are parent-provided evidence only, not evidence that this
extended workload or the candidate has passed. Do not update the oracle from
candidate output. Preserve exact sources and failures for each native build.

## Native environment and remaining limits

Use the same actual storage-unity compile, whole-production-library linkage,
C++17 context/Flow setup and common/datum/ob_datum.h include as the frozen TU.
Parent-owned build_native.py/run_native.py are unchanged; this sidecar does not
assume that either helper automatically selects the new extended filename.

Fixtures remain direct, manually well-formed decoder inputs with real packing,
headers, arenas and row indexes, rather than full encoder-selected disk blocks.
Variable layouts still contain one variable column. Failure injection covers
the no-NULL variable decode loop, not early NULL-scan failure or malformed
row/column directories. Guard bytes establish checked write boundaries, not
absence of out-of-bounds reads. There is no sanitizer, concurrency, service,
performance or actual branch-diagnostic evidence from this sidecar.
