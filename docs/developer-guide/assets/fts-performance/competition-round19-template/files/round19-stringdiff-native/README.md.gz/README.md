# Round 19 string-diff native sidecar

## Freeze and evidence status

The C++ test is frozen for the parent's control/candidate native builds. This
sidecar author has not compiled or executed it, run SQL, benchmarks or Git, or
edited production sources. No regression pass, fast-path coverage, supported
branch claim or performance improvement is asserted.

Parent evidence: control-build1 failed compilation for the missing ObDatum
declaration and implicit MemoryContext boolean conversion. Parent archived its
exact failed source as control-build1/test-source-failed.cpp, added
common/datum/ob_datum.h before row_index, and changed the context check to
context_ != nullptr. Parent reports control-build2 starting; its result is
pending. The frozen source includes these parent-owned fixes. This handoff
makes no further C++ edits. build_native.py is also parent-owned.

## Contract and finite workload

The TU calls linked production ObStringDiffDecoder::batch_decode and unchanged
scalar decode, using actual contexts, row indexes and arena-backed allocation.
It compares complete owned results with both scalar decoding and independently
generated source bytes. It does not implement a decoder.

Exactly 152 cases use 67 physical rows and at most 64 selected rows per case.
Lengths: 1, 2, 16, 64, 127, 128, 129, 255 bytes. Capacities: 0, 1, 2, 7, 64.
The finite schedule is 80 fixed length/packing/capacity combinations, 32 extra
fixed layout/NULL cases, 32 variable cases at lengths 1/128/129/255, 6 explicit
non-NULL two-row length-127/128/129 cases, and 2 allocation-failure cases.

Both hex/non-hex payloads are covered. Layouts include common prefix, common
prefix/suffix, alternating common/diff bytes and common middle. Descriptors
split at the real 127-byte count limit. NULL modes: none, first selected row
NULL, mixed and all physical rows NULL. Selected IDs are reordered and
duplicated; the second batch reverses them. Common bytes include NUL/high-bit
bytes. Fixtures manually produce well-formed decoder metadata with the actual
hex packer, headers, ObColumnDecoderCtx::fill and fixed/variable row indexes.
Variable fixtures have one variable column, a 16-bit offset table, and no diff
payload in NULL rows.

## Complete output and checks

Each T record contains case, operation, output slot, input row ID, return code,
complete raw datum pack/flags, length and all result bytes in hex. Results own
their bytes; no pointer values are printed. A successful complete run emits
4,960 tuple records plus CASE/B/PASS records, conservatively below 4 MiB
excluding production-library logging. Unexpected errors fail; no silent skips,
normalization or fabricated expected outputs are used.

Checks: scalar/batch/source equality; allocation count and slot stride; leading
and trailing allocation guards; within-slot slack guards; unchanged encoded
inputs; previous-batch stability; independence from poisoned input; and
non-overlapping row/batch storage. Guarded allocation delegates to a real
arena. Zero-byte allocation preserves the real arena policy. Allocation-failure
cases preserve scalar NULL-success versus batch allocation-failure, recording
complete flags and length.

Parent should retain full original/candidate stdout and exit status and compare
complete deterministic output. Candidate output must not establish the
original oracle. Preserve failed sources/logs before repairs. Parent owns all
compilation, execution and runtime interpretation.

## Required environment and limits

Use the parent's production storage-unity compile/whole-library link capture,
replacing observer main with this TU. C++17 is needed for std::optional. Direct
headers: common/datum/ob_datum.h, lib/allocator/page_arena.h, lib/rc/context.h,
storage/blocksstable/encoding/ob_bit_stream.h, ob_row_index.h and
ob_string_diff_decoder.h (last two also under the encoding directory). The
decoder header includes real string-diff metadata and hex-packing declarations.
Real memory context/Flow initialization and allocator libraries are required;
this is not header-only. Parent-owned build_native.py controls variant capture,
the production source hash pin and actual compile/link commands.

Fixtures directly exercise decoders, not full checksummed disk blocks or encoder
selection. All-NULL metadata tests decoder behavior without claiming encoder
heuristics select STRING_DIFF for an entirely NULL column. Variable coverage is
limited to one variable column. Malformed metadata, injected row-index errors,
real allocator exhaustion, multiple columns, concurrency and sanitizers are
outside scope. Guard bytes do not prove absence of out-of-bounds reads. Actual
path diagnostics are needed before asserting a specific fast path was executed.
