"""Run one hash-pinned native test; never builds or opens SQL connections."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

def require(ok, reason):
    if not ok:
        raise RuntimeError(reason)

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--build-dir', required=True, type=Path)
    p.add_argument('--output-dir', required=True, type=Path)
    p.add_argument('--compare-run', type=Path)
    p.add_argument('--execute', action='store_true')
    a = p.parse_args()
    build, out = a.build_dir.resolve(), a.output_dir.resolve()
    require(a.execute and build.is_relative_to(HERE) and build != HERE, 'Explicit helper-owned build required')
    require(out.is_relative_to(HERE) and out != HERE and not out.exists(), 'Fresh helper-owned run required')
    require(not out.is_relative_to(build) and not build.is_relative_to(out), 'Separate build/run required')
    receipt = json.loads((build / 'receipt.json').read_text(encoding='utf-8'))
    require(receipt.get('build_succeeded') and receipt['compile']['exit_code'] == 0
            and receipt['link']['exit_code'] == 0, 'Successful native build required')
    require(receipt['production_sha256_before'] == receipt['production_sha256_after'], 'Production input mutation')
    require(sha(HERE / 'test_stringdiff_template.cpp') == receipt['test_sha256'], 'Test source changed')
    exe = build / 'test_stringdiff_template.exe'
    require(sha(exe) == receipt['executable_sha256'], 'Executable changed')
    for dll in receipt['runtime_dlls']:
        require(sha(build / dll['name']) == dll['sha256'], 'Runtime DLL changed')
    reference = None
    if a.compare_run:
        ref = a.compare_run.resolve()
        require(ref.is_relative_to(HERE) and ref != HERE, 'Helper-owned reference required')
        reference = json.loads((ref / 'run.json').read_text(encoding='utf-8'))
        require(reference['output_validation'] == 'PASS' and reference['variant'] == 'control'
                and reference['test_sha256'] == receipt['test_sha256'], 'Identical passing control test required')
        require(sha(ref / 'tuples.log') == reference['tuples_sha256'], 'Control tuples changed')
    out.mkdir()
    (out / 'build-receipt.json').write_bytes((build / 'receipt.json').read_bytes())
    result = dict(variant=receipt['variant'], test_sha256=receipt['test_sha256'],
                  executable_sha256=receipt['executable_sha256'], native='PENDING', output_validation='PENDING',
                  sql='NOT RUN', performance='NOT RUN', timeout_seconds=180)
    def save():
        (out / 'run.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    save()
    env = os.environ.copy()
    temp = out / 'tmp'; temp.mkdir()
    env['TMP'] = env['TEMP'] = str(temp)
    env['PATH'] = str(build) + os.pathsep + env.get('PATH', '')
    with (out / 'stdout.log').open('wb') as stdout, (out / 'stderr.log').open('wb') as stderr:
        try:
            r = subprocess.run([str(exe)], cwd=out, env=env, stdout=stdout, stderr=stderr, timeout=180)
        except subprocess.TimeoutExpired:
            result['native'] = 'TIMEOUT'; save(); raise
    result.update(exit_code=r.returncode, native='PASS' if r.returncode == 0 else 'FAIL',
                  logs_sha256={n: sha(out / n) for n in ('stdout.log', 'stderr.log')})
    save()
    require(r.returncode == 0, 'Native failed; output preserved')
    require((out / 'stdout.log').stat().st_size <= 64 * 1024 * 1024, 'Output too large')
    lines = (out / 'stdout.log').read_bytes().splitlines()
    tuples = [x for x in lines if x.startswith((b'CASE\t', b'T\t', b'B\t', b'PASS\t'))]
    require([x for x in tuples if x.startswith(b'PASS\t')] == [b'PASS\tcases=152'], 'Missing complete matrix')
    require(sum(x.startswith(b'CASE\t') for x in tuples) == 152, 'Incomplete cases')
    require(sum(x.startswith(b'T\t') for x in tuples) > 0, 'Missing tuples')
    data = b'\n'.join(tuples) + b'\n'
    (out / 'tuples.log').write_bytes(data)
    result['tuples_sha256'] = sha(out / 'tuples.log')
    result['tuple_lines'] = len(tuples)
    if reference is not None:
        result['control_tuple_match'] = data == (ref / 'tuples.log').read_bytes()
        save()
        require(result['control_tuple_match'], 'Control/candidate complete tuple mismatch')
    result['output_validation'] = 'PASS'; save()
    print(json.dumps(result, indent=2))

if __name__ == '__main__':
    main()
