# Round19 template: strict offline paired comparison

Prepared only. `summarize-template.py` has not been imported, compiled, or run by this sidecar. There is no round19 comparison result or score claim here. No SQL/build/benchmark/Git/server action is part of this script, and no archived round18 input is changed or selected. Current preparation writes only this README and the script.

## Parent invocation, only after complete pairs

From any working directory, using the existing Python environment:

```powershell
& 'C:/Users/11946/Documents/ChatGPT/OceanBase比赛/.venv/Scripts/python.exe' -B `
  'C:/Users/11946/Documents/ChatGPT/OceanBase比赛/setup/fts/round19-evidence/summarize-template.py' --pairs 1
```

`--pairs` accepts only 1, 2, or 3 and always selects pairs a1..aN, each with both control and candidate. Change the argument for the later complete two-/three-pair snapshots. It does not skip an incomplete pair or run anything to complete it. A candidate-a1 benchmark still in progress is not sufficient.

Inputs are exact filenames in the parent `setup/fts` directory:

- `r19-template-{control|candidate}-a{1|2|3}-experiment.json`
- `r19-template-{control|candidate}-a{1|2|3}-report.txt`

Binary SHA-256 pins are mandatory for every receipt:

| Variant | SHA-256 |
| --- | --- |
| accepted round18 count control | b271980a025bf9b20086e69f116ec2c24f164d21edd814b4e03d418cadd239fc |
| round19 template candidate | 2881dce4a7f2c5eea50057b74bf5cc3a77c0142a4eeb7d1ca45adfa1526ae5cb |

The script checks recorded binary identities, not whatever executable happens to occupy a mutable binary path later. That distinction preserves historical evidence without substituting a different build.

## Strict validation

- Require matching receipt/report labels, exact report path, WARN logging, and integer requested/verified affinity masks both equal to 15.
- Require exactly one successful `benchmark` and one later successful `input-validation` action. All other recorded actions must also have unique names and integer exit code zero. Extra successful regression actions are allowed.
- Require ROWS=20000, BATCH=500, ROUNDS=3000, QUERY_ROUNDS=200, SAMPLES=3, WARMUP=30, SKIP_LOAD=0 in every report. Parameters and hit counts use exact decimal comparisons so float rounding cannot conceal a mismatch.
- Require CN/BENG/mixed/LIMIT hits 8001/11000/7332/20 and all nine scoring timings present, finite, and positive. All other numeric report fields and JSON float values must also be finite.
- Reject missing files/fields, duplicate JSON keys (including nested objects), duplicate report keys even with equal values, duplicate action names, malformed numeric values, non-finite numbers, wrong labels/parameters/hits/binaries/affinity, and appended multiple reports. Validation uses explicit exceptions, not removable Python assertions.
- Preserve raw input byte counts/SHA-256 and full parsed receipts/values; re-read inputs before output and reject any changed bytes. Each file is bounded at 4 MiB with an explicit failure, never truncation. No input lock is claimed.

Expected hit counts and a successful input-validation action are evidence checks, not a replacement for the parent's full correctness regressions.

## Means, deltas, and limitations

For each pair, calculate each metric's `(control-candidate)/control`. Arithmetic-average the three build metrics, two tokenize metrics, and four query metrics separately; average those three category results equally. Negative metric/category changes participate without individual clipping.

The primary aggregate first arithmetic-averages each timing over the selected control runs and separately over candidate runs, then applies the same metric/category formulas to those run means. The descriptive mean of pair improvements is also reported separately; it is not silently substituted for the ratio-of-run-means aggregate. There is no nine-metric equal weighting, SELECT1 subtraction, outlier removal, or pair selection.

For both each pair and the primary aggregate, report two explicit views of the **local increment relative to accepted control**:

- Signed, unclipped normalized delta equivalents: `raw100_delta_unclipped = 200*r`, `weighted50_delta_unclipped = 100*r`, where r is the overall improvement fraction. These can be negative and are not actual formal-score differences.
- The bounded local scoring-curve equivalents: `local_curve_raw100_clipped = 100*min(max(r,0),0.5)/0.5`, and weighted50 is half that. Clipping occurs only after the equal-category overall result.

Neither view is a cumulative competition score or an improvement measured against the official fixed baseline. No accepted round18 score is added. No previous formal result is inferred, and no full-score claim is made.

## Immutable outputs

Successful validation exclusively creates `template-comparison-1pair.json`, `template-comparison-2pair.json`, or `template-comparison-3pair.json` in this directory. Existing paths are refused, even for identical contents; exclusive binary creation also prevents a concurrent overwrite. No `--force`, append, or overwrite mode exists. All inputs must validate before output creation. A partial output caused by an I/O failure is retained and is not silently retried or overwritten. Validation errors exit 1 and emit no score summary.
