"""Apply the same local four-logical-CPU mask before the unchanged harness.

This affects only this helper process and its descendants, never other apps or
the installed service. Official benchmark inputs, SQL and timers are untouched.
"""
import ctypes
from ctypes import wintypes
import json
from pathlib import Path
import runpy
import sys

HERE = Path(__file__).resolve().parent
args = sys.argv[1:]
assert "--label" in args
label = args[args.index("--label") + 1]
assert all(c.isalnum() or c in "-_" for c in label)
output = HERE / (label + "-affinity.json")
assert not output.exists()
kernel = ctypes.WinDLL("kernel32", use_last_error=True)
kernel.GetCurrentProcess.restype = wintypes.HANDLE
kernel.GetProcessAffinityMask.argtypes = [wintypes.HANDLE, ctypes.POINTER(ctypes.c_size_t), ctypes.POINTER(ctypes.c_size_t)]
kernel.GetProcessAffinityMask.restype = wintypes.BOOL
kernel.SetProcessAffinityMask.argtypes = [wintypes.HANDLE, ctypes.c_size_t]
kernel.SetProcessAffinityMask.restype = wintypes.BOOL
handle = kernel.GetCurrentProcess()
allowed, system = ctypes.c_size_t(), ctypes.c_size_t()
if not kernel.GetProcessAffinityMask(handle, ctypes.byref(allowed), ctypes.byref(system)):
    raise ctypes.WinError(ctypes.get_last_error())
mask = 0xF
assert allowed.value & mask == mask
before = allowed.value
if not kernel.SetProcessAffinityMask(handle, mask):
    raise ctypes.WinError(ctypes.get_last_error())
if not kernel.GetProcessAffinityMask(handle, ctypes.byref(allowed), ctypes.byref(system)):
    raise ctypes.WinError(ctypes.get_last_error())
assert allowed.value == mask
output.write_text(json.dumps({"label": label, "mask": mask, "logical_cpu_ids": [0,1,2,3],
                             "allowed_before": before, "system_mask": system.value,
                             "scope": "own helper process and inherited children only",
                             "timing_and_inputs": "unchanged official harness/workload",
                             "comparison_limit": "pair only with other affinity4 runs; separate from older unrestricted runs"}, indent=2)+"\n", encoding="utf-8")
sys.argv = [str(HERE / "experiment-competition.py"), *args]
runpy.run_path(str(HERE / "experiment-competition.py"), run_name="__main__")
