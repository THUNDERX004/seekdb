"""Explicit capture/plan; only --build compiles the test TU and links once.

Never applies the proposal, compiles production source, runs a native program,
invokes a production build, SQL, performance work, Git, or server startup.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = Path(r"D:\Projects\OceanBase\seekdb")
BUILD = ROOT / "build_fts_competition"
PROPOSAL = HERE.parent / "round16-lazy-rows"
MAIN_OBJ = "src/observer/CMakeFiles/ob_main.dir/main.cpp.obj"
DAS = ("src/sql/das/ob_das_domain_utils.h", "src/sql/das/ob_das_domain_utils.cpp")
CONTEXT = (
    "src/data_plane/api/data_plane/fts/ob_fts_parser_helper.h",
    "src/data_plane/api/data_plane/fts/ob_fts_struct.h",
    "src/storage/fts/ob_fts_parser_helper.cpp",
    "src/storage/fts/ob_fts_parser_property.cpp",
    "src/storage/fts/ob_fts_stop_word.cpp",
    "src/storage/fts/ob_fts_struct.cpp",
    "src/storage/fts/ob_ngram_ft_parser.cpp",
    "src/data_plane/api/data_plane/blocksstable/ob_datum_row.h",
    "src/data_plane/api/data_plane/blocksstable/ob_storage_datum.h",
    "src/storage/blocksstable/ob_datum_row.cpp",
    "src/oblib/common/datum/ob_datum.h",
    "src/oblib/lib/rc/context.h", "src/oblib/lib/rc/context.cpp",
    "src/sql/engine/basic/ob_chunk_datum_store.h",
    "src/sql/engine/basic/ob_chunk_datum_store.cpp",
)


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_json(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def windows_args(command):
    """MS CRT command decoding, without invoking a shell; prior native helper infrastructure."""
    result, index = [], 0
    while index < len(command):
        while index < len(command) and command[index] in " \t\r\n":
            index += 1
        if index == len(command):
            break
        arg, quoted = [], False
        while index < len(command):
            if command[index] in " \t\r\n" and not quoted:
                break
            slashes = 0
            while index < len(command) and command[index] == "\\":
                slashes += 1
                index += 1
            if index < len(command) and command[index] == '"':
                arg.append("\\" * (slashes // 2))
                if slashes % 2:
                    arg.append('"')
                elif quoted and index + 1 < len(command) and command[index + 1] == '"':
                    arg.append('"')
                    index += 1
                else:
                    quoted = not quoted
                index += 1
            else:
                arg.append("\\" * slashes)
                if index < len(command) and command[index] in " \t\r\n" and not quoted:
                    break
                if index < len(command):
                    arg.append(command[index])
                    index += 1
        require(not quoted, "Unterminated command quote")
        result.append("".join(arg))
    return result


def response_write(path, args):
    text = subprocess.list2cmdline(args)
    require(windows_args(text) == args, "Response-file quoting round trip failed")
    path.write_text(text + "\n", encoding="utf-8")


def expand(value, variables):
    def replace(match):
        key = match.group(1)
        if key in ("$", " ", ":"):
            return key
        key = key[1:-1] if key.startswith("{") else key
        require(key in variables, "Unsupported Ninja variable: " + key)
        return variables[key]
    return re.sub(r"\$(\$| |:|\{[^}]+\}|[A-Za-z_][A-Za-z_0-9]*)", replace, value)


def ninja_blocks(path):
    lines = path.read_text(encoding="utf-8").splitlines()
    require(not any(line.endswith("$") for line in lines), "Ninja continuation requires deliberate recapture")
    result = []
    for i, line in enumerate(lines):
        if line.startswith(("build ", "rule ")):
            values = {}
            for following in lines[i + 1:]:
                if not following.startswith("  "):
                    break
                key, sep, value = following.strip().partition(" = ")
                require(sep, "Unsupported Ninja binding")
                values[key] = value
            result.append((line, values))
    return result


def records():
    compilation = json.loads((BUILD / "compile_commands.json").read_text(encoding="utf-8"))
    units = []
    for item in compilation:
        if "/ob_sql.dir/" in item.get("output", "").replace("\\", "/"):
            unit = Path(item["file"])
            if "src/sql/das/ob_das_domain_utils.cpp" in unit.read_text(encoding="utf-8").replace("\\", "/"):
                units.append(item)
    require(len(units) == 1, "Expected exactly one real DAS-domain unity compile record")
    edges = [(line, values) for line, values in ninja_blocks(BUILD / "build.ninja")
             if line.startswith("build ") and ": CXX_EXECUTABLE_LINKER__seekdb_" in line]
    require(len(edges) == 1, "Expected one seekdb link edge")
    line, values = edges[0]
    name, tail = line.split(": ", 1)[1].split(" ", 1)
    objects = expand(tail.split(" |", 1)[0], {}).split()
    require(objects.count(MAIN_OBJ) == 1 and all(p.endswith(".obj") for p in objects), "Main object not uniquely replaceable")
    rule = [v for key, v in ninja_blocks(BUILD / "CMakeFiles/rules.ninja") if key == "rule " + name]
    require(len(rule) == 1 and rule[0].get("rspfile_content") == "$in $LINK_PATH $LINK_LIBRARIES", "Unexpected executable link rule")
    require(values.get("PRE_LINK") == "cd .", "Nontrivial PRE_LINK requires review")
    return {"compile_record": units[0], "explicit_objects": objects, "link_rule": rule[0],
            "link_variables": {k: values[k] for k in ("LINK_FLAGS", "LINK_PATH", "LINK_LIBRARIES", "TARGET_FILE")}}


def eager_bytes(path):
    raw = path.read_bytes()
    begin = raw.index(b"/*static*/ int ObDASDomainUtils::generate_fulltext_word_rows(")
    end = raw.index(b"int ObDASDomainUtils::get_pure_mutivalue_data", begin)
    return raw[begin:end]


def capture(rec):
    settings = HERE / "build-settings.json"
    require(not settings.exists(), "Capture already exists; refusing overwrite")
    pins = []
    for rel in DAS:
        original, candidate = PROPOSAL / "original" / rel, PROPOSAL / rel
        live = sha(ROOT / rel)
        require(live in (sha(original), sha(candidate)), "Live DAS differs from both proposal sides: " + rel)
        pins.append({"path": rel, "original_sha256": sha(original), "candidate_sha256": sha(candidate),
                     "live_at_capture_sha256": live})
    original_eager = eager_bytes(PROPOSAL / "original" / DAS[1])
    require(original_eager == eager_bytes(PROPOSAL / DAS[1]) == eager_bytes(ROOT / DAS[1]),
            "The production eager oracle is no longer byte-identical")
    write_json(settings, {
        "schema_version": 1, "explicit_capture": True, "source_root": str(ROOT), "build_dir": str(BUILD),
        "capture_mode": "Read source/configuration and write auxiliary metadata/response files only",
        "records": rec, "unity_sha256": sha(rec["compile_record"]["file"]),
        "build_file_sha256": {rel: sha(BUILD / rel) for rel in
                              ("compile_commands.json", "build.ninja", "CMakeFiles/rules.ninja")},
        "proposal_pins": pins, "unchanged_eager_range_sha256": hashlib.sha256(original_eager).hexdigest(),
        "context_pins": {rel: sha(ROOT / rel) for rel in CONTEXT},
        "test_sha256": sha(HERE / "test_fts_lazy_rows.cpp"),
        "environment_required": {"VSCMD_ARG_TGT_ARCH": "x64", "VCToolsVersion": "14.44.35207",
                                 "WindowsSDKVersion": "10.0.26100.0"},
        "candidate_applied_at_capture": all(p["live_at_capture_sha256"] == p["candidate_sha256"] for p in pins),
        "compile": "NOT RUN", "link": "NOT RUN", "native": "NOT RUN", "sql": "NOT RUN", "performance": "NOT RUN",
        "limitations": "Configuration capture is not compiled archive provenance. Parent must complete round16 build and serial gate.",
    })


def full(value):
    path = Path(value)
    return path if path.is_absolute() else BUILD / path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", required=True, type=Path)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--capture", action="store_true", help="Explicit initial plan-only capture; never compiles/links/runs")
    mode.add_argument("--build", action="store_true", help="Requires existing explicit capture and completed candidate build; never runs")
    args = parser.parse_args()
    output = args.output_dir.resolve()
    require(output.is_relative_to(HERE) and output != HERE and not output.exists(), "Use a NEW helper-owned output directory")
    rec = records()
    if args.capture:
        capture(rec)
    settings_path = HERE / "build-settings.json"
    require(settings_path.is_file(), "Missing build-settings.json: explicitly run --capture first; build never captures implicitly")
    settings = json.loads(settings_path.read_text(encoding="utf-8"))
    require(settings.get("explicit_capture") and rec == settings["records"], "Captured CMake records changed")
    require(all(sha(BUILD / rel) == val for rel, val in settings["build_file_sha256"].items()), "Captured build files changed")
    require(sha(rec["compile_record"]["file"]) == settings["unity_sha256"], "DAS unity changed")
    require(sha(HERE / "test_fts_lazy_rows.cpp") == settings["test_sha256"], "Frozen test changed")
    source_status = {p["path"]: sha(ROOT / p["path"]) == p["candidate_sha256"] for p in settings["proposal_pins"]}
    context_status = {rel: sha(ROOT / rel) == val for rel, val in settings["context_pins"].items()}
    require(hashlib.sha256(eager_bytes(ROOT / DAS[1])).hexdigest() == settings["unchanged_eager_range_sha256"], "Eager oracle changed")
    production_obj = full(rec["compile_record"]["output"])
    archive = BUILD / "src/sql/ob_sql_static.lib"
    fresh = (production_obj.is_file() and archive.is_file()
             and all(production_obj.stat().st_mtime_ns >= (ROOT / rel).stat().st_mtime_ns for rel in DAS)
             and archive.stat().st_mtime_ns >= production_obj.stat().st_mtime_ns)
    if args.build:
        require(os.name == "nt", "Requires captured native Windows x64 ABI")
        require(all(source_status.values()), "Apply and complete the real round16 candidate build first; no staged source is compiled here")
        require(all(context_status.values()), "Relevant public dependencies changed; review before recapture")
        require(fresh, "Production candidate object/archive freshness guard failed")
        for key, value in settings["environment_required"].items():
            require(os.environ.get(key, "").rstrip("\\/").lower() == value.lower(), "Wrong VS environment: " + key)
        require(os.environ.get("INCLUDE") and os.environ.get("LIB"), "VS INCLUDE/LIB environment missing")

    record = rec["compile_record"]
    tokens = windows_args(record["command"])
    compiler, compile_args, replacements = tokens[0], [], {"source": 0, "object": 0, "pdb": 0}
    require(Path(compiler).name.lower() == "clang-cl.exe", "Expected production clang-cl")
    for token in tokens[1:]:
        if token.startswith("/Fo"):
            require(token[3:].replace("\\", "/") == record["output"].replace("\\", "/"), "Unexpected /Fo")
            token = "/Fo" + (output / "fts_lazy_rows.obj").as_posix(); replacements["object"] += 1
        elif token.startswith("/Fd"):
            token = "/Fd" + (output / "fts_lazy_rows_compile.pdb").as_posix(); replacements["pdb"] += 1
        elif token == record["file"]:
            token = (HERE / "test_fts_lazy_rows.cpp").as_posix(); replacements["source"] += 1
        compile_args.append(token)
    require(replacements == {"source": 1, "object": 1, "pdb": 1}, "Compile substitution not exact")
    require("-c" in compile_args and "--" in compile_args, "Expected compile-only source contract")
    libs = windows_args(expand(rec["link_variables"]["LINK_LIBRARIES"], {}))
    require(all(p.lower().endswith(".lib") for p in libs), "Unexpected library expression")
    libs = [full(p).as_posix() if "/" in p or "\\" in p else p for p in libs]
    require(archive.as_posix() in libs and (BUILD / "src/oblib/oblib.lib").as_posix() in libs, "Real SQL/oblib archives missing")
    explicit = [full(p).as_posix() for p in rec["explicit_objects"] if p != MAIN_OBJ]
    link_args = [(output / "fts_lazy_rows.obj").as_posix()] + explicit
    link_args += windows_args(expand(rec["link_variables"]["LINK_PATH"], {})) + libs
    rule = re.fullmatch(r'.+? /C "\$PRE_LINK && (.+) && \$POST_BUILD"', rec["link_rule"]["command"])
    require(rule is not None, "Unexpected CMake link wrapper")
    quote = lambda p: subprocess.list2cmdline([p.as_posix()])
    variables = {"OBJECT_DIR": quote(output / "link-intermediate"), "RSP_FILE": quote(output / "link-inputs.rsp"),
                 "TARGET_FILE": quote(output / "test_fts_lazy_rows.exe"), "TARGET_IMPLIB": quote(output / "fts_lazy_rows.lib"),
                 "TARGET_PDB": quote(output / "fts_lazy_rows_link.pdb"), "MANIFESTS": "",
                 "LINK_FLAGS": rec["link_variables"]["LINK_FLAGS"]}
    link_command = windows_args(expand(rule.group(1), variables))
    require("vs_link_exe" in link_command and "--manifests" in link_command, "Production link wrapper lost")
    artifacts = [Path(p) for p in explicit + libs if "/" in p or "\\" in p]
    require(all(p.is_file() for p in artifacts), "Production link artifact absent; no rebuild attempted")
    dlls = sorted((BUILD / "src/observer").glob("*.dll"))
    require(dlls, "Production runtime DLLs absent")
    output.mkdir()
    response_write(output / "compile.rsp", compile_args)
    response_write(output / "link-inputs.rsp", link_args)
    commands = {"cwd": str(output), "compile": [compiler, "@" + (output / "compile.rsp").as_posix()],
                "link": link_command, "replaced_main": MAIN_OBJ, "production_source_compiled": False}
    write_json(output / "commands.json", commands)
    receipt = {"mode": "build" if args.build else "capture-plan" if args.capture else "plan-only",
               "settings_sha256": sha(settings_path), "test_sha256": settings["test_sha256"],
               "candidate_source_matches": source_status, "context_matches": context_status, "fresh_by_mtime_only": fresh,
               "commands_sha256": sha(output / "commands.json"),
               "compile": "NOT RUN", "link": "NOT RUN", "native": "NOT RUN", "sql": "NOT RUN", "performance": "NOT RUN"}
    write_json(output / "receipt.json", receipt)
    if not args.build:
        print("CAPTURE/PLAN ONLY; NO COMPILER/LINKER/RUNTIME:", output)
        return
    environment = os.environ.copy()
    temporary = output / "tmp"; temporary.mkdir()
    environment["TMP"] = environment["TEMP"] = str(temporary)
    pinned = sorted(set(artifacts + [production_obj]), key=str)
    receipt["production_sha256_before"] = {str(p): sha(p) for p in pinned}
    write_json(output / "receipt.json", receipt)
    for stage in ("compile", "link"):
        if stage == "link":
            (output / "link-intermediate").mkdir()
        with (output / (stage + ".log")).open("wb") as log:
            completed = subprocess.run(commands[stage], cwd=output, env=environment, stdout=log, stderr=subprocess.STDOUT)
        receipt[stage] = {"exit_code": completed.returncode, "log_sha256": sha(output / (stage + ".log"))}
        write_json(output / "receipt.json", receipt)
        require(completed.returncode == 0, stage + " failed; inspect log; no fallback or retry")
    receipt["production_sha256_after"] = {str(p): sha(p) for p in pinned}
    require(receipt["production_sha256_before"] == receipt["production_sha256_after"], "Production artifacts changed during helper build")
    require(all(sha(ROOT / p["path"]) == p["candidate_sha256"] for p in settings["proposal_pins"]), "Candidate source changed during helper build")
    receipt["runtime_dlls"] = []
    for dll in dlls:
        shutil.copy2(dll, output / dll.name)
        require(sha(dll) == sha(output / dll.name), "Runtime DLL copy mismatch")
        receipt["runtime_dlls"].append({"name": dll.name, "sha256": sha(output / dll.name)})
    receipt["executable_sha256"] = sha(output / "test_fts_lazy_rows.exe")
    receipt["build_succeeded"] = True
    write_json(output / "receipt.json", receipt)
    print("COMPILED/LINKED ONLY; NOT RUN:", output / "test_fts_lazy_rows.exe")


if __name__ == "__main__":
    try:
        main()
    except (RuntimeError, OSError, ValueError, KeyError) as error:
        print("ERROR:", error, file=sys.stderr)
        sys.exit(1)
