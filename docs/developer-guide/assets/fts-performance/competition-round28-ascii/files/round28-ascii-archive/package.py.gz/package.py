"""Archive an explicit frozen Round28 allowlist; offline bytes only, no workloads."""
from datetime import datetime, timezone
from decimal import Decimal
import gzip
import io
import json
from pathlib import Path

from verify_package import digest, require, verify
from publish_docs import ASSET_REL, DOCS, REPO, insert, unchanged

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
SOURCE = 'src/share/text_analysis/ob_token_stream.cpp'
ORIGINAL = '0fce1e910e786b24f4d5fbaa48e39bf2c4fb357bd20f3f6560ff0181c86a3a58'
CANDIDATE = '0bef1d905eccbd9eedf0b0e8190b331ceaef0678c3df21393cfff7a874c785a9'
PATCH = '842f2c6a4a02dcf1cb280a44cb9ecc6a20a05c5bb52c9da468d4a835c2c70eac'
HEADER = '00f881913e2ddd1124e1d5eb000a7eca80ec74f5203c60db5a8a875e4222e13a'
TEST = '7d464d4db30518eba4b9f776097cf106ddceb21240ccc68f86d15d5ccf0e7eab'
BUILDER = 'f1b4bfae15df923870eb82023d12c7783552a65ca5142a3cd2a7c826e5edd653'
RUNNER = '2254291ec00cf921151c75233803e8af96cc1aae51e3c8e8be3d05765785d3ae'
SHARED = '30779fbf52372a91bbc37e823b7fde4579eae04850dc784064170758667410f9'
UTILITY = '0aca605abda2fea4ab7b32335c5fe04302895748e8f63a6ce46887b04b822035'
STDOUT = '76436bae7278790385c86788a1942c29a3d51d3533531e2385f60a64ca572386'
RECORDS = 'e1403ec9aa5e1735ca888105c25eb8379ab81e9bd2a3a514e3491841f7fbed8f'
FIXTURE = 'c395dd01bde831f7a8a1965d32d13d99c5bd876ef28807eabb85e614aa48409d'
EXPECTED = 'd322411c90638ba7cb0dbb4a71c2b770ff41309cac3da185e375a2e9b8d40570'
NATIVE = 'round28-token-stream-build/'
PROP = 'round28-ascii-spans-proposal/'
EVIDENCE = 'round28-ascii-evidence/'
PINS = {'control': 'c7fcc8676875246a38bc4135f29e6f52b85a9d29a9563679003d5b6140666b01',
        'candidate': 'f10e0fea8fa6d09b2e36388ee3f145fd0e9096a5c614eca0f91e9fa461ab17b0',
        'official': 'bae4a3b9e1b4662d4021b28d5adc085764beb6cf02122eacd57b8e16b6fe1762'}
SOURCES = {'control': 'f56ddd03e66826919d8d9192bc4c0afece8843dd',
           'candidate': 'c110239a7+round28-ascii',
           'official': '5bce9e06d1281347ad61344e4b01fab9158c58a2'}
PARAMS = dict(rows=20000, batch=500, rounds=3000, query_rounds=200, samples=3, warmup=30, skip_load=0)
HITS = dict(query_cn_hits=8001, query_beng_hits=11000, query_mixed_hits=7332, query_limit_hits=20)
OLD = ['test_' + x + '.py' for x in ['hot_path', 'tokenize_config', 'collation', 'match_batches',
                                   'map_concurrency', 'stopword_concurrency', 'dictionary_prefixes']]
FIRST = ['sort-metadata', 'count-union-accounting', 'query-materialization', 'casecopy', 'bmp', 'ranked']
BUILD_FILES = ['receipt.json', 'compile.log', 'compile.rsp', 'link-inputs.rsp', 'link.log',
               'link-intermediate/embed.manifest', 'link-intermediate/intermediate.manifest',
               'link-intermediate/manifest.rc']
RUN_FILES = ['build-receipt.json', 'run.json', 'stdout.log', 'stderr.log', 'tuples.log']


def raw(name):
    return (ROOT / name).read_bytes()


def load(name):
    return json.loads(raw(name))


def identity(data):
    return dict(bytes=len(data), sha256=digest(data))


def write_new(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(data)


def write_json(name, value):
    write_new(HERE / name, (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n').encode())


def receipt(label, variant):
    data = load(label + '-experiment.json')
    require(data['label'] == label and data['binary_sha256'] == PINS[variant]
            and data['source_commit'] == SOURCES[variant], 'Execution identity differs: ' + label)
    require(data['log_level'] == 'WARN' and data['affinity_mask'] == data['affinity_mask_verified'] == 15,
            'Execution configuration differs: ' + label)
    require(data['owned_server_exit_before_cleanup'] is None, 'Unexpected pre-cleanup exit: ' + label)
    return data


def check_comparisons():
    checked, snapshots = [], []
    for count in [1, 2, 3]:
        name = EVIDENCE + f'ascii-comparison-{count}pair.json'
        data = load(name)
        require(data['status'] == 'COMPLETE' and data['completed_pairs'] == len(data['pairs']) == count,
                'Incomplete immutable comparison')
        require(data['binary_pins'] == {k: PINS[k] for k in ['control', 'candidate']}
                and data['source_labels'] == {k: SOURCES[k] for k in ['control', 'candidate']}
                and data['parameters'] == PARAMS and data['hits'] == HITS
                and data['helper_sha256'] == UTILITY, 'Comparison fixed identities differ')
        labels = {f'r28-ascii-{variant}-a{n}' for variant in ['control', 'candidate']
                  for n in range(1, count + 1)}
        require(set(data['records']) == labels, 'Wrong timing selection')
        require(set(data['input_hashes']) == {label + '-' + suffix for label in labels
                for suffix in ['report.txt', 'experiment.json']}, 'Missing immutable input hashes')
        for path, pin in data['input_hashes'].items():
            require(identity(raw(path)) == pin, 'Frozen input changed: ' + path)
        for label, record in data['records'].items():
            meta = receipt(label, 'control' if '-control-' in label else 'candidate')
            require(meta == record['receipt'] and [x['action'] for x in meta['actions']] ==
                    ['benchmark', 'input-validation'] and all(x['exit_code'] == 0 for x in meta['actions']),
                    'Incomplete timing actions')
            fields = {}
            for line in raw(label + '-report.txt').decode('utf-8-sig').splitlines():
                if ':' in line:
                    k, v = line.split(':', 1)
                    require(k.strip() not in fields, 'Duplicate report field')
                    fields[k.strip()] = v.strip()
            require(set(fields) == set(record['values']) | set(record['text_fields']), 'Report fields differ')
            require(all(Decimal(fields[k]) == Decimal(str(v)) for k, v in record['values'].items())
                    and all(fields[k] == v for k, v in record['text_fields'].items()), 'Raw report differs')
            require(all(record['values'][k] == v for k, v in (PARAMS | HITS).items()), 'Parameters/hits differ')
        checked.append(dict(source=name, **identity(raw(name)), input_hashes_verified=len(data['input_hashes']),
                            all_raw_report_fields='MATCH', recalculation='NOT RUN; immutable results preserved'))
        snapshots.append(data)
    final = snapshots[-1]
    for data in snapshots:
        require(data['pairs'] == final['pairs'][:data['completed_pairs']]
                and all(record == final['records'][label] for label, record in data['records'].items()),
                'Earlier immutable snapshot differs from final prefix')
    return final, checked


def check_native():
    require(raw(NATIVE + 'test_whitespace_spans.cpp') ==
            raw('round28-token-stream-native/test_whitespace_spans.cpp') and
            digest(raw(NATIVE + 'test_whitespace_spans.cpp')) == TEST, 'Native TU differs')
    require(digest(raw(NATIVE + 'build_native.py')) == BUILDER and
            digest(raw(NATIVE + 'run_native.py')) == RUNNER, 'Executed helper differs')
    outputs, variants = {}, {}
    for variant, source_sha in [('control', ORIGINAL), ('candidate', CANDIDATE)]:
        bp, rp = NATIVE + variant + '-build1/', NATIVE + variant + '-run1/'
        build_raw = raw(bp + 'receipt.json')
        build, run = json.loads(build_raw), load(rp + 'run.json')
        require(raw(rp + 'build-receipt.json') == build_raw, 'Copied build receipt differs')
        require(build['build_succeeded'] and build['compile']['exit_code'] == build['link']['exit_code'] == 0,
                'Native compile/link not passing')
        require(not build['production_source_compiled'] and build['expected_source_sha256'] == source_sha
                and build['expected_header_sha256'] == HEADER, 'Native production provenance differs')
        require(build['production_sha256_before'] == build['production_sha256_after'], 'Recorded native inputs changed')
        require(build['builder_sha256'] == BUILDER and build['helper_sha256'] == SHARED
                and run['run_helper_sha256'] == RUNNER and build['test_sha256'] == run['test_sha256'] == TEST,
                'Native helper/TU identity differs')
        require(build['expected_cases'] == run['expected_cases'] == 4699 and
                build['executable_sha256'] == run['executable_sha256'], 'Native build/run mismatch')
        require(run['native'] == run['output_validation'] == 'PASS' and run['exit_code'] == 0,
                'Native did not pass')
        for step in ['compile', 'link']:
            require(digest(raw(bp + step + '.log')) == build[step]['log_sha256'], 'Native build log differs')
        files = {name: raw(rp + name) for name in ['stdout.log', 'stderr.log', 'tuples.log']}
        require(all(digest(files[k]) == v for k, v in run['logs_sha256'].items())
                and digest(files['tuples.log']) == run['tuples_sha256'] == RECORDS, 'Native output hash differs')
        lines = [x for x in files['stdout.log'].splitlines() if x.startswith((b'CASE\t', b'T\t', b'B\t', b'PASS\t'))]
        require(b'\n'.join(lines) + b'\n' == files['tuples.log'], 'Complete normalized records differ')
        require(len(lines) == run['tuple_lines'] == 73151
                and sum(x.startswith(b'CASE\t') for x in lines) == 4699
                and sum(x.startswith(b'T\t') for x in lines) == 68451
                and [x for x in lines if x.startswith(b'PASS\t')] == [b'PASS\tcases=4699'], 'Native record counts differ')
        outputs[variant] = files
        variants[variant] = dict(source_sha256=source_sha, executable_sha256=run['executable_sha256'],
                                library_input_count=len(build['production_sha256_before']), cases=4699,
                                T_records=68451, CASE_T_PASS_records=73151)
    require(outputs['control'] == outputs['candidate'] and not outputs['control']['stderr.log']
            and digest(outputs['control']['stdout.log']) == STDOUT, 'Complete native raw bytes differ')
    parent = load(NATIVE + 'parent-output-verification.json')
    require(parent['status'] == 'PASS' and parent['full_stdout_equal'] and parent['both_stderr_empty']
            and parent['stdout_sha256'] == STDOUT and parent['cases'] == 4699 and parent['T_records'] == 68451,
            'Parent output verification differs')
    provenance = load(NATIVE + 'provenance.json')
    require(digest(raw(NATIVE + 'build_native.py').replace(b'\r\n', b'\n')) == provenance['builder_sha256']
            and digest(raw(NATIVE + 'run_native.py').replace(b'\r\n', b'\n')) == provenance['runner_sha256'],
            'Historical generated-text hashes differ beyond newlines')
    return dict(status='PASS: parent actual native runs; independent offline complete-byte recheck',
                execution_by_archiver='NOT RUN', variants=variants,
                outputs={name: dict(identity(data), control_candidate_equal=True)
                         for name, data in outputs['control'].items()},
                limits=['Finite synthetic cases, not production SQL/BM25 integration or performance proof',
                        'Available descriptors only; no real mbminlen>1 descriptor, guard pages or sanitizer run',
                        'No concurrency/reload/input-output-aliasing proof',
                        'Historical generated-text helper hashes are LF; actual execution receipts pin raw CRLF bytes'],
                no_established_suite_promotion=True)


def check_sql():
    a = receipt('r28-ascii-candidate-regression-a1', 'candidate')
    b = receipt('r28-ascii-control-regression-a1', 'control')
    for data in [a, b]:
        require([x['action'] for x in data['actions']] == FIRST and
                [x['exit_code'] for x in data['actions']] == [0, 0, 0, 0, 0, 1], 'Initial failure sequence differs')
    require(b"root[54][4][0][1]" in raw(a['label'] + '-ranked.log') and
            b'0.40073254302705685' in raw(a['label'] + '-ranked.log'), 'Initial score failure missing')
    require(b'_get_server_information' in raw(b['label'] + '-ranked.log'), 'Control handshake failure missing')
    captured = {}
    expected = (REPO / 'unittest/storage/fts/ranked_batches_expected.json.gz').read_bytes()
    fixture = (REPO / 'unittest/storage/fts/test_ranked_batches.py').read_bytes()
    require(digest(expected) == EXPECTED and digest(fixture) == FIXTURE, 'Frozen ranked fixture changed')
    for label, variant in [('r28-ascii-official-ranked-a1', 'official'), ('r28-ascii-candidate-ranked-a2', 'candidate')]:
        meta = receipt(label, variant)
        require([x['action'] for x in meta['actions']] == ['ranked', 'keytypes'] + OLD
                and all(x['exit_code'] == 0 for x in meta['actions']), 'Isolated SQL repeat incomplete')
        name = EVIDENCE + label + '-ranked-actual.json.gz'
        data = raw(name)
        require(data == expected, 'Complete captured ranked bytes differ')
        rows = json.loads(gzip.decompress(data))
        require(len(rows) == 432 and sum(len(x[-1]) for x in rows) == 142692, 'Capture counts differ')
        report = load(EVIDENCE + label + '-ranked-actual.json.comparison.json')
        require(report['status'] == 'PASS' and not report['differences'] and report['actual_sha256'] == EXPECTED
                and report['fixture_sha256'] == FIXTURE, 'Capture comparison receipt differs')
        captured[label] = dict(status='PASS', cases=432, result_rows=142692,
                               compressed=identity(data), decompressed=identity(gzip.decompress(data)))
    return dict(initial_candidate='Score assertion after complete in-memory capture; full actual not persisted',
                initial_control='Handshake connection reset before ranked fixture SQL',
                cause='UNEXPLAINED; no fix or reproduction claimed', isolated_repeats=captured,
                actual_SQL_execution_by_archiver='NOT RUN')


def main():
    require(not (HERE / 'archive').exists(), 'Frozen output exists; never overwrite')
    final, comparisons = check_comparisons()
    native, sql = check_native(), check_sql()
    original = raw(PROP + 'original/' + SOURCE)
    candidate = raw(PROP + 'candidate/' + SOURCE)
    require(digest(original) == ORIGINAL and digest(candidate) == CANDIDATE
            and digest(raw(PROP + 'source.patch')) == PATCH, 'Exact proposal identities differ')
    restoration = load(NATIVE + 'rejection-restoration.json')
    require(restoration['decision'] == 'REJECTED_RESTORED_EXACT' and restoration['source'] == SOURCE
            and restoration['original_sha256'] == ORIGINAL and restoration['candidate_sha256'] == CANDIDATE
            and restoration['comparison_sha256'] == digest(raw(EVIDENCE + 'ascii-comparison-3pair.json'))
            and restoration['aggregate'] == final['aggregate'], 'Restoration disposition differs')
    require((REPO / SOURCE).read_bytes() == original, 'Live source is not exact restored original')
    restore_log = raw('round28-ascii-rejection-restoration-build.log')
    require(b'Building CXX object src/share/' in restore_log and b'Linking CXX executable src' in restore_log,
            'Restoration rebuild log missing actual source rebuild/link')
    review = load('round28-ranked-review/source-pins.json')
    require(digest(raw('round28-ranked-review/report.md')) == review['report']['sha256'], 'Bounded BM25 review changed')

    dependencies = [
        ('round19-evidence/summarize-template.py', 'summarize-template.py', UTILITY),
        ('round16-row-native/prepare_fts_lazy_rows.py', 'native-link-util.py', SHARED),
        ('round27-root-evidence/experiment-with-exit.py', 'experiment-with-exit.py',
         '8baa4b26289b4ecac8941ebd7cfdfd8f480c74723c6a84cafd1d7b09660d7478'),
        ('round27-dat-root-build/build_native.py', 'predecessor-build_native.py',
         '25f2533c60a3245b0f3870878bf9fafbda5cdf13d3b6812de84d482967c2db6f'),
        ('round27-dat-root-build/run_native.py', 'predecessor-run_native.py',
         '7584265b751ff5a55f0a869614494b58b5dedda348808154fe996d42acea62bf')]
    dependency_pins = []
    for source, target, sha in dependencies:
        data = raw(source)
        require(digest(data) == sha, 'Shared dependency changed: ' + source)
        write_new(HERE / 'dependencies' / target, data)
        dependency_pins.append(dict(original_source=source, snapshot='dependencies/' + target, **identity(data)))
    for name in ['test_ranked_batches.py', 'ranked_batches_expected.json.gz']:
        data = (REPO / 'unittest/storage/fts' / name).read_bytes()
        write_new(HERE / 'dependencies/ranked-fixture' / name, data)
        dependency_pins.append(dict(original_source=str(REPO / 'unittest/storage/fts' / name),
            snapshot='dependencies/ranked-fixture/' + name, **identity(data)))

    protected = ['tools/benchmark/fts_large_bench.sh', 'tools/benchmark/fts_large_bench_gen.py',
                 'tools/benchmark/fts_large_bench_setup.sql', 'tools/benchmark/fts_large_bench_score.py',
                 'tools/benchmark/fts_large_bench_baseline.json', '.github/workflows/vldb.yml']
    state = dict(protected_preimages={p: identity((REPO / p).read_bytes()) for p in protected if (REPO / p).exists()},
        protected_reference_paths_absent=[p for p in protected if not (REPO / p).exists()],
        read_only_identity_pins={SOURCE: ORIGINAL,
            'src/share/text_analysis/ob_token_stream.h': HEADER,
            'unittest/storage/fts/test_ranked_batches.py': FIXTURE,
            'unittest/storage/fts/ranked_batches_expected.json.gz': EXPECTED,
            'docs/developer-guide/assets/fts-performance/competition-round27-root/manifest.json':
                digest((REPO / 'docs/developer-guide/assets/fts-performance/competition-round27-root/manifest.json').read_bytes())},
        documents_preimages={p: identity((REPO / p).read_bytes()) for p in DOCS})
    unchanged(state)
    write_json('status.json', state)
    write_json('source-identities.json', dict(decision='REJECTED_RESTORED_EXACT', source=SOURCE,
        original_sha256=ORIGINAL, candidate_sha256=CANDIDATE, patch_sha256=PATCH,
        restored_live_bytes='MATCH EXACT ORIGINAL', historical_binary_pins=PINS, historical_source_labels=SOURCES,
        historical_report_checkout_labels={k: v['text_fields'] for k, v in final['records'].items()},
        report_git_head_is_runtime_checkout_label_not_binary_source_attestation=True,
        restoration_build='Parent confirmed PASS; actual rebuild/link log archived; no exit-code receipt invented',
        historical_restoration_json_rebuild_field=restoration['rebuild'],
        historical_pending_field_preserved=True, current_binary_or_library_reads=False,
        official_file_preimages=state['protected_preimages'], protected_reference_paths_absent=state['protected_reference_paths_absent']))
    write_json('input-verification.json', dict(status='PASS', immutable_comparisons=comparisons, SQL=sql,
        native=native, summarizer_execution='NOT RUN', workload_execution='NOT RUN',
        pair1_pause='Parent attested user pause between its control/candidate; both raw runs retained without correction',
        no_causal_target_regression_claim=True))
    provenance = load(NATIVE + 'provenance.json')
    write_json('provenance-audit.json', dict(dependencies=dependency_pins,
        actual_native_builder_raw_sha256=BUILDER, actual_native_runner_raw_sha256=RUNNER,
        historical_generated_LF_sha256=dict(builder=provenance['builder_sha256'], runner=provenance['runner_sha256']),
        raw_vs_generated_difference='Exactly CRLF versus LF; both normalized identities independently verified',
        capture_harness=load(EVIDENCE + 'capture-harness-provenance.json'),
        bounds='Historical receipts are preserved verbatim. No current production products or complete invocation attestation invented.'))
    write_json('disposition.json', dict(decision='REJECTED_RESTORED_EXACT', completed_pairs=3,
        parent_reason=restoration['reason'], recorded_aggregate=final['aggregate'], method=final['method'],
        interpretation=final['interpretation'], no_native_TU_promotion=True,
        limitations=['Pair1 crossed user pause; all runs retained, no causal target degradation claim',
                    'Pair2/3 are insufficient for reliable causal attribution',
                    'Initial score mismatch and separate control handshake reset remain unexplained; later PASS is not repair proof',
                    'No formal score, cumulative gain, full score, stability or statistical significance claim',
                    'Finite native whitespace equality does not establish BM25 integration or performance'],
        execution_by_archiver='Offline bytes only'))

    metric_rows = '\n'.join('| ' + m['metric'] + ' | ' + format(m['control'], '.6f') + ' | ' +
        format(m['candidate'], '.6f') + ' | ' + format(100*m['improvement'], '+.6f') + '% |'
        for m in final['aggregate']['metrics'])
    pair_rows = '\n'.join('| ' + str(p['pair']) + ' | ' + ' | '.join(format(100*p['category_improvements'][k], '+.6f') + '%'
        for k in ['build', 'tokenize', 'query']) + ' | ' + format(100*p['overall_improvement'], '+.6f') + '% |'
        for p in final['pairs'])
    operations = []
    for lang, rel in zip(['en', 'zh-CN'], DOCS):
        template = (HERE / ('report-template.' + lang + '.md')).read_text(encoding='utf-8')
        section = template.replace('@@METRICS@@', metric_rows).replace('@@PAIRS@@', pair_rows).encode()
        name = 'report.' + lang + '.md'
        write_new(HERE / name, section)
        before = (REPO / rel).read_bytes()
        require(identity(before) == state['documents_preimages'][rel], 'Report changed during preparation')
        operations.append(dict(path=rel, section=name, preimage_sha256=digest(before),
            section_sha256=digest(section), postimage_sha256=digest(insert(before, section))))
    write_json('document-identities.json', operations)

    inputs = []
    for variant in ['control', 'candidate']:
        for n in [1, 2, 3]:
            label = f'r28-ascii-{variant}-a{n}'
            inputs += [label + '-' + x for x in ['report.txt', 'experiment.json', 'benchmark.log', 'input-validation.log', 'server.log']]
    for label in ['r28-ascii-candidate-regression-a1', 'r28-ascii-control-regression-a1']:
        inputs += [label + '-' + action + '.log' for action in FIRST]
        inputs += [label + '-' + x for x in ['experiment.json', 'server.log', 'sort-plans.json']]
    for label in ['r28-ascii-official-ranked-a1', 'r28-ascii-candidate-ranked-a2']:
        inputs += [label + '-' + action + '.log' for action in ['ranked', 'keytypes'] + OLD]
        inputs += [label + '-experiment.json', label + '-server.log']
    inputs += ['round28-ascii-candidate-build.log', 'round28-ascii-rejection-restoration-build.log']
    inputs += [EVIDENCE + x for x in ['ascii-comparison-1pair.json', 'ascii-comparison-2pair.json', 'ascii-comparison-3pair.json',
        'summarize.py', 'capture_ranked.py', 'capture-harness-provenance.json', 'experiment-with-capture.py', 'prepare_capture_harness.py']]
    for label in ['r28-ascii-official-ranked-a1', 'r28-ascii-candidate-ranked-a2']:
        inputs += [EVIDENCE + label + '-ranked-actual.json' + suffix for suffix in ['.gz', '.comparison.json']]
    inputs += [PROP + x for x in ['manifest.json', 'report.md', 'source.patch', 'original/' + SOURCE, 'candidate/' + SOURCE]]
    inputs += [folder + '/' + x for folder in ['round28-ascii-review', 'round28-ranked-review'] for x in ['report.md', 'source-pins.json']]
    inputs += ['round28-token-stream-native/' + x for x in ['README.md', 'SHA256SUMS', 'test_whitespace_spans.cpp']]
    inputs += [NATIVE + x for x in ['application.json', 'apply_candidate.py', 'binary.json', 'build_native.py', 'build.ps1',
        'parent-output-verification.json', 'pin_binary.py', 'prepare.py', 'provenance.json', 'rejection-restoration.json',
        'restore.py', 'run_native.py', 'stage_test.py', 'test-provenance.json', 'test_whitespace_spans.cpp', 'verify_outputs.py']]
    for variant in ['control', 'candidate']:
        inputs += [NATIVE + variant + '-build1/' + x for x in BUILD_FILES]
        inputs += [NATIVE + variant + '-run1/' + x for x in RUN_FILES]
    own = ['package.py', 'verify_package.py', 'publish_docs.py', 'README.md', 'report-template.en.md', 'report-template.zh-CN.md',
           'report.en.md', 'report.zh-CN.md', 'source-identities.json', 'input-verification.json', 'provenance-audit.json',
           'disposition.json', 'document-identities.json', 'selection.json']
    own += ['dependencies/' + x[1] for x in dependencies]
    own += ['dependencies/ranked-fixture/' + x for x in ['test_ranked_batches.py', 'ranked_batches_expected.json.gz']]
    inputs += ['round28-ascii-archive/' + x for x in own]
    require(len(inputs) == len(set(inputs)), 'Duplicate allowlist entries')
    inputs.sort()
    write_json('selection.json', dict(method='Explicit frozen Round28 allowlist; only necessary predecessor infrastructure snapshots',
        files=inputs, exclusions=['All other experiment raw evidence and Round29 paths', 'EXE/PDB/OBJ/LIB/DLL/RES/TMP',
            'Current D binary/libraries, runtime/data, secrets, large unrelated server logs',
            'Whole historical report backups', 'Mutable status/publication/verification receipts']))
    archive = HERE / 'archive'
    archive.mkdir()
    entries = []
    for source in inputs:
        require(Path(source).suffix.lower() not in ['.exe', '.pdb', '.obj', '.lib', '.dll', '.res', '.tmp'], 'Binary product excluded')
        require('round29' not in source.lower() and '.secrets' not in source.lower(), 'Out of scope path')
        data = raw(source)
        require(len(data) < 25_000_000, 'Unexpected large selected log')
        buffer = io.BytesIO()
        with gzip.GzipFile(fileobj=buffer, filename='', mode='wb', mtime=0, compresslevel=9) as stream:
            stream.write(data)
        packed = buffer.getvalue()
        target = 'files/' + source + '.gz'
        write_new(archive / target, packed)
        entries.append(dict(source=source, path=target, raw_bytes=len(data), raw_sha256=digest(data),
                            packed_bytes=len(packed), packed_sha256=digest(packed)))
    manifest = dict(schema_version=1, experiment='round28-ascii-rejected', decision='REJECTED_RESTORED_EXACT',
        created_utc=datetime.now(timezone.utc).isoformat(), completed_pairs=3, source_root=str(ROOT), checkout_root=str(REPO),
        historical_source_labels=SOURCES, historical_binary_pins=PINS,
        comparison=EVIDENCE + 'ascii-comparison-3pair.json (immutable verbatim; 1/2-pair snapshots also retained)',
        pair1='Crossed a parent-attested user pause; preserved without correction or causal regression attribution',
        native='Actual production-linked 4699 cases each PASS; full stdout/stderr and normalized records independently equal',
        SQL='Initial score mismatch and separate control handshake reset unexplained; later official/candidate isolated exact outputs PASS',
        restoration='Exact original CPP verified; parent-confirmed rebuild PASS and full rebuild/link log archived; historical pending JSON unchanged',
        no_native_TU_promotion=True, encoding='Exact-byte per-file gzip; raw/packed SHA256 and sizes; mtime=0; no newline conversion',
        execution_by_archiver='Offline only; no Git/build/native/runtime/SQL/benchmark/profile',
        formal_cumulative_full_score_stability_or_significance_claim='NONE', files=entries)
    manifest_raw = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode()
    write_new(archive / 'manifest.json', manifest_raw)
    write_new(archive / 'COMPLETE.json', (json.dumps(dict(status='COMPLETE', file_count=len(entries),
        manifest_sha256=digest(manifest_raw)), indent=2) + '\n').encode())
    write_json('publication-plan.json', dict(repository=str(REPO), asset_directory=ASSET_REL,
                                            manifest_sha256=digest(manifest_raw), documents=operations))
    result = verify(archive, ROOT)
    unchanged(state)
    write_json('verification.json', result)
    print(json.dumps(result, ensure_ascii=True))


if __name__ == '__main__':
    main()
