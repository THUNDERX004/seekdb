# Round28 ASCII spans — REJECTED, exact original restored

This is an offline evidence archive. It never invokes a compiler, native test, database, SQL, benchmark, profiler or Git, and never reads current production binaries/libraries. Parent-confirmed restoration build PASS is backed by the exact rebuild/link log; the historical restoration JSON's `SEPARATE PENDING` field remains unchanged and is explained separately.

The allowlist contains six complete timing runs; immutable 1/2/3-pair comparisons; exact proposal originals/candidate/patch and static review; production-linked native preparation, both actual build/run receipts, commands/response files and full stdout/stderr/records; both initial SQL failures; isolated official/candidate ranked/keytype/seven-suite repeats and complete captures; the actual capture harness; a bounded BM25 source review; and restoration evidence. Shared infrastructure and the frozen ranked fixture are copied byte-for-byte only into this new helper's dependencies directory. No prior experiment raw outputs, future files or Round29 paths are selected.

Pair1 crossed a user pause. Its timings remain verbatim, without correction/removal or attribution of the measured BENG reduction to the candidate. Pair2/3 do not establish reliable causal benefit either. The initial score mismatch and control handshake reset remain unexplained; later exact PASS is not repair/reproduction proof. Native equality is finite whitespace coverage, not BM25 integration, shortcut execution or speedup. The rejected TU remains archive-only, with no established-suite promotion.

Historical preparation text stays untouched. Generator helper hashes are LF text; actual build/run receipts pin raw CRLF files. Both forms are verified independently. Report checkout `git_head` values remain historical runtime labels; receipt binary/source identity and exact source/patch pins govern the experiment identity. No formal, cumulative, full-score, stability or statistical significance claim is made.

Run once from `C:/Users/11946/Documents/ChatGPT/OceanBase比赛`:

```powershell
.venv/Scripts/python.exe -B setup/fts/round28-ascii-archive/package.py
.venv/Scripts/python.exe -B setup/fts/round28-ascii-archive/publish_docs.py
.venv/Scripts/python.exe -B setup/fts/round28-ascii-archive/publish_docs.py --execute
```

Only the new `D:/Projects/OceanBase/seekdb/docs/developer-guide/assets/fts-performance/competition-round28-ascii` directory and a new top section in each existing English/Chinese FTS report are published. Exact prior document bytes are preserved; whole-history backups are not packed. Official benchmark/scoring files, the prior archive manifest, live restored CPP/header and ranked fixture identities are checked before/after publication. Parent owns commit/push.

Independent read-only verification:

```powershell
.venv/Scripts/python.exe -B setup/fts/round28-ascii-archive/verify_package.py --package-dir D:/Projects/OceanBase/seekdb/docs/developer-guide/assets/fts-performance/competition-round28-ascii --source-root C:/Users/11946/Documents/ChatGPT/OceanBase比赛/setup/fts
```

Every selected raw stream, including nested JSON.gz and CRLF stdout, is preserved exactly in deterministic per-file gzip with raw/packed SHA256 and sizes. Mutable publication/status/verification receipts stay outside the immutable package. The verification helper performs no workload or statistical recalculation.
