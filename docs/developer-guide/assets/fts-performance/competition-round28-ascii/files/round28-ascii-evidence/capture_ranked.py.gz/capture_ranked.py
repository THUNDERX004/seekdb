"""Call the unchanged production ranked fixture and preserve actual rows before compare."""
from pathlib import Path
import argparse
import gzip
import hashlib
import importlib.util
import json
import os

FIXTURE = Path('D:/Projects/OceanBase/seekdb/unittest/storage/fts/test_ranked_batches.py')
spec = importlib.util.spec_from_file_location('ranked_fixture', FIXTURE)
fixture = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fixture)

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--port', type=int, default=2891)
    args = p.parse_args()
    output = Path(os.environ['FTS_RANKED_CAPTURE_PATH'])
    assert not output.exists()
    actual = fixture.capture(dict(host='127.0.0.1', port=args.port, user='root',
        password=os.getenv('SEEKDB_TEST_PASSWORD', ''), charset='utf8mb4',
        autocommit=True, read_timeout=180))
    output.write_bytes(gzip.compress((json.dumps(actual, ensure_ascii=True,
        separators=(',', ':')) + '\n').encode(), mtime=0))
    expected = json.loads(gzip.decompress(FIXTURE.with_name('ranked_batches_expected.json.gz').read_bytes()))
    differences = []
    def compare(left, right, path='root'):
        import math
        if isinstance(left, float):
            if not math.isclose(left, right, rel_tol=1e-12, abs_tol=1e-12):
                differences.append(dict(path=path, expected=left, actual=right))
        elif isinstance(left, (list, tuple)):
            if not isinstance(right, (list, tuple)) or len(left) != len(right):
                differences.append(dict(path=path, expected_length=len(left),
                    actual_length=len(right) if isinstance(right, (list, tuple)) else None))
            else:
                for index, (a, b) in enumerate(zip(left, right)):
                    compare(a, b, path + '[' + str(index) + ']')
        elif left != right:
            differences.append(dict(path=path, expected=left, actual=right))
    compare(expected, actual)
    with output.with_suffix('.comparison.json').open('x') as f:
        json.dump(dict(status='PASS' if not differences else 'FAIL',
            cases=len(actual), rows=sum(len(x[-1]) for x in actual),
            fixture_sha256=hashlib.sha256(FIXTURE.read_bytes()).hexdigest(),
            actual_sha256=hashlib.sha256(output.read_bytes()).hexdigest(),
            differences=differences), f, indent=2)
    fixture.compare(expected, actual)
    print('PASS complete ordered IDs and scores; cases=', len(actual),
          'result_rows=', sum(len(x[-1]) for x in actual))

if __name__ == '__main__':
    main()
