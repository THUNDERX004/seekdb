"""Derive an auxiliary harness changing only ranked-result collection."""
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent
BASE = HERE.parent / 'round27-root-evidence/experiment-with-exit.py'
old = BASE.read_bytes()
text = old.decode('utf-8')
needle = "str(ROOT/'unittest/storage/fts/test_ranked_batches.py')"
assert text.count(needle) == 1
text = text.replace(needle, "str(HERE/'round28-ascii-evidence/capture_ranked.py')")
needle = "env.pop('SEEKDB_TEST_PASSWORD', None)"
assert text.count(needle) == 1
text = text.replace(needle, needle + "\n    env['FTS_RANKED_CAPTURE_PATH'] = str(HERE/'round28-ascii-evidence'/(a.label+'-ranked-actual.json.gz'))")
out = HERE / 'experiment-with-capture.py'
new = text.encode('utf-8')
with out.open('xb') as f:
    f.write(new)
with (HERE / 'capture-harness-provenance.json').open('x') as f:
    json.dump(dict(base=str(BASE), base_sha256=hashlib.sha256(old).hexdigest(),
        output=str(out), output_sha256=hashlib.sha256(new).hexdigest(),
        changes='Only ranked fixture dispatch plus destination env; fixture capture and compare unchanged'), f, indent=2)
print('CREATED auxiliary ranked-capture harness')
