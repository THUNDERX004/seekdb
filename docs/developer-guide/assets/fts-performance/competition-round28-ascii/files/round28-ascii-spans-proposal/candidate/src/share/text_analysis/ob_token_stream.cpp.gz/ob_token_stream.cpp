/*
 * Copyright (c) 2025 OceanBase.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#define USING_LOG_PREFIX SHARE

#include "share/text_analysis/ob_token_stream.h"
#include "share/rc/ob_server_runtime.h"

namespace oceanbase
{
namespace share
{

ObTextTokenizer::ObTextTokenizer()
  : ObITokenStream(),
    input_doc_(nullptr),
    cs_(nullptr),
    iter_end_(false),
    is_inited_(false)
{
}

void ObTextTokenizer::reset()
{
  input_doc_ = nullptr;
  cs_ = nullptr;
  iter_end_ = false;
  is_inited_ = false;
}

int ObTextTokenizer::open(const ObDatum &document, const ObCharsetInfo *cs)
{
  int ret = OB_SUCCESS;
  if (IS_INIT) {
    ret = OB_INIT_TWICE;
  } else if (OB_ISNULL(cs)) {
    ret = OB_INVALID_ARGUMENT;
  } else if (OB_UNLIKELY(document.is_outrow())) {
    ret = OB_NOT_SUPPORTED;
  } else {
    input_doc_ = &document;
    cs_ = cs;
    if (document.is_null() || 0 == document.len_) {
      iter_end_ = true;
    } else if (OB_FAIL(inner_open(document, cs_))) {
    } else {
      is_inited_ = true;
    }
  }
  return ret;
}

ObTextWhitespaceTokenizer::ObTextWhitespaceTokenizer()
  : ObTextTokenizer(),
    curr_token_ptr_(nullptr),
    trav_pos_(0)
{
}

void ObTextWhitespaceTokenizer::reset()
{
  curr_token_ptr_ = nullptr;
  trav_pos_ = 0;
  ObTextTokenizer::reset();
}

int ObTextWhitespaceTokenizer::inner_open(const ObDatum &document, const ObCharsetInfo *cs)
{
  int ret = OB_SUCCESS;
  curr_token_ptr_ = nullptr;
  trav_pos_ = 0;
  return ret;
}

int ObTextWhitespaceTokenizer::get_next(ObDatum &next_token, int64_t &token_freq)
{
  int ret = OB_SUCCESS;
  if (IS_NOT_INIT) {
    ret = OB_NOT_INIT;
  } else if (iter_end_) {
    ret = OB_ITER_END;
  } else {
    const char *doc = input_doc_->ptr_;
    const uint32_t doc_len = get_input_buf_len();
    // A null table or a wider minimum character stays on the original path.
    const unsigned char *ascii_ctype = 1 == cs_->mbminlen ? cs_->ctype : nullptr;
    int64_t token_len = 0;
    // to next non-whitespace pos
    while (OB_SUCC(ret) && found_delimiter()) {
      int64_t c_len = 0;
      if (nullptr != ascii_ctype
          && static_cast<unsigned char>(doc[trav_pos_]) < 0x80) {
        // The first byte was classified by found_delimiter().
        int64_t pos = trav_pos_ + 1;
        while (pos < doc_len) {
          const unsigned char ch = static_cast<unsigned char>(doc[pos]);
          if (ch >= 0x80 || 0 == (ascii_ctype[ch + 1] & (_MY_SPC | _MY_CTR | _MY_PNT))) {
            break;
          }
          ++pos;
        }
        c_len = pos - trav_pos_;
      } else {
        // Preserve the original character-length path outside ASCII spans.
        c_len = 1 == cs_->mbminlen
            && static_cast<unsigned char>(doc[trav_pos_]) < 0x80
            ? 1 : ob_mbcharlen_ptr(cs_, doc + trav_pos_, doc + doc_len);
      }
      trav_pos_ += c_len;
      if (trav_pos_ >= doc_len || 0 == c_len) {// if char is invalid, just skip the rest of document
        iter_end_ = true;
        ret = OB_ITER_END;
      }
    }

    if (OB_SUCC(ret)) {
      curr_token_ptr_ = get_trav_ptr();
    }

    // to next whitespace pos
    while (OB_SUCC(ret) && !found_delimiter()) {
      int64_t c_len = 0;
      if (nullptr != ascii_ctype
          && static_cast<unsigned char>(doc[trav_pos_]) < 0x80) {
        // The first byte was classified by found_delimiter().
        int64_t pos = trav_pos_ + 1;
        while (pos < doc_len) {
          const unsigned char ch = static_cast<unsigned char>(doc[pos]);
          if (ch >= 0x80 || 0 != (ascii_ctype[ch + 1] & (_MY_SPC | _MY_CTR | _MY_PNT))) {
            break;
          }
          ++pos;
        }
        c_len = pos - trav_pos_;
      } else {
        // Preserve the original character-length path outside ASCII spans.
        c_len = 1 == cs_->mbminlen
            && static_cast<unsigned char>(doc[trav_pos_]) < 0x80
            ? 1 : ob_mbcharlen_ptr(cs_, doc + trav_pos_, doc + doc_len);
      }
      trav_pos_ += c_len;
      token_len += c_len;
      if (trav_pos_ >= doc_len || 0 == c_len) {
        iter_end_ = true;
        if (0 == token_len) {
          ret = OB_ITER_END;
        }
        break;
      }
    }

    if (OB_SUCC(ret)) {
      next_token.set_string(curr_token_ptr_, static_cast<uint32_t>(token_len));
      token_freq = 1;
      LOG_DEBUG("[TEXT ANALYSIS] got next token", K(ret), K(next_token), K(next_token.get_string()),
          K(input_doc_->len_), K_(trav_pos));
    }
  }
  return ret;
}

bool ObTextWhitespaceTokenizer::found_delimiter()
{
  const unsigned char curr_char = static_cast<unsigned char>(input_doc_->ptr_[trav_pos_]);
  // These three character classes share the same charset classification table.
  return nullptr != cs_->ctype
      && 0 != (cs_->ctype[curr_char + 1] & (_MY_SPC | _MY_CTR | _MY_PNT));
}

ObTokenNormalizer::ObTokenNormalizer()
  : in_stream_(nullptr),
    cs_(nullptr),
    is_inited_(false)
{
}

void ObTokenNormalizer::reset()
{
  in_stream_ = nullptr;
  cs_ = nullptr;
  is_inited_ = false;
}

void ObTokenNormalizer::reuse()
{
  if (nullptr != in_stream_) {
    in_stream_->reuse();
  }
}

int ObTokenNormalizer::init(const ObCharsetInfo *cs, ObITokenStream &in_stream)
{
  int ret = OB_SUCCESS;
  if (IS_INIT) {
    ret = OB_INIT_TWICE;
  } else if (OB_ISNULL(cs)) {
    ret = OB_INVALID_ARGUMENT;
  } else {
    in_stream_ = &in_stream;
    cs_ = cs;
    if (OB_FAIL(inner_init(cs_, in_stream))) {
    }
    is_inited_ = true;
  }
  return ret;
}

int ObTokenStopWordNormalizer::get_next(ObDatum &next_token, int64_t &token_freq)
{
  int ret = OB_SUCCESS;
  bool found_next_valid_token = false;
  token_freq = 0;
  if (IS_NOT_INIT) {
    ret = OB_NOT_INIT;
  }

  while (OB_SUCC(ret) && !found_next_valid_token) {
    // Only filter out pure punctuation / control mark tokens for now
    if (OB_FAIL(in_stream_->get_next(next_token, token_freq))) {
      if (OB_UNLIKELY(OB_ITER_END != ret)) {
      }
    } else if (OB_FAIL(filter_special_marks(next_token, found_next_valid_token))) {
    } else if (!found_next_valid_token) {
      next_token.reset();
    }
  }
  return ret;
}

int ObTokenStopWordNormalizer::filter_special_marks(const ObDatum &check_token, bool &is_valid)
{
  int ret = OB_SUCCESS;
  const int64_t token_len = check_token.len_;
  const char *token = check_token.ptr_;
  int64_t special_mark_cnt = 0;
  for (int64_t i = 0; i < token_len; ++i) {
    const char *character = token + i;
    if (ob_ispunct(cs_, *character) || ob_iscntrl(cs_, *character)) {
      special_mark_cnt++;
    }
  }
  is_valid = !(special_mark_cnt == token_len);
  return ret;
}

ObBasicEnglishNormalizer::ObBasicEnglishNormalizer(ObIAllocator *output_allocator)
  : ObTokenNormalizer(),
    norm_allocator_("TxtTokGrpFilter", OB_MALLOC_NORMAL_BLOCK_SIZE),
    output_allocator_(output_allocator)
{
}

void ObBasicEnglishNormalizer::reset()
{
  norm_allocator_.reset();
  ObTokenNormalizer::reset();
}

void ObBasicEnglishNormalizer::reuse()
{
  norm_allocator_.reuse();
  ObTokenNormalizer::reuse();
}

int ObBasicEnglishNormalizer::get_next(ObDatum &next_token, int64_t &token_freq)
{
  int ret = OB_SUCCESS;
  if (IS_NOT_INIT) {
    ret = OB_NOT_INIT;
  } else {
    next_token.reset();
    token_freq = 0;
    if (nullptr == output_allocator_) {
      norm_allocator_.reuse();
    }
    ObDatum tmp_datum;
    bool found_alnum = false;
    uint32_t norm_token_len = 0;
    const char *norm_token_ptr = nullptr;
    while (OB_SUCC(ret) && !found_alnum) {
      tmp_datum.reset();
      if (OB_FAIL(in_stream_->get_next(tmp_datum, token_freq))) {
        if (OB_UNLIKELY(OB_ITER_END != ret)) {
        }
      } else {
        // trim leading and trailing non-alnum characters
        const char *token = tmp_datum.ptr_;
        const uint32_t raw_token_len = tmp_datum.len_;
        uint32_t first_alnum_pos = 0;
        uint32_t last_alnum_pos = raw_token_len - 1;
        for (uint32_t i = 0; i < raw_token_len; ++i) {
          const char *character = token + i;
          if (ob_isalnum(cs_, *character)) {
            first_alnum_pos = i;
            found_alnum = true;
            break;
          }
        }

        for (int32_t i = raw_token_len - 1; 0 <= i && i < raw_token_len && i >= first_alnum_pos; --i) {
          const char *character = token + i;
          if (ob_isalnum(cs_, *character)) {
            last_alnum_pos = i;
            found_alnum = true;
            break;
          }
        }

        if (!found_alnum) {
          // skip
        } else if (OB_UNLIKELY(last_alnum_pos < first_alnum_pos)) {
          ret = OB_ERR_UNEXPECTED;
        } else {
          norm_token_len = last_alnum_pos - first_alnum_pos + 1;
          norm_token_ptr = token + first_alnum_pos;
        }
      }
    }

    if (OB_FAIL(ret)) {
    } else if (OB_UNLIKELY(!found_alnum)) {
      ret = OB_ERR_UNEXPECTED;
    } else {
      ObString norm_alnum_token(norm_token_len, norm_token_ptr);
      ObString norm_lower_token;
      if (OB_FAIL(ObCharset::tolower(cs_, norm_alnum_token, norm_lower_token,
              nullptr == output_allocator_ ? norm_allocator_ : *output_allocator_))) {
      } else {
        next_token.set_string(norm_lower_token);
      }
    }
  }
  return ret;
}


ObTextTokenGroupNormalizer::ObTextTokenGroupNormalizer()
  : ObTokenNormalizer(),
    token_allocator_("TxtTokGrpFilter", OB_MALLOC_MIDDLE_BLOCK_SIZE),
    grouping_map_(),
    map_iter_(),
    map_end_iter_(),
    in_stream_iter_end_(false)
{
}

void ObTextTokenGroupNormalizer::reset()
{
  grouping_map_.destroy();
  in_stream_iter_end_ = false;
  token_allocator_.reset();
  ObTokenNormalizer::reset();
}

void ObTextTokenGroupNormalizer::reuse()
{
  grouping_map_.reuse();
  in_stream_iter_end_ = false;
  token_allocator_.reuse();
  ObTokenNormalizer::reuse();
}

int ObTextTokenGroupNormalizer::inner_init(const ObCharsetInfo *cs, ObITokenStream &in_stream)
{
  // TODO: use resaonable initialize bucket cnt
  int ret = OB_SUCCESS;
  if (OB_ISNULL(cs)) {
    ret = OB_INVALID_ARGUMENT;
  } else if (OB_FAIL(grouping_map_.create(
      DEFAULT_HASH_MAP_BUCKET_CNT,
      "TxtTokGrpHash",
      "TxtTokGrpHash"))) {
  }
  return ret;
}

int ObTextTokenGroupNormalizer::get_next(ObDatum &next_token, int64_t &token_freq)
{
  int ret = OB_SUCCESS;
  if (IS_NOT_INIT) {
    ret = OB_NOT_INIT;
  } else if (!in_stream_iter_end_ && OB_FAIL(build_grouping_map())) {
  }

  if (OB_SUCC(ret)) {
    if (map_iter_ == map_end_iter_) {
      ret = OB_ITER_END;
    } else {
      next_token.set_string(map_iter_->first);
      token_freq = map_iter_->second;
      ++map_iter_;
    }
  }
  return ret;
}

int ObTextTokenGroupNormalizer::build_grouping_map()
{
  int ret = OB_SUCCESS;
  ObDatum token;
  if (OB_UNLIKELY(in_stream_iter_end_)) {
    ret = OB_ERR_UNEXPECTED;
  }

  while (OB_SUCC(ret)) {
    int64_t grouped_token_freq = 0;
    int64_t curr_token_freq = 0;
    if (OB_FAIL(in_stream_->get_next(token, curr_token_freq))) {
      if (OB_UNLIKELY(OB_ITER_END != ret)) {
      }
    } else {
      ObString token_string = token.get_string();
      int hash_ret = grouping_map_.get_refactored(token_string, grouped_token_freq);
      if (OB_HASH_NOT_EXIST == hash_ret) {
        ObString copied_token_string;
        if (OB_FAIL(ob_write_string(token_allocator_, token_string, copied_token_string))) {
        } else if (OB_FAIL(grouping_map_.set_refactored(copied_token_string, curr_token_freq))) {
        }
      } else if (OB_SUCCESS == hash_ret) {
        // add token_freq in hash map directly, to avoid deep copy token string
        *grouping_map_.get(token_string) += curr_token_freq;
      } else {
        ret = hash_ret;
      }
    }
  }

  if (OB_UNLIKELY(ret != OB_ITER_END)) {
  } else {
    ret = OB_SUCCESS;
    map_end_iter_ = grouping_map_.end();
    map_iter_ = grouping_map_.begin();
    in_stream_iter_end_ = true;
  }
  return ret;
}

} // namespace share
} // namespace oceanbase
