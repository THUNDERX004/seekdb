# Round 28 ASCII-span source review — 2026-11-04

No concrete Major or Blocker behavior difference was found in the bounded
source review. Performance remains unmeasured by this sidecar. This is not a
merge verdict or a claim of candidate execution, SQL validation or speedup.

The review followed `D:/Projects/OceanBase/seekdb/AGENTS.md` and
`.agents/skills/code-review/SKILL.md`. Its promised contract is identical
public tokenizer return values, token pointer/bytes/length and frequency,
including unchanged output arguments on end/error, while batching only
same-class ASCII characters already admitted by the original length shortcut.
The inspected patch changes only `ObTextWhitespaceTokenizer::get_next`.
Independent text comparison confirmed identical source before and after that
function; the public header and found_delimiter implementation are unchanged.

Reviewed immutable proposal snapshots under
`../round28-ascii-spans-proposal/{original,candidate}/src/share/text_analysis/`:

- Original CPP SHA-256:
  `0fce1e910e786b24f4d5fbaa48e39bf2c4fb357bd20f3f6560ff0181c86a3a58`.
- Candidate CPP SHA-256:
  `0bef1d905eccbd9eedf0b0e8190b331ceaef0678c3df21393cfff7a874c785a9`.
- Frozen native TU SHA-256:
  `7d464d4db30518eba4b9f776097cf106ddceb21240ccc68f86d15d5ccf0e7eab`.

Candidate line references below refer to that staged CPP. Other paths and
lines refer to the selected checkout. The parent-owned live CPP was observed
at the candidate hash while collecting source pins; the staged snapshots,
rather than assumptions about mutable live state, define this review.

The delimiter and token scans at candidate CPP:102-126 and :134-162 preserve
the original outer predicates. Each admitted span begins at an ASCII byte
already classified by found_delimiter, with mbminlen equal to one and a
non-null ctype table. Its additional bytes must also be ASCII and have the
same class under the identical `_MY_SPC | _MY_CTR | _MY_PNT` mask and unsigned
byte-plus-one table index. Each of those bytes would have length one under
the original shortcut. The local scan therefore reaches the same cursor and
token length as the original sequence of single-byte iterations; no decoder,
output write or external callback has been omitted between those iterations.
The final state increments and end/error blocks remain in their original
order. NUL is a classified byte, not a terminator; punctuation/control
classification remains table-driven rather than a hardcoded whitespace list.

The ctype pointer is local to each get_next call (candidate CPP:99), so it is
reloaded on the next call, including for a caller-owned descriptor changed
between calls. Both additional table reads use the actual current descriptor
table; this introduces no process-wide or per-tokenizer classification cache.
The review explicitly traced the existing ctype assignment in
`src/oblib/lib/charset/ob_ctype_uca.cc:507-515`: it occurs in the collation
initializer. `ob_charset.cpp:2061-2084,2534-2583` runs descriptor initialization
as part of lookup before returning the retained descriptor. The retained
UTF8MB4 length routine at `ob_ctype_utf8.cc:88-101` and binary routine at
`ob_ctype_bin.cc:29-33` do not mutate ctype or charset metadata. No supported
mid-call pointer replacement or table-mutation path was found in this trace.
Concurrent unsynchronized modification of borrowed descriptor/document data
is not established as a supported tokenizer operation by these callers.

Every newly introduced doc[pos] read is guarded by pos < doc_len before the
read (candidate CPP:108-109 and :140-141). Spans never include a high byte.
The initial doc[trav_pos_] access already exists in the original classifier
and original length expression. For an initialized, unmodified document,
reaching/exceeding its end sets iter_end before another classifier evaluation.
The datum's 29-bit length and int64 cursors also leave pos+1 and accumulated
ASCII lengths within range (`common/datum/ob_datum.h:140-148`). The change
does not replace byte-length bounds with strlen, a terminator search or an
unchecked vector load.

The fallback expressions at candidate CPP:118-120 and :150-152 retain the
original ASCII shortcut plus real `ob_mbcharlen_ptr` call. A non-ASCII byte
following a span is processed at the same cursor and token length as before.
In particular, `ob_ctype_mb.cc:333-341` reports a lead-byte length and is not
a full remaining-input validator. For bytes `41 42 e2 20 58`, the retained
UTF8MB4 length routine reports three at e2, consuming the following space and
X as part of that character-length step; both versions produce the same
five-byte token. For `41 42 e2` at the declared end, both can expose a
five-byte token, including two bytes beyond the declared document length.
That existing malformed-input behavior is not introduced or corrected by
the proposal. Zero-length decoder returns still use the original stop logic:
end/error leaves output untouched unless a prior positive token prefix makes
the unchanged success block applicable. This review does not certify the
preimage's malformed-input memory safety.

The proposal does not change open/reset/reuse or output ownership.
Candidate CPP:165-169 still writes only a borrowed input slice and frequency
one on success; initialization/end guards precede charset access. Empty/NULL
open, repeated open, and failure returns remain those of CPP:44-85. The BENG
caller stores the borrowed datum in its parser member and opens the tokenizer
on that stable member (`storage/fts/ob_beng_ft_parser.cpp:61-76`, header:54-57).
Its normalizer consumes the slice while the parser is active and writes
normalized output into the existing caller allocator (:29-58); reset clears
the normalizer and tokenizer before resetting the datum (:84-89). The share
analyzer likewise reuses the pipeline before opening the caller's document
(`share/text_analysis/ob_text_analyzer.cpp:157-169`). The candidate introduces
no allocation, retained ctype pointer, new borrowed owner or cleanup path.

At review handoff the parent reported actual-production **control PASS 4,699**
with the frozen TU unchanged; candidate build/run was in progress. This review
did not inspect raw executable/link receipts or run logs. The native oracle
at `test_whitespace_spans.cpp:59-126` preserves the exact generic algorithm,
and :198-216 compares return, pack, pointer, bytes, length, offset and
frequency with explicit end/error sentinel checks. The finite corpus includes
all byte values, ASCII runs, malformed/truncated boundaries, public API
lifecycle calls and a null-ctype descriptor copy using the real decoder.
`ob_charset.cpp:2087-2122` retains only UTF8MB4 general/bin/unicode and binary;
the fixture correctly records the other requested encodings unavailable.
It supplies no execution evidence for mbminlen > 1. That branch remains the
original source expression rather than a newly implemented decoder path.

The padded native fixtures safely expose the preimage's possible positive
length beyond declared end, but do not detect all out-of-bounds reads.
Guard-page/sanitizer behavior, input/output datum aliasing, concurrent use,
restored encodings, candidate native results and SQL integration are outside
this source-only evidence. None is presented as a demonstrated proposal
defect. Actual ASCII-span execution frequency and performance remain separate
parent-owned measurements; source operation counts do not establish a gain.

Only this new review directory was written. No frozen fixture/proposal,
production source/docs or Git state was changed, and no build, native
execution, runtime, SQL or benchmark operation was performed by this review.
