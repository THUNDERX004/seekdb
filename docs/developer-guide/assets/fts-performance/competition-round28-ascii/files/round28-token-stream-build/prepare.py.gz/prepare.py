"""Adapt actual production native-link infrastructure to the share tokenizer."""
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent
BASE = HERE.parent/'round27-dat-root-build'
builder_raw = (BASE/'build_native.py').read_bytes()
builder = builder_raw.decode('utf-8')
replacements = [
    ("src/storage/fts/dict/ob_ft_dat_dict.cpp", "src/share/text_analysis/ob_token_stream.cpp"),
    ("src/storage/fts/dict/ob_ft_dat_dict.h", "src/share/text_analysis/ob_token_stream.h"),
    ("test_dat_root", "test_whitespace_spans"),
    ("/ob_storage.dir/", "/ob_share.dir/"),
    ("src/storage/ob_storage_static.lib", "src/share/ob_share_static.lib"),
    ("DAT reader", "token stream"),
]
for old, new in replacements:
    assert old in builder, old
    builder = builder.replace(old, new)
runner_raw = (BASE/'run_native.py').read_bytes()
runner = runner_raw.decode('utf-8').replace('test_dat_root', 'test_whitespace_spans')
for name, source in [('build_native.py', builder), ('run_native.py', runner)]:
    with (HERE/name).open('x', encoding='utf-8') as f:
        f.write(source)
with (HERE/'provenance.json').open('x', encoding='utf-8') as f:
    json.dump(dict(base=str(BASE), original_builder_sha256=hashlib.sha256(builder_raw).hexdigest(),
        builder_sha256=hashlib.sha256(builder.encode('utf-8')).hexdigest(),
        original_runner_sha256=hashlib.sha256(runner_raw).hexdigest(),
        runner_sha256=hashlib.sha256(runner.encode('utf-8')).hexdigest()), f, indent=2)
print('Prepared actual-share token-stream native adapter')
