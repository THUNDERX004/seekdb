/* Copyright (c) 2026. Licensed under the Apache License, Version 2.0. */
// Source-only sidecar. Link this SAME TU to the actual original/candidate archives.
#include <algorithm>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <initializer_list>
#include <optional>
#include <stdexcept>
#include <string>
#include <vector>
#include "common/datum/ob_datum.h"
#include "lib/charset/ob_charset.h"
#include "lib/charset/ob_ctype.h"
#include "lib/oblog/ob_log.h"
#include "lib/rc/context.h"
#include "share/text_analysis/ob_token_stream.h"

using namespace oceanbase;
using namespace oceanbase::common;
using namespace oceanbase::share;

namespace {
constexpr int kExpectedCases = 4699;
constexpr size_t kPad = 32;
int cases = 0, call_no = 0;
const char *phase = "startup";
const char sentinel[32] = {'s', 0, 'E', char(0x81), 'N', 'T', '!'};
void need(bool ok, const char *why) { if (!ok) throw std::runtime_error(why); }
std::string bytes(std::initializer_list<unsigned int> v)
{
  std::string s;
  for (auto b : v) { need(b < 256, "invalid input byte"); s.push_back(static_cast<char>(b)); }
  return s;
}

class ContextScope final {
public:
  ContextScope()
  {
    lib::ContextParam p;
    p.set_mem_attr("R28Token", ObCtxIds::DEFAULT_CTX_ID).set_properties(lib::USE_TL_PAGE_OPTIONAL);
    need(CURRENT_CONTEXT->CREATE_CONTEXT(context_, p) == OB_SUCCESS && context_ != nullptr,
         "CREATE_CONTEXT");
    flow_.emplace(context_);
    if (flow_->init() != OB_SUCCESS) {
      flow_.reset(); DESTROY_CONTEXT(context_); context_ = nullptr; need(false, "Flow::init");
    }
  }
  ~ContextScope()
  {
    if (flow_) { flow_->deinit(); flow_.reset(); }
    if (context_ != nullptr) DESTROY_CONTEXT(context_);
  }
private:
  lib::MemoryContext context_ = nullptr;
  std::optional<lib::Flow> flow_;
};

// Exact current preimage algorithm, including the existing one-character
// ASCII shortcut. This oracle NEVER scans/batches an ASCII span and calls the
// real charset decoder for precisely the same remaining cases as the preimage.
class GenericTokenizer final {
public:
  void reset() { input_ = nullptr; cs_ = nullptr; ended_ = false; inited_ = false;
                 current_ = nullptr; pos_ = 0; }
  void reuse() { reset(); }
  int open(const ObDatum &doc, const ObCharsetInfo *cs)
  {
    if (inited_) return OB_INIT_TWICE;
    if (cs == nullptr) return OB_INVALID_ARGUMENT;
    if (doc.is_outrow()) return OB_NOT_SUPPORTED;
    input_ = &doc; cs_ = cs;
    if (doc.is_null() || doc.len_ == 0) {
      ended_ = true; // The preimage does NOT mark empty/NULL documents initialized.
    } else {
      current_ = nullptr; pos_ = 0; inited_ = true;
      // The preimage's inner_open does NOT clear a previously true iter_end_.
    }
    return OB_SUCCESS;
  }
  int get_next(ObDatum &out, int64_t &freq)
  {
    int ret = OB_SUCCESS;
    if (!inited_) {
      ret = OB_NOT_INIT;
    } else if (ended_) {
      ret = OB_ITER_END;
    } else {
      const char *doc = input_->ptr_;
      const uint32_t len = input_->len_;
      int64_t token_len = 0;
      while (ret == OB_SUCCESS && delimiter()) {
        const int64_t n = cs_->mbminlen == 1 && static_cast<unsigned char>(doc[pos_]) < 0x80
            ? 1 : ob_mbcharlen_ptr(cs_, doc + pos_, doc + len);
        pos_ += n;
        if (pos_ >= len || n == 0) { ended_ = true; ret = OB_ITER_END; }
      }
      if (ret == OB_SUCCESS) current_ = doc + pos_;
      while (ret == OB_SUCCESS && !delimiter()) {
        const int64_t n = cs_->mbminlen == 1 && static_cast<unsigned char>(doc[pos_]) < 0x80
            ? 1 : ob_mbcharlen_ptr(cs_, doc + pos_, doc + len);
        pos_ += n; token_len += n;
        if (pos_ >= len || n == 0) {
          ended_ = true;
          if (token_len == 0) ret = OB_ITER_END;
          break;
        }
      }
      if (ret == OB_SUCCESS) { out.set_string(current_, static_cast<uint32_t>(token_len)); freq = 1; }
    }
    return ret;
  }
private:
  bool delimiter() const
  {
    need(input_ != nullptr && pos_ >= 0 && pos_ < input_->len_, "unsafe generic classifier position");
    const unsigned char c = static_cast<unsigned char>(input_->ptr_[pos_]);
    return cs_->ctype != nullptr && (cs_->ctype[c + 1] & (_MY_SPC | _MY_CTR | _MY_PNT)) != 0;
  }
  const ObDatum *input_ = nullptr;
  const ObCharsetInfo *cs_ = nullptr;
  bool ended_ = false, inited_ = false;
  const char *current_ = nullptr;
  int64_t pos_ = 0;
};

enum class DocMode { Inline, Null, Outrow };
struct Input {
  std::vector<unsigned char> storage, saved;
  ObDatum doc;
  const char *ptr;
  uint32_t pack;
  size_t logical;
  explicit Input(const std::string &s, DocMode mode = DocMode::Inline)
      : storage(kPad + s.size() + kPad, 0xd3), logical(s.size())
  {
    std::memcpy(storage.data() + kPad, s.c_str(), s.size());
    for (size_t i = 0; i < kPad; ++i) storage[kPad + s.size() + i] = static_cast<unsigned char>(0x90 + i % 31);
    ptr = reinterpret_cast<const char *>(storage.data() + kPad);
    doc.set_string(ptr, static_cast<uint32_t>(s.size()));
    if (mode == DocMode::Null) doc.set_null();
    if (mode == DocMode::Outrow) doc.set_outrow();
    pack = doc.pack_; saved = storage;
  }
  void verify() const
  { need(storage == saved && doc.ptr_ == ptr && doc.pack_ == pack, "input datum/buffer modified"); }
};

ObDatum output_sentinel(int kind)
{
  ObDatum d; d.set_string(sentinel, 7);
  if (kind == 1) d.set_outrow();
  if (kind == 2) d.set_null();
  if (kind == 3) d.set_has_lob_header();
  return d;
}

struct Result {
  int ret;
  const char *ptr;
  uint32_t pack, len;
  int64_t freq, offset;
  const char *region;
  std::string value;
  bool operator==(const Result &r) const
  { return ret == r.ret && ptr == r.ptr && pack == r.pack && len == r.len
        && freq == r.freq && offset == r.offset && std::strcmp(region, r.region) == 0 && value == r.value; }
};

Result result(int ret, const ObDatum &d, int64_t freq, const Input &input)
{
  Result r{ret, d.ptr_, d.pack_, d.len_, freq, -1, "null", {}};
  if (d.ptr_ == sentinel) {
    r.region = "sentinel"; r.offset = 0;
    need(d.len_ <= sizeof(sentinel), "sentinel output length");
  } else if (d.ptr_ != nullptr) {
    const auto p = reinterpret_cast<uintptr_t>(d.ptr_);
    const auto first = reinterpret_cast<uintptr_t>(input.ptr);
    const auto readable = input.logical + kPad;
    need(p >= first && p - first <= readable && d.len_ <= readable - (p - first),
         "output outside labeled readable fixture bounds");
    r.region = "doc"; r.offset = static_cast<int64_t>(p - first);
  }
  need(d.ptr_ != nullptr || d.len_ == 0, "nonempty null output");
  if (d.len_ != 0) r.value.assign(d.ptr_, d.len_);
  return r;
}

void emit(const char *model, const char *operation, const Result &r)
{
  std::printf("T\t%d\tcall=%d\t%s\t%s\tret=%d\tpack=%08x\tlen=%u\tptr=%s\toffset=%lld\tfreq=%lld\thex=",
      cases, call_no, operation, model, r.ret, unsigned(r.pack), unsigned(r.len), r.region,
      static_cast<long long>(r.offset), static_cast<long long>(r.freq));
  for (unsigned char c : r.value) std::printf("%02x", unsigned(c));
  std::putchar('\n');
}

int step(ObTextWhitespaceTokenizer &actual, GenericTokenizer &oracle, Input &input, const char *op)
{
  phase = op; ++call_no;
  const int kind = call_no % 4;
  ObDatum p = output_sentinel(kind), g = output_sentinel(kind);
  const auto before = result(OB_SUCCESS, p, -700000 - call_no, input);
  int64_t pf = before.freq, gf = before.freq;
  const int gr = oracle.get_next(g, gf);
  const int pr = actual.get_next(p, pf);
  const auto a = result(pr, p, pf, input), b = result(gr, g, gf, input);
  emit("production", op, a); emit("generic", op, b);
  need(a == b, "production/generic token return/pointer/pack/bytes/frequency mismatch");
  if (pr != OB_SUCCESS)
    need(a.ptr == before.ptr && a.pack == before.pack && a.freq == before.freq
         && a.value == before.value, "output sentinel changed on end/error");
  else need(a.freq == 1 && std::strcmp(a.region, "doc") == 0, "successful token ownership/frequency");
  input.verify();
  return pr;
}

void open_pair(ObTextWhitespaceTokenizer &actual, GenericTokenizer &oracle,
               Input &input, const ObCharsetInfo *cs, const char *op)
{
  phase = op; ++call_no;
  const int g = oracle.open(input.doc, cs), p = actual.open(input.doc, cs);
  const auto d = output_sentinel(call_no % 4);
  emit("production", op, result(p, d, -800000 - call_no, input));
  emit("generic", op, result(g, d, -800000 - call_no, input));
  need(p == g, "open return mismatch"); input.verify();
}

void drain(ObTextWhitespaceTokenizer &actual, GenericTokenizer &oracle, Input &input, const char *op)
{
  // Each successful call consumes bytes. Bound also covers empty/uninitialized
  // cases and a positive decoder length extending into the safe padding.
  const size_t bound = input.logical + kPad + 4;
  bool stopped = false;
  for (size_t i = 0; i < bound; ++i) {
    const int ret = step(actual, oracle, input, op);
    if (ret != OB_SUCCESS) { stopped = true; break; }
  }
  need(stopped, "tokenizer failed to make bounded progress");
  step(actual, oracle, input, "repeat-end-1");
  step(actual, oracle, input, "repeat-end-2");
}

void run(const char *cs_name, const ObCharsetInfo *cs, const std::string &label,
         const std::string &s, bool lifecycle = false, DocMode mode = DocMode::Inline,
         bool null_cs = false)
{
  ++cases; call_no = 0;
  Input input(s, mode);
  std::printf("CASE\t%d\tcs=%s\tname=%s\tmode=%d\tnull_cs=%d\tdeclared=%u\tpayload=%u\treadable=%u"
              "\tpadding=32\tdocpack=%08x\tlifecycle=%d\thex=",
      cases, cs_name, label.c_str(), int(mode), int(null_cs), unsigned(input.doc.len_),
      unsigned(s.size()), unsigned(s.size() + kPad), unsigned(input.doc.pack_), int(lifecycle));
  for (unsigned char c : s) std::printf("%02x", unsigned(c));
  std::putchar('\n');
  ObTextWhitespaceTokenizer actual;
  GenericTokenizer oracle;
  step(actual, oracle, input, "unopened");
  open_pair(actual, oracle, input, null_cs ? nullptr : cs, "open");
  drain(actual, oracle, input, "next");
  if (lifecycle) {
    open_pair(actual, oracle, input, cs, "reopen-without-reset");
    drain(actual, oracle, input, "after-reopen");
    actual.reset(); oracle.reset();
    step(actual, oracle, input, "after-reset");
    open_pair(actual, oracle, input, cs, "open-after-reset");
    drain(actual, oracle, input, "reset-next");
    actual.reuse(); oracle.reuse();
    step(actual, oracle, input, "after-reuse");
    open_pair(actual, oracle, input, cs, "open-after-reuse");
    drain(actual, oracle, input, "reuse-next");
    // Empty/NULL open leaves ended=true without initialization. A subsequent
    // nonempty open can succeed but still return END; preserve the preimage.
    Input other("Alpha !! Beta");
    open_pair(actual, oracle, other, cs, "open-other-without-reset");
    drain(actual, oracle, other, "other-next");
    actual.reset(); oracle.reset();
    open_pair(actual, oracle, other, cs, "open-other-after-reset");
    drain(actual, oracle, other, "other-reset-next");
    input.verify(); other.verify();
  }
}

std::vector<std::string> edges()
{
  return {"", bytes({0}), bytes({0xc2, 0x80}), bytes({0xdf, 0xbf}), bytes({0xe0, 0xa0, 0x80}),
    bytes({0xed, 0x9f, 0xbf}), bytes({0xee, 0x80, 0x80}), bytes({0xef, 0xbf, 0xbf}),
    bytes({0xe4, 0xb8, 0xad}), bytes({0xf0, 0x9f, 0x99, 0x82}), bytes({0xf4, 0x8f, 0xbf, 0xbf}),
    bytes({0x80}), bytes({0xc0}), bytes({0xc1}), bytes({0xff}), bytes({0xc2}), bytes({0xe0}),
    bytes({0xe0, 0xa0}), bytes({0xed, 0xa0}), bytes({0xf0}), bytes({0xf0, 0x9f}),
    bytes({0xf0, 0x9f, 0x99}), bytes({0xe2, 0x28, 0xa1}), bytes({0xc0, 0x80}),
    bytes({0xed, 0xa0, 0x80}), bytes({0xf4, 0x90, 0x80, 0x80}), bytes({0xf8, 0x80, 0x80, 0x80, 0x80}),
    bytes({0xe4, 0xb8}), bytes({0x81, 0x40}), bytes({0x81, 0x30, 0x81, 0x30}),
    bytes({0x41, 0, 0x20, 0, 0x42, 0}), bytes({0, 0, 0, 0x41})};
}

std::vector<std::string> mixed()
{
  std::string ascending, descending, alternating;
  for (int i = 0; i < 256; ++i) {
    ascending.push_back(static_cast<char>(i)); descending.push_back(static_cast<char>(255 - i));
    alternating += i % 2 ? "A!" : " B";
  }
  return {ascending, descending, alternating, "Alpha, beta!Gamma\tDelta\r\nEND",
    bytes({'A', 0, 'B', 0x7f, 'C'}),
    std::string(128, 'A') + bytes({0xe4, 0xb8, 0xad}) + std::string(128, 'B'),
    std::string(128, ' ') + bytes({0xf0, 0x9f, 0x99, 0x82}) + " ! tail",
    bytes({'!', ' ', 0xe4, 0xb8, 0xad, '.', 0xf0, 0x9f, 0x99, 0x82, 0, 'Z'})};
}

void api_cases(const char *name, const ObCharsetInfo *cs)
{
  run(name, cs, "api-empty", "", true);
  run(name, cs, "api-null", "not-a-document", true, DocMode::Null);
  run(name, cs, "api-outrow", "not-an-inline-document", true, DocMode::Outrow);
  run(name, cs, "api-null-charset", "Alpha beta", true, DocMode::Inline, true);
}

void corpus(const char *name, const ObCharsetInfo *cs)
{
  for (int b = 0; b < 256; ++b) {
    const std::string one(1, static_cast<char>(b));
    run(name, cs, "byte-start-" + std::to_string(b), one + "AB ");
    run(name, cs, "byte-end-" + std::to_string(b), "AB " + one);
    run(name, cs, "byte-middle-" + std::to_string(b), "AA " + one + " BB");
  }
  for (int n = 0; n <= 256; ++n) {
    const std::string s = std::string(n, ' ') + std::string(n, 'A') + ","
        + std::string(n, 'B') + std::string(n, '\t');
    run(name, cs, "run-" + std::to_string(n), s, n == 0 || n == 1 || n == 128 || n == 256);
  }
  for (int n : {0, 1, 2, 7, 15, 16, 31, 32, 63, 64, 127, 128, 255, 256}) {
    run(name, cs, "only-token-" + std::to_string(n), std::string(n, 'A'));
    run(name, cs, "only-delimiter-" + std::to_string(n), std::string(n, '!'));
  }
  const auto e = edges(); need(e.size() == 32, "edge corpus size");
  for (size_t i = 0; i < e.size(); ++i) {
    run(name, cs, "edge-alone-" + std::to_string(i), e[i]);
    run(name, cs, "edge-after-token-" + std::to_string(i), std::string(127, 'A') + e[i]);
    run(name, cs, "edge-after-delimiters-" + std::to_string(i), std::string(128, '!') + e[i] + " END");
  }
  const auto m = mixed(); need(m.size() == 8, "mixed corpus size");
  for (size_t i = 0; i < m.size(); ++i) run(name, cs, "mixed-" + std::to_string(i), m[i], true);
  api_cases(name, cs);
}

struct CharsetSlot { const char *name; int collation; bool expected; };
const CharsetSlot slots[] = {
  {"utf8mb4_general_ci", 45, true}, {"utf8mb4_bin", 46, true}, {"utf8mb4_unicode_ci", 224, true},
  {"utf8mb3_general_ci", 33, false}, {"latin1_bin", 47, false}, {"binary", 63, true},
  {"gbk_chinese_ci", 28, false}, {"gb18030_chinese_ci", 248, false},
  {"utf16le_general_ci", 56, false}, {"utf16_be_general_ci", 54, false}, {"utf32_general_ci", 60, false}
};
} // namespace

int main()
{
  try {
    OB_LOGGER.set_log_level("ERROR");
    ContextScope context;
    const ObCharsetInfo *utf8_bin = nullptr;
    for (const auto &slot : slots) {
      ++cases; call_no = 0; phase = "availability";
      const auto *cs = ObCharset::get_charset(static_cast<ObCollationType>(slot.collation));
      std::printf("CASE\t%d\tcs=%s\tavailability=1\tcollation=%d\tavailable=%d\tmbmin=%u\tmbmax=%u\tctype=%d\n",
          cases, slot.name, slot.collation, int(cs != nullptr), cs ? cs->mbminlen : 0,
          cs ? cs->mbmaxlen : 0, int(cs != nullptr && cs->ctype != nullptr));
      Input empty("");
      const auto d = output_sentinel(0);
      emit("availability", "lookup", result(cs ? OB_SUCCESS : OB_NOT_SUPPORTED, d, -900000, empty));
      need((cs != nullptr) == slot.expected, "charset availability changed: refreeze finite schedule");
      if (cs != nullptr) corpus(slot.name, cs);
      if (slot.collation == 46) utf8_bin = cs;
    }
    need(utf8_bin != nullptr, "missing retained UTF8MB4_BIN");
    // A public, test-owned descriptor copy with the REAL decoder and a null
    // classifier table tests the proposal's null-table fallback. This is not
    // presented as an unavailable encoding or a replacement decoder.
    ObCharsetInfo no_ctype = *utf8_bin; no_ctype.ctype = nullptr;
    const auto m = mixed(), e = edges();
    for (size_t i = 0; i < m.size(); ++i)
      run("utf8mb4_bin_noctype", &no_ctype, "mixed-" + std::to_string(i), m[i], true);
    for (size_t i = 0; i < e.size(); ++i)
      run("utf8mb4_bin_noctype", &no_ctype, "edge-" + std::to_string(i), e[i]);
    api_cases("utf8mb4_bin_noctype", &no_ctype);
    need(cases == kExpectedCases, "incomplete finite corpus");
    std::printf("PASS\tcases=%d\n", cases);
    return std::fflush(stdout) == 0 && !std::ferror(stdout) ? 0 : 1;
  } catch (const std::exception &e) {
    std::fprintf(stderr, "FAIL\tcase=%d\tcall=%d\tphase=%s\t%s\n", cases, call_no, phase, e.what());
    return 1;
  }
}
