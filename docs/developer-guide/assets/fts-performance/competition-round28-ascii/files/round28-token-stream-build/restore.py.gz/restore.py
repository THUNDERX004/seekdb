"""Reject round28 and restore only its exact original production source."""
from pathlib import Path
from datetime import datetime
import hashlib
import json

HERE = Path(__file__).resolve().parent
FTS = HERE.parent
ROOT = Path('D:/Projects/OceanBase/seekdb')
REL = 'src/share/text_analysis/ob_token_stream.cpp'
old = (FTS / 'round28-ascii-spans-proposal/original' / REL).read_bytes()
new = (FTS / 'round28-ascii-spans-proposal/candidate' / REL).read_bytes()
assert hashlib.sha256(old).hexdigest() == '0fce1e910e786b24f4d5fbaa48e39bf2c4fb357bd20f3f6560ff0181c86a3a58'
assert hashlib.sha256(new).hexdigest() == '0bef1d905eccbd9eedf0b0e8190b331ceaef0678c3df21393cfff7a874c785a9'
assert (ROOT / REL).read_bytes() == new
comparison = FTS / 'round28-ascii-evidence/ascii-comparison-3pair.json'
result = json.loads(comparison.read_bytes())
assert result['completed_pairs'] == 3
assert result['aggregate']['overall_improvement'] < 0
receipt = dict(decision='REJECTED_RESTORED_EXACT', timestamp=datetime.now().astimezone().isoformat(),
    source=REL, original_sha256=hashlib.sha256(old).hexdigest(),
    candidate_sha256=hashlib.sha256(new).hexdigest(),
    comparison_sha256=hashlib.sha256(comparison.read_bytes()).hexdigest(),
    aggregate=result['aggregate'],
    reason='No convincing measured target benefit; three-pair overall reduction negative. Pair1 spans a user pause and is retained, not presented as a causal regression. Initial ranked-score discrepancy remains unexplained despite separate exact native and ranked repeats.',
    native='4699 actual-production cases PASS with identical complete stdout; finite matrix only',
    first_candidate_regression='r28-ascii-candidate-regression-a1 failed ranked score comparison; server alive',
    control_regression='r28-ascii-control-regression-a1 ranked handshake reset; cause undetermined',
    official_ranked_repeat='r28-ascii-official-ranked-a1 PASS ranked/keytypes/seven suites',
    candidate_ranked_repeat='r28-ascii-candidate-ranked-a2 PASS ranked/keytypes/seven suites',
    production_promotion='NONE', rebuild='SEPARATE PENDING')
assert not (HERE / 'rejection-restoration.json').exists()
(ROOT / REL).write_bytes(old)
assert (ROOT / REL).read_bytes() == old
with (HERE / 'rejection-restoration.json').open('x', encoding='utf-8') as f:
    json.dump(receipt, f, indent=2)
print('REJECTED; exact original source restored')
