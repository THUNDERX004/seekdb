"""Independent full-byte native output check; executes no test or workload."""
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent
outputs = {}
for variant in ('control', 'candidate'):
    directory = HERE / (variant + '-run1')
    receipt = json.loads((directory / 'run.json').read_text())
    raw = (directory / 'stdout.log').read_bytes()
    err = (directory / 'stderr.log').read_bytes()
    lines = raw.splitlines()
    assert receipt['native'] == receipt['output_validation'] == 'PASS'
    assert receipt['exit_code'] == 0 and err == b''
    assert receipt['test_sha256'] == '7d464d4db30518eba4b9f776097cf106ddceb21240ccc68f86d15d5ccf0e7eab'
    assert hashlib.sha256(raw).hexdigest() == receipt['logs_sha256']['stdout.log']
    assert sum(x.startswith(b'CASE\t') for x in lines) == 4699
    assert [x for x in lines if x.startswith(b'PASS\t')] == [b'PASS\tcases=4699']
    outputs[variant] = raw
assert outputs['control'] == outputs['candidate']
result = dict(status='PASS', cases=4699,
    T_records=sum(x.startswith(b'T\t') for x in outputs['control'].splitlines()),
    full_stdout_equal=True, both_stderr_empty=True,
    stdout_sha256=hashlib.sha256(outputs['control']).hexdigest(),
    execution='Offline full raw output verification only')
with (HERE / 'parent-output-verification.json').open('x') as f:
    json.dump(result, f, indent=2)
print(json.dumps(result))
