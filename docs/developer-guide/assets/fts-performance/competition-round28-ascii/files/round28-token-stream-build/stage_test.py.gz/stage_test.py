"""Pin the complete same-TU original/candidate native regression input."""
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent
source = HERE.parent/'round28-token-stream-native/test_whitespace_spans.cpp'
raw = source.read_bytes()
assert hashlib.sha256(raw).hexdigest() == '7d464d4db30518eba4b9f776097cf106ddceb21240ccc68f86d15d5ccf0e7eab'
with (HERE/'test_whitespace_spans.cpp').open('xb') as f:
    f.write(raw)
assert source.read_bytes() == raw
with (HERE/'test-provenance.json').open('x', encoding='utf-8') as f:
    json.dump(dict(source=str(source), sha256=hashlib.sha256(raw).hexdigest(), expected_cases=4699), f, indent=2)
print('STAGED 4699-case TU', hashlib.sha256(raw).hexdigest())
