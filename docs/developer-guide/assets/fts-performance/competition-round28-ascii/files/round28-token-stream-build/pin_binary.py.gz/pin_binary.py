"""Freeze current token-stream candidate executable/PDB/DLL set."""
from pathlib import Path
import hashlib
import json
import shutil

HERE = Path(__file__).resolve().parent
ROOT = Path('D:/Projects/OceanBase/seekdb')
BUILD = ROOT/'build_fts_competition/src/observer'
OUT = ROOT/'build/fts-round28-ascii-candidate'
assert hashlib.sha256((ROOT/'src/share/text_analysis/ob_token_stream.cpp').read_bytes()).hexdigest() == '0bef1d905eccbd9eedf0b0e8190b331ceaef0678c3df21393cfff7a874c785a9'
assert not OUT.exists()
OUT.mkdir()
identities = {}
for source in [BUILD/'seekdb.exe', BUILD/'seekdb.pdb', *sorted(BUILD.glob('*.dll'))]:
    digest = hashlib.sha256(source.read_bytes()).hexdigest()
    shutil.copy2(source, OUT/source.name)
    assert hashlib.sha256((OUT/source.name).read_bytes()).hexdigest() == digest
    identities[source.name] = dict(bytes=source.stat().st_size, sha256=digest)
with (HERE/'binary.json').open('x', encoding='utf-8') as f:
    json.dump(dict(output=str(OUT), files=identities), f, indent=2)
print('PINNED', identities['seekdb.exe']['sha256'])
