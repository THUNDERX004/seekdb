"""Apply the exact single-function proposal only to its verified preimage."""
from pathlib import Path
import hashlib
import json
import difflib

HERE = Path(__file__).resolve().parent
ROOT = Path('D:/Projects/OceanBase/seekdb')
PROPOSAL = HERE.parent/'round28-ascii-spans-proposal'
REL = 'src/share/text_analysis/ob_token_stream.cpp'
OLD = '0fce1e910e786b24f4d5fbaa48e39bf2c4fb357bd20f3f6560ff0181c86a3a58'
NEW = '0bef1d905eccbd9eedf0b0e8190b331ceaef0678c3df21393cfff7a874c785a9'
old = (PROPOSAL/'original'/REL).read_bytes()
new = (PROPOSAL/'candidate'/REL).read_bytes()
assert hashlib.sha256(old).hexdigest() == OLD
assert hashlib.sha256(new).hexdigest() == NEW
assert (ROOT/REL).read_bytes() == old
start = b'int ObTextWhitespaceTokenizer::get_next('
end = b'\nbool ObTextWhitespaceTokenizer::found_delimiter()'
before, after = old.split(start)
old_func, suffix = after.split(end)
assert new.startswith(before + start) and new.endswith(end + suffix)
patch = ''.join(difflib.unified_diff(old.decode('utf-8').splitlines(True), new.decode('utf-8').splitlines(True),
                                   fromfile='a/'+REL, tofile='b/'+REL)).encode('utf-8')
assert (PROPOSAL/'source.patch').read_bytes() == patch
(ROOT/REL).write_bytes(new)
with (HERE/'application.json').open('x', encoding='utf-8') as f:
    json.dump(dict(status='APPLIED', source=REL, original_sha256=OLD,
        candidate_sha256=NEW, source_patch_sha256=hashlib.sha256(patch).hexdigest(),
        scope='Only get_next changed; exact preimage/postimage and unified patch verified'), f, indent=2)
print('APPLIED exact one-function ASCII-span proposal')
