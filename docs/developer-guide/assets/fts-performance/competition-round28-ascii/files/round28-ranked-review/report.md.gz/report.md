Round28 ranked score mismatch: bounded source-only review

结论：原因仍未解释。源码与离线数值分析给出了可区分统计输入差异和词条语义差异的诊断方向，没有证明首轮候选失败由后台统计、计划重编译或 ASCII span 修改引起。Round28 已由父任务决定 REJECT；本报告仅作为历史诊断证据，未解释的分数差异不再作为该候选的晋升阻塞。没有继续拓展调查。

工作范围是读取源码、既有日志/receipt/JSON.gz，以及离线解压、确定性语料枚举、算术和 SHA256。未执行 SQL、native、数据库运行、编译、性能测试或 Git；未修改 D: 文件、冻结 fixture 或其他归档。下述 SQL 都是尚未执行的诊断建议，不是本报告新增的验证结果。父任务负责所有运行和完整输出捕获。

已核对的事实：

| 证据 | 已证事实及边界 |
| --- | --- |
| `C:/Users/11946/Documents/ChatGPT/OceanBase比赛/setup/fts/r28-ascii-candidate-regression-a1-ranked.log` | 首个比较失败是 `root[54][4][0][1]`：期望 `0.3978152416996387`，实际 `0.40073254302705685`。这是分数断言失败。 |
| 同标签 experiment receipt | sort/count/materialization/casecopy/BMP action 均 exit 0；ranked exit 1；候选二进制 SHA256 `f10e0fea8fa6d09b2e36388ee3f145fd0e9096a5c614eca0f91e9fa461ab17b0`；`owned_server_exit_before_cleanup=null`。这只是清理前进程未观测到退出，不是持续健康证明。 |
| `C:/Users/11946/Documents/ChatGPT/OceanBase比赛/setup/fts/r28-ascii-control-regression-a1-ranked.log` 及 receipt | C7 control 在 PyMySQL 握手 `_get_server_information()` 阶段连接重置，尚未进入 fixture 建库/查询；清理前 exit 仍为 null。不能把该异常当成同一分数问题的复现，也不能断言根因已修复。 |
| 官方单独 ranked actual 与 comparison receipt | BAE 原始二进制 ranked/keytypes/7 existing actions exit 0；432 cases、142692 result rows。独立离线比较发现 ranked actual 的压缩及解压字节都与冻结 expected 完全一致。 |
| 候选单独 `r28-ascii-candidate-ranked-a2` actual 与 receipt | 同一候选二进制的 ranked/keytypes/7 existing actions exit 0；432 cases、142692 result rows；actual 压缩及解压字节也与冻结 expected 完全一致。该复测 PASS 不能抹去首轮失败或证明其原因。 |
| Native whitespace 4699 outputs identical | 父任务提供的有限 native 等价证据；本次 source review 未重新执行 native，不能替代 BM25 统计链路的运行证据。 |

官方、候选单独 actual 和 frozen expected 的共同压缩 SHA256 是 `d322411c90638ba7cb0dbb4a71c2b770ff41309cac3da185e375a2e9b8d40570`；解压字节 SHA256 是 `9da5f0b417a56eb98313c83082cdbf86491ca9062c56a92eeccbca511c6f55ee`。具体文件的完整路径、大小及源码读取时哈希见相邻 `source-pins.json`。历史二进制身份来自 receipt，本次未读取或打包当前可变二进制，也未从 Git 验证历史源码与二进制的逐对象对应。

冻结测试 [test_ranked_batches.py](D:/Projects/OceanBase/seekdb/unittest/storage/fts/test_ranked_batches.py:36) 中，第 54 个零基 case 是 `simple_docs / mutated / database / ORDER BY id`，第一个结果为 id=1。等价 SQL 是：

```sql
SELECT id, MATCH(body) AGAINST('database') AS score
FROM fts_ranked_batches.simple_docs
WHERE MATCH(body) AGAINST('database')
ORDER BY id;
```

每阶段有 9 terms × 6 suffixes = 54 cases，两个表各经历 built、mutated、transaction、rolled_back，共 432 cases。比较在 `capture()` 完成并删除两张表及数据库之后才执行；`root[54]` 是第一个比较差异，不能解释为运行在 mutated 首行时停止。首轮没有保存完整 actual，后续完整捕获由父任务独立完成；本报告没有补造缺失输出。

mutated 阶段先 autocommit `UPDATE ... SET body='database tokenizer audit' WHERE MOD(id,17)=0`，再 autocommit `DELETE ... WHERE MOD(id,23)=0`。transaction 阶段另将 `MOD(id,29)=0` 改成 `phasebeta tokenizer`，随后 ROLLBACK。id=1 不在这些更新/删除集合中，正文始终为 `background background database database audit audit phasealpha`，词法长度 7，database 频率 2。未改变的该行仍受全库统计参数影响。

以下数字仅由冻结 `corpus()` 及上述精确 DML 在离线字典中枚举，未导入 fixture 模块或连接数据库。长度是本语料单空格分隔的词法长度，不是实测倒排统计：

| 阶段 | 全部行 N | body 非 NULL | 词法 token 总和 | database 文档数 | id1 长度 / tf |
| --- | ---: | ---: | ---: | ---: | ---: |
| built | 3073 | 2999 | 41625 | 1999 | 7 / 2 |
| UPDATE 后、DELETE 前 | 3073 | 3003 | 39746 | 2062 | 7 / 2 |
| mutated：DELETE 后 | 2940 | 2873 | 38009 | 1973 | 7 / 2 |
| transaction：未回滚 | 2940 | 2875 | 36945 | 1906 | 7 / 2 |
| rolled_back | 2940 | 2873 | 38009 | 1973 | 7 / 2 |

实际源码链路如下，引用是当前读取的源码快照，不是对首轮失败运行的动态调用记录：

1. [ob_server.cpp](D:/Projects/OceanBase/seekdb/src/observer/ob_server.cpp:2147) 在 `init_fts()` 安装 legacy DAS text-retrieval engine。工厂安装及构造位于 [ob_das_legacy_tr_merge_iter.cpp](D:/Projects/OceanBase/seekdb/src/observer/composition/retrieval/ob_das_legacy_tr_merge_iter.cpp:1353) 和 :1191；[ob_das_tr_merge_iter.cpp](D:/Projects/OceanBase/seekdb/src/sql/das/iter/sparse_retrieval/ob_das_tr_merge_iter.cpp:127) 将调用转发给该 engine。这避免了仅凭名称把旁存的旧 SQL iterator 当成当前默认链路。
2. 单行词频 `tf` 与文长 `L` 不是基表字节长度。[ob_das_domain_utils.cpp](D:/Projects/OceanBase/seekdb/src/sql/das/ob_das_domain_utils.cpp:277) 先调用真实 parse helper，再生成 `[WORD,DOC_ID,WORD_COUNT,DOC_LENGTH]` 或 `[DOC_ID,WORD,WORD_COUNT,DOC_LENGTH]`，:328–329 写入 tf、L。[ob_fts_parser_helper.cpp](D:/Projects/OceanBase/seekdb/src/storage/fts/ob_fts_parser_helper.cpp:383) 将 `doc_length` 设为 `get_add_word_count()`；[ob_fts_stop_word.cpp](D:/Projects/OceanBase/seekdb/src/storage/fts/ob_fts_stop_word.cpp:131) 经长度过滤、规范化/停用词检查、groupby 后按 word frequency 累加接受数量。因此不能用 unique token 数替代 L。BENG 在 [ob_beng_ft_parser.cpp](D:/Projects/OceanBase/seekdb/src/storage/fts/ob_beng_ft_parser.cpp:61) 接入 whitespace tokenizer 和 normalizer；当前 proposal 只改这个 tokenizer 的 ASCII span 扫描。
3. UPDATE 的 domain-index 写入在 [ob_das_update_op.cpp](D:/Projects/OceanBase/seekdb/src/sql/das/ob_das_update_op.cpp:389) 执行 delete old rows 再 insert new rows；旧 FTS 行通常走 `DOMAIN_DML_MODE_FT_SCAN`，新行恢复 DEFAULT 分词路径（:300、:343、:361）。[ob_das_domain_utils.cpp](D:/Projects/OceanBase/seekdb/src/sql/das/ob_das_domain_utils.cpp:993) 根据 mode 选择生成新词行或扫描 doc-word 辅助表旧词行，:1169 起拷贝原词行 tf/L。DELETE 的旧行 mode 选择见 [ob_das_dml_ctx_define.cpp](D:/Projects/OceanBase/seekdb/src/sql/das/ob_das_dml_ctx_define.cpp:112)，实际删除见 [ob_das_delete_op.cpp](D:/Projects/OceanBase/seekdb/src/sql/das/ob_das_delete_op.cpp:80)。这些路径说明应核对哪些 tuple；本次没有证明首轮实际辅助表内容或事务可见性正确。
4. 总文档数 N 有不同来源。[ob_log_table_scan.cpp](D:/Projects/OceanBase/seekdb/src/sql/optimizer/ob_log_table_scan.cpp:3765) 创建 token document COUNT 与 total document COUNT；[ob_tsc_cg_service.cpp](D:/Projects/OceanBase/seekdb/src/sql/code_generator/ob_tsc_cg_service.cpp:1845) 为 total COUNT 选择基表（skip-rowkey-doc 模式）或 doc-id 辅助表。:1899–1908 又将 optimizer `table_row_count_/part_count_` 写入 ctdef 的 `estimated_total_doc_cnt_`。optimizer 行数可来自已收集 stats（[ob_join_order.cpp](D:/Projects/OceanBase/seekdb/src/sql/optimizer/ob_join_order.cpp:13546)）、存储行数估计（[ob_access_path_estimation.cpp](D:/Projects/OceanBase/seekdb/src/sql/optimizer/ob_access_path_estimation.cpp:1483)、:1563）及默认/动态采样路径。不能把此参数直接等同于当前 `COUNT(*)` 或 `COUNT(body)`。
5. [ob_inv_idx_param_estimator.cpp](D:/Projects/OceanBase/seekdb/src/storage/retrieval/ob_inv_idx_param_estimator.cpp:206) 在 estimated N > 0 时直接使用 ctdef 常量；否则读取 total-count scan iterator。传参见 [ob_das_legacy_tr_merge_iter.cpp](D:/Projects/OceanBase/seekdb/src/observer/composition/retrieval/ob_das_legacy_tr_merge_iter.cpp:477)。DAAT/TAAT 的 relevance pre-process 调用 estimator，分别见 [ob_text_daat_iter.cpp](D:/Projects/OceanBase/seekdb/src/storage/retrieval/ob_text_daat_iter.cpp:69) 与 [ob_text_taat_iter.cpp](D:/Projects/OceanBase/seekdb/src/storage/retrieval/ob_text_taat_iter.cpp:64)。:179 的 reuse 只在 switch_tablet 时清除已估计参数；这不是 estimator 跨独立 SQL 语句永久缓存的证明。
6. 平均文长 A 的分子也不是当前全部可见 posting 的精确求和。[ob_tsc_cg_service.cpp](D:/Projects/OceanBase/seekdb/src/sql/code_generator/ob_tsc_cg_service.cpp:3192) 配置 inverted index `SUM(token_cnt)` skip-index；没有 sum 属性时回退。legacy merge :226 以 `true,true,true` 初始化 `ObBlockStatScanParam`，按 [ob_block_stat_iter.h](D:/Projects/OceanBase/seekdb/src/storage/retrieval/ob_block_stat_iter.h:39) 分别表示 single-major-only、最大 block granule、whole-range。[ob_block_stat_iter.cpp](D:/Projects/OceanBase/seekdb/src/storage/retrieval/ob_block_stat_iter.cpp:381) 要求首个为 major 并在一个 major 后停止；:261 直接返回 baseline skip-index row，跳过普通路径中的 SSTable/memtable 汇总。estimator :43–92 累加该 sum，除以所用 N，并将 A 下限设为 10；无法使用 sum skip index 时直接使用默认 A=10。这一设计允许分子与最新 DML 可见行数不在同一刷新时点，不能仅据此宣称发生了“后台统计 bug”。
7. token document frequency df 在 [ob_text_retrieval_token_iter.cpp](D:/Projects/OceanBase/seekdb/src/storage/retrieval/ob_text_retrieval_token_iter.cpp:364) 取 token range 的 `estimate_row_count()` logical row count，再用 df 与 N 预计算 query-token weight；:168/:182 将 df/weight 写入表达式，:205/:243 读取 posting 并求分数。它不是本报告 SQL `COUNT(MATCH)` 的等价实测替身。
8. [ob_expr_bm25.cpp](D:/Projects/OceanBase/seekdb/src/sql/engine/expr/ob_expr_bm25.cpp:146) 的实际函数及 [API header](D:/Projects/OceanBase/seekdb/src/query/api/query/engine/expr/ob_expr_bm25.h:74) 给出 `k1=1.2, b=.75, epsilon=.25`，`w=max(.25,log((max(N-df,0)+.5)/(df+.5)))*2.2`，`score=w*tf/(tf+1.2*(.25+.75*L/A))`。scalar 与 batch evaluation 均用 posting tf/L、precomputed w 和 A，见 :64/:100；并未在每行重新精确 COUNT。

条件性数值拟合可用于挑选诊断数据。对 id1 假设真实 `tf=2,L=7,w=.55`；使用上表 built/mutated df 和相应 N 时 IDF 都落在 epsilon clamp，所以这些 df 的区别不会改变 w。下列结果在本次 Python 浮点运算中与日志对应值数值相等，不是调用生产函数的测试，也不证明这些假设是首轮真实表达式值：

| 条件 A | 推算 score | 与日志关系 |
| --- | ---: | --- |
| `41625/3073 = 13.545395379108363` | `0.3978152416996387` | 恰等于 expected，亦等于冻结 built id1 score |
| `41625/2940 = 14.158163265306122` | `0.40073254302705685` | 恰等于首轮 actual |
| `38009/2940 = 12.928231292517006` | `0.39464635128234415` | 最新词法总和 / 最新基表行数并不能拟合两者 |

这使“相同旧 major token sum，不同 total-doc-count 输入”成为值得区分的假设；并未排除不同 tf、L、weight、计划/快照或表达式传值也能产生该 score。尤其 built/mutated 的同 term/suffix SQL 文本相同，若不同运行复用/重编译了不同计划，ctdef N 可能不同；没有首轮 plan-id、编译参数或实际 N/A 记录，不能据此认定发生了重编译或 stats 刷新。

后续若父任务另开诊断运行，最小需要在 built 后、UPDATE 后、DELETE 后、transaction 内、ROLLBACK 后记录同连接与阶段标识。原测试结束会 DROP 数据库，事后执行以下语句无法取回当时数据。额外诊断会改变执行顺序/时序，应独立标为 diagnostic，保留既有完整 fixture 输出，不能修改 expected、放松分数容差或向正式性能时序插入这些 SQL。

```sql
-- Proposed only; no statement below was executed by this review.
SELECT CURRENT_TIMESTAMP(6) AS captured_at, DATABASE() AS db,
       CONNECTION_ID() AS connection_id,
       @@autocommit AS autocommit,
       @@character_set_connection AS connection_charset,
       @@collation_connection AS connection_collation;
SHOW CREATE TABLE fts_ranked_batches.simple_docs;
SHOW INDEX FROM fts_ranked_batches.simple_docs;

-- Lexical, independent base-data checks valid for THIS exact single-space ASCII corpus.
SELECT COUNT(*) AS base_rows, COUNT(body) AS nonnull_bodies,
       SUM(body IS NULL) AS null_bodies,
       SUM(CASE WHEN body IS NULL OR body='' THEN 0
                ELSE 1+LENGTH(body)-LENGTH(REPLACE(body,' ','')) END) AS lexical_tokens,
       SUM(CASE WHEN LOCATE(' database ',CONCAT(' ',body,' '))>0 THEN 1 ELSE 0 END)
         AS lexical_database_df
FROM fts_ranked_batches.simple_docs;

-- Raw bytes and real current parser output, not merely output JSON array length.
SELECT id,part,HEX(body) AS body_hex,
       TOKENIZE(body,'beng','[{"output":"all"}]') AS token_detail
FROM fts_ranked_batches.simple_docs
WHERE id IN (1,17,23,29,41,391,493,697,1189)
ORDER BY id;

-- Independent membership comparison; parent already owns complete ranked score captures.
SELECT id FROM fts_ranked_batches.simple_docs
WHERE LOCATE(' database ',CONCAT(' ',body,' '))>0 ORDER BY id;
SELECT id FROM fts_ranked_batches.simple_docs
WHERE MATCH(body) AGAINST('database') ORDER BY id;
```

id17/23/29/41 及交集 id391/493/697/1189 分别覆盖 UPDATE、DELETE、事务 UPDATE、NULL 及交叉影响。`TOKENIZE(... output=all)` 的源码输出字段是 `doc_len` 和 token→frequency 对象数组；须比较 token 字节、frequency、doc_len，不能仅比 unique token 数。该调用重新解析当前正文，不读取已有 posting；即使它一致，也不能证明构建/更新时持久化的 tf/L 一致。完整 posting 和 doc-word tuple 若没有受支持 SQL 暴露，就需要另行记录实际 iterator 的 doc-id/token/tf/L/可见性，不能发明内部辅助表名直接读取。

以下 metadata 查询由当前源码的内表定义支持，但本次未实测历史二进制是否暴露、权限是否允许。只过滤专用测试库；若缺失/拒绝，应保留原错误，不以空结果充当参数正确证据。不要采集全库 SQL/session/config 内容。用当前连接分别在阶段前后采样：

```sql
SELECT OWNER,TABLE_NAME,OBJECT_TYPE,PARTITION_NAME,
       NUM_ROWS,LAST_ANALYZED,STALE_STATS
FROM oceanbase.DBA_TAB_STATISTICS
WHERE OWNER='fts_ranked_batches'
  AND TABLE_NAME IN ('simple_docs','composite_docs');

SELECT PLAN_ID,SQL_ID,PLAN_HASH,SCHEMA_VERSION,FIRST_LOAD_TIME,
       LAST_ACTIVE_TIME,EXECUTIONS,HIT_COUNT,QUERY_SQL
FROM oceanbase.`V$OB_PLAN_CACHE_PLAN_STAT`
WHERE DB_ID IN (SELECT database_id FROM oceanbase.__all_database
               WHERE database_name='fts_ranked_batches')
  AND LOWER(QUERY_SQL) LIKE '%simple_docs%'
  AND LOWER(QUERY_SQL) LIKE '%match%'
ORDER BY PLAN_ID;

-- Bind ? to one PLAN_ID actually returned above in a diagnostic client.
SELECT plan_id,plan_line_id,operator,name,rows,cost,property
FROM oceanbase.__all_virtual_plan_cache_plan_explain
WHERE plan_id=? ORDER BY plan_line_id;

-- Separate optional explain; it can compile a NEW plan, so is not proof of the executed plan.
EXPLAIN EXTENDED
SELECT id,MATCH(body) AGAINST('database') AS score
FROM fts_ranked_batches.simple_docs
WHERE MATCH(body) AGAINST('database') ORDER BY id;
```

定义依据：[ob_inner_table_schema_def.py](D:/Projects/OceanBase/seekdb/src/share/inner_table/ob_inner_table_schema_def.py:7425) 的 V$ plan view、:3260 的 cached-plan explain、:9657 的 DBA_TAB_STATISTICS。此 checkout 已移除 GV$OB_SQL_AUDIT/V$OB_SQL_AUDIT，不建议照搬这些已移除视图。`NUM_ROWS`、plan estimated rows、LAST_ANALYZED/STALE_STATS 都不直接证明实际 BM25 N/A；[ob_log_table_scan.cpp](D:/Projects/OceanBase/seekdb/src/sql/optimizer/ob_log_table_scan.cpp:2600) 的 retrieval annotation 也没有打印这些实际值。

若只靠 SQL 仍无法区分，必要缺失数据是同一 query/plan/tablet/snapshot 下的：ctdef `estimated_total_doc_cnt_` 和所走 N 分支、最终 N、选中 major SSTable identity/snapshot 与各 block sum/汇总 S、最终 A、token range/estimated df、预计算 w，以及 id1 posting tf/L 和 scalar/batch 参数。需从真实上述函数/表达式记录，不用 copied BM25 oracle 代替。母任务可选择在独立诊断中取得，本 sidecar 未增加 instrumentation 或执行它。

判别方式：若完整 token maps、持久化 tf/L 和 membership 相同，而实际 N/A 不同且真实 BM25 输入重算吻合，可解释“分数如何变化”，但仍须 plan/major/stats 时序证据才可解释“为何不同”。若 N/A/df/w 相同而 token tuple 不同，才指向构建/更新/查询语义或值传递；若所有实际输入相同而 score 不同，则需继续查表达式求值和行对应。通过 id1 条件反推 `A=6.3/(1.1/score-2.3)` 仅是辅助拟合。新单独 PASS、进程清理前未退出、native 等价各自都不能证明首轮问题已修复。

父任务最终决定 REJECT Round28，提供三组 aggregate overall reduction `-4.502282398%`、BENG token reduction `-10.9690844233%`。这些数字在本 source review 中未重新计算。pair1 跨用户暂停，不能当成 ASCII span 导致退化的因果证据；pair2/3 也不足以可靠归因。源码报告至此结束，剩余 gap 原样归档；不迁移 Round28 TU 到 established suites，不提出性能晋升或正式成绩结论。
