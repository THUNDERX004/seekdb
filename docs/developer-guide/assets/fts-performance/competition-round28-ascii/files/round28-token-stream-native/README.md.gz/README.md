# Round 28 whitespace span native source

Frozen TU: `test_whitespace_spans.cpp`.
SHA-256: `7d464d4db30518eba4b9f776097cf106ddceb21240ccc68f86d15d5ccf0e7eab`.
Fixed corpus: **4,699 cases**. Exact successful final line:
`PASS\tcases=4699`, with a literal tab in the actual output.

This is a source-only handoff. The sidecar has not compiled or executed this
TU, built or edited production, accessed database runtime, run SQL, benchmarked
or used Git. Only this new directory was written. Parent owns the separate
actual original/candidate compile, storage/share archive linkage, execution
and interpretation. No further TU edits are planned after this freeze.

## Link and compare

Compile the same frozen TU for both actual production variants with the
parent's native helper and production compile/link environment. Calls to
`ObTextWhitespaceTokenizer::open/get_next/reset/reuse` resolve to actual
production symbols. The TU includes only public headers, never production
CPP or private-state access, and supplies no replacement production symbol.
It requires C++17, real MemoryContext/Flow, charset, datum, logging and
allocator dependencies. Replace the observer main with this TU using the
parent's established native infrastructure.

The observed local preimage CPP SHA-256 is
`0fce1e910e786b24f4d5fbaa48e39bf2c4fb357bd20f3f6560ff0181c86a3a58`;
unchanged public header SHA-256 is
`00f881913e2ddd1124e1d5eb000a7eca80ec74f5203c60db5a8a875e4222e13a`.
Paths in the selected checkout `D:/Projects/OceanBase/seekdb` are
`src/share/text_analysis/ob_token_stream.cpp` and `.h`. These identify the
local preimage, not an independently retrieved official competition baseline.
The separate ASCII-span proposal reports candidate CPP SHA-256
`0bef1d905eccbd9eedf0b0e8190b331ceaef0678c3df21393cfff7a874c785a9`.
Actual linked candidate identity must be established by the parent's receipt.

Pin the copied TU, production CPP/header, compile arguments, actual containing
unity/object/archive inputs, executable and runtime dependencies. Compare
complete original/candidate stdout bytes, require zero exit status, empty
stderr, exactly 4,699 CASE records and the exact final PASS line. Both binaries
also independently compare every actual call to the generic oracle. Preserve
the exact failed source, logs and receipt before any concrete repair; any new
TU hash must be rebuilt and run on both variants. No build/run result is
asserted by this handoff.

## Oracle and observable contract

`GenericTokenizer` reproduces the current preimage's one-character algorithm,
using the real charset `ctype` mask and `ob_mbcharlen_ptr`. It preserves the
existing `mbminlen == 1 && unsigned_byte < 0x80 ? 1 : decoder(...)` shortcut.
It does not implement an ASCII-span scan or use the candidate to derive
expectations. It also reproduces public open/reset/reuse state transitions,
including their ordering and empty/NULL-open behavior.

Each get_next call compares return code, complete datum pack (length, NULL and
flag bits), length, exact token bytes, actual pointer identity, input offset
and token frequency. Every call starts with an output sentinel and negative
frequency; plain, outrow, NULL and LOB-header sentinels rotate. On every
non-success return, pointer, pack, bytes and frequency must remain unchanged.
Successful tokens must borrow the current fixture's input buffer and have
frequency one. Input datum pointer/pack and all physical buffer bytes are
checked unchanged. No output comparison uses ASLR addresses or normalizes an
unknown pointer into a valid region.

The preimage's empty/NULL open succeeds without setting `is_inited_`, so its
subsequent get_next returns NOT_INIT. Its inner_open also leaves an earlier
true iter_end flag unchanged. The lifecycle oracle preserves both behaviors;
it does not replace them with a preferred API interpretation. Reopening an
initialized tokenizer returns INIT_TWICE before other validation.

Every CASE record identifies case number, charset, exact fixture bytes in
hex, declared datum length, physical payload length, readable buffer extent,
32-byte padding, datum pack, input mode, NULL-charset flag and lifecycle flag.
An availability CASE records requested collation ID, actual availability,
minimum/maximum character length and table presence.

Each operation emits deterministic T records with case/call number, operation,
production/generic model, actual return, pack, length, pointer region and
offset, frequency and all output bytes. Pointer regions are `doc`, `sentinel`
or `null`; raw pointers are compared in-process but never printed. Open T
records contain the actual open return with an unchanged sentinel datum and
frequency as metadata; open does not accept those output arguments. The
availability T records are lookup metadata, not tokenizer calls. Tuple count
depends on actual oracle tokenization; the case count is fixed. No timestamps,
timings, random data or variant labels enter the transcript. Production info
logging is suppressed in this native process.

## Fixed schedule and available encodings

| Group | Cases |
| --- | ---: |
| Requested descriptor availability | 11 |
| Four retained descriptors × 256 byte values × start/end/middle | 3,072 |
| Four retained descriptors × ASCII run lengths 0 through 256 | 1,028 |
| Four descriptors × 14 boundary lengths × all-token/all-delimiter | 112 |
| Four descriptors × 32 edges × alone/after-token/after-delimiters | 384 |
| Four descriptors × 8 mixed/lifecycle documents | 32 |
| Four descriptors × empty/NULL/outrow/NULL-charset API cases | 16 |
| Public UTF8MB4_BIN descriptor copy with ctype=null: 8 mixed + 32 edges + 4 API | 44 |
| Total | **4,699** |

Availability expectations are derived from this checkout's actual
`ObCharset::get_charset_uninit` switch in
`src/oblib/lib/charset/ob_charset.cpp`: it retains exactly UTF8MB4 general
(45), bin (46), unicode (224), and binary (63). Every slot is actually looked
up and its result is checked against that expectation. UTF8MB3 general (33),
latin1 bin (47), GBK Chinese (28), GB18030 Chinese (248), UTF16LE general (56),
UTF16 BE/general (54) and UTF32 general (60) have no backing descriptor in
this checkout and are recorded unavailable. The UTF8MB3 numeric slot tests a
distinct descriptor, rather than relabeling a UTF8 name alias to UTF8MB4.
If availability changes, the test fails and requires a deliberate new finite
corpus/hash. There are no silent skips or fabricated encoding implementations.

The null-ctype control is explicitly a test-owned public descriptor copy with
the retained UTF8MB4 decoder, unchanged encoding metadata and only ctype set
to null. It exercises the candidate's null-table fallback without pretending
to cover any unavailable encoding. No replacement character-length handler
or synthetic multibyte-minimum descriptor is supplied.

All 256 bytes occur separately at the beginning, end and middle, including
NUL, DEL, every ASCII control/punctuation byte and every high byte. ASCII
length matrices include leading/trailing delimiter runs, token runs, empty
runs and single-class documents. Mixed fixtures contain ascending/descending
byte sequences, alternating classes, embedded NUL, UTF8 BMP/non-BMP and long
ASCII spans on either side. Edge fixtures include canonical two/three/four
byte UTF8 boundaries; isolated/invalid leads and continuations; truncated
sequences; overlong forms; surrogate UTF8; above-U+10FFFF and five-byte forms;
GBK/GB18030-shaped bytes; UTF16LE/UTF32-shaped raw bytes. The latter are only
raw-byte inputs to available descriptors, not claims of encoding coverage.

Every case tests unopened get_next, open, draining and two repeated get_next
calls after stop. Selected length cases, all mixed cases and all API cases
also test repeated open, reset/uninitialized state, reopen/drain, reuse,
another input without reset, and reset/reopen on that other input. Documents
and descriptor storage remain alive through all consuming calls.

## Exact bounds and limits

Physical fixtures own 32 prefix guard bytes, the exact hex-recorded payload,
and 32 readable suffix bytes. Suffix byte i is `0x90 + i % 31`; the complete
buffer is immutable and checked after calls. The declared document length is
the datum's actual len, which is zero for NULL. The physical payload may be
nonempty for NULL/outrow API-failure fixtures, but those modes are never
treated as valid inline text. No nonempty NULL pointer or expired document is
passed to an initialized tokenizer.

The real `ob_mbcharlen_ptr` reports a lead-byte character length and is not a
full remaining-buffer validator. On truncated UTF8 the original can return a
successful token extending past the declared document end. The labeled
readable suffix makes this existing behavior safe to observe, and all emitted
bytes, length and offset are compared exactly. Output outside the entire
labeled readable region fails before the test reads it. The oracle classifier
asserts that every byte it classifies is within the declared input; each drain
has a finite payload-plus-padding call bound. This test neither repairs nor
hides the original decoder behavior.

Guards and output checks do not prove absence of out-of-bounds reads. There
are no guard pages, sanitizer runs, concurrent mutation, input/output datum
aliasing, unavailable encoding execution, benchmarks or performance claims.
No supported descriptor here has mbminlen greater than one, so that fallback
requires separate evidence if such encodings are restored. A candidate that
leaves the original implementation unchanged can pass: these are correctness
tests, not proof that the ASCII-span path executed or improved performance.
