"""Read-only exact raw/gzip/source verification for rejected round27 evidence."""
import argparse
import gzip
import hashlib
import json
from pathlib import Path


def require(ok, reason):
    if not ok:
        raise RuntimeError(reason)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def relative(value):
    path = Path(value)
    require(not path.is_absolute() and '..' not in path.parts and ':' not in value
            and chr(92) not in value, 'Unsafe relative path')
    return path


def verify(directory, source_root=None):
    directory = Path(directory).resolve()
    manifest_raw = (directory / 'manifest.json').read_bytes()
    manifest = json.loads(manifest_raw)
    complete = json.loads((directory / 'COMPLETE.json').read_bytes())
    require(complete['status'] == 'COMPLETE' and
            complete['manifest_sha256'] == digest(manifest_raw), 'Manifest/completion mismatch')
    require(manifest['experiment'] == 'round27-root-rejected' and manifest['decision'] == 'REJECTED_RESTORED_EXACT' and
            manifest['completed_pairs'] == 2, 'Wrong experiment/pair count')
    expected, sources = {'manifest.json', 'COMPLETE.json'}, set()
    raw_total = packed_total = 0
    for item in manifest['files']:
        relative(item['source'])
        require(item['path'] == 'files/' + item['source'] + '.gz', 'Unexpected gzip mapping')
        require(item['source'] not in sources and item['path'] not in expected, 'Duplicate entry')
        require(relative(item['source']).suffix.lower() not in
                ['.exe', '.pdb', '.dll', '.obj', '.lib', '.res', '.tmp'], 'Excluded binary product')
        packed = (directory / relative(item['path'])).read_bytes()
        require(len(packed) == item['packed_bytes'] and
                digest(packed) == item['packed_sha256'], 'Packed identity mismatch: ' + item['source'])
        raw = gzip.decompress(packed)
        require(len(raw) == item['raw_bytes'] and
                digest(raw) == item['raw_sha256'], 'Raw identity mismatch: ' + item['source'])
        if source_root is not None:
            require(raw == (Path(source_root) / item['source']).read_bytes(),
                    'Original source differs: ' + item['source'])
        expected.add(item['path'])
        sources.add(item['source'])
        raw_total += len(raw)
        packed_total += len(packed)
    require(len(sources) == complete['file_count'], 'File count mismatch')
    require({p.relative_to(directory).as_posix() for p in directory.rglob('*') if p.is_file()}
            == expected, 'Missing/unlisted archive file')
    return dict(status='PASS', file_count=len(sources), manifest_sha256=digest(manifest_raw),
                raw_bytes=raw_total, packed_bytes=packed_total, raw_packed_hashes='ALL MATCH',
                source_bytes='ALL MATCH' if source_root is not None else 'NOT REQUESTED',
                execution='Offline bytes only; no Git/build/native/SQL/benchmark/profile')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--package-dir', required=True, type=Path)
    parser.add_argument('--source-root', type=Path)
    parser.add_argument('--report', type=Path)
    args = parser.parse_args()
    result = verify(args.package_dir, args.source_root)
    if args.report:
        with args.report.open('xb') as stream:
            stream.write((json.dumps(result, indent=2) + '\n').encode('utf-8'))
    print(json.dumps(result, ensure_ascii=True))


if __name__ == '__main__':
    main()
