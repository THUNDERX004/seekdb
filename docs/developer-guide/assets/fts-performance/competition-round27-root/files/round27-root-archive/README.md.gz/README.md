# Round27 root-prefix proposal — REJECTED, restored

Offline exact-byte archive only. The parent rejected this two-file experiment and restored both original files; the frozen restoration JSON and rebuild log must exist and the live CPP/header must match those original hashes before packaging/publication. No compiler/linker, native executable, server, SQL, benchmark, profiler or Git is invoked by these archive scripts. Current mutable D: binaries/libraries are never read or packaged. Round28 and other experiment evidence are excluded.

Selection is explicit: four complete timing runs; the failed initial candidate sequence; full control and candidate regression repeats; both immutable comparisons and summarizer; root proposal/original/candidate/reviews; diagnostic source, bounded 69KB captured log and exact outputs; source/restoration build logs; frozen 16416-case native TUs, helpers, all receipts/compile/link response files and flags, full stdout/stderr/records; exit-harness provenance. Only necessary shared infrastructure is snapshotted under this new helper's dependencies directory; no raw evidence from other rounds is added.

Historical pending preparation/review text remains unchanged. Later parent execution is described separately. Legacy tuple_lines counts CASE/T/PASS records, not T alone: 114913 records include 98496 T rows and 16416 CASE rows. Complete raw stdout and stderr are compared independently of normalized records.

The first ranked connection reset remains unexplained. The later control and candidate full 14-action sequences passed; candidate exit_before_cleanup=null records a still-live process at that observation. Neither later PASS nor cleanup exit establishes the earlier failure's cause, repair or reproduction.

Native preparation provenance distinguishes generated-text hashes from actual file hashes. Final build/run receipts pin the actual executed helper and identical TU. The initial builder generator receipt does not equal the final raw or normalized builder; both are preserved without inventing a complete historical mutation chain. Original preparation files are never rewritten to resolve that difference. See provenance-audit.json for exact pins and bounds.

From the workspace root, prepare once, inspect the plan, then publish authorized paths:

    .venv/Scripts/python.exe -B setup/fts/round27-root-archive/package.py
    .venv/Scripts/python.exe -B setup/fts/round27-root-archive/publish_docs.py
    .venv/Scripts/python.exe -B setup/fts/round27-root-archive/publish_docs.py --execute

Read-only verification:

    .venv/Scripts/python.exe -B setup/fts/round27-root-archive/verify_package.py --package-dir D:/Projects/OceanBase/seekdb/docs/developer-guide/assets/fts-performance/competition-round27-root --source-root C:/Users/11946/Documents/ChatGPT/OceanBase比赛/setup/fts

Only the new D: competition-round27-root asset directory and new top sections in the two existing FTS reports are published. Existing report bytes remain intact; no full history backups are packed. Gzip preserves exact raw bytes with raw/packed SHA256 and sizes. Mutable status/publication/verification receipts stay outside the immutable package. This rejected native TU is archived only, never promoted into an established unit suite. Parent owns review/commit/push.
