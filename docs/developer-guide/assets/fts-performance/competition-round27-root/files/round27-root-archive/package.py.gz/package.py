"""Archive explicit frozen round27 evidence. No workloads, imports of evidence or Git."""
import ast
from datetime import datetime, timezone
from decimal import Decimal
import gzip
import io
import json
from pathlib import Path

from verify_package import digest, require, verify
from publish_docs import ASSET_REL, DOCS, REPO, insert, unchanged

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
CPP = 'src/storage/fts/dict/ob_ft_dat_dict.cpp'
HEADER = 'src/storage/fts/dict/ob_ft_dat_dict.h'
PINS = {
    'control': 'c7fcc8676875246a38bc4135f29e6f52b85a9d29a9563679003d5b6140666b01',
    'candidate': '1da2c6e4522616454e3f60a6f4c1649c53365a5b059095b8f87030ac529bc22a',
}
SOURCES = {'control': 'f56ddd03e66826919d8d9192bc4c0afece8843dd',
           'candidate': '94e1a77354b51761d3baf7a73c98b794d313d36e+round27-root'}
SOURCE_PINS = {
    CPP: {'original_sha256': '131d28841ac827601aefc5dbf786589b72d15a5444f9269abbc8aa1ca95dd11f',
          'candidate_sha256': 'b10c4938d38eae3cdbc1a9556ccdc3b1e9b1470a99d4db8762da573d1481ee31'},
    HEADER: {'original_sha256': '6ac81ac0b70d718780fd16c78a0a357f49978aed24553a82fc0081e20d3f303a',
             'candidate_sha256': '5bb77e3cccc908ec7fbeabc6833327d3ba09c4312f72eb87d1f1f9924e15580b'},
}
TEST = '5316b2ae7b480fe6d73144237c1e0f73c7612d86f4328fcbd8d9cce937053009'
BUILDER = '25f2533c60a3245b0f3870878bf9fafbda5cdf13d3b6812de84d482967c2db6f'
RUNNER = '7584265b751ff5a55f0a869614494b58b5dedda348808154fe996d42acea62bf'
SHARED = '30779fbf52372a91bbc37e823b7fde4579eae04850dc784064170758667410f9'
UTILITY = '0aca605abda2fea4ab7b32335c5fe04302895748e8f63a6ce46887b04b822035'
STDOUT = 'ca736bb5badb8c6a32143a5dd988121abd1f8ad3ef51d28898657e55ce41fedd'
RECORDS = '2f261d6564ff94ab904632bf6de2e5ae071ecab7ada4fc3eef008f4f57acd499'
NATIVE = 'round27-dat-root-build/'
PROP = 'round27-dat-root-proposal/'
DIAG = 'round27-dat-root-diagnostic/'
EVIDENCE = 'round27-root-evidence/'
PARAMS = dict(rows=20000, batch=500, rounds=3000, query_rounds=200, samples=3, warmup=30, skip_load=0)
HITS = dict(query_cn_hits=8001, query_beng_hits=11000, query_mixed_hits=7332, query_limit_hits=20)
BUILD_FILES = ['receipt.json', 'compile.log', 'compile.rsp', 'link-inputs.rsp', 'link.log',
               'link-intermediate/embed.manifest', 'link-intermediate/intermediate.manifest',
               'link-intermediate/manifest.rc']
RUN_FILES = ['build-receipt.json', 'run.json', 'stdout.log', 'stderr.log', 'tuples.log']
OLD_SUITES = ['test_' + x + '.py' for x in ['hot_path', 'tokenize_config', 'collation', 'match_batches',
                                          'map_concurrency', 'stopword_concurrency', 'dictionary_prefixes']]
ACTIONS = ['sort-metadata', 'count-union-accounting', 'query-materialization', 'casecopy', 'bmp',
           'ranked', 'keytypes'] + OLD_SUITES


def load(path):
    return json.loads(path.read_bytes())


def raw(source):
    return (ROOT / source).read_bytes()


def identity(data):
    return dict(bytes=len(data), sha256=digest(data))


def write_new(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(data)


def write_json(name, value):
    write_new(HERE / name, (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n').encode('utf-8'))


def receipt(label, variant):
    result = load(ROOT / (label + '-experiment.json'))
    require(result['label'] == label and result['binary_sha256'] == PINS[variant]
            and result['source_commit'] == SOURCES[variant], 'Execution receipt identity differs: ' + label)
    require(result['log_level'] == 'WARN' and type(result['affinity_mask']) is int
            and type(result['affinity_mask_verified']) is int
            and result['affinity_mask'] == result['affinity_mask_verified'] == 15, 'Environment differs')
    return result


def native_check():
    require(raw(NATIVE + 'test_dat_root.cpp') == raw('round27-dat-root-native/test_dat_root.cpp')
            and digest(raw(NATIVE + 'test_dat_root.cpp')) == TEST, 'Frozen native TUs differ')
    require(digest(raw(NATIVE + 'build_native.py')) == BUILDER and
            digest(raw(NATIVE + 'run_native.py')) == RUNNER, 'Executed native helper differs')
    variants, outputs = {}, {}
    for variant in ['control', 'candidate']:
        build_prefix, run_prefix = NATIVE + variant + '-build1/', NATIVE + variant + '-run1/'
        build_bytes = raw(build_prefix + 'receipt.json')
        build, run = json.loads(build_bytes), load(ROOT / (run_prefix + 'run.json'))
        require(raw(run_prefix + 'build-receipt.json') == build_bytes, 'Copied build receipt differs')
        require(build['build_succeeded'] and build['compile']['exit_code'] == build['link']['exit_code'] == 0,
                'Native compile/link not passing')
        require(build['production_sha256_before'] == build['production_sha256_after'], 'Recorded native inputs mutated')
        require(not build['production_source_compiled'], 'Unexpected standalone production compilation')
        source_key = 'original_sha256' if variant == 'control' else 'candidate_sha256'
        require(build['expected_source_sha256'] == SOURCE_PINS[CPP][source_key]
                and build['expected_header_sha256'] == SOURCE_PINS[HEADER][source_key], 'Native production identity differs')
        require(build['test_sha256'] == run['test_sha256'] == TEST and
                build['builder_sha256'] == BUILDER and build['helper_sha256'] == SHARED and
                run['run_helper_sha256'] == RUNNER, 'Native helper/test pins differ')
        require(build['expected_cases'] == run['expected_cases'] == 16416 and
                build['executable_sha256'] == run['executable_sha256'], 'Run/build identity differs')
        require(run['native'] == run['output_validation'] == 'PASS' and run['exit_code'] == 0, 'Native did not pass')
        for step in ['compile', 'link']:
            require(digest(raw(build_prefix + step + '.log')) == build[step]['log_sha256'], 'Build log differs')
        files = {name: raw(run_prefix + name) for name in ['stdout.log', 'stderr.log', 'tuples.log']}
        require(all(digest(files[name]) == value for name, value in run['logs_sha256'].items())
                and digest(files['tuples.log']) == run['tuples_sha256'] == RECORDS, 'Native output pin differs')
        lines = [line for line in files['stdout.log'].splitlines()
                 if line.startswith((b'CASE\t', b'T\t', b'B\t', b'PASS\t'))]
        require(b'\n'.join(lines) + b'\n' == files['tuples.log'], 'Complete record extraction differs')
        counts = {prefix: sum(line.startswith(prefix.encode() + b'\t') for line in lines)
                  for prefix in ['CASE', 'T', 'B', 'PASS']}
        require(counts == dict(CASE=16416, T=98496, B=0, PASS=1)
                and len(lines) == run['tuple_lines'] == 114913, 'Native matrix counts differ')
        require([x for x in lines if x.startswith(b'PASS\t')] == [b'PASS\tcases=16416'], 'Incomplete native trailer')
        outputs[variant] = files
        variants[variant] = dict(source_sha256=build['expected_source_sha256'],
            header_sha256=build['expected_header_sha256'], executable_sha256=run['executable_sha256'],
            test_sha256=TEST, cases=16416, tuples=98496, records=114913,
            library_input_count=len(build['production_sha256_before']), recorded_inputs_unchanged=True)
    require(outputs['control'] == outputs['candidate'] and not outputs['control']['stderr.log'],
            'Complete native stdout/stderr/records differ')
    require(digest(outputs['control']['stdout.log']) == STDOUT, 'Expected full stdout pin differs')
    parent = load(ROOT / (NATIVE + 'parent-output-verification.json'))
    require(parent['status'] == 'PASS' and parent['full_stdout_equal'] and parent['full_stderr_empty'], 'Parent verification differs')
    for variant, pins in parent['variants'].items():
        require(pins['stdout_sha256'] == STDOUT and pins['cases'] == 16416 and
                pins['tuples'] == 98496 and pins['records'] == 114913 and
                pins['expected_source_sha256'] == variants[variant]['source_sha256'] and
                pins['expected_header_sha256'] == variants[variant]['header_sha256'], 'Parent output evidence differs')
    return dict(status='PASS (parent actual runs; independent offline full-byte recheck)',
        native_execution_by_archiver='NOT RUN', variants=variants,
        outputs={name: dict(identity(data), complete_bytes_equal=True)
                 for name, data in outputs['control'].items()},
        counts=dict(cases=16416, T_rows=98496, deterministic_CASE_T_PASS_records=114913),
        limits=['Finite synthetic fixtures, not shortcut execution or performance proof',
                'No concurrent reload, malformed-layout general safety, sanitizer or Linux CI proof',
                'Actual recorded build/library pins only; current mutable binaries/libraries never read'])


def comparison_check(number):
    source = EVIDENCE + f'root-comparison-{number}pair.json'
    data = load(ROOT / source)
    require(data['status'] == 'COMPLETE' and data['completed_pairs'] == len(data['pairs']) == number,
            'Incomplete strict comparison')
    require(data['binary_pins'] == PINS and data['source_labels'] == SOURCES
            and data['parameters'] == PARAMS and data['hits'] == HITS
            and data['helper_sha256'] == UTILITY, 'Comparison fixed identity differs')
    labels = {prefix + str(n) for prefix in ['r27-root-control-a', 'r27-root-candidate-bench-a']
              for n in range(1, number + 1)}
    require(set(data['records']) == labels, 'Wrong timing labels')
    require(set(data['input_hashes']) == {label + '-' + suffix for label in labels
            for suffix in ['report.txt', 'experiment.json']}, 'Incomplete comparison input hashes')
    for path, pin in data['input_hashes'].items():
        require(identity(raw(path)) == pin, 'Immutable comparison input changed: ' + path)
    for label, record in data['records'].items():
        variant = 'control' if '-control-' in label else 'candidate'
        meta = receipt(label, variant)
        require(record['receipt'] == meta and [x['action'] for x in meta['actions']] == ['benchmark', 'input-validation']
                and all(x['exit_code'] == 0 for x in meta['actions']), 'Timing actions differ')
        fields = {}
        for line in raw(label + '-report.txt').decode('utf-8-sig').splitlines():
            if ':' in line:
                key, value = line.split(':', 1)
                require(key.strip() not in fields, 'Duplicate report field')
                fields[key.strip()] = value.strip()
        require(set(fields) == set(record['values']) | set(record['text_fields']), 'Report fields differ')
        require(all(Decimal(fields[k]) == Decimal(str(v)) for k, v in record['values'].items())
                and all(fields[k] == v for k, v in record['text_fields'].items()), 'Raw report values differ')
        require(all(record['values'][k] == v for k, v in PARAMS.items())
                and all(record['values'][k] == v for k, v in HITS.items()), 'Timing input/hit mismatch')
    return data, dict(source=source, **identity(raw(source)),
                      input_hashes_verified=len(data['input_hashes']), raw_report_fields='ALL MATCH',
                      performance_recalculation='NOT RUN')


def diagnostic_check():
    prefix = DIAG + 'r27-root-frequency-a1/'
    source, meta, frequency = [load(ROOT / (DIAG + path)) for path in
        ['source.json', 'r27-root-frequency-a1/receipt.json', 'r27-root-frequency-a1/frequency.json']]
    require(meta['status'] == frequency['status'] == 'COMPLETE' and meta['scoring'] is False
            and frequency['scoring'] is False, 'Diagnostic incomplete or not separate')
    require(digest(raw(DIAG + 'original.cpp')) == source['original_sha256'] == SOURCE_PINS[CPP]['original_sha256']
            and digest(raw(DIAG + 'instrumented.cpp')) == source['instrumented_sha256'] == meta['instrumented_source_sha256'],
            'Diagnostic source mismatch')
    require(digest(raw(DIAG + 'run.py')) == meta['helper_sha256'], 'Diagnostic run helper differs')
    require(digest(raw(prefix + 'runtime.log')) == frequency['runtime_log_sha256']
            and digest(raw(prefix + 'server.log')) == meta['server_log_sha256'], 'Diagnostic logs differ')
    require(len(raw(prefix + 'runtime.log')) < 1024 * 1024, 'Diagnostic log unexpectedly large')
    for item in meta['workloads']:
        parser = item['parser']
        for suffix, key in [('input.sql', 'input_sha256'), ('stdout.log', 'stdout_sha256'), ('stderr.log', 'stderr_sha256')]:
            require(digest(raw(prefix + parser + '.' + suffix)) == item[key], 'Diagnostic stream differs')
        lines = raw(prefix + parser + '.stdout.log').splitlines()
        require(item['results'] == len(lines) == 2000 and item['child_exit_code'] == 0
                and all(line == lines[0] for line in lines) and digest(lines[0]) == item['reference_sha256']
                and item['exact_reference_match'], 'Diagnostic output/reference pin differs')
    require(load(ROOT / (DIAG + 'restoration.json'))['sha256'] == SOURCE_PINS[CPP]['original_sha256'],
            'Diagnostic restoration pin differs')
    return dict(status='PASS offline recorded-stream hash recheck',
        diagnostic_scoring=False, source=DIAG + 'r27-root-frequency-a1/frequency.json',
        bounded_runtime_log=identity(raw(prefix + 'runtime.log')),
        snapshots=frequency['snapshots'], thread_reader_generations=frequency['thread_reader_generations'],
        limits='Recorded incomplete last-prefix snapshots; omitted tails; no CPU-share or performance inference',
        reference_provenance='Output lines match recorded reference SHA only; other-round references not copied or rerun')


def main():
    require(not (HERE / 'archive').exists() and not (HERE / 'status.json').exists(), 'Never overwrite a prepared/frozen package')
    restore_path = ROOT / (PROP + 'rejection-restoration.json')
    require(restore_path.is_file() and (ROOT / 'round27-root-rejection-restoration-build.log').is_file(),
            'PENDING restoration receipt/build log; do not freeze')
    restoration = load(restore_path)
    require(restoration['status'] == 'REJECTED_RESTORED_EXACT' and restoration['files'] == SOURCE_PINS,
            'Restoration not complete')
    for path, pins in SOURCE_PINS.items():
        require(digest((REPO / path).read_bytes()) == pins['original_sha256']
                and (REPO / path).read_bytes() == raw(PROP + 'original/' + path), 'Live source not restored exactly')
        for variant in ['original', 'candidate']:
            require(digest(raw(PROP + variant + '/' + path)) == pins[variant + '_sha256'], 'Proposal source pin differs')
    require(load(ROOT / (PROP + 'source.json'))['files'] == SOURCE_PINS
            and load(ROOT / (PROP + 'application.json'))['files'] == SOURCE_PINS, 'Historical source/application pins differ')
    require(digest(raw(PROP + 'source.patch')) == '001a7f959ee2747df19c889a3391c5fd6f2af5aff820e80ca782e98a230e88db', 'Exact patch differs')
    require(load(ROOT / (PROP + 'binary.json'))['files']['seekdb.exe']['sha256'] == PINS['candidate'], 'Frozen binary receipt differs')
    prior = load(ROOT / 'round25-cumulative-archive/status.json')
    readonly = {path: pin['original_sha256'] for path, pin in SOURCE_PINS.items()}
    readonly.update(prior['read_only_identity_pins'])
    readonly['docs/developer-guide/assets/fts-performance/competition-round25-cumulative/manifest.json'] = prior['manifest_sha256']
    state = dict(status='PREPARING_REJECTED_ROOT_ARCHIVE', created_utc=datetime.now(timezone.utc).isoformat(),
        protected_preimages=prior['protected_preimages'], protected_reference_paths_absent=prior['protected_reference_paths_absent'],
        read_only_identity_pins=readonly, documents_preimages={rel: identity((REPO / rel).read_bytes()) for rel in DOCS},
        decision='REJECTED_RESTORED_EXACT', no_production_or_test_promotion=True,
        scope='New round27-root assets and two top report sections; archive-only native TU',
        execution='Offline bytes only; no Git/build/native/runtime/SQL/benchmark/profile')
    unchanged(state)
    inputs = []
    # Explicit immutable experiment inputs, never recursively selecting future rounds.
    for prefix in ['r27-root-control-a', 'r27-root-candidate-bench-a']:
        for number in [1, 2]:
            inputs += [prefix + str(number) + '-' + suffix for suffix in
                       ['report.txt', 'experiment.json', 'benchmark.log', 'input-validation.log', 'server.log']]
    first_suffixes = ['bmp.log', 'casecopy.log', 'count-union-accounting.log', 'experiment.json',
                      'query-materialization.log', 'ranked.log', 'server.log', 'sort-metadata.log', 'sort-plans.json']
    inputs += ['r27-root-candidate-a1-' + suffix for suffix in first_suffixes]
    repeat_suffixes = first_suffixes + ['keytypes.log'] + [name + '.log' for name in OLD_SUITES]
    for label in ['r27-root-control-regression-a1', 'r27-root-candidate-regression-a2']:
        inputs += [label + '-' + suffix for suffix in repeat_suffixes]
    require({p.name for p in ROOT.glob('r27-root-*') if p.is_file()} == set(inputs), 'Unexpected/missing round27 run file; inspect')
    failed = receipt('r27-root-candidate-a1', 'candidate')
    require([x['action'] for x in failed['actions']] == ACTIONS[:6]
            and [x['exit_code'] for x in failed['actions']] == [0, 0, 0, 0, 0, 1], 'Initial failure sequence differs')
    require(b'ConnectionResetError' in raw('r27-root-candidate-a1-ranked.log'), 'Failure traceback missing')
    regression = {}
    for label, variant in [('r27-root-control-regression-a1', 'control'), ('r27-root-candidate-regression-a2', 'candidate')]:
        meta = receipt(label, variant)
        require([x['action'] for x in meta['actions']] == ACTIONS and all(x['exit_code'] == 0 for x in meta['actions']),
                'Full repeat not passing')
        regression[label] = dict(actions=14, status='PASS', owned_server_metadata={k:v for k,v in meta.items() if k.startswith('owned_server_')})
    retry = load(ROOT / 'r27-root-candidate-regression-a2-experiment.json')
    require('owned_server_exit_before_cleanup' in retry and retry['owned_server_exit_before_cleanup'] is None,
            'Candidate repeat live-at-observation evidence missing')
    inputs += [PROP + name for name in ['application.json', 'apply.py', 'binary.json', 'pin_binary.py', 'prepare.py',
               'README.md', 'rejection-restoration.json', 'restore.py', 'source.json', 'source.patch']]
    inputs += [PROP + variant + '/' + path for variant in ['original', 'candidate'] for path in [CPP, HEADER]]
    inputs += ['round27-dat-root-review/report.md']
    inputs += ['round27-dat-root-native/' + name for name in
               ['README.md', 'report.md', 'review-gaps.md', 'SHA256SUMS', 'source-pins.json', 'test_dat_root.cpp']]
    inputs += [NATIVE + name for name in ['build.ps1', 'build_native.py', 'parent-output-verification.json',
               'prepare_builder.py', 'prepare_runner.py', 'provenance.json', 'runner-provenance.json', 'run_native.py',
               'stage_test.py', 'test-provenance.json', 'test_dat_root.cpp', 'verify_outputs.py']]
    for variant in ['control', 'candidate']:
        inputs += [NATIVE + variant + '-build1/' + name for name in BUILD_FILES]
        inputs += [NATIVE + variant + '-run1/' + name for name in RUN_FILES]
    inputs += [DIAG + name for name in ['collect.py', 'instrumented.cpp', 'original.cpp', 'prepare.py',
               'restoration.json', 'restore.py', 'run.py', 'source.json', 'source.patch']]
    inputs += [DIAG + 'r27-root-frequency-a1/' + name for name in ['beng.input.sql', 'beng.stderr.log', 'beng.stdout.log',
               'ik.input.sql', 'ik.stderr.log', 'ik.stdout.log', 'frequency.json', 'receipt.json', 'runtime.log', 'server.log']]
    inputs += [EVIDENCE + name for name in ['experiment-with-exit.py', 'harness-provenance.json', 'prepare_harness.py',
               'root-comparison-1pair.json', 'root-comparison-2pair.json', 'summarize.py']]
    inputs += ['round27-dat-root-candidate-build.log', 'round27-dat-root-original-build.log',
               'round27-dat-root-diagnostic-build.log', 'round27-root-rejection-restoration-build.log']
    for path in inputs:
        require((ROOT / path).is_file(), 'Missing explicit artifact: ' + path)
        if path.endswith(('server.log', 'runtime.log')):
            require(len(raw(path)) < 1024 * 1024, 'Unexpected large log, inspect first')
    # Snapshot only exact infrastructure dependencies, not other-round experiment data.
    deps = [
        ('strict_pair_util.py', 'round19-evidence/summarize-template.py', UTILITY),
        ('native_link_util.py', 'round16-row-native/prepare_fts_lazy_rows.py', SHARED),
        ('native_builder_base.py', 'round19-stringdiff-native/build_native.py', 'fa34ed893fad0065e8ea0fe4ce6074e07a2940dd7e9f9da519dffb911bede59f'),
        ('native_runner_base.py', 'round19-stringdiff-native/run_native.py', '0d0331f57da3493376f3217b01618603963724b33b661666eafe149e99254cf3'),
        ('experiment_base.py', 'experiment-competition.py', 'a1202900451deb7b4d82a4d96d675269390dd64b993cd361eda51e0ee39e7a25'),
        ('mysql_client.py', 'mysql_client.py', '4a92f02c3e84be0dc3ca7caf1bfeef1bc7cd543c4c5de0794a687aa5dc091105'),
    ]
    dependencies = []
    for name, origin, pin in deps:
        data = raw(origin)
        require(digest(data) == pin, 'Infrastructure dependency changed: ' + origin)
        snapshot = HERE / 'dependencies' / name
        write_new(snapshot, data)
        source = snapshot.relative_to(ROOT).as_posix()
        inputs.append(source)
        dependencies.append(dict(snapshot=source, original_path=origin, **identity(data)))
    comparisons, comparison_receipts = [], []
    for number in [1, 2]:
        data, meta = comparison_check(number)
        comparisons.append(data)
        comparison_receipts.append(meta)
    final = comparisons[-1]
    require(comparisons[0]['pairs'] == final['pairs'][:1], 'First-pair historical snapshot differs')
    require(final['aggregate']['category_improvements'] == {'build': -0.010407909317108126,
            'tokenize': 0.0025440313111546446, 'query': 0.017866384007121157}
            and final['aggregate']['overall_improvement'] == 0.0033341686670558916, 'Parent final decision fields differ')
    native = native_check()
    diagnostic = diagnostic_check()
    # Preserve historical generator receipts; final build/run self-pins are independent.
    harness = load(ROOT / (EVIDENCE + 'harness-provenance.json'))
    harness_raw = raw(EVIDENCE + 'experiment-with-exit.py')
    require(harness['base_sha256'] == digest(raw('experiment-competition.py')) and
            harness['candidate_sha256'] == digest(harness_raw.replace(b'\r\n', b'\n')), 'Exit harness provenance differs')
    runner = load(ROOT / (NATIVE + 'runner-provenance.json'))
    require(runner['base_sha256'] == digest(raw('round19-stringdiff-native/run_native.py')) and
            runner['result_sha256'] == digest(raw(NATIVE + 'run_native.py').replace(b'\r\n', b'\n')), 'Runner text provenance differs')
    builder = load(ROOT / (NATIVE + 'provenance.json'))
    require(builder['base_sha256'] == digest(raw('round19-stringdiff-native/build_native.py')), 'Builder base changed')
    tree = ast.parse(raw(NATIVE + 'prepare_builder.py'))
    node = next(n for n in tree.body if isinstance(n, ast.Assign)
                and any(isinstance(t, ast.Name) and t.id == 'replacements' for t in n.targets))
    generated = raw('round19-stringdiff-native/build_native.py').decode('utf-8')
    for old, new in ast.literal_eval(node.value):
        require(old in generated, 'Frozen generator replacement no longer applicable')
        generated = generated.replace(old, new)
    require(generated.encode('utf-8') == raw(NATIVE + 'build_native.py').replace(b'\r\n', b'\n'),
            'Final builder differs from current frozen generator text')
    provenance = dict(dependencies=dependencies,
        final_executed=dict(builder_sha256=BUILDER, runner_sha256=RUNNER, test_sha256=TEST,
                            exit_harness_raw_sha256=digest(harness_raw)),
        historical_harness_generated_text_sha256=harness['candidate_sha256'],
        historical_runner_generated_text_sha256=runner['result_sha256'],
        text_newlines='Runner/harness generated-text hashes are LF; actual archived files and execution self-pins are raw CRLF',
        builder=dict(historical_initial_generator_result_sha256=builder['result_sha256'],
                     final_raw_sha256=BUILDER, final_LF_sha256=digest(generated.encode('utf-8')),
                     current_frozen_generator_reproduces_final_LF=True,
                     historical_initial_result_equals_final_LF=builder['result_sha256'] == digest(generated.encode('utf-8')),
                     limitation='Initial generator receipt is historical and differs from final helper even after newline normalization; no missing intermediate source or mutation chain invented'),
        execution_proof='Actual native build/run receipts pin final helper/test/source/library identities; no current build products read')
    write_json('status.json', state)
    write_json('source-identities.json', dict(decision='REJECTED_RESTORED_EXACT', source_pins=SOURCE_PINS,
        restored_live_sources='MATCH EXACT ORIGINALS', historical_source_labels=SOURCES, historical_binary_pins=PINS,
        historical_report_checkout_labels={label:r['text_fields']['git_head'] for label,r in final['records'].items()},
        production_build_restoration='Parent reports PASS; exact restoration JSON and full rebuild log archived',
        no_test_promotion=True, current_binaries_or_libraries_read=False,
        protected_preimages=state['protected_preimages'], protected_reference_paths_absent=state['protected_reference_paths_absent'],
        read_only_identity_pins=readonly))
    write_json('native-byte-comparison.json', native)
    write_json('provenance-audit.json', provenance)
    write_json('input-verification.json', dict(status='PASS', comparisons=comparison_receipts, diagnostic=diagnostic,
        failed_initial_sequence=dict(label='r27-root-candidate-a1', passed_actions=ACTIONS[:5], failed_action='ranked',
            failure_cause='UNDETERMINED; no repair/reproduction claim', benchmark='NOT REACHED'),
        full_regression_repeats=regression, summarizer_execution='NOT RUN'))
    write_json('disposition.json', dict(decision='REJECTED_RESTORED_EXACT', completed_pairs=2,
        parent_reason=restoration['reason'], recorded_aggregate=final['aggregate'],
        interpretation=final['interpretation'], method=final['method'],
        limits=['No convincing target benefit; untouched-query variation is not causal proof',
                'Initial ranked reset remains unexplained despite later full PASS',
                'No formal/cumulative/full-score/stability/statistical significance claim',
                'Diagnostic prefix counts do not measure CPU share or performance',
                'Finite native equality does not prove all production paths or candidate shortcut execution'],
        no_native_TU_promotion=True, execution_by_archiver='Offline bytes only'))
    rows = '\n'.join('| ' + x['metric'] + ' | ' + format(x['control'], '.6f') + ' | ' +
            format(x['candidate'], '.6f') + ' | ' + format(100*x['improvement'], '+.6f') + '% |'
            for x in final['aggregate']['metrics'])
    pair_rows = '\n'.join('| ' + str(p['pair']) + ' | ' + ' | '.join(
            format(100*p['category_improvements'][k], '+.6f') + '%' for k in ['build', 'tokenize', 'query']) +
            ' | ' + format(100*p['overall_improvement'], '+.6f') + '% |' for p in final['pairs'])
    doc_ops = []
    for lang in ['en', 'zh-CN']:
        text = (HERE / ('report-template.' + lang + '.md')).read_bytes().decode('utf-8')
        section = text.replace('§', chr(96)).replace('@@ROWS@@', rows).replace('@@PAIRS@@', pair_rows)
        section_raw = section.replace('\r\n', '\n').encode('utf-8')
        name = 'report.' + lang + '.md'
        write_new(HERE / name, section_raw)
        rel = 'docs/developer-guide/' + lang + '/fts-performance.md'
        before = (REPO / rel).read_bytes()
        require(identity(before) == state['documents_preimages'][rel], 'Report changed during preparation')
        doc_ops.append(dict(path=rel, section=name, preimage_sha256=digest(before),
            section_sha256=digest(section_raw), postimage_sha256=digest(insert(before, section_raw))))
    write_json('document-identities.json', doc_ops)
    own = ['package.py', 'verify_package.py', 'publish_docs.py', 'README.md', 'report-template.en.md',
           'report-template.zh-CN.md', 'report.en.md', 'report.zh-CN.md', 'source-identities.json',
           'native-byte-comparison.json', 'provenance-audit.json', 'input-verification.json',
           'disposition.json', 'document-identities.json', 'selection.json']
    inputs += ['round27-root-archive/' + name for name in own]
    require(len(inputs) == len(set(inputs)), 'Duplicate selected input')
    inputs.sort()
    write_json('selection.json', dict(method='Explicit immutable round27 allowlist; shared infrastructure snapshots only',
        files=inputs, exclusions=['Other experiment evidence, including Round28', 'Current D: binaries/libraries',
            'EXE/PDB/OBJ/LIB/DLL/RES/TMP', 'Runtime/data directories/secrets', 'Large unrelated server logs',
            'Full report history backups', 'Mutable status/publication/verification receipts']))
    archive = HERE / 'archive'
    archive.mkdir()
    entries = []
    for source in inputs:
        require(Path(source).suffix.lower() not in ['.exe', '.pdb', '.obj', '.lib', '.dll', '.res', '.tmp'], 'Binary excluded')
        data = raw(source)
        buffer = io.BytesIO()
        with gzip.GzipFile(fileobj=buffer, filename='', mode='wb', mtime=0, compresslevel=9) as stream:
            stream.write(data)
        packed = buffer.getvalue()
        target = 'files/' + source + '.gz'
        write_new(archive / target, packed)
        entries.append(dict(source=source, path=target, raw_bytes=len(data), raw_sha256=digest(data),
                            packed_bytes=len(packed), packed_sha256=digest(packed)))
    manifest = dict(schema_version=1, experiment='round27-root-rejected', decision='REJECTED_RESTORED_EXACT',
        created_utc=datetime.now(timezone.utc).isoformat(), completed_pairs=2, source_root=str(ROOT), checkout_root=str(REPO),
        historical_source_labels=SOURCES, historical_binary_pins=PINS,
        comparison=EVIDENCE + 'root-comparison-2pair.json (immutable verbatim)',
        native='Recorded production-linked 16416 cases each PASS; complete stdout/stderr/records equal',
        initial_ranked_failure='Preserved; cause undetermined; not a completed timing run',
        restoration='Exact original CPP/header verified; parent restoration build PASS; log archived',
        encoding='Exact-byte per-file gzip; raw/packed sizes and SHA256; empty filename; mtime=0; no newline conversion',
        execution_by_archiver='Offline bytes only; no Git/build/native/runtime/SQL/benchmark/profile',
        formal_cumulative_or_full_score_claim='NONE', files=entries)
    manifest_raw = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    write_new(archive / 'manifest.json', manifest_raw)
    write_new(archive / 'COMPLETE.json', (json.dumps(dict(status='COMPLETE', file_count=len(entries),
            manifest_sha256=digest(manifest_raw)), indent=2) + '\n').encode('utf-8'))
    write_json('publication-plan.json', dict(repository=str(REPO), asset_directory=ASSET_REL,
        manifest_sha256=digest(manifest_raw), documents=doc_ops))
    result = verify(archive, ROOT)
    unchanged(state)
    write_json('verification.json', result)
    print(json.dumps(result, ensure_ascii=True))


if __name__ == '__main__':
    main()
