"""Publish only rejected round27 root assets and two report insertions; no workloads."""
import argparse
import json
from pathlib import Path
from verify_package import digest, require, verify

HERE = Path(__file__).resolve().parent
REPO = Path('D:/Projects/OceanBase/seekdb')
ASSETS = REPO / 'docs/developer-guide/assets/fts-performance'
ASSET_REL = 'docs/developer-guide/assets/fts-performance/competition-round27-root'
ASSET = REPO / ASSET_REL
DOCS = ['docs/developer-guide/en/fts-performance.md', 'docs/developer-guide/zh-CN/fts-performance.md']


def insert(raw, section):
    end = raw.index(b'\n') + 1
    require(raw[end:end + 1] == b'\n', 'Unexpected title spacing')
    return raw[:end] + b'\n' + section + raw[end + 1:]


def unchanged(state):
    for rel, pin in state['protected_preimages'].items():
        raw = (REPO / rel).read_bytes()
        require(len(raw) == pin['bytes'] and digest(raw) == pin['sha256'], 'Protected file changed: ' + rel)
    for rel in state['protected_reference_paths_absent']:
        require(not (REPO / rel).exists(), 'Previously absent protected reference changed')
    for rel, pin in state['read_only_identity_pins'].items():
        require(digest((REPO / rel).read_bytes()) == pin, 'Read-only identity changed: ' + rel)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true')
    args = parser.parse_args()
    plan = json.loads((HERE / 'publication-plan.json').read_bytes())
    state = json.loads((HERE / 'status.json').read_bytes())
    require(plan['repository'] == str(REPO) and plan['asset_directory'] == ASSET_REL,
            'Publication scope differs')
    require([x['path'] for x in plan['documents']] == DOCS, 'Wrong document paths')
    require(not ASSET.exists(), 'Asset directory exists; never overwrite frozen archives')
    checked = verify(HERE / 'archive', HERE.parent)
    require(checked['manifest_sha256'] == plan['manifest_sha256'], 'Package changed')
    unchanged(state)
    after = {}
    for op in plan['documents']:
        require(op['section'] in ['report.en.md', 'report.zh-CN.md'], 'Wrong section path')
        raw, section = (REPO / op['path']).read_bytes(), (HERE / op['section']).read_bytes()
        require(digest(raw) == op['preimage_sha256'] and digest(section) == op['section_sha256'],
                'Document/section changed')
        require(b'competition-round27-root/manifest.json' not in raw, 'Already inserted')
        after[op['path']] = insert(raw, section)
        require(digest(after[op['path']]) == op['postimage_sha256'], 'Unexpected postimage')
    if not args.execute:
        print(json.dumps(dict(status='PLAN_ONLY', manifest_sha256=checked['manifest_sha256'],
                              file_count=checked['file_count'], documents=DOCS)))
        return
    ASSET.mkdir()
    for source in sorted((HERE / 'archive').rglob('*')):
        if source.is_file():
            target = ASSET / source.relative_to(HERE / 'archive')
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open('xb') as stream:
                stream.write(source.read_bytes())
    for op in plan['documents']:
        target = REPO / op['path']
        require(digest(target.read_bytes()) == op['preimage_sha256'], 'Concurrent report change')
        target.write_bytes(after[op['path']])
    unchanged(state)
    result = verify(ASSET, HERE.parent)
    for op in plan['documents']:
        raw = (REPO / op['path']).read_bytes()
        section = (HERE / op['section']).read_bytes()
        start = raw.index(b'\n') + 2
        require(raw[start:start + len(section)] == section, 'Inserted bytes differ')
        require(digest(raw) == op['postimage_sha256'] and
                digest(raw[:start] + raw[start + len(section):]) == op['preimage_sha256'],
                'Prior document bytes changed')
    result.update(status='PUBLISHED_AND_VERIFIED', documents=plan['documents'],
                  prior_report_bytes='PRESERVED', production_tests_build_edits_by_archiver='NONE',
                  official_files_and_pinned_prior_archive_identities='UNCHANGED',
                  Git_build_workloads='NOT RUN')
    with (HERE / 'publication.json').open('xb') as stream:
        stream.write((json.dumps(result, indent=2) + '\n').encode('utf-8'))
    print(json.dumps(result, ensure_ascii=True))


if __name__ == '__main__':
    main()
