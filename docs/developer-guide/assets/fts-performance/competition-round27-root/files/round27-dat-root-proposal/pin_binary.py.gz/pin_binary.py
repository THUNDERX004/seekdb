"""Pin completed production candidate EXE/PDB/DLL bytes into a fresh build directory."""
from pathlib import Path
import hashlib
import json
import shutil

HERE = Path(__file__).resolve().parent
ROOT = Path('D:/Projects/OceanBase/seekdb')
BUILD = ROOT / 'build_fts_competition/src/observer'
OUT = ROOT / 'build/fts-round27-root-candidate'
manifest = json.loads((HERE / 'source.json').read_text(encoding='utf-8'))
for rel, pins in manifest['files'].items():
    assert hashlib.sha256((ROOT / rel).read_bytes()).hexdigest() == pins['candidate_sha256']
assert not OUT.exists()
OUT.mkdir()
files = [BUILD/'seekdb.exe', BUILD/'seekdb.pdb', *sorted(BUILD.glob('*.dll'))]
identities = {}
for source in files:
    raw_sha = hashlib.sha256(source.read_bytes()).hexdigest()
    shutil.copy2(source, OUT / source.name)
    assert hashlib.sha256((OUT/source.name).read_bytes()).hexdigest() == raw_sha
    identities[source.name] = dict(bytes=source.stat().st_size, sha256=raw_sha)
with (HERE/'binary.json').open('x', encoding='utf-8') as f:
    json.dump(dict(output=str(OUT), source_files=manifest['files'], files=identities), f, indent=2)
print('PINNED', identities['seekdb.exe']['sha256'])
