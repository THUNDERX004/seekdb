"""Stage a bounded reader-only root transition proposal, without applying it."""
from pathlib import Path
import difflib
import hashlib
import json

HERE = Path(__file__).resolve().parent
ROOT = Path('D:/Projects/OceanBase/seekdb')
changes = {
    'src/storage/fts/dict/ob_ft_dat_dict.h': [
        ('ObFTDATReader(ObFTDAT *dat) : dat_(dat), utf8_bmp_codes_(nullptr) {}',
         'ObFTDATReader(ObFTDAT *dat) : dat_(dat), utf8_bmp_codes_(nullptr), root_code_limit_(0) {}'),
        ('  const ObFTWordCode *utf8_bmp_codes_;\n',
         '  const ObFTWordCode *utf8_bmp_codes_;\n  int32_t root_code_limit_;\n')],
    'src/storage/fts/dict/ob_ft_dat_dict.cpp': [
        ('  const int64_t bytes = (1 << 16) * sizeof(ObFTWordCode);\n',
         '  root_code_limit_ = 0;\n  const int64_t bytes = (1 << 16) * sizeof(ObFTWordCode);\n'),
        ('    utf8_bmp_codes_ = codes;\n',
         '''    utf8_bmp_codes_ = codes;
    const int32_t *base = reinterpret_cast<const int32_t *>(dat_->buff + dat_->base_offset_);
    const int32_t *check = reinterpret_cast<const int32_t *>(dat_->buff + dat_->check_offset_);
    if (dat_->array_size_ > 2 && base[1] == 1) {
      // Only this validated prefix has root transitions at code + 1.
      for (int64_t code = 1; code < INT32_MAX && code + 1 < dat_->array_size_
          && check[code + 1] == 1; ++code) {
        root_code_limit_ = static_cast<int32_t>(code);
      }
    }
'''),
        ('''    int32_t idx = abs(base[hit.base_idx_]) + code;

    if (check[idx] != hit.base_idx_) {''',
         '''    const bool root_match = index >= 0 && hit.base_idx_ == 1
        && code > 0 && code <= root_code_limit_;
    const int32_t idx = root_match ? code + 1 : abs(base[hit.base_idx_]) + code;

    if (!root_match && check[idx] != hit.base_idx_) {''')]
}
items, patch = {}, []
for rel, replacements in changes.items():
    raw = (ROOT / rel).read_bytes()
    source = raw.decode('utf-8').replace('\r\n', '\n')
    for old, new in replacements:
        assert source.count(old) == 1, (rel, old)
        source = source.replace(old, new, 1)
    updated = source.replace('\n', '\r\n').encode('utf-8') if b'\r\n' in raw else source.encode('utf-8')
    for directory, data in [('original', raw), ('candidate', updated)]:
        path = HERE / directory / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open('xb') as f:
            f.write(data)
    items[rel] = dict(original_sha256=hashlib.sha256(raw).hexdigest(),
                     candidate_sha256=hashlib.sha256(updated).hexdigest())
    patch += difflib.unified_diff(raw.decode('utf-8').splitlines(True), updated.decode('utf-8').splitlines(True),
                                 fromfile='a/' + rel, tofile='b/' + rel)
with (HERE / 'source.patch').open('x', encoding='utf-8', newline='') as f:
    f.write(''.join(patch))
with (HERE / 'source.json').open('x', encoding='utf-8') as f:
    json.dump(dict(status='PROPOSAL_ONLY', files=items, production_applied=False), f, indent=2)
print(json.dumps(items, indent=2))
