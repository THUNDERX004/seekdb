# Validated root transition prefix

Status: staged experiment; not accepted or claimed to improve performance.

The current reader loads the base of the current node, adds the mapped character
code and checks the parent array for every successful lookup. During optional
BMP-code initialization, this proposal validates the consecutive positive codes
whose root transitions are exactly code + 1 with parent 1. A reader-local
32-bit bound remembers only those proven successes. Matching a BMP code inside
that interval at normalized root state 1 can omit the root base and parent
loads. It still reads the destination base to preserve terminal/prefix behavior.

No code-table representation, dictionary data or allocation changes. The reader
adds a four-byte scalar (its ordinary x64 object may grow by eight bytes due to
alignment). Initialization scans at most the proven root prefix and stops at the
first hole or array boundary; a nonunit root base disables it. The wide loop
index stops below INT32_MAX, so an accepted code plus one fits the original
signed index. There is no additional 256KiB table or per-document cache.

The scalar starts at zero and is reset before each optional initialization.
Allocation failure leaves it disabled. Reader/dictionary publication and pinning
are unchanged; the cache relies on the existing immutable published DAT
generation, and does not support in-place concurrent dictionary mutation.

The original output clearing, code lookup/error handling, distinct-output
assignment, zero-to-one normalization and both success bodies retain their
order. In particular, assignment does not copy dict_, and distinct output may
retain an incoming match flag on a prefix-only transition. Aliasing behavior is
not simplified. Missing codes, mapped root misses, continuation states,
malformed/non-BMP bytes and readers without the optional table use the original
path.

Actual unscored diagnostic:
../round27-dat-root-diagnostic/r27-root-frequency-a1/frequency.json.
The last complete snapshots across 14 thread/reader generations contain 350,215
calls, including 144,481 eligible root successes (41.254943% of snapshot calls).
These are prefix snapshots: unsnapshotted tails are omitted. IK and BENG each
execute 2,000 exact official-literal statements; every native output matches its
frozen accepted-C7 reference. The diagnostic does not establish CPU share,
performance benefit, independent semantic correctness, or workload universality.
Temporary counters were restored byte-for-byte, then the original reader was
rebuilt. Diagnostic timings never enter scores.

Promotion requires actual-production-linked original/candidate native state
comparison, focused SQL regressions and unchanged full official-parameter
paired timings. All regressions and measurement are pending at staging time.
