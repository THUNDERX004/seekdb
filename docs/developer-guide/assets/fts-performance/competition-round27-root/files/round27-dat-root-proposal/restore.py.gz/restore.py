"""Reject the root-prefix proposal and restore both exact preimages."""
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent
ROOT = Path('D:/Projects/OceanBase/seekdb')
manifest = json.loads((HERE/'source.json').read_text(encoding='utf-8'))
for rel, pins in manifest['files'].items():
    assert hashlib.sha256((ROOT/rel).read_bytes()).hexdigest() == pins['candidate_sha256']
    assert hashlib.sha256((HERE/'original'/rel).read_bytes()).hexdigest() == pins['original_sha256']
for rel, pins in manifest['files'].items():
    (ROOT/rel).write_bytes((HERE/'original'/rel).read_bytes())
with (HERE/'rejection-restoration.json').open('x', encoding='utf-8') as f:
    json.dump(dict(status='REJECTED_RESTORED_EXACT', files=manifest['files'],
        reason='Two-pair mean IK tokenize reduction only 0.5088%, build -1.0408%, total +0.3334% dominated unrelated query variation; no convincing target benefit. Initial ranked connection-reset also remains unexplained, despite full control/candidate repeat PASS. No promotion.'), f, indent=2)
print('REJECTED_RESTORED_EXACT two files')
