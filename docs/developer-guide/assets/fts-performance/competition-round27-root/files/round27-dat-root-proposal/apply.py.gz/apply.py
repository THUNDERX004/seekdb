"""Apply only the staged preimage-pinned two-file proposal after control tests."""
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent
ROOT = Path('D:/Projects/OceanBase/seekdb')
manifest = json.loads((HERE / 'source.json').read_text(encoding='utf-8'))
for rel, pins in manifest['files'].items():
    assert hashlib.sha256((ROOT / rel).read_bytes()).hexdigest() == pins['original_sha256'], rel
    assert hashlib.sha256((HERE / 'candidate' / rel).read_bytes()).hexdigest() == pins['candidate_sha256'], rel
for rel, pins in manifest['files'].items():
    (ROOT / rel).write_bytes((HERE / 'candidate' / rel).read_bytes())
with (HERE / 'application.json').open('x', encoding='utf-8') as f:
    json.dump(dict(status='APPLIED', files=manifest['files']), f, indent=2)
print('APPLIED two guarded reader source files')
