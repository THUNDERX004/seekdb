"""Adapt the pinned native runner without changing its validation contract."""
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent
BASE = HERE.parent / 'round19-stringdiff-native/run_native.py'
raw = BASE.read_bytes()
source = raw.decode('utf-8').replace('test_stringdiff_template', 'test_dat_root')
with (HERE / 'run_native.py').open('x', encoding='utf-8') as f:
    f.write(source)
with (HERE / 'runner-provenance.json').open('x', encoding='utf-8') as f:
    json.dump(dict(base=str(BASE), base_sha256=hashlib.sha256(raw).hexdigest(),
                   result_sha256=hashlib.sha256(source.encode('utf-8')).hexdigest()), f, indent=2)
print('Prepared native runner only')
