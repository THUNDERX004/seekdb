"""Independent exact native transcript/count and source pin verification."""
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent
PIN = '5316b2ae7b480fe6d73144237c1e0f73c7612d86f4328fcbd8d9cce937053009'
assert hashlib.sha256((HERE/'test_dat_root.cpp').read_bytes()).hexdigest() == PIN
outputs, records = {}, {}
for variant in ('control', 'candidate'):
    run = HERE/(variant+'-run1')
    r = json.loads((run/'run.json').read_text(encoding='utf-8'))
    b = json.loads((run/'build-receipt.json').read_text(encoding='utf-8'))
    assert r['test_sha256'] == b['test_sha256'] == PIN
    assert r['expected_cases'] == 16416 and r['exit_code'] == 0
    assert r['native'] == r['output_validation'] == 'PASS'
    assert b['compile']['exit_code'] == b['link']['exit_code'] == 0
    assert b['production_sha256_before'] == b['production_sha256_after']
    stdout, stderr = (run/'stdout.log').read_bytes(), (run/'stderr.log').read_bytes()
    assert stderr == b''
    lines = stdout.splitlines()
    assert len(lines) == 114913
    assert sum(line.startswith(b'CASE\t') for line in lines) == 16416
    assert sum(line.startswith(b'T\t') for line in lines) == 98496
    assert lines[-1] == b'PASS\tcases=16416'
    for index in range(16416):
        group = lines[index*7:index*7+7]
        assert group[0].startswith(b'CASE\t'+str(index+1).encode()+b'\t')
        for line, field in zip(group[1:], (b'input.last', b'input.out', b'production.last',
                                          b'production.out', b'generic.last', b'generic.out')):
            assert line.startswith(b'T\t'+str(index+1).encode()+b'\t'+field+b'\t')
    outputs[variant] = stdout
    records[variant] = dict(stdout_sha256=hashlib.sha256(stdout).hexdigest(),
        stderr_sha256=hashlib.sha256(stderr).hexdigest(), records=len(lines),
        cases=16416, tuples=98496, expected_source_sha256=b['expected_source_sha256'],
        expected_header_sha256=b['expected_header_sha256'])
assert outputs['control'] == outputs['candidate']
with (HERE/'parent-output-verification.json').open('x', encoding='utf-8') as f:
    json.dump(dict(status='PASS', full_stdout_equal=True, full_stderr_empty=True,
                   variants=records), f, indent=2)
print('PASS full stdout/stderr + exact 16416 cases / 98496 tuples / 114913 records')
