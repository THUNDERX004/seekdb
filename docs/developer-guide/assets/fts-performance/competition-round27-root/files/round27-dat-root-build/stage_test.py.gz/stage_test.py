"""Snapshot one complete native test TU without modifying its author's directory."""
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent
source = HERE.parent / 'round27-dat-root-native/test_dat_root.cpp'
raw = source.read_bytes()
assert hashlib.sha256(raw).hexdigest() == '5316b2ae7b480fe6d73144237c1e0f73c7612d86f4328fcbd8d9cce937053009'
with (HERE / 'test_dat_root.cpp').open('xb') as f:
    f.write(raw)
assert source.read_bytes() == raw
with (HERE / 'test-provenance.json').open('x', encoding='utf-8') as f:
    json.dump(dict(source=str(source), test_sha256=hashlib.sha256(raw).hexdigest(),
                   expected_cases=16416, builder_sha256=hashlib.sha256((HERE/'build_native.py').read_bytes()).hexdigest(),
                   original_generator_sha256=hashlib.sha256((HERE/'prepare_builder.py').read_bytes()).hexdigest()), f, indent=2)
print('STAGED complete 16416-case TU', hashlib.sha256(raw).hexdigest())
