"""Create a dedicated DAT native-link adapter from the proven link infrastructure."""
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent
BASE = HERE.parent / 'round19-stringdiff-native/build_native.py'
data = BASE.read_bytes()
text = data.decode('utf-8')
replacements = [
    ("1 <= args.expected_cases <= 1000", "1 <= args.expected_cases <= 100000"),
    ("SOURCE = 'src/storage/blocksstable/encoding/ob_string_diff_decoder.cpp'",
     "SOURCE = 'src/storage/fts/dict/ob_ft_dat_dict.cpp'\nHEADER = 'src/storage/fts/dict/ob_ft_dat_dict.h'"),
    ("DEFAULT_TEST = HERE / 'test_stringdiff_template.cpp'", "DEFAULT_TEST = HERE / 'test_dat_root.cpp'"),
    ('test_stringdiff_template.exe', 'test_dat_root.exe'),
    ('decoder', 'DAT reader'),
    ("parser.add_argument('--expected-source-sha256', required=True)",
     "parser.add_argument('--expected-source-sha256', required=True)\n    parser.add_argument('--expected-header-sha256', required=True)"),
    ("util.require(util.sha(ROOT / SOURCE) == args.expected_source_sha256, 'Wrong live DAT reader source')",
     "util.require(util.sha(ROOT / SOURCE) == args.expected_source_sha256, 'Wrong live DAT reader source')\n    util.require(util.sha(ROOT / HEADER) == args.expected_header_sha256, 'Wrong live DAT reader header')"),
    ("test_sha256=util.sha(test), test_source=test.name, expected_cases=args.expected_cases,",
     "test_sha256=util.sha(test), test_source=test.name, expected_cases=args.expected_cases,\n                   expected_header_sha256=args.expected_header_sha256,"),
    ("util.require(production_obj.stat().st_mtime_ns >= (ROOT / SOURCE).stat().st_mtime_ns",
     "util.require(production_obj.stat().st_mtime_ns >= max((ROOT / SOURCE).stat().st_mtime_ns, (ROOT / HEADER).stat().st_mtime_ns)"),
    ("util.require(util.sha(ROOT / SOURCE) == args.expected_source_sha256 and util.sha(test) == receipt['test_sha256'], 'Source changed during native build')",
     "util.require(util.sha(ROOT / SOURCE) == args.expected_source_sha256 and util.sha(ROOT / HEADER) == args.expected_header_sha256\n                 and util.sha(test) == receipt['test_sha256'], 'Source changed during native build')"),
]
for old, new in replacements:
    assert old in text, old
    text = text.replace(old, new)
with (HERE / 'build_native.py').open('x', encoding='utf-8') as f:
    f.write(text)
with (HERE / 'provenance.json').open('x', encoding='utf-8') as f:
    json.dump(dict(base=str(BASE), base_sha256=hashlib.sha256(data).hexdigest(),
                   result_sha256=hashlib.sha256(text.encode('utf-8')).hexdigest()), f, indent=2)
print('Prepared native adapter only')
