"""Apply temporary unscored counters, preserving the reader's original operations."""
import difflib
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path('D:/Projects/OceanBase/seekdb')
REL = 'src/storage/fts/dict/ob_ft_dat_dict.cpp'

def main():
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument('--source-sha256', required=True)
    a = p.parse_args()
    target = ROOT / REL
    raw = target.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == a.source_sha256
    original = HERE / 'original.cpp'
    assert not original.exists(), 'Immutable diagnostic preimage already exists'
    src = raw.decode('utf-8').replace('\r\n', '\n')
    anchor = '  if (OB_FAIL(ret) && OB_ENTRY_NOT_EXIST != ret) {\n'
    assert src.count(anchor) == 1
    insertion = r'''
  // Temporary diagnostic only: no benchmark or score uses this binary.
  struct RootCounters {
    const void *reader;
    const void *dat;
    unsigned long long calls, bmp, missing, root0, root1, other, eligible, root_success;
    int32_t limit;
  };
  static thread_local RootCounters counters[512] = {};
  int slot = 0;
  while (slot < 512 && counters[slot].reader != nullptr
      && (counters[slot].reader != this || counters[slot].dat != dat_)) {
    ++slot;
  }
  if (slot < 512) {
    RootCounters &c = counters[slot];
    if (c.reader == nullptr) {
      c.reader = this;
      c.dat = dat_;
      if (dat_->array_size_ > 2 && base[1] == 1) {
        for (int64_t n = 1; n < INT32_MAX && n + 1 < dat_->array_size_
            && check[n + 1] == 1; ++n) {
          c.limit = static_cast<int32_t>(n);
        }
      }
    }
    ++c.calls;
    c.bmp += index >= 0;
    c.missing += ret == OB_ENTRY_NOT_EXIST;
    c.root0 += last_hit.base_idx_ == 0;
    c.root1 += last_hit.base_idx_ == 1;
    c.other += last_hit.base_idx_ > 1;
    const bool root = last_hit.base_idx_ <= 1;
    c.eligible += ret == OB_SUCCESS && index >= 0 && root && code > 0 && code <= c.limit;
    if (ret == OB_SUCCESS && root) {
      const int64_t next = static_cast<int64_t>(abs(base[1])) + code;
      c.root_success += next >= 0 && next < dat_->array_size_ && check[next] == 1;
    }
    if (c.calls == 1 || c.calls % 1024 == 0) {
      fprintf(stderr, "R27_DAT thread=%p reader=%p dat=%p limit=%d table=%d calls=%llu bmp=%llu missing=%llu root0=%llu root1=%llu other=%llu eligible=%llu root_success=%llu\n",
          static_cast<void *>(counters), c.reader, c.dat, c.limit, utf8_bmp_codes_ != nullptr,
          c.calls, c.bmp, c.missing, c.root0, c.root1, c.other, c.eligible, c.root_success);
      fflush(stderr);
    }
  } else if (slot == 512) {
    static thread_local bool reported = false;
    if (!reported) {
      fprintf(stderr, "R27_DAT_OVERFLOW thread=%p\n", static_cast<void *>(counters));
      fflush(stderr);
      reported = true;
    }
  }
'''
    src = src.replace(anchor, insertion + anchor)
    if src.count('#include <cstdio>') == 0:
        src = src.replace('#define USING_LOG_PREFIX STORAGE_FTS\n',
                          '#define USING_LOG_PREFIX STORAGE_FTS\n#include <cstdio>\n#include <climits>\n', 1)
    changed = src.replace('\n', '\r\n').encode('utf-8') if b'\r\n' in raw else src.encode('utf-8')
    original.write_bytes(raw)
    (HERE / 'instrumented.cpp').write_bytes(changed)
    (HERE / 'source.patch').write_text(''.join(difflib.unified_diff(
        raw.decode('utf-8').splitlines(True), changed.decode('utf-8').splitlines(True),
        fromfile='a/' + REL, tofile='b/' + REL)), encoding='utf-8', newline='')
    target.write_bytes(changed)
    receipt = dict(original_sha256=hashlib.sha256(raw).hexdigest(),
                   instrumented_sha256=hashlib.sha256(changed).hexdigest(),
                   source=REL, scoring=False, limitation='Per-thread/per-reader snapshots every 1024 calls; unsnapshotted tails and threads remain; no CPU-share inference.')
    (HERE / 'source.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(receipt))

if __name__ == '__main__':
    main()
