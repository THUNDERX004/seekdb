"""Freeze the diagnostic log and summarize last complete counter snapshots."""
from pathlib import Path
import hashlib
import json
import re

HERE = Path(__file__).resolve().parent
OUT = HERE / 'r27-root-frequency-a1'
LOG = Path('C:/Users/11946/AppData/Local/Temp/seekdb-fts-round19-shared/log/seekdb.log')
KEYS = ('calls', 'bmp', 'missing', 'root0', 'root1', 'other', 'eligible', 'root_success')
raw = LOG.read_bytes()
with (OUT / 'runtime.log').open('xb') as f:
    f.write(raw)
pattern = re.compile(rb'R27_DAT thread=(\S+) reader=(\S+) dat=(\S+) limit=(\d+) table=(\d+) calls=(\d+) bmp=(\d+) missing=(\d+) root0=(\d+) root1=(\d+) other=(\d+) eligible=(\d+) root_success=(\d+)')
last, count = {}, 0
for match in pattern.finditer(raw):
    parts = match.groups()
    key = tuple(p.decode('ascii') for p in parts[:3])
    item = dict(zip(('limit', 'table', *KEYS), map(int, parts[3:])))
    assert item['root0'] + item['root1'] + item['other'] == item['calls']
    assert item['eligible'] <= item['root_success'] <= item['root0'] + item['root1']
    if key in last:
        assert all(item[k] >= last[key][k] for k in KEYS)
        assert item['limit'] == last[key]['limit']
    last[key] = item
    count += 1
assert last and b'R27_DAT_OVERFLOW' not in raw
totals = {key: sum(row[key] for row in last.values()) for key in KEYS}
result = dict(status='COMPLETE', scoring=False, snapshots=count,
    thread_reader_generations=len(last), totals_at_last_snapshots=totals,
    eligible_fraction_of_snapshotted_calls=totals['eligible'] / totals['calls'],
    rows=[dict(thread=k[0], reader=k[1], dat=k[2], **v) for k, v in last.items()],
    runtime_log_sha256=hashlib.sha256(raw).hexdigest(),
    interpretation='Prefix snapshots of actual instrumented dictionary calls; unsnapshotted tails omitted, not a complete call count or CPU-share/performance result. Workload IK then BENG, 2000 each, all exact matches to frozen C7 output. No dictionary reload/DDL.')
with (OUT / 'frequency.json').open('x', encoding='utf-8') as f:
    json.dump(result, f, indent=2)
    f.write('\n')
print(json.dumps({k:v for k,v in result.items() if k != 'rows'}, indent=2))
