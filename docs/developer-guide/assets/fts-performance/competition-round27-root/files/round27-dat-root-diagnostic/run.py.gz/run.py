"""Own one isolated diagnostic server and native child; no timing is scored."""
import ctypes
import hashlib
import json
import os
from pathlib import Path
import re
import socket
import subprocess
import time

HERE = Path(__file__).resolve().parent
ROOT = Path('D:/Projects/OceanBase/seekdb')
BINARY = ROOT / 'build_fts_competition/src/observer/seekdb.exe'
CLIENT = ROOT / 'build/fts-native-client/mysql-native.exe'
INSTRUMENTED = '0f604ed680a98893d71b9b3498c9bc4659a9478353c2800febd1e1f413fbecba'

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda: f.read(1048576), b''):
            h.update(b)
    return h.hexdigest()

def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--label', required=True)
    parser.add_argument('--binary-sha256', required=True)
    args = parser.parse_args()
    assert re.fullmatch(r'[a-z0-9-]+', args.label)
    assert sha(ROOT / 'src/storage/fts/dict/ob_ft_dat_dict.cpp') == INSTRUMENTED
    assert sha(BINARY) == args.binary_sha256
    assert sha(CLIENT) == 'da3692bc7f5e4ae199e5007d9dca90aa1e849a626c4db6d0d9d860120b3f0a3c'
    out = HERE / args.label
    out.mkdir()
    with socket.socket() as sock:
        assert sock.connect_ex(('127.0.0.1', 2891)) != 0, 'Dedicated port occupied'
    env = os.environ.copy()
    for key in ('SEEKDB_TEST_PASSWORD', 'MYSQL_PWD'):
        env.pop(key, None)
    receipt = dict(scoring=False, label=args.label, binary_sha256=sha(BINARY),
                   instrumented_source_sha256=INSTRUMENTED, client_sha256=sha(CLIENT),
                   helper_sha256=sha(Path(__file__)), workloads=[], status='STARTED')
    proc = None
    try:
        command = [str(BINARY), '--nodaemon',
                   '--base-dir=C:/Users/11946/AppData/Local/Temp/seekdb-fts-round19-shared',
                   '--port=2891', '--parameter', 'rpc_port=2892', '--parameter', 'cpu_count=4',
                   '--parameter', 'memory_budget=2G', '--parameter', 'log_disk_size=2G', '--log-level=WARN']
        receipt['command'] = command
        with (out / 'server.log').open('wb') as log:
            proc = subprocess.Popen(command, cwd=ROOT, env=env, stdout=log,
                                    stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW)
            receipt['owned_server_pid'] = proc.pid
            k = ctypes.WinDLL('kernel32', use_last_error=True)
            k.SetProcessAffinityMask.argtypes = [ctypes.c_void_p, ctypes.c_size_t]
            k.SetProcessAffinityMask.restype = ctypes.c_int
            k.GetProcessAffinityMask.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_size_t),
                                                 ctypes.POINTER(ctypes.c_size_t)]
            k.GetProcessAffinityMask.restype = ctypes.c_int
            assert k.SetProcessAffinityMask(int(proc._handle), 15)
            actual, system = ctypes.c_size_t(), ctypes.c_size_t()
            assert k.GetProcessAffinityMask(int(proc._handle), ctypes.byref(actual), ctypes.byref(system))
            assert actual.value == 15
            receipt['affinity_mask_verified'] = actual.value
            import pymysql
            for _ in range(120):
                assert proc.poll() is None, 'Owned server exited during startup'
                try:
                    with pymysql.connect(host='127.0.0.1', port=2891, user='root', connect_timeout=1) as c:
                        with c.cursor() as cur:
                            cur.execute('SELECT 1')
                            assert cur.fetchone() == (1,)
                    break
                except (OSError, pymysql.MySQLError):
                    time.sleep(1)
            else:
                raise RuntimeError('Startup timeout')
            print('READY diagnostic owned pid=' + str(proc.pid), flush=True)
            for parser_name in ('ik', 'beng'):
                frozen = HERE.parent / 'round21-tokenizer-cycle' / ('r21-' + parser_name + '-a1-instance') / 'diagnostic'
                input_raw = (frozen / 'warmup.input.sql').read_bytes()
                lines = input_raw.decode('utf-8').splitlines()
                assert len(lines) == 33 and len(set(lines[3:])) == 1
                statement = lines[3]
                assert statement.startswith('SELECT tokenize(')
                data = ('\n'.join(lines[:3] + [statement] * 2000) + '\n').encode('utf-8')
                reference = json.loads((frozen / 'reference.json').read_text(encoding='utf-8'))['exact_native_utf8_line'].encode('utf-8')
                inp, stdout, stderr = [out / (parser_name + ext) for ext in ('.input.sql', '.stdout.log', '.stderr.log')]
                inp.write_bytes(data)
                with inp.open('rb') as source, stdout.open('xb') as target, stderr.open('xb') as error:
                    child = subprocess.Popen([str(CLIENT)], cwd=ROOT, env=env, stdin=source,
                                             stdout=target, stderr=error, creationflags=subprocess.CREATE_NO_WINDOW)
                    try:
                        code = child.wait(timeout=120)
                    finally:
                        if child.poll() is None:
                            child.kill()
                            child.wait(timeout=10)
                assert code == 0, 'Native child failed'
                output = stdout.read_bytes().splitlines()
                assert len(output) == 2000 and all(line == reference for line in output)
                assert not stderr.read_bytes()
                receipt['workloads'].append(dict(parser=parser_name, results=len(output), exact_reference_match=True,
                    input_sha256=sha(inp), stdout_sha256=sha(stdout), stderr_sha256=sha(stderr),
                    reference_sha256=hashlib.sha256(reference).hexdigest(), child_exit_code=code))
                print('PASS exact reference ' + parser_name, flush=True)
            assert sha(BINARY) == args.binary_sha256
            assert sha(ROOT / 'src/storage/fts/dict/ob_ft_dat_dict.cpp') == INSTRUMENTED
            receipt['status'] = 'COMPLETE'
    finally:
        if proc is not None:
            if proc.poll() is None:
                proc.terminate()
                try:
                    proc.wait(timeout=20)
                except subprocess.TimeoutExpired:
                    proc.kill()
                    proc.wait(timeout=10)
            receipt['owned_server_exit_code'] = proc.returncode
        if (out / 'server.log').is_file():
            receipt['server_log_sha256'] = sha(out / 'server.log')
        (out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
    print('COMPLETE diagnostic', flush=True)

if __name__ == '__main__':
    main()
