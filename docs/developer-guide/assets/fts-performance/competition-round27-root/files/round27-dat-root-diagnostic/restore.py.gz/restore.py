"""Restore only the hash-pinned transient counter edit, never other dirty work."""
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent
target = Path('D:/Projects/OceanBase/seekdb/src/storage/fts/dict/ob_ft_dat_dict.cpp')
data = json.loads((HERE / 'source.json').read_text(encoding='utf-8'))
assert hashlib.sha256(target.read_bytes()).hexdigest() == data['instrumented_sha256']
raw = (HERE / 'original.cpp').read_bytes()
assert hashlib.sha256(raw).hexdigest() == data['original_sha256']
target.write_bytes(raw)
with (HERE / 'restoration.json').open('x', encoding='utf-8') as f:
    json.dump(dict(status='RESTORED_EXACT', sha256=hashlib.sha256(target.read_bytes()).hexdigest()), f, indent=2)
print('RESTORED_EXACT', data['original_sha256'])
