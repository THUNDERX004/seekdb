"""Snapshot the existing local harness with additional process exit diagnostics."""
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent
BASE = HERE.parent/'experiment-competition.py'
raw = BASE.read_bytes()
source = raw.decode('utf-8').replace('\r\n', '\n')
source = source.replace("HERE = Path(__file__).resolve().parent", "HERE = Path(__file__).resolve().parent.parent", 1)
old = '''        finally:
            if proc.poll() is None:
'''
new = '''        finally:
            meta['owned_server_pid'] = proc.pid
            meta['owned_server_exit_before_cleanup'] = proc.poll()
            if proc.poll() is None:
'''
assert source.count(old) == 1
source = source.replace(old, new, 1)
old = "            metadata_path.write_text(json.dumps(meta, indent=2)+'\\n', encoding='utf-8')"
new = "            meta['owned_server_exit_after_cleanup'] = proc.returncode\n" + old
assert source.count(old) == 1
source = source.replace(old, new, 1)
with (HERE/'experiment-with-exit.py').open('x', encoding='utf-8') as f:
    f.write(source)
with (HERE/'harness-provenance.json').open('x', encoding='utf-8') as f:
    json.dump(dict(base=str(BASE), base_sha256=hashlib.sha256(raw).hexdigest(),
                   candidate_sha256=hashlib.sha256(source.encode('utf-8')).hexdigest(),
                   scope='Auxiliary harness output-root preserved; only owned-server PID/exit metadata added; no official workload edits.'), f, indent=2)
print('Prepared owned-server exit diagnostic harness')
