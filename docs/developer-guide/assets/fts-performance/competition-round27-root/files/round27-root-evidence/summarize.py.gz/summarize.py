"""Strict unchanged-workload incremental root-prefix comparison; no formal score."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
from statistics import mean

HERE = Path(__file__).resolve().parent
FTS = HERE.parent
HELPER = FTS / 'round19-evidence/summarize-template.py'
PINS = {'control': 'c7fcc8676875246a38bc4135f29e6f52b85a9d29a9563679003d5b6140666b01',
        'candidate': '1da2c6e4522616454e3f60a6f4c1649c53365a5b059095b8f87030ac529bc22a'}
SOURCES = {'control': 'f56ddd03e66826919d8d9192bc4c0afece8843dd',
           'candidate': '94e1a77354b51761d3baf7a73c98b794d313d36e+round27-root'}

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--pairs', required=True, type=int, choices=(1, 2, 3))
    args = p.parse_args()
    assert hashlib.sha256(HELPER.read_bytes()).hexdigest() == '0aca605abda2fea4ab7b32335c5fe04302895748e8f63a6ce46887b04b822035'
    spec = importlib.util.spec_from_file_location('strict_pair_util', HELPER)
    u = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(u)
    u.PINS = PINS
    out = HERE / ('root-comparison-' + str(args.pairs) + 'pair.json')
    u.require(not out.exists(), 'Immutable output already exists')
    inputs, raw_inputs, records, pairs = {}, {}, {}, []
    runs = {'control': [], 'candidate': []}
    def compare(old, new):
        result = u.comparison(old, new)
        result.pop('incremental_score_equivalents')
        return result
    for number in range(1, args.pairs + 1):
        for variant in runs:
            label = ('r27-root-control-a' if variant == 'control'
                     else 'r27-root-candidate-bench-a') + str(number)
            report = FTS / (label + '-report.txt')
            receipt = FTS / (label + '-experiment.json')
            r = u.receipt(u.read_input(receipt, inputs, raw_inputs), label, variant, report)
            u.require(r['source_commit'] == SOURCES[variant], 'Wrong source label')
            d = u.report(u.read_input(report, inputs, raw_inputs), label)
            records[label] = dict(receipt=r, **d)
            runs[variant].append(d['values'])
        pairs.append(dict(pair=number, **compare(runs['control'][-1], runs['candidate'][-1])))
    means = {variant: {key: mean(run[key] for run in samples) for key in u.METRICS}
             for variant, samples in runs.items()}
    result = dict(status='COMPLETE', completed_pairs=args.pairs, pairs=pairs, records=records,
        binary_pins=PINS, source_labels=SOURCES, parameters=u.PARAMS, hits=u.HITS,
        helper_sha256=hashlib.sha256(HELPER.read_bytes()).hexdigest(),
        input_hashes=inputs, metric_means=means,
        aggregate=compare(means['control'], means['candidate']),
        interpretation='Incremental local comparison against accepted span candidate; not a cumulative or formal score.',
        failed_regression='r27-root-candidate-a1 stopped at ranked connection reset before benchmark; preserved separately, never treated as a completed timing run.',
        method='Per-metric run means; signed within-category metric means and equal category weighting. No sample removal, SELECT1 subtraction or score correction.')
    for path, raw in raw_inputs.items():
        u.require(u.snapshot(path) == raw, 'Input changed during validation')
    with out.open('x', encoding='utf-8') as f:
        json.dump(result, f, indent=2, allow_nan=False)
        f.write('\n')
    print(json.dumps(dict(output=str(out), aggregate=result['aggregate']), indent=2))

if __name__ == '__main__':
    main()
