# Bounded source review — 2026-11-04

No demonstrated Blocker or Major defect was identified in this bounded review.
This is a source review, not a merge verdict, performance result, or additional
execution gate. No source changes or executions were performed during review.
The frozen TU, README, report, source-pins and SHA256SUMS were left unchanged.
This separate review is intentionally outside that frozen artifact set.

Reviewed source identities:

| Input | SHA-256 |
| --- | --- |
| Frozen test TU | `5316b2ae7b480fe6d73144237c1e0f73c7612d86f4328fcbd8d9cce937053009` |
| Staged candidate DAT header | `5bb77e3cccc908ec7fbeabc6833327d3ba09c4312f72eb87d1f1f9924e15580b` |
| Staged candidate DAT CPP | `b10c4938d38eae3cdbc1a9556ccdc3b1e9b1470a99d4db8762da573d1481ee31` |
| Staged original DAT header | `6ac81ac0b70d718780fd16c78a0a357f49978aed24553a82fc0081e20d3f303a` |
| Staged original DAT CPP | `131d28841ac827601aefc5dbf786589b72d15a5444f9269abbc8aa1ca95dd11f` |

Staged inputs are under `../round27-dat-root-proposal/{original,candidate}/`
with the original repository-relative `src/storage/fts/dict/` paths. Review
followed the checkout's `.agents/skills/code-review/SKILL.md` and inspected
unchanged reader owners/publication and hit/map semantics in the checkout.

The promised behavior is identical reader return and complete hit state for
all supported inputs, with redundant root base/check reads removed only after
a successful BMP lookup and an initialization-proven root transition. The
candidate constructor initializes the bound to zero (header:171), resets it
before allocation (CPP:253), and publishes a positive value only after a
successful table fill and `base[1] == 1` validation (CPP:259-268). The scan uses
int64 arithmetic and stops before both array size and INT32_MAX; therefore
an eligible `code + 1` fits the original int32 index and addresses a checked
root destination. Holes reduce the proven prefix without declaring later
codes absent. Failed reinit clears the bound while retaining the original
code-table behavior.

CPP:311-326 evaluates eligibility after the unchanged flag clear, lookup,
distinct-output assignment and zero normalization. The candidate retains the
destination base load and both original update bodies. The unchanged prefix
body still permits a copied true match flag in distinct-output calls. The
oracle at `test_dat_root.cpp:122` uses the real map and assignment operation;
the full snapshots at lines 362-376 compare both last and output, all eight
fields and return. The private synthetic reinit sequence at line 491 would
expose retention of the previous root success bound. No private reader field
or candidate eligibility implementation is used by the oracle.

The cached proof depends on immutable DAT arrays during matching. The reviewed
production path initializes each cache reader before storing it in its range
(`ob_ft_range_dict.cpp:452-473`), then initializes the builtin reader before
release publication (`ob_ft_dict_hub.cpp:69-89`). Reader/cache member ordering
and range teardown retain DAT/table owners through reader use; the builtin
API explicitly requires immutability and teardown after parser users stop
(`ob_ft_dict_hub.h:114`). No supported in-place mutation or concurrent reader
reinitialization path was found in this bounded trace. Such a future path
would need synchronized validation or disabled caching; this test does not
authorize that lifecycle.

Remaining evidence limits, not demonstrated correctness findings:

- A fully disabled candidate shortcut can also pass every oracle comparison.
  Known eligible fixture arrays establish opportunities, not actual path
  execution. Parent original-path counts establish applicability, while the
  parent owns candidate execution identity and performance interpretation.
- Continuation matrices start from safe generic-derived states with sentinels;
  they do not replay an entire production reader token sequence or exercise
  cache eviction/publication concurrently. Parent SQL/lifecycle gates cover
  integration separately. No additional TU expansion is requested here.
- Small safe boundary fixtures do not establish INT32_MAX-scale allocation,
  sanitizer behavior, all corrupted layouts, Linux evaluation or a speedup.
  Source arithmetic covers the proposed cap; guard bytes are write checks.
- Parent-reported original/candidate PASS and matching transcript hashes are
  recorded in the frozen report. This review did not audit raw executables,
  link receipts, stdout/stderr or production SQL/benchmark results. Those
  artifacts remain parent-owned and must retain the actual source/object/
  header/archive identities used for the two builds.
