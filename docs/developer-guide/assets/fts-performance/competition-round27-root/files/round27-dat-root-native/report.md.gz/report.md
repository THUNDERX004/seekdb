# Source-only freeze report — 2026-11-04

Frozen `test_dat_root.cpp` SHA-256:
`5316b2ae7b480fe6d73144237c1e0f73c7612d86f4328fcbd8d9cce937053009`.
The parent reports actual original and candidate runs of this exact TU in the
separate `round27-dat-root-build` directory both passed all 16,416 cases and
emitted 114,913 records each. Full stdout and stderr bytes were identical.
Parent-reported stdout SHA-256:
`ca736bb5badb8c6a32143a5dd988121abd1f8ad3ef51d28898657e55ce41fedd`.
Parent-reported tuple-stream SHA-256:
`2f261d6564ff94ab904632bf6de2e5ae071ecab7ada4fc3eef008f4f57acd499`.
These execution results remain parent-owned; the sidecar performed no run or
independent raw-output audit. Parent SQL/full benchmark work remains separate.

The test has a fixed 16,416-case schedule, six complete hit tuples per case
(98,496 tuples), and exact success trailer `PASS\tcases=16416`. It invokes the
actual linked reader, trie, builder, hash map and hit API. Its independent
generic map/base/check oracle compares return and all eight hit fields,
including raw pointer identity in-process, flags, count and current check.
Stable sentinel IDs replace ASLR pointers only in the deterministic transcript.

The ordinary corpus is built with real trie+builder; manual DATs are limited
to array/byte boundaries, holes and nonunit root bases. Explicit failure/reinit,
code-limit/limit+1, alias/distinct sentinel, BMP/NUL/malformed/non-BMP,
independent maps/readers and lifetime cases are documented in `README.md`.
Private synthetic DAT changes between quiescent reinit calls expose stale
cached bounds without accessing or depending on the new private field.

Source inspection and SHA recording only were performed. No native build,
native execution, SQL, runtime access, benchmark, production write or Git
operation was performed by this sidecar. All authored files are under this
new auxiliary directory. Parent instrumentation and candidate changes are
separate work and are not included here. No additional TU edits are planned
after the reported freeze; concrete parent compile findings should be repaired
as a separately pinned revision and executed identically on both variants.

Observed DAT header/CPP hashes match the round24 proposal's original source
pins. Full observed source pins and artifact hashes accompany this report.
They record local source identity, not official-baseline ancestry or a
performance/correctness pass. No remote baseline lookup was performed because
this task explicitly excludes Git and production work.
