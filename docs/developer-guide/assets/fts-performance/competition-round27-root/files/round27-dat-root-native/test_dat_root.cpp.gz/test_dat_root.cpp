/* Copyright (c) 2026. Licensed under the Apache License, Version 2.0. */
// Source-only sidecar. Compile this SAME TU against each actual production variant.
// No production .cpp is included, no private state is accessed, and the only
// reference matcher below is the pre-existing generic map/base/check algorithm.
#include <algorithm>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <initializer_list>
#include <limits>
#include <optional>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

#include "lib/allocator/page_arena.h"
#include "lib/charset/ob_charset.h"
#include "lib/oblog/ob_log.h"
#include "lib/rc/context.h"
#include "storage/fts/dict/ob_ft_dat_dict.h"
#include "storage/fts/dict/ob_ft_trie.h"

using namespace oceanbase;
using namespace oceanbase::common;
using namespace oceanbase::storage;

namespace {
using Reader = ObFTDATReader<void>;
constexpr int kExpectedCases = 16416;
constexpr int64_t kTableBytes = (int64_t(1) << 16) * sizeof(ObFTWordCode);
int cases = 0;
const char *phase = "startup";

void need(bool ok, const char *why)
{
  if (!ok) throw std::runtime_error(why);
}

std::string bytes(std::initializer_list<unsigned int> values)
{
  std::string s;
  for (unsigned int v : values) {
    need(v <= 255, "invalid byte literal");
    s.push_back(static_cast<char>(v));
  }
  return s;
}

ObString view(const std::string &s)
{
  return ObString(static_cast<int32_t>(s.size()), s.c_str());
}

// This encodes test input only; it does not perform dictionary transitions or
// reproduce the proposal's root eligibility/validation algorithm.
std::string utf8(uint32_t cp)
{
  need(cp <= 0x10ffff && !(cp >= 0xd800 && cp <= 0xdfff), "invalid scalar");
  if (cp < 0x80) return bytes({cp});
  if (cp < 0x800) return bytes({0xc0 | (cp >> 6), 0x80 | (cp & 63)});
  if (cp < 0x10000) return bytes({0xe0 | (cp >> 12), 0x80 | ((cp >> 6) & 63), 0x80 | (cp & 63)});
  return bytes({0xf0 | (cp >> 18), 0x80 | ((cp >> 12) & 63),
                0x80 | ((cp >> 6) & 63), 0x80 | (cp & 63)});
}

class SentinelDict final : public ObIFTDict {
public:
  int init() override { return OB_NOT_SUPPORTED; }
  int match(const ObString &, bool &) const override { return OB_NOT_SUPPORTED; }
  int match(const ObString &, ObDATrieHit &) const override { return OB_NOT_SUPPORTED; }
  int match_with_hit(const ObString &, const ObDATrieHit &, ObDATrieHit &) const override
  { return OB_NOT_SUPPORTED; }
};
SentinelDict dict_a, dict_b;

int dict_id(const ObIFTDict *p)
{
  if (p == nullptr) return 0;
  if (p == &dict_a) return 1;
  if (p == &dict_b) return 2;
  need(false, "unexpected dict pointer (no pointer normalization permitted)");
  return -1;
}

struct HitFields {
  const ObIFTDict *dict;
  int64_t char_cnt, start, end;
  uint32_t base, check;
  bool match, prefix;
  bool operator==(const HitFields &o) const
  {
    return dict == o.dict && char_cnt == o.char_cnt && start == o.start && end == o.end
        && base == o.base && check == o.check && match == o.match && prefix == o.prefix;
  }
};

HitFields fields(const ObDATrieHit &h)
{
  return {h.dict_, h.char_cnt_, h.start_pos_, h.end_pos_, h.base_idx_,
          h.current_check_, h.is_match_, h.is_prefix_};
}

// Explicit member initialization avoids using the deliberately incomplete hit
// assignment operator to construct independent reference/production inputs.
void load(ObDATrieHit &h, const HitFields &f)
{
  h.dict_ = f.dict; h.char_cnt_ = f.char_cnt; h.start_pos_ = f.start;
  h.end_pos_ = f.end; h.base_idx_ = f.base; h.current_check_ = f.check;
  h.is_match_ = f.match; h.is_prefix_ = f.prefix;
}

int32_t *base_of(ObFTDAT *dat)
{ return reinterpret_cast<int32_t *>(dat->buff + dat->base_offset_); }
int32_t *check_of(ObFTDAT *dat)
{ return reinterpret_cast<int32_t *>(dat->buff + dat->check_offset_); }

// Independent oracle: ALWAYS use the actual production ObArrayHashMap::find.
// Never consult a BMP table, cached root bound, or candidate matcher here.
// Ordering, alias effects and actual ObDATrieHit::operator= match the original.
int generic_match(ObFTDAT *dat, const ObString &ch,
                  const ObDATrieHit &last, ObDATrieHit &hit)
{
  int ret = OB_SUCCESS;
  ObFTWordCode code = 0;
  hit.set_unmatch();
  ObFTSingleWord word;
  need(word.set_word(ch.ptr(), ch.length()) == OB_SUCCESS, "unsafe oracle key");
  ret = dat->get_map()->find(word, code);
  if (ret != OB_SUCCESS && ret != OB_ENTRY_NOT_EXIST) {
    // Preserve the real error and the initial flag clear.
  } else if (ret == OB_ENTRY_NOT_EXIST) {
    ret = OB_SUCCESS;
    hit.set_unmatch();
  } else {
    if (&last != &hit) hit = last; // In particular, this does NOT copy dict_.
    if (hit.base_idx_ == 0) hit.base_idx_ = 1;
    int32_t *base = base_of(dat), *check = check_of(dat);
    need(hit.base_idx_ < dat->array_size_, "fixture source index out of bounds");
    need(base[hit.base_idx_] != std::numeric_limits<int32_t>::min(), "unsafe abs in fixture");
    const int64_t wide_idx = int64_t(std::abs(base[hit.base_idx_])) + code;
    need(wide_idx >= 0 && wide_idx < int64_t(dat->array_size_)
         && wide_idx <= std::numeric_limits<int32_t>::max(), "fixture destination out of bounds");
    const int32_t idx = std::abs(base[hit.base_idx_]) + code;
    if (check[idx] != static_cast<int64_t>(hit.base_idx_)) {
      hit.set_unmatch();
    } else if (base[idx] < 0) {
      hit.base_idx_ = idx;
      hit.end_pos_ = hit.end_pos_ + ch.length();
      hit.char_cnt_++;
      hit.set_match();
      hit.set_prefix();
    } else {
      hit.base_idx_ = idx;
      hit.end_pos_ = hit.end_pos_ + ch.length();
      hit.char_cnt_++;
      hit.set_prefix();
    }
  }
  return ret;
}

ObFTWordCode mapped_code(ObFTDAT *dat, const std::string &s)
{
  ObFTSingleWord word;
  ObFTWordCode code = 0;
  need(word.set_word(s.c_str(), static_cast<int32_t>(s.size())) == OB_SUCCESS, "map key");
  need(dat->get_map()->find(word, code) == OB_SUCCESS && code > 0, "expected mapped character");
  return code;
}

class ContextScope final {
public:
  ContextScope()
  {
    lib::ContextParam p;
    p.set_mem_attr("R27DatRoot", ObCtxIds::DEFAULT_CTX_ID).set_properties(lib::USE_TL_PAGE_OPTIONAL);
    need(CURRENT_CONTEXT->CREATE_CONTEXT(context_, p) == OB_SUCCESS && context_ != nullptr,
         "CREATE_CONTEXT");
    flow_.emplace(context_);
    if (flow_->init() != OB_SUCCESS) {
      flow_.reset(); DESTROY_CONTEXT(context_); context_ = nullptr;
      need(false, "Flow::init");
    }
  }
  ~ContextScope()
  {
    if (flow_) { flow_->deinit(); flow_.reset(); }
    if (context_ != nullptr) DESTROY_CONTEXT(context_);
  }
private:
  lib::MemoryContext context_ = nullptr;
  std::optional<lib::Flow> flow_;
};

// All optional-table storage stays alive until after its reader. Previously
// successful allocations are retained across failed/successful reinitialization.
class TableAllocator final : public ObIAllocator {
public:
  struct Block { unsigned char *raw; std::vector<unsigned char> saved; };
  ObArenaAllocator arena;
  std::vector<Block> blocks;
  bool fail = false;
  int calls = 0;

  void *alloc(int64_t n) override
  {
    ++calls;
    need(n == kTableBytes, "proposal allocated something other than the existing BMP table");
    if (fail) return nullptr;
    auto *p = static_cast<unsigned char *>(arena.alloc(n + 64));
    need(p != nullptr, "unexpected real arena exhaustion");
    std::memset(p, 0xd3, 32);
    std::memset(p + 32, 0xa5, static_cast<size_t>(n));
    std::memset(p + 32 + n, 0x6b, 32);
    blocks.push_back({p, {}});
    return p + 32;
  }
  void *alloc(int64_t n, const ObMemAttr &) override { return alloc(n); }
  void free(void *) override {} // Arena retains every generation until reader teardown.

  void verify(ObFTDAT *dat)
  {
    for (auto &b : blocks) {
      for (int j = 0; j < 32; ++j)
        need(b.raw[j] == 0xd3 && b.raw[32 + kTableBytes + j] == 0x6b, "table allocation guards");
      if (b.saved.empty()) {
        // Validate every table slot through the real byte-key map, independently
        // of fill_utf8_bmp_codes / ft_utf8_bmp_index and the candidate private state.
        const auto *codes = reinterpret_cast<const ObFTWordCode *>(b.raw + 32);
        for (uint32_t cp = 0; cp < (1U << 16); ++cp) {
          ObFTWordCode expected = 0;
          if (!(cp >= 0xd800 && cp <= 0xdfff)) {
            const std::string s = utf8(cp);
            ObFTSingleWord key;
            need(key.set_word(s.c_str(), static_cast<int32_t>(s.size())) == OB_SUCCESS, "BMP verification key");
            ObFTWordCode found = 0;
            const int ret = dat->get_map()->find(key, found);
            need(ret == OB_SUCCESS || ret == OB_ENTRY_NOT_EXIST, "BMP verification map error");
            if (ret == OB_SUCCESS) { need(found > 0, "nonpositive fixture code"); expected = found; }
          }
          need(codes[cp] == expected, "BMP code contents changed or sign-tagged");
        }
        b.saved.assign(b.raw + 32, b.raw + 32 + kTableBytes);
      } else {
        need(std::memcmp(b.saved.data(), b.raw + 32, static_cast<size_t>(kTableBytes)) == 0,
             "previous BMP table mutated");
      }
    }
  }
};

struct Fixture {
  ObArenaAllocator arena;
  std::string name;
  ObFTDAT *dat = nullptr;
  std::vector<unsigned char> saved;

  Fixture(const std::string &label, std::vector<std::string> words) : name(label)
  {
    // Real trie and builder, with sorted byte keys as required by trie insertion.
    ObArenaAllocator trie_arena;
    ObFTTrie<void> trie(trie_arena, CS_TYPE_UTF8MB4_BIN);
    std::sort(words.begin(), words.end());
    words.erase(std::unique(words.begin(), words.end()), words.end());
    for (const auto &s : words) need(trie.insert(view(s), {}) == OB_SUCCESS, "real trie insert");
    ObFTDATBuilder<void> builder(arena);
    need(builder.init(trie) == OB_SUCCESS, "real builder init");
    need(builder.build_from_trie(trie) == OB_SUCCESS, "real builder build");
    size_t length = 0;
    need(builder.get_mem_block(dat, length) == OB_SUCCESS && dat != nullptr
         && int64_t(length) == dat->mem_block_size_, "real builder block");
    need(trie.root()->children_ != nullptr && base_of(dat)[1] == 1, "expected real root layout");
    int32_t c = 0;
    for (auto it = trie.root()->children_->begin(); it != trie.root()->children_->end(); ++it) {
      ++c;
      need(it->child_->dat_build_info_.code_ == c, "noncontiguous builder root codes");
      need(it->child_->dat_build_info_.state_index_ == uint32_t(c + 1)
           && check_of(dat)[c + 1] == 1, "builder root state");
    }
    seal(); // Trie storage dies here; DAT keys must remain independently usable.
  }

  // Manual layouts are confined to safe array/byte boundaries, holes, and
  // nonunit root bases that the ordinary builder cannot produce.
  Fixture(const std::string &label, size_t n, int32_t root_base,
          const std::vector<std::string> &keys,
          std::initializer_list<int32_t> successful_codes) : name(label)
  {
    const size_t map_size = (ObArrayHashMap::estimate_size(keys.size()) + 3) & ~size_t(3);
    const size_t total = sizeof(ObFTDAT) + map_size + n * sizeof(int32_t) * 2;
    dat = static_cast<ObFTDAT *>(arena.alloc(static_cast<int64_t>(total)));
    need(dat != nullptr && n >= 3, "manual DAT allocation");
    std::memset(dat, 0, total);
    dat->mem_block_size_ = static_cast<int64_t>(total);
    dat->node_num_ = keys.size(); dat->word_num_ = keys.size(); dat->array_size_ = n;
    dat->base_offset_ = map_size;
    dat->check_offset_ = map_size + n * sizeof(int32_t);
    need(dat->get_map()->init(keys.size()) == OB_SUCCESS, "real manual map init");
    for (size_t k = 0; k < keys.size(); ++k)
      need(dat->get_map()->insert(view(keys[k]), static_cast<int32_t>(k + 1)) == OB_SUCCESS,
           "real manual map insert");
    base_of(dat)[1] = root_base;
    for (int32_t c : successful_codes) {
      const int32_t i = std::abs(root_base) + c;
      need(c > 0 && size_t(c) <= keys.size() && i > 1 && size_t(i) < n, "unsafe manual edge");
      check_of(dat)[i] = 1;
      base_of(dat)[i] = c % 2 == 0 ? 1 : -1;
    }
    seal();
  }

  void seal()
  {
    const auto *p = reinterpret_cast<const unsigned char *>(dat);
    saved.assign(p, p + dat->mem_block_size_);
  }
  void verify() const
  {
    need(dat->mem_block_size_ == int64_t(saved.size())
         && std::memcmp(dat, saved.data(), saved.size()) == 0, "reader modified pinned DAT/map bytes");
  }
};

struct Seed { std::string name; uint32_t base; };

uint32_t continued_at(Fixture &f, const std::string &s)
{
  ObDATrieHit h(&dict_a, 0);
  need(generic_match(f.dat, view(s), h, h) == OB_SUCCESS && h.is_prefix_, "continuation seed unavailable");
  return h.base_idx_;
}

void emit_hit(const char *which, int ret, const HitFields &h)
{
  // ret and EVERY public hit field are present in every tuple, including input
  // snapshots. IDs are stable across ASLR; comparisons above use real pointers.
  std::printf("T\t%d\t%s\tret=%d\tdict=%d\tchar_cnt=%lld\tstart_pos=%lld\tend_pos=%lld"
              "\tbase_idx=%u\tcurrent_check=%u\tis_match=%d\tis_prefix=%d\n",
      cases, which, ret, dict_id(h.dict), static_cast<long long>(h.char_cnt),
      static_cast<long long>(h.start), static_cast<long long>(h.end),
      unsigned(h.base), unsigned(h.check), int(h.match), int(h.prefix));
}

void one(Fixture &f, Reader &reader, const std::string &s, const Seed &seed,
         int flags, bool alias)
{
  ++cases;
  const HitFields in{&dict_a, 11, 101, 137, seed.base, 0xfedcba98U,
                     (flags & 1) != 0, (flags & 2) != 0};
  const HitFields out{&dict_b, 73, 701, 743, 17, 0x89abcdefU, true, true};
  ObDATrieHit live_last(&dict_a, 0), live_out(&dict_b, 0);
  ObDATrieHit ref_last(&dict_a, 0), ref_out(&dict_b, 0);
  load(live_last, in); load(ref_last, in); load(live_out, out); load(ref_out, out);
  std::printf("CASE\t%d\tfixture=%s\tphase=%s\tseed=%s\tflags=%d\talias=%d\tlen=%u\thex=",
      cases, f.name.c_str(), phase, seed.name.c_str(), flags, int(alias), unsigned(s.size()));
  for (unsigned char c : s) std::printf("%02x", unsigned(c));
  std::putchar('\n');

  // Reference first, with bounds checks, so every actual call has a safe fixture.
  const int rr = alias ? generic_match(f.dat, view(s), ref_last, ref_last)
                       : generic_match(f.dat, view(s), ref_last, ref_out);
  const int pr = alias ? reader.match_with_hit(view(s), live_last, live_last)
                       : reader.match_with_hit(view(s), live_last, live_out);
  emit_hit("input.last", OB_SUCCESS, in);
  emit_hit("input.out", OB_SUCCESS, alias ? in : out);
  emit_hit("production.last", pr, fields(live_last));
  emit_hit("production.out", pr, fields(alias ? live_last : live_out));
  emit_hit("generic.last", rr, fields(ref_last));
  emit_hit("generic.out", rr, fields(alias ? ref_last : ref_out));
  need(pr == rr && fields(live_last) == fields(ref_last)
       && fields(live_out) == fields(ref_out), "production/generic full-field mismatch");
  if (!alias) need(fields(live_last) == in, "distinct last_hit changed");
  need(fields(alias ? live_last : live_out).dict == (alias ? &dict_a : &dict_b),
       "hit assignment copied dict_");
}

void matrix(Fixture &f, Reader &reader, TableAllocator &a, const char *label,
            const std::vector<std::string> &probes, const std::vector<Seed> &seeds)
{
  phase = label;
  f.verify(); a.verify(f.dat);
  for (const auto &seed : seeds) for (const auto &s : probes)
    for (int flags = 0; flags < 4; ++flags) for (bool alias : {false, true})
      one(f, reader, s, seed, flags, alias);
  f.verify(); a.verify(f.dat);
}

void initialize(Fixture &f, Reader &reader, TableAllocator &a, bool failure)
{
  f.verify(); a.verify(f.dat);
  const int before = a.calls;
  const size_t blocks = a.blocks.size();
  a.fail = failure;
  need(reader.init_utf8_bmp_codes(a) == OB_SUCCESS, "optional initialization return");
  need(a.calls == before + 1 && a.blocks.size() == blocks + (failure ? 0 : 1),
       "optional initialization allocation contract");
  f.verify(); a.verify(f.dat);
}

std::vector<std::string> normal_words()
{
  return {bytes({0}), bytes({0, 'A'}), "A", "AB", "ABA", "AZ", "BC", "D",
          utf8(0x7f), utf8(0x80), utf8(0x7ff), utf8(0x800), utf8(0xd7ff),
          utf8(0xe000), utf8(0xffff), utf8(0x4e2d), utf8(0x4e2d) + "A",
          utf8(0x4e2d) + utf8(0x6587), utf8(0x1f642), utf8(0x1f642) + "A", utf8(0x10ffff)};
}

std::vector<std::string> normal_probes()
{
  return {bytes({0}), "A", "B", "D", "Z", "C", utf8(0x7f), utf8(0x80), utf8(0x7ff),
          utf8(0x800), utf8(0xd7ff), utf8(0xe000), utf8(0xffff), utf8(0x4e2d), utf8(0x6587),
          utf8(0x1f642), utf8(0x10ffff), "Q", utf8(0x4e01), utf8(0x1f680), "",
          bytes({0x80}), bytes({0xc2}), bytes({0xe0, 0xa0}), bytes({0xf0, 0x9f, 0x99}),
          bytes({0xc0, 0x80}), bytes({0xe0, 0x80, 0x80}), bytes({0xed, 0xa0, 0x80}),
          bytes({0xf4, 0x90, 0x80, 0x80}), bytes({0xe2, 0x28, 0xa1}), "AB", bytes({'A', 0}),
          bytes({0xf8, 0x80, 0x80, 0x80, 0x80}), bytes({0xff}), bytes({'A', 0, 'B'}),
          bytes({0xf0, 0x80, 0x80, 0x80})};
}

std::vector<std::string> boundary_probes()
{
  return {"A", "B", "C", "Q", bytes({0}), "", utf8(0x4e2d), utf8(0x1f642),
          bytes({0x80}), bytes({0xc0, 0x80}), bytes({0xed, 0xa0, 0x80}), "AB"};
}

std::vector<Seed> boundary_seeds(Fixture &f, const std::string &continuation)
{ return {{"root0", 0}, {"root1", 1}, {"continuation", continued_at(f, continuation)}}; }

void ordinary()
{
  Fixture f("real-trie", normal_words());
  const auto probes = normal_probes();
  const std::vector<Seed> seeds{{"root0", 0}, {"root1", 1}, {"after-A", continued_at(f, "A")},
      {"after-B", continued_at(f, "B")}, {"after-D", continued_at(f, "D")},
      {"after-CJK", continued_at(f, utf8(0x4e2d))}, {"after-nonBMP", continued_at(f, utf8(0x1f642))}};
  need(probes.size() == 36 && seeds.size() == 7, "ordinary corpus size");
  // Check distinct terminal+prefix, prefix-only and terminal-leaf construction.
  need(base_of(f.dat)[seeds[2].base] < 0 && base_of(f.dat)[seeds[3].base] >= 0
       && base_of(f.dat)[seeds[4].base] < 0, "real terminal/prefix fixture states");
  const auto root_code = mapped_code(f.dat, utf8(0x10ffff));
  need(check_of(f.dat)[1 + root_code] == 1
       && mapped_code(f.dat, "Z") == root_code + 1 && check_of(f.dat)[1 + root_code + 1] != 1,
       "real code=limit and code=limit+1 fixture boundary");
  TableAllocator a;
  Reader reader(f.dat);
  matrix(f, reader, a, "table-disabled", probes, seeds);
  initialize(f, reader, a, true);
  matrix(f, reader, a, "first-allocation-fails", probes, seeds);
  initialize(f, reader, a, false);
  matrix(f, reader, a, "table-enabled", probes, seeds);
  initialize(f, reader, a, true);
  matrix(f, reader, a, "reinit-allocation-fails", probes, seeds);
  initialize(f, reader, a, false);
  matrix(f, reader, a, "reinit-succeeds", probes, seeds);
}

void boundary_pair(Fixture &f, const std::string &continuation)
{
  const auto probes = boundary_probes();
  const auto seeds = boundary_seeds(f, continuation);
  need(probes.size() == 12 && seeds.size() == 3, "boundary corpus size");
  TableAllocator a;
  Reader reader(f.dat);
  matrix(f, reader, a, "table-disabled", probes, seeds);
  initialize(f, reader, a, false);
  matrix(f, reader, a, "table-enabled", probes, seeds);
}

void boundaries()
{
  const std::vector<std::string> abc{"A", "B", "C"};
  { Fixture f("array-minimum", 3, 1, {"A"}, {1}); boundary_pair(f, "A"); }
  { Fixture f("array-last-entry", 5, 1, abc, {1, 2, 3}); boundary_pair(f, "A"); }
  { Fixture f("hole-at-code2", 8, 1, abc, {1, 3}); boundary_pair(f, "A"); }
  { Fixture f("hole-at-code1", 8, 1, abc, {2, 3}); boundary_pair(f, "B"); }
  { Fixture f("root-base-plus3", 10, 3, abc, {1, 2, 3}); boundary_pair(f, "A"); }
  { Fixture f("root-base-minus3", 10, -3, abc, {1, 2, 3}); boundary_pair(f, "A"); }
  { Fixture f("root-base-zero", 8, 0, abc, {2, 3}); boundary_pair(f, "B"); }
  {
    // Byte-key boundary cases cannot be inserted as UTF8MB4 trie characters.
    // They are valid ObFTSingleWord keys (length <= MAX_MB_LEN) in a safe DAT.
    const std::vector<std::string> keys{"A", bytes({0}), utf8(0x4e2d), utf8(0x1f642), "",
        bytes({0x80}), bytes({0xc0, 0x80}), bytes({0xed, 0xa0, 0x80}), "AB", bytes({'A', 0, 'B'})};
    Fixture f("byte-key-array-boundary", 12, 1, keys, {1, 2, 3, 4, 5, 6, 7, 8, 9, 10});
    boundary_pair(f, "A");
  }
}

void quiescent_reinit()
{
  // TEST-OWNED private synthetic block only. No published DAT or concurrent
  // reader is changed. Map codes remain identical, so even retained old BMP
  // storage stays valid. These edits make a stale scalar bound observable.
  Fixture f("private-hole-reinit", 10, 1, {"A", "B", "C"}, {1, 2, 3});
  TableAllocator a;
  Reader reader(f.dat);
  const auto probes = boundary_probes();
  const auto seeds = boundary_seeds(f, "C");
  initialize(f, reader, a, false);
  matrix(f, reader, a, "dense-success", probes, seeds);

  f.verify(); check_of(f.dat)[2] = 0; f.seal();
  initialize(f, reader, a, true);
  matrix(f, reader, a, "first-hole-failed-reinit", probes, seeds);

  f.verify(); check_of(f.dat)[2] = 1; check_of(f.dat)[3] = 0; f.seal();
  initialize(f, reader, a, false);
  matrix(f, reader, a, "middle-hole-successful-reinit", probes, seeds);

  f.verify();
  base_of(f.dat)[1] = 3;
  check_of(f.dat)[2] = 0; check_of(f.dat)[3] = 0;
  for (int i = 4; i <= 6; ++i) { check_of(f.dat)[i] = 1; base_of(f.dat)[i] = i % 2 ? 1 : -1; }
  f.seal();
  initialize(f, reader, a, false);
  matrix(f, reader, a, "nonunit-successful-reinit", probes, seeds);
}

std::vector<std::string> other_words()
{ return {"0", "1", "2", "A", "AY", "K"}; }

void isolation()
{
  Fixture f("independent-A", normal_words()), g("independent-B", other_words());
  need(mapped_code(f.dat, "A") != mapped_code(g.dat, "A"), "maps must assign different A codes");
  const std::vector<std::string> probes{"A", "Y", utf8(0x4e2d)};
  const std::vector<Seed> seeds{{"root0", 0}, {"root1", 1}};
  TableAllocator a, b, fresh_alloc;
  Reader x(f.dat), y(g.dat), fresh(f.dat);
  matrix(f, x, a, "A-disabled", probes, seeds);
  matrix(g, y, b, "B-disabled", probes, seeds);
  initialize(g, y, b, false);
  matrix(g, y, b, "B-enabled", probes, seeds);
  matrix(f, x, a, "A-after-B-init", probes, seeds);
  initialize(f, x, a, false);
  matrix(f, x, a, "A-enabled", probes, seeds);
  matrix(g, y, b, "B-after-A-init", probes, seeds);
  matrix(f, fresh, fresh_alloc, "same-DAT-new-disabled-reader", probes, seeds);
  matrix(g, y, b, "B-after-new-A-reader", probes, seeds);
  need(fresh_alloc.calls == 0, "disabled reader allocated");
}

void lifetimes()
{
  const std::vector<std::string> probes{"A", "Y", utf8(0x4e2d)};
  const std::vector<Seed> seeds{{"root0", 0}, {"root1", 1}};
  std::optional<Reader> same_reader_storage;
  for (int generation = 0; generation < 2; ++generation) {
    Fixture f(generation == 0 ? "lifetime-generation0" : "lifetime-generation1",
              generation == 0 ? normal_words() : other_words());
    TableAllocator a, disabled_alloc;
    same_reader_storage.emplace(f.dat); // Identical reader object address, different map generation.
    initialize(f, *same_reader_storage, a, false);
    matrix(f, *same_reader_storage, a, "rebuilt-enabled", probes, seeds);
    same_reader_storage.reset(); // Reader ends BEFORE table allocator and pinned DAT.
    Reader disabled(f.dat);
    matrix(f, disabled, disabled_alloc, "fresh-disabled", probes, seeds);
    need(disabled_alloc.calls == 0, "fresh reader inherited allocation state");
  }
}
} // namespace

int main()
{
  try {
    OB_LOGGER.set_log_level("ERROR");
    ContextScope context;
    need(ObCharset::get_charset(CS_TYPE_UTF8MB4_BIN) != nullptr, "real UTF8MB4 charset unavailable");
    ordinary();                  // 36 * 7 * 4 * 2 * 5 = 10080 cases.
    boundaries();                // 12 * 3 * 4 * 2 * 2 * 8 = 4608 cases.
    quiescent_reinit();           // 12 * 3 * 4 * 2 * 4 = 1152 cases.
    isolation();                 // 3 * 2 * 4 * 2 * 8 = 384 cases.
    lifetimes();                 // 3 * 2 * 4 * 2 * 4 = 192 cases.
    need(cases == kExpectedCases, "incomplete fixed corpus");
    std::printf("PASS\tcases=%d\n", cases);
    return std::fflush(stdout) == 0 && !std::ferror(stdout) ? 0 : 1;
  } catch (const std::exception &e) {
    std::fprintf(stderr, "FAIL\tcase=%d\tphase=%s\t%s\n", cases, phase, e.what());
    return 1;
  }
}
