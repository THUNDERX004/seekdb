# Round 27 DAT root native correctness source

Frozen source: `test_dat_root.cpp`, SHA-256
`5316b2ae7b480fe6d73144237c1e0f73c7612d86f4328fcbd8d9cce937053009`.
The finite corpus is **16,416 cases**, with **98,496 full-field tuples**. This
directory is a source-only handoff. Its author has not compiled or executed the
test, built production, run SQL, accessed the database runtime, or used Git.
The parent owns actual original/candidate linking and execution in a separate
`round27-dat-root-build` sibling. Preserve this directory and the frozen TU.

## Actual production linkage

Compile this identical TU separately for the actual original and candidate
production variants, adapting the parent's round19/round16 native helper. Use
the production compile environment and storage archives, replacing observer
main with this TU. The test calls linked `ObFTDATReader<void>`,
`ObFTDATBuilder<void>`, `ObFTTrie<void>`, `ObArrayHashMap` and
`ObFTSingleWord` implementations. It neither includes production `.cpp` files
nor supplies substitutes for these symbols. C++17, the real memory context /
Flow setup, charset support and allocator dependencies are required.

For each variant, compile the TU with that variant's matching production
headers and link its freshly rebuilt production object/archives. Reader layout
can differ between variants. Pin both DAT header and implementation, actual
storage unity/object/archive inputs, shared dependencies, frozen test SHA,
commands, executable SHA and exit status in the parent's build/run receipts.
The observed original DAT source pins are in `source-pins.json`; they identify
the local accelerated original, not an independently retrieved official
competition baseline. Do not link a candidate-header TU to an original reader
object, or infer rebuilt object identity from the source hash alone.

The parent reports both actual original and candidate native executions passed
the same frozen TU: 16,416 cases and 114,913 records each, with identical full
stdout and stderr bytes. Parent-reported stdout SHA-256 is
`ca736bb5badb8c6a32143a5dd988121abd1f8ad3ef51d28898657e55ce41fedd`;
tuple-stream SHA-256 is
`2f261d6564ff94ab904632bf6de2e5ae071ecab7ada4fc3eef008f4f57acd499`.
These are parent-reported execution results, not sidecar-executed verification.
A
source repair after a concrete build failure must preserve the failed source
and receipt, obtain a new hash, and rebuild **both variants** from the same
repaired TU. This initial handoff does not contain build/run scripts.

## Independent generic oracle and output

Every test invocation calls actual production `match_with_hit` and a separate
generic reference in this TU. The reference always calls the real
`dat->get_map()->find`, then uses the original `abs(base[state]) + code` and
`check` transition. It never consults the BMP table or candidate private bound,
and contains no root shortcut. Bounds assertions establish safe fixture
indices before the actual reader is called.

The oracle preserves the original operation order: clear output flags before
lookup; missing code returns success without hit copy or root normalization;
known code uses the real hit assignment only for distinct output; normalize
state zero to one; then perform the original transition and updates. Thus it
preserves both the assignment operator's omission of `dict_` and restoration
of a true match flag on a distinct prefix-only transition. Full snapshots are
constructed by explicit public member writes, avoiding accidental dependence
on that incomplete assignment operator during setup.

Each deterministic stdout `CASE\t...` record identifies its case number,
fixture, phase, source state, incoming flags, alias mode and exact input bytes
as length plus hex. Six `T\t...` records follow, in this order:

1. `input.last`
2. `input.out`
3. `production.last`
4. `production.out`
5. `generic.last`
6. `generic.out`

Every tuple includes return code, `dict_`, `char_cnt_`, `start_pos_`,
`end_pos_`, `base_idx_`, `current_check_`, `is_match_` and `is_prefix_`.
Input snapshots have `ret=0` as pre-call metadata; production/reference tuples
contain the actual respective invocation return code. Both last and output
are compared explicitly, including distinct-input immutability. Aliased
output is the same hit as last. Real dictionary pointers are compared directly
in-process; stdout uses stable IDs 1/2 for two real sentinel dictionary
objects, with no ASLR addresses. Unknown pointers fail instead of being
normalized. The production hit equality operator is not the assertion oracle.

A successful run emits exactly 16,416 CASE lines, 98,496 T lines and one final
line `PASS\tcases=16416` (114,913 records total), returns zero, and has empty
stderr. `\t` denotes a literal tab in the actual stream. Expected structured
output is bounded below 32 MiB. No timestamps, durations, variant labels,
addresses or random values are emitted by the TU. Production info logging is
disabled in this native process; retain any unexpected library diagnostics in
the parent's raw logs and treat nonempty stderr as a gate failure.

Parent should retain and compare the complete original and candidate stdout
byte-for-byte, plus zero exit status, empty stderr, exact record counts and
the exact final PASS. Do not trim mismatching tuples or produce candidate
expectations from candidate output. Each variant also independently requires
all of its actual outputs to equal the generic oracle.

## Fixed schedule and coverage

| Group | Fixed schedule | Cases |
| --- | --- | ---: |
| Ordinary real trie | 36 probes × 7 states × 4 incoming flag combinations × 2 alias modes × 5 table phases | 10,080 |
| Manual boundary/fallback DATs | 12 probes × 3 states × 4 flags × 2 alias modes × 2 phases × 8 fixtures | 4,608 |
| Private fixture reinitialization | 12 probes × 3 states × 4 flags × 2 alias modes × 4 phases | 1,152 |
| Independent readers/maps | 3 probes × 2 states × 4 flags × 2 alias modes × 8 matrices | 384 |
| Destroy/rebuild generations | 3 probes × 2 states × 4 flags × 2 alias modes × 4 matrices | 192 |
| Total | No optional skips or argument-controlled cases | **16,416** |

Ordinary fixtures use actual UTF8MB4 trie insertion and the real builder. The
temporary trie allocator ends before matching; the independently owned DAT
remains pinned. Root states zero and one and continuations after ASCII,
CJK and non-BMP input are exercised, including terminal+prefix, prefix-only,
terminal-leaf and their continuation misses. Root absence is tested both as
an unmapped byte key and as a mapped descendant-only character. Positions,
counts, `current_check_`, output base and dictionary pointers have deliberately
different sentinels. Every pair of incoming match/prefix flags is covered,
with initially true flags in the distinct output sentinel.

Canonical inputs include NUL, ASCII, U+007F/U+0080, U+07FF/U+0800,
U+D7FF/U+E000, U+FFFF, CJK, U+1F642 and U+10FFFF. Miss probes include absent
BMP and non-BMP characters, empty input, isolated continuation/lead bytes,
truncated two/three/four-byte sequences, overlong encodings, surrogate UTF-8,
above-U+10FFFF bytes, bad continuation bytes, five-byte input, 0xFF, multi-ASCII
keys and embedded NUL. All keys are non-null and within the actual
`ObFTSingleWord::MAX_MB_LEN` storage policy (the constant is on `ObCharset`).

Eight manual DATs cover the minimum array with one root destination, a dense
root prefix ending at the last array entry, a hole at code two (code=limit,
limit+1 miss and later root success), a hole at code one (zero validated
coverage but later real successes), root bases +3/-3/0 and a byte-key boundary
layout. The last fixture maps malformed, empty, non-BMP and multiple-character
byte keys through the real map, so fallback covers successful lookups as well
as missing keys. These layouts are intentionally outside what the normal
UTF8MB4 trie builder produces; arrays remain safe for all requested root and
continuation transitions. Manual fixture construction uses public DAT fields
and real map init/insert, not private reader access or a replacement matcher.

The ordinary five phases are never initialized, first allocation failure,
successful table initialization, failure after prior success, and successful
reinitialization. Failed optional allocation must retain return-success and
correct generic behavior. Each successful initialization allocates exactly
the existing 256 KiB code table; no second table is permitted. All 65,536
slots are checked independently via generated canonical UTF-8 and real map
find (surrogate slots must remain zero), then frozen for mutation checks.
Guards bracket each actual arena-backed allocation, and every prior table
allocation stays alive through reader destruction. DAT/map bytes are compared
before and after each matrix and initialization.

The private reinitialization fixture first initializes a dense root, then
introduces a first-code hole and forces allocation failure, then initializes
a middle-code hole successfully, then initializes a nonunit root successfully.
These edits occur only to a test-owned synthetic block between calls, with
the same map codes and all storage alive. This makes stale success bounds
observable through the public reader result. No published dictionary or
concurrent reader is mutated. It is a defensive reader-reinit test, not a
claim that production permits concurrent or in-place dictionary reload.

Isolation matrices interleave two actual DATs assigning different codes to
`A`, initialize their readers in opposite order, and introduce a new disabled
reader for an already initialized DAT. Lifetime matrices destroy the reader
before its table/DAT storage and rebuild a different generation in the same
reader object storage. They do not require the allocator to reuse a DAT
address, and never dereference expired hits, maps, tables or readers.

## Interpretation limits

This source does not inspect `root_code_limit_`, reproduce the proposed fast
algorithm, or count actual fast-path execution. Known fixture arrays establish
test opportunities; only parent-owned actual instrumentation can establish
which path ran or its frequency. Native correctness does not prove speedup,
SQL/parser integration, concurrency safety, sanitizers, Linux/platform
evaluation, INT32_MAX-sized array behavior, or all malformed dictionary layouts.
The guard bytes detect writes, not all out-of-bounds reads. Invalid pointers,
overlong-than-storage keys, negative codes and arbitrary corrupted DATs are
outside the safe fixture contract.
