# Round 30 CJK live-hit public API fixture

Status: **FROZEN SOURCE; NOT COMPILED / NOT RUN by this sidecar.**
The parent owns staging, actual production linking and serial execution.
The frozen TU is `test_cjk_hits.cpp`; its exact SHA-256 and the documentation
hashes are in `SHA256SUMS` and `freeze.json`. No production sources, build
configuration, Git state, SQL fixtures or runtime were changed here.

## Fixed corpus

Exactly **20 cases**: these ten documents in maxword (`is_smart=false`) and
smart (`is_smart=true`) contexts, in the same order. No optional skips or flags.

1. 132 repeated Chinese characters, requiring at least 96 continuation calls
   in one step. These correspond to distinct simultaneously live prefixes;
   this exercises growth beyond both 8 and 64 without inspecting capacity.
2. A 120-character repeating Chinese triple, requiring at least eight live
   continuations. Its roots route to distinct real child dictionary objects;
   different maximum word lengths force holes among surviving prefixes.
3. Delimiters, including embedded NUL, flush live prefixes. Words containing
   those delimiters deliberately exist in the word set but must not cross a flush.
4. Valid UTF-8 with 1/2/3/4-byte characters, NUL, ASCII letter/digit,
   fullwidth letter, hiragana and Hangul. Under the actual classifier, the
   two-byte accented character and four-byte emoji are delimiters; they are
   not forced into a useful-character class.
5. Terminal words with and without longer descendants, and leaf retention.
6. Last-character processing with still-unfinished prefixes.
7. An all-miss next document, checking that the reused processor was cleared.
8. Public `reset_resource()` during live prefixes; token results and handle
   count reset, while later cross-reset tokens still use valid original backing.
9. A continuation returns `OB_ERR_UNEXPECTED` after a valid state mutation,
   at character 70/start 31, with partial earlier tokens preserved. The harness
   explicitly steps to the next character to test cleared-state recovery.
10. A root call returns that error after valid mutation at character 12;
    earlier continuation tokens remain and subsequent characters recover.

Each mode has an independent dictionary, allocator and processor. A processor
is reused sequentially for all ten documents. This does not test interleaving
or concurrent use. Document backing, dictionary objects, memory context and
arena remain alive for every call and token inspection; objects are destroyed
before their backing allocator. Inputs are well-formed and bounded.

## Actual production API and independent oracle

The TU calls linked production `ObIKCJKProcessor::do_process` and actual
`TokenizeContext` stepping, reset and token-list APIs. It uses the actual
`ObArenaAllocator`, `ObDATrieHit`, `ObIFTDict` interface and token structures.
There is no production `.cpp` inclusion, alternate CJK processor algorithm,
private-state access, private `sizeof`, or fabricated container representation.

The synthetic dictionary implements immutable word sets as immutable prefix
states. A public router delegates to separate child `ObIFTDict` objects, as a
range dictionary does. Children have disjoint state IDs. Valid continuation
input/output aliasing is snapshotted before writes. All eight hit fields are
recorded and checked: actual `dict_` identity, character count, start, end,
base, check, match and prefix. Unknown pointers fail. Strict-leaf and DAT-like
terminal-prefix flags are both represented. This is a controlled dictionary
contract test; it does not exercise the production DAT builder or dictionary
cache implementation.

The token oracle enumerates document substrings against complete explicit
words, sorts by offset ascending/length descending, and checks the complete
token list after every character, including bytes, offsets, lengths, character
counts, type and exact original-text pointer. It does not maintain a second
active-hit container. A separate substring-prefix enumeration checks the
complete ordered dictionary-call sequence; prefix IDs are fixture metadata,
not production DAT expectations. This detects reordered survivors and missing
or altered child identity even where final token membership might coincide.

## Output and parent comparison

A successful execution must return zero, have empty stderr, emit exactly 20
`CASE\t...` records, and finish with `PASS\tcases=20` plus newline.
`T\t...` records contain every token after every step; `D\t...` records contain
ordered outer dictionary calls, input bytes, alias indicator, return code and
all before/after hit fields. `R` records contain reset/process/step results;
`END` records contain final context returns and observed continuation counts.
The dictionary pointer is checked directly in-process and printed as a stable
identity; the token pointer is checked directly and printed as `fulltext`.
No ASLR addresses, elapsed times, binary variant labels or random data appear.

Build this **identical TU** separately with each variant's matching production
headers and actual rebuilt production archive/objects. Since the processor's
layout may change, never mix original headers with candidate objects or vice
versa. The parent's original CJK `.cpp/.h` snapshots are pinned separately in
`source-pins.json`; live source observations are not proof of archive identity.
Keep actual command/ABI/link-input/executable hashes and exit receipts in the
parent's build directory. The sidecar supplies no replacement production symbols.

Capture stdout/stderr as complete binary files independently for candidate
and restored original. Compare their **entire stdout bytes**, byte lengths
and SHA-256, not only `T` records; also check exact final PASS, CASE count,
zero exits and empty stderr for both. Each binary independently must satisfy
the substring oracle. Do not generate a candidate expectation by recording
candidate output. A source repair after a concrete failure requires a new
hash and using that same repaired TU for both variants.

## Explicit limits

This sidecar has performed source authoring and offline hashing only. There is
no native pass, integration pass, SQL result or performance result here. Mode
flags are checked, but arbitration, stopwords and final full-parser smart
segmentation are outside this focused CJK-processor test.

The original root path ignores `hits_.push_back` and `ctx.add_token` return
values; this fixture does not alter or simulate them. No allocation-failure
injection, allocation ordinal equivalence, allocation count equivalence,
immediate-free allocator, exception-safety or sanitizer claim is made. The
original list erases a node while its iterator is subsequently incremented.
The actual arena's public `free` is a no-op, retaining that backing until arena
destruction, as in the parser's arena usage. This fixture does not provoke
reclaimed-node crashes, repair that original limitation, or prove safety under
another allocator. The focused dictionary-error recovery deliberately resumes
after stepping; the full parser normally returns the error to its caller.
Exact duplicate live hits from artificial repeated calls at an unchanged
cursor, distinct-output dictionary alias modes and arbitrary corrupt inputs
are not tested. Repeated equal input symbols retain distinct valid positions.
