# Round 30 CJK live-hit experiment: rejected archive

This helper only reads frozen auxiliary inputs and writes its own `package/`.
It never executes an imported helper, compiler, executable, SQL client or Git,
and does not access or modify D files. The parent owns publication and Git.

Final gates are the actual `round30-cjk-hits-build/decision.json`, exact-source
snapshots/restoration record and successful restoration log, both native
build/run receipts, complete stdout/stderr, and `parent-output-verification.json`.
`archive.py --execute` refuses missing or inconsistent gates and an existing
package. Historical proposal/native metadata saying not applied/not run is
preserved byte-for-byte; it predates the separate parent execution receipts.

The explicit selection includes all three proposal files, all five frozen
native files, round30 source snapshots/helpers/receipts/compile/link commands
and logs, both full native outputs, all eleven SQL action logs and receipt,
four complete benchmark reports/receipts/log sets, both immutable comparisons,
candidate/restoration build logs, and these archival scripts/snippets.
Three exact reused helper dependencies (round16 native link utility, round19
strict summarizer, round27 exit-aware experiment harness) are included as
source only. No prior-round measurements or extra experiments are selected.

Every input is gzip-packed from raw bytes, with raw/packed byte counts and
SHA-256 in `package/manifest.json`. All text is compressed, including the two
18.7 MB native stdout streams; no newline conversion or transcript trimming
is performed. Binaries, objects, libraries, PDB/DLL, link intermediates, tmp,
runtime/data, credential files and unrelated server logs are excluded.
The small per-run server-console logs are included. Each stdout is bounded
to 64 MiB, other inputs to 4 MiB and total raw inputs to 96 MiB.

From the workspace root, after final gates only:

```powershell
& ./.venv/Scripts/python.exe -B -X utf8 setup/fts/round30-cjk-hits-evidence/archive.py --execute
& ./.venv/Scripts/python.exe -B -X utf8 setup/fts/round30-cjk-hits-evidence/verify_archive.py
```

Copy the contents of `package` unchanged to the parent's chosen assets
directory. A copied package can be verified with `verify_archive.py --package
<destination> --source-root <workspace-setup/fts>`; `--packed-only` omits the
independent source-file comparison. The verifier writes no files. Store its
JSON stdout outside the immutable package. `report.en.md` and `report.zh-CN.md`
are concise proposed sections for parent publication, not D edits by this helper.

The result is REJECTED: two local complete pairs give equal-category overall
time reduction -0.308969%, target IK +1.431889%. No production or established
test promotion; no new formal result, cumulative result, full score, stability
or causal explanation of untouched metrics. Native PASS means the finite
20-case fixture passed on both actual linked variants with identical complete
170,541-line stdout and empty stderr. It does not prove every input, allocator,
OOM schedule, Linux or sanitizer behavior. The original list/arena limitations
remain documented in the frozen fixture README.
