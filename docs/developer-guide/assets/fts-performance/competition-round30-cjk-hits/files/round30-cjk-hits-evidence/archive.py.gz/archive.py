"""Create the bounded C-only round30 archive AFTER the parent's final gates.

No imported experiment/build helpers are executed. All inputs are read-only.
"""
from __future__ import annotations

import argparse
import gzip
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
FTS = HERE.parent
BUILD = FTS / 'round30-cjk-hits-build'
DEST = HERE / 'package'
TEST_SHA = '22a3087af260d37540dcc674f421d673858e385fdb62a3b831f9053da037332e'
STDOUT_SHA = '61b6344b29cfb687895d6f2637625c16ef3190490c720d15e836b1f13f3d6693'
EXPERIMENT = 'round30-cjk-live-hits-rejected'
DEPENDENCIES = (
    'round16-row-native/prepare_fts_lazy_rows.py',
    'round19-evidence/summarize-template.py',
    'round27-root-evidence/experiment-with-exit.py',
)
BENCH_LABELS = tuple('r30-cjk-hits-' + variant + '-a' + str(pair)
                    for pair in (1, 2) for variant in ('control', 'candidate'))
SQL_LABEL = 'r30-cjk-hits-candidate-regression-a1'
SQL_ACTIONS = ('casecopy', 'bmp', 'ranked', 'keytypes', 'test_hot_path.py',
               'test_tokenize_config.py', 'test_collation.py', 'test_match_batches.py',
               'test_map_concurrency.py', 'test_stopword_concurrency.py', 'test_dictionary_prefixes.py')


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def load(path):
    return json.loads(path.read_bytes())


def write_json(path, value):
    with path.open('xb') as stream:
        stream.write((json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n').encode('utf-8'))


def selection():
    """Exact allowlist; never recurse into builds, runtime, temp or other rounds."""
    result = set()

    def add(relative):
        path = FTS / relative
        require(path.is_file() and path.resolve().is_relative_to(FTS), 'Missing/outside input: ' + relative)
        require(not path.is_symlink(), 'Symlink input: ' + relative)
        parts = tuple(part.lower() for part in Path(relative).parts)
        require(not any(part in {'.git', '.secrets', 'tmp', 'temp', 'runtime', 'data'} for part in parts),
                'Excluded directory input: ' + relative)
        require(path.suffix.lower() not in {'.exe', '.obj', '.lib', '.pdb', '.dll', '.tmp', '.res'},
                'Excluded binary input: ' + relative)
        limit = 64 * 1024 * 1024 if path.name == 'stdout.log' else 4 * 1024 * 1024
        require(path.stat().st_size <= limit, 'Oversized input; review explicitly: ' + relative)
        result.add(path)

    for name in ('cjk-hits.patch', 'report.md', 'source-pins.json'):
        add('round30-cjk-hits-proposal/' + name)
    for name in ('test_cjk_hits.cpp', 'README.md', 'source-pins.json', 'freeze.json', 'SHA256SUMS'):
        add('round30-cjk-hits-native/' + name)
    for name in ('application.json', 'binary.json', 'build_native.py', 'build.ps1',
                 'candidate-ob_ik_cjk_processor.cpp', 'candidate-ob_ik_cjk_processor.h',
                 'comparison-1pair.json', 'comparison-2pair.json', 'decision.json', 'manage.py',
                 'original-ob_ik_cjk_processor.cpp', 'original-ob_ik_cjk_processor.h',
                 'parent-output-verification.json', 'preparation.json', 'restoration.json',
                 'run_native.py', 'staging.json', 'summarize.py', 'test_cjk_hits.cpp', 'verify_pair.py'):
        add('round30-cjk-hits-build/' + name)
    for variant in ('control', 'candidate'):
        for name in ('receipt.json', 'compile.log', 'link.log', 'compile.rsp', 'link-inputs.rsp'):
            add('round30-cjk-hits-build/' + variant + '-build1/' + name)
        for name in ('run.json', 'build-receipt.json', 'stdout.log', 'stderr.log'):
            add('round30-cjk-hits-build/' + variant + '-run1/' + name)
    for label in BENCH_LABELS:
        for suffix in ('report.txt', 'experiment.json', 'benchmark.log', 'input-validation.log', 'server.log'):
            add(label + '-' + suffix)
    for action in SQL_ACTIONS:
        add(SQL_LABEL + '-' + action + '.log')
    for suffix in ('experiment.json', 'server.log'):
        add(SQL_LABEL + '-' + suffix)
    for name in ('round30-cjk-hits-candidate-build.log', 'round30-cjk-hits-restoration-build.log'):
        add(name)
    for name in DEPENDENCIES:
        add(name)
    for name in ('archive.py', 'verify_archive.py', 'README.md', 'report.en.md', 'report.zh-CN.md', 'syntax-check.json'):
        add('round30-cjk-hits-evidence/' + name)
    require(sum(path.stat().st_size for path in result) <= 96 * 1024 * 1024, 'Raw archive budget exceeded')
    return sorted(result, key=lambda path: path.relative_to(FTS).as_posix())


def validate_final_inputs():
    decision = load(BUILD / 'decision.json')
    require(decision['status'] == 'REJECTED_RESTORED_EXACT', 'Parent final rejection/restoration gate missing')
    require(decision['restoration_build'].startswith('PASS'), 'Parent restoration build gate missing')
    require(load(BUILD / 'restoration.json')['status'] == 'RESTORED_EXACT', 'Missing source restoration record')
    require(b'Linking CXX executable' in (FTS / 'round30-cjk-hits-restoration-build.log').read_bytes(),
            'Restoration linking evidence missing')
    pins = load(FTS / 'round30-cjk-hits-proposal/source-pins.json')
    for item in pins['artifacts']:
        raw = (FTS / 'round30-cjk-hits-proposal' / item['path']).read_bytes()
        require(sha(raw) == item['sha256'] and len(raw) == item['bytes'], 'Proposal identity mismatch')
    for target in pins['targets']:
        for prefix, key in (('original-', 'preimage_sha256'), ('candidate-', 'candidate_sha256')):
            raw = (BUILD / (prefix + Path(target['path']).name)).read_bytes()
            require(sha(raw) == target[key], 'Source snapshot identity mismatch')
    frozen = FTS / 'round30-cjk-hits-native'
    for line in (frozen / 'SHA256SUMS').read_text(encoding='ascii').splitlines():
        digest, name = line.split('  ', 1)
        require(Path(name).name == name and sha((frozen / name).read_bytes()) == digest, 'Frozen artifact mismatch')
    require(sha((frozen / 'test_cjk_hits.cpp').read_bytes()) == TEST_SHA, 'Wrong frozen TU')
    require((BUILD / 'test_cjk_hits.cpp').read_bytes() == (frozen / 'test_cjk_hits.cpp').read_bytes(), 'Staged TU differs')

    comparison = load(BUILD / 'comparison-2pair.json')
    require(comparison['status'] == 'COMPLETE' and comparison['completed_pairs'] == 2, 'Two-pair gate incomplete')
    require(decision['aggregate'] == comparison['aggregate'], 'Final decision/immutable comparison disagree')
    for count in (1, 2):
        comp = load(BUILD / ('comparison-' + str(count) + 'pair.json'))
        require(comp['status'] == 'COMPLETE' and comp['completed_pairs'] == count, 'Missing immutable comparison')
        for name, pin in comp['input_hashes'].items():
            require(Path(name).name == name, 'Unsafe comparison input name')
            raw = (FTS / name).read_bytes()
            require(sha(raw) == pin['sha256'] and len(raw) == pin['bytes'], 'Comparison input changed: ' + name)
    for label in BENCH_LABELS:
        receipt = load(FTS / (label + '-experiment.json'))
        require(receipt['affinity_mask_verified'] == 15 and receipt['log_level'] == 'WARN', 'Timing environment mismatch')
        require(receipt['owned_server_exit_before_cleanup'] is None, 'Server exited before cleanup')
        require({x['action'] for x in receipt['actions']} == {'benchmark', 'input-validation'}
                and all(x['exit_code'] == 0 for x in receipt['actions']), 'Incomplete timing actions')
    sql = load(FTS / (SQL_LABEL + '-experiment.json'))
    require({x['action'] for x in sql['actions']} == set(SQL_ACTIONS)
            and all(x['exit_code'] == 0 for x in sql['actions']), 'SQL gate incomplete')

    proof = load(BUILD / 'parent-output-verification.json')
    require(proof['status'] == 'PASS' and proof['complete_stdout_equal'] is True, 'Native differential pending')
    require(proof['test_sha256'] == TEST_SHA and proof['cases'] == 20
            and proof['stdout_sha256'] == STDOUT_SHA and proof['complete_lines'] == 170541, 'Unexpected native proof')
    outputs = []
    counts = {}
    for variant in ('control', 'candidate'):
        build = BUILD / (variant + '-build1')
        run = BUILD / (variant + '-run1')
        receipt = load(build / 'receipt.json')
        require(receipt.get('build_succeeded') is True
                and receipt['compile']['exit_code'] == receipt['link']['exit_code'] == 0, 'Native build incomplete')
        require(receipt['production_sha256_before'] == receipt['production_sha256_after'], 'Native input identity drift')
        require(receipt['test_sha256'] == TEST_SHA and receipt['expected_cases'] == 20, 'Native build TU mismatch')
        target_cpp = next(x for x in pins['targets'] if x['path'].endswith('.cpp'))
        target_h = next(x for x in pins['targets'] if x['path'].endswith('.h'))
        key = 'preimage_sha256' if variant == 'control' else 'candidate_sha256'
        require(receipt['expected_source_sha256'] == target_cpp[key]
                and receipt['expected_header_sha256'] == target_h[key], 'Variant source/header mismatch')
        require(sha((FTS / DEPENDENCIES[0]).read_bytes()) == receipt['helper_sha256'], 'Actual native helper changed')
        require(sha((BUILD / 'build_native.py').read_bytes()) == receipt['builder_sha256'], 'Native builder changed')
        for stage in ('compile', 'link'):
            require(sha((build / (stage + '.log')).read_bytes()) == receipt[stage]['log_sha256'], 'Build log identity mismatch')
        require((run / 'build-receipt.json').read_bytes() == (build / 'receipt.json').read_bytes(), 'Run/build receipts differ')
        record = load(run / 'run.json')
        raw = (run / 'stdout.log').read_bytes()
        require(record == proof['variants'][variant], 'Final native proof differs from run receipt')
        require(record['exit_code'] == 0 and record['output_validation'] == 'PASS'
                and record['test_sha256'] == TEST_SHA and record['expected_cases'] == 20, 'Native run gate incomplete')
        require(record['executable_sha256'] == receipt['executable_sha256'], 'Run/build executable identity mismatch')
        require(sha(raw) == record['stdout_sha256'] == STDOUT_SHA, 'Native stdout identity mismatch')
        require(not (run / 'stderr.log').read_bytes()
                and record['stderr_sha256'] == sha(b''), 'Unexpected native stderr')
        lines = raw.splitlines()
        require(len(lines) == 170541 and lines[-1] == b'PASS\tcases=20'
                and sum(line.startswith(b'CASE\t') for line in lines) == 20, 'Native record counts/PASS mismatch')
        counts[variant] = {name: sum(line.startswith((name + '\t').encode()) for line in lines)
                           for name in ('CASE', 'D', 'T', 'R', 'END', 'PASS')}
        outputs.append(raw)
    require(outputs[0] == outputs[1], 'Native complete stdout mismatch')
    return comparison, counts


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true', help='Required explicit final-package action')
    args = parser.parse_args()
    require(args.execute, 'Preparation only. After parent final gates, pass --execute.')
    require(HERE.name == 'round30-cjk-hits-evidence' and not DEST.exists(), 'Fresh C evidence/package required')
    require(DEST.parent == HERE, 'Fixed helper-owned destination required')
    comparison, counts = validate_final_inputs()
    selected = selection()
    # Input identities are captured before writing; no benchmark/helper is imported.
    initial = {path: (path.stat().st_size, sha(path.read_bytes())) for path in selected}
    DEST.mkdir()
    entries = []
    for path in selected:
        relative = path.relative_to(FTS).as_posix()
        raw = path.read_bytes()
        require((len(raw), sha(raw)) == initial[path], 'Input changed during packaging: ' + relative)
        packed = gzip.compress(raw, compresslevel=9, mtime=0)
        out = DEST / 'files' / (relative + '.gz')
        out.parent.mkdir(parents=True, exist_ok=True)
        with out.open('xb') as stream:
            stream.write(packed)
        require(gzip.decompress(packed) == raw, 'Internal gzip exact-byte failure')
        entries.append(dict(source=relative, path='files/' + relative + '.gz',
                            raw_bytes=len(raw), raw_sha256=sha(raw),
                            packed_bytes=len(packed), packed_sha256=sha(packed)))
    for path, before in initial.items():
        require((path.stat().st_size, sha(path.read_bytes())) == before, 'Input changed before completion')
    manifest = dict(schema=1, experiment=EXPERIMENT, decision='REJECTED_RESTORED_EXACT',
                    completed_pairs=2, promotion='NONE; no production or established-test promotion',
                    native=dict(status='PASS', cases=20, complete_lines=170541,
                                stdout_sha256=STDOUT_SHA, actual_record_counts=counts),
                    aggregate=comparison['aggregate'],
                    provenance=dict(source='Exact proposal and C source snapshots; parent restoration decision/log',
                                    native='Actual parent build/run receipts and complete stdout/stderr, independently rechecked offline',
                                    historical_pending_statuses='Original proposal/frozen helper metadata preserved unchanged; final decision governs execution outcome',
                                    helper_dependencies=list(DEPENDENCIES)),
                    limits='Local two-pair incremental experiment only; no formal/cumulative/full-score or causal-untouched-metric claim. No live binary packaged or D files accessed by archiver.',
                    files=entries)
    write_json(DEST / 'manifest.json', manifest)
    manifest_sha = sha((DEST / 'manifest.json').read_bytes())
    result = dict(status='COMPLETE', file_count=len(entries), manifest_sha256=manifest_sha,
                  raw_bytes=sum(x['raw_bytes'] for x in entries), packed_bytes=sum(x['packed_bytes'] for x in entries))
    write_json(DEST / 'COMPLETE.json', result)
    write_json(HERE / 'archive-summary.json', dict(result, package=str(DEST), execution='C-only exact-byte archive; no build/native/SQL/Git'))
    print(json.dumps(dict(result, package=str(DEST)), ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
