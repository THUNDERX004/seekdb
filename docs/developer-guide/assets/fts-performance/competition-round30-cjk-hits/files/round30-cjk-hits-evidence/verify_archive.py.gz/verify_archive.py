"""Read-only verification of the copied/self-contained round30 exact-byte package."""
import argparse
import gzip
import hashlib
import json
from pathlib import Path, PurePosixPath

HERE = Path(__file__).resolve().parent
FTS = HERE.parent


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--package', type=Path, default=HERE / 'package')
    parser.add_argument('--source-root', type=Path, default=FTS,
                        help='Original setup/fts root for independent source-byte verification')
    parser.add_argument('--packed-only', action='store_true', help='Verify portable archive without original auxiliary sources')
    args = parser.parse_args()
    root, source_root = args.package.resolve(), args.source_root.resolve()
    raw_manifest = (root / 'manifest.json').read_bytes()
    manifest = json.loads(raw_manifest)
    complete = json.loads((root / 'COMPLETE.json').read_bytes())
    require(manifest['experiment'] == 'round30-cjk-live-hits-rejected'
            and manifest['decision'] == 'REJECTED_RESTORED_EXACT'
            and manifest['completed_pairs'] == 2, 'Wrong experiment/decision')
    require(complete['status'] == 'COMPLETE' and complete['manifest_sha256'] == sha(raw_manifest), 'Incomplete package')
    expected = {'manifest.json', 'COMPLETE.json'}
    sources = set()
    raw_total = packed_total = 0
    for entry in manifest['files']:
        relative = PurePosixPath(entry['source'])
        require(not relative.is_absolute() and '..' not in relative.parts and ':' not in str(relative)
                and '\\' not in str(relative), 'Unsafe manifest path')
        require(entry['path'] == 'files/' + str(relative) + '.gz'
                and entry['path'] not in expected and str(relative) not in sources, 'Duplicate/mismatched path')
        packed_path = root / entry['path']
        require(packed_path.resolve().is_relative_to(root), 'Archive path escapes package')
        packed = packed_path.read_bytes()
        require(len(packed) == entry['packed_bytes'] and sha(packed) == entry['packed_sha256'], 'Packed identity mismatch')
        raw = gzip.decompress(packed)
        require(len(raw) == entry['raw_bytes'] and sha(raw) == entry['raw_sha256'], 'Raw identity mismatch')
        if not args.packed_only:
            source_path = source_root / str(relative)
            require(source_path.resolve().is_relative_to(source_root)
                    and source_path.read_bytes() == raw, 'Original source bytes differ: ' + str(relative))
        raw_total += len(raw)
        packed_total += len(packed)
        expected.add(entry['path'])
        sources.add(str(relative))
    require(len(manifest['files']) == complete['file_count'] and raw_total == complete['raw_bytes']
            and packed_total == complete['packed_bytes'], 'Package totals mismatch')
    require({p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()} == expected, 'Extra/missing package files')
    print(json.dumps(dict(status='PASS', file_count=complete['file_count'],
                          manifest_sha256=sha(raw_manifest), raw_bytes=raw_total, packed_bytes=packed_total,
                          packed_raw_bytes='ALL MATCH',
                          original_source_bytes='NOT CHECKED' if args.packed_only else 'ALL MATCH',
                          execution='Offline verification only; no workload/build/Git'), indent=2))


if __name__ == '__main__':
    main()
