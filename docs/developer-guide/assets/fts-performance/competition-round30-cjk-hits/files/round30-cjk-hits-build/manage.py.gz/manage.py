"""Bounded, hash-checked round30 preparation, source application, and binary pinning."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil

HERE = Path(__file__).resolve().parent
ROOT = Path('D:/Projects/OceanBase/seekdb')
PROPOSAL = HERE.parent / 'round30-cjk-hits-proposal'
FIXTURE = HERE.parent / 'round30-cjk-hits-native/test_cjk_hits.cpp'
TEST = ROOT / 'unittest/storage/fts/test_cjk_hits.cpp'
PATCH_SHA = '41b4c5e99f33d5c0457010bf6c0b1bdcb8af10a76c557a3b9179bf1121925034'

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def save(name, value):
    with (HERE / name).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')

def targets():
    return json.loads((PROPOSAL / 'source-pins.json').read_text(encoding='utf-8'))['targets']

def prepare():
    patch = (PROPOSAL / 'cjk-hits.patch').read_bytes()
    assert sha(patch) == PATCH_SHA
    lines = patch.splitlines(keepends=True)
    index = 0
    records = []
    for item in targets():
        rel = item['path']
        old = (ROOT / rel).read_bytes()
        assert sha(old) == item['preimage_sha256']
        assert lines[index] == b'--- a/' + rel.encode() + b'\n'
        assert lines[index+1] == b'+++ b/' + rel.encode() + b'\n'
        index += 2
        old_lines = old.splitlines(keepends=True)
        output, cursor = [], 0
        while index < len(lines) and lines[index].startswith(b'@@ '):
            match = re.fullmatch(rb'@@ -(\d+),(\d+) \+(\d+),(\d+) @@\n', lines[index])
            assert match
            start, old_count, new_start, new_count = map(int, match.groups())
            index += 1
            before, after = [], []
            while index < len(lines) and lines[index][:1] in (b' ', b'-', b'+') and not lines[index].startswith(b'--- a/'):
                line = lines[index]
                if line[:1] in (b' ', b'-'): before.append(line[1:])
                if line[:1] in (b' ', b'+'): after.append(line[1:])
                index += 1
            assert len(before) == old_count and len(after) == new_count
            assert cursor <= start-1 and old_lines[start-1:start-1+old_count] == before
            output.extend(old_lines[cursor:start-1])
            assert len(output) == new_start-1
            output.extend(after)
            cursor = start-1+old_count
        new = b''.join(output + old_lines[cursor:])
        assert sha(new) == item['candidate_sha256']
        name = Path(rel).name
        for prefix, raw in [('original-', old), ('candidate-', new)]:
            with (HERE / (prefix + name)).open('xb') as stream:
                stream.write(raw)
        records.append(dict(path=rel, original_sha256=sha(old), candidate_sha256=sha(new)))
    assert index == len(lines)
    base = HERE.parent / 'round29-arbitrator-build/build_native.py'
    raw = base.read_bytes()
    builder = raw.decode('utf-8').replace('ob_ik_arbitrator', 'ob_ik_cjk_processor').replace('test_arbitrator_decode', 'test_cjk_hits').replace('IK arbitrator', 'IK CJK processor')
    with (HERE / 'build_native.py').open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(builder)
    save('preparation.json', dict(targets=records, patch_sha256=sha(patch), builder_base_sha256=sha(raw), builder_sha256=sha((HERE/'build_native.py').read_bytes()), execution='Source snapshots and helper only; no D writes/build/native/SQL'))
    print('PREPARED verified two-file source snapshots and production-link helper')

def stage(cases):
    assert 0 < cases <= 100000
    assert not TEST.exists() and not (HERE / FIXTURE.name).exists()
    raw = FIXTURE.read_bytes()
    assert b'ObIKCJKProcessor' in raw and b'#define private' not in raw
    (HERE / FIXTURE.name).write_bytes(raw)
    TEST.write_bytes(raw)
    assert TEST.read_bytes() == raw
    save('staging.json', dict(test_sha256=sha(raw), expected_cases=cases, staged=str(TEST)))
    print('STAGED same frozen native TU', sha(raw), cases)

def apply():
    assert not (HERE / 'application.json').exists()
    originals = []
    for item in targets():
        path = ROOT / item['path']
        assert sha(path.read_bytes()) == item['preimage_sha256']
        raw = (HERE / ('candidate-' + path.name)).read_bytes()
        assert sha(raw) == item['candidate_sha256']
        originals.append((path, raw))
    for path, raw in originals:
        path.write_bytes(raw)
        assert path.read_bytes() == raw
    save('application.json', dict(status='APPLIED', patch_sha256=PATCH_SHA, targets=targets()))
    print('APPLIED verified CJK storage proposal')

def pin():
    for item in targets():
        assert sha((ROOT / item['path']).read_bytes()) == item['candidate_sha256']
    output = ROOT / 'build/fts-round30-cjk-hits-candidate'
    build = ROOT / 'build_fts_competition/src/observer'
    assert not output.exists()
    output.mkdir()
    files = {}
    for source in [build/'seekdb.exe', build/'seekdb.pdb', *sorted(build.glob('*.dll'))]:
        digest = sha(source.read_bytes())
        shutil.copy2(source, output / source.name)
        assert sha((output/source.name).read_bytes()) == digest
        files[source.name] = dict(bytes=source.stat().st_size, sha256=digest)
    save('binary.json', dict(output=str(output), files=files))
    print('PINNED', files['seekdb.exe']['sha256'])

def restore():
    assert not (HERE / 'restoration.json').exists()
    writes = []
    for item in targets():
        path = ROOT / item['path']
        assert sha(path.read_bytes()) == item['candidate_sha256']
        raw = (HERE / ('original-' + path.name)).read_bytes()
        assert sha(raw) == item['preimage_sha256']
        writes.append((path, raw))
    for path, raw in writes:
        path.write_bytes(raw)
        assert path.read_bytes() == raw
    save('restoration.json', dict(status='RESTORED_EXACT', purpose='Run identical native TU against original storage; final optimization decision remains pending', targets=targets()))
    print('RESTORED exact original CJK source/header')

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['prepare', 'stage', 'apply', 'pin', 'restore'])
    parser.add_argument('--cases', type=int)
    args = parser.parse_args()
    if args.action == 'stage': stage(args.cases)
    else: globals()[args.action]()
