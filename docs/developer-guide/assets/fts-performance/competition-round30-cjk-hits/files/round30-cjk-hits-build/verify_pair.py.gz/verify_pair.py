"""Read-only full-output comparison after both actual production variants pass."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
records = {}
outputs = {}
for variant in ('control', 'candidate'):
    root = HERE/(variant+'-run1')
    record = json.loads((root/'run.json').read_text(encoding='utf-8'))
    raw = (root/'stdout.log').read_bytes()
    assert record['variant'] == variant and record['exit_code'] == 0 and record['output_validation'] == 'PASS'
    assert hashlib.sha256(raw).hexdigest() == record['stdout_sha256']
    assert not (root/'stderr.log').read_bytes()
    records[variant] = record
    outputs[variant] = raw
assert records['control']['test_sha256'] == records['candidate']['test_sha256']
assert records['control']['expected_cases'] == records['candidate']['expected_cases']
assert outputs['control'] == outputs['candidate'], 'Full native call/hit/token transcript differs'
result = dict(status='PASS', complete_stdout_equal=True, test_sha256=records['control']['test_sha256'], cases=records['control']['expected_cases'], stdout_sha256=records['control']['stdout_sha256'], complete_lines=len(outputs['control'].splitlines()), variants=records, execution='Offline full-byte comparison only')
with (HERE/'parent-output-verification.json').open('x',encoding='utf-8') as stream:
    json.dump(result,stream,indent=2); stream.write('\n')
print(json.dumps({key:value for key,value in result.items() if key != 'variants'},indent=2))
