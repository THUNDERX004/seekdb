"""Compile only the focused test TU and link actual production IK CJK processor archives."""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import subprocess

HERE = Path(__file__).resolve().parent
HELPER = HERE.parent / 'round16-row-native/prepare_fts_lazy_rows.py'
spec = importlib.util.spec_from_file_location('native_link_util', HELPER)
util = importlib.util.module_from_spec(spec)
spec.loader.exec_module(util)
ROOT, BUILD = util.ROOT, util.BUILD
SOURCE = 'src/storage/fts/ik/ob_ik_cjk_processor.cpp'
HEADER = 'src/storage/fts/ik/ob_ik_cjk_processor.h'
DEFAULT_TEST = ROOT / 'unittest/storage/fts/test_cjk_hits.cpp'

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output-dir', required=True, type=Path)
    parser.add_argument('--variant', required=True, choices=['control', 'candidate'])
    parser.add_argument('--expected-source-sha256', required=True)
    parser.add_argument('--expected-header-sha256', required=True)
    parser.add_argument('--test-source', type=Path, default=DEFAULT_TEST)
    parser.add_argument('--expected-cases', type=int, default=152)
    parser.add_argument('--build', action='store_true')
    args = parser.parse_args()
    test = args.test_source.resolve()
    util.require(test == DEFAULT_TEST.resolve() and 1 <= args.expected_cases <= 100000,
                 'Expected the selected checkout finite native test')
    out = args.output_dir.resolve()
    util.require(out.is_relative_to(HERE) and out != HERE and not out.exists(), 'Use a fresh helper-owned output directory')
    util.require(re.fullmatch('[a-f0-9]{64}', args.expected_source_sha256) is not None, 'Expected source hash required')
    util.require(util.sha(ROOT / SOURCE) == args.expected_source_sha256, 'Wrong live IK CJK processor source')
    util.require(util.sha(ROOT / HEADER) == args.expected_header_sha256, 'Wrong live IK CJK processor header')
    util.require(test.is_file(), 'Missing focused native test source')
    rec = util.records()
    compilation = json.loads((BUILD / 'compile_commands.json').read_text(encoding='utf-8'))
    units = [x for x in compilation if '/ob_storage.dir/' in x.get('output', '').replace(chr(92), '/')
             and SOURCE in Path(x['file']).read_text(encoding='utf-8').replace(chr(92), '/')]
    util.require(len(units) == 1, 'Expected one actual IK CJK processor-containing production unity')
    record = units[0]
    production_obj = util.full(record['output'])
    archive = BUILD / 'src/storage/ob_storage_static.lib'
    util.require(production_obj.is_file() and archive.is_file(), 'Missing production IK CJK processor object/archive')
    util.require(production_obj.stat().st_mtime_ns >= max((ROOT / SOURCE).stat().st_mtime_ns, (ROOT / HEADER).stat().st_mtime_ns)
                 and archive.stat().st_mtime_ns >= production_obj.stat().st_mtime_ns, 'Stale production IK CJK processor artifacts')
    tokens = util.windows_args(record['command'])
    compiler, compile_args, replaced = tokens[0], [], dict(source=0, object=0, pdb=0)
    util.require(Path(compiler).name.lower() == 'clang-cl.exe', 'Unexpected production compiler')
    for token in tokens[1:]:
        if token.startswith('/Fo'):
            token = '/Fo' + (out / 'test.obj').as_posix(); replaced['object'] += 1
        elif token.startswith('/Fd'):
            token = '/Fd' + (out / 'test-compile.pdb').as_posix(); replaced['pdb'] += 1
        elif token == record['file']:
            token = test.as_posix(); replaced['source'] += 1
        compile_args.append(token)
    util.require(replaced == dict(source=1, object=1, pdb=1), 'Unexpected compile substitution')
    libs = util.windows_args(util.expand(rec['link_variables']['LINK_LIBRARIES'], {}))
    util.require(all(p.lower().endswith('.lib') for p in libs), 'Unexpected library expression')
    libs = [util.full(p).as_posix() if '/' in p or chr(92) in p else p for p in libs]
    util.require(archive.as_posix() in libs, 'Production storage archive absent from link')
    explicit = [util.full(p).as_posix() for p in rec['explicit_objects'] if p != util.MAIN_OBJ]
    link_args = [(out / 'test.obj').as_posix(), *explicit]
    link_args += util.windows_args(util.expand(rec['link_variables']['LINK_PATH'], {})) + libs
    wrapper = rec['link_rule']['command']
    first, last = wrapper.find(' && '), wrapper.rfind(' && ')
    util.require(first >= 0 and last > first, 'Unexpected production link wrapper')
    quote = lambda p: subprocess.list2cmdline([p.as_posix()])
    variables = dict(OBJECT_DIR=quote(out / 'link-intermediate'), RSP_FILE=quote(out / 'link-inputs.rsp'),
                     TARGET_FILE=quote(out / 'test_cjk_hits.exe'), TARGET_IMPLIB=quote(out / 'test.lib'),
                     TARGET_PDB=quote(out / 'test-link.pdb'), MANIFESTS='', LINK_FLAGS=rec['link_variables']['LINK_FLAGS'])
    link_command = util.windows_args(util.expand(wrapper[first + 4:last], variables))
    util.require('vs_link_exe' in link_command and '--manifests' in link_command, 'Wrong link wrapper')
    artifacts = sorted(set([util.full(p) for p in explicit + libs if '/' in p or chr(92) in p] + [production_obj]), key=str)
    util.require(all(p.is_file() for p in artifacts), 'Missing production link input')
    out.mkdir()
    util.response_write(out / 'compile.rsp', compile_args)
    util.response_write(out / 'link-inputs.rsp', link_args)
    commands = dict(compile=[compiler, '@' + (out / 'compile.rsp').as_posix()], link=link_command)
    receipt = dict(variant=args.variant, expected_source_sha256=args.expected_source_sha256,
                   test_sha256=util.sha(test), test_source=test.name, expected_cases=args.expected_cases,
                   expected_header_sha256=args.expected_header_sha256,
                   builder_sha256=util.sha(Path(__file__)), helper_sha256=util.sha(HELPER), production_source_compiled=False,
                   replaced_main=util.MAIN_OBJ, storage_unity=record, commands=commands,
                   compile='NOT RUN', link='NOT RUN', native='NOT RUN', performance='NOT RUN')
    save = lambda: util.write_json(out / 'receipt.json', receipt)
    save()
    if not args.build:
        print('PLAN ONLY', out); return
    util.require(os.name == 'nt' and os.environ.get('VSCMD_ARG_TGT_ARCH') == 'x64'
                 and os.environ.get('INCLUDE') and os.environ.get('LIB'), 'Requires VS x64 native environment')
    receipt['production_sha256_before'] = {str(p): util.sha(p) for p in artifacts}
    save()
    environment = os.environ.copy()
    temporary = out / 'tmp'; temporary.mkdir()
    environment['TEMP'] = environment['TMP'] = str(temporary)
    for stage in ('compile', 'link'):
        if stage == 'link':
            (out / 'link-intermediate').mkdir()
        with (out / (stage + '.log')).open('wb') as log:
            result = subprocess.run(commands[stage], cwd=out, env=environment, stdout=log, stderr=subprocess.STDOUT)
        receipt[stage] = dict(exit_code=result.returncode, log_sha256=util.sha(out / (stage + '.log')))
        save()
        util.require(result.returncode == 0, stage + ' failed; preserve output and inspect log')
    receipt['production_sha256_after'] = {str(p): util.sha(p) for p in artifacts}
    util.require(receipt['production_sha256_before'] == receipt['production_sha256_after'], 'Production artifacts changed during native build')
    util.require(util.sha(ROOT / SOURCE) == args.expected_source_sha256 and util.sha(ROOT / HEADER) == args.expected_header_sha256
                 and util.sha(test) == receipt['test_sha256'], 'Source changed during native build')
    receipt['runtime_dlls'] = []
    for dll in sorted((BUILD / 'src/observer').glob('*.dll')):
        shutil.copy2(dll, out / dll.name)
        util.require(util.sha(dll) == util.sha(out / dll.name), 'DLL copy mismatch')
        receipt['runtime_dlls'].append(dict(name=dll.name, sha256=util.sha(dll)))
    receipt['executable_sha256'] = util.sha(out / 'test_cjk_hits.exe')
    receipt['build_succeeded'] = True
    save()
    print('COMPILED AND LINKED; NOT RUN', out)

if __name__ == '__main__':
    main()
