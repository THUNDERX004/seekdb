"""Validate fixed-input completed round30 reports; equal-category signed improvements."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
from statistics import mean

HERE = Path(__file__).resolve().parent
FTS = HERE.parent
HELPER = FTS / 'round19-evidence/summarize-template.py'
SOURCE = '1f52c9ff617139141a0e079f3bb0bf631e72ad33+round30-cjk-hits'

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--pairs', required=True, type=int, choices=(1,2,3))
    args = parser.parse_args()
    assert hashlib.sha256(HELPER.read_bytes()).hexdigest() == '0aca605abda2fea4ab7b32335c5fe04302895748e8f63a6ce46887b04b822035'
    spec = importlib.util.spec_from_file_location('strict_pair_util', HELPER)
    u = importlib.util.module_from_spec(spec); spec.loader.exec_module(u)
    binary = json.loads((HERE/'binary.json').read_text(encoding='utf-8'))
    pins = {'control':'c7fcc8676875246a38bc4135f29e6f52b85a9d29a9563679003d5b6140666b01', 'candidate':binary['files']['seekdb.exe']['sha256']}
    sources = {'control':'f56ddd03e66826919d8d9192bc4c0afece8843dd', 'candidate':SOURCE}
    u.PINS = pins
    out = HERE / ('comparison-'+str(args.pairs)+'pair.json')
    assert not out.exists()
    inputs, raws, records, bases, pairs = {}, {}, {}, set(), []
    runs = {'control':[], 'candidate':[]}
    def compare(old,new):
        result = u.comparison(old,new)
        result.pop('incremental_score_equivalents')
        return result
    for number in range(1,args.pairs+1):
        for variant in runs:
            label = 'r30-cjk-hits-'+variant+'-a'+str(number)
            report = FTS/(label+'-report.txt')
            receipt = FTS/(label+'-experiment.json')
            r = u.receipt(u.read_input(receipt,inputs,raws),label,variant,report)
            assert r['source_commit'] == sources[variant]
            base = Path(r['base_dir'])
            assert base.name == 'seekdb-fts-round30-'+variant+'-a'+str(number) and str(base) not in bases
            assert r['owned_server_exit_before_cleanup'] is None
            bases.add(str(base))
            d = u.report(u.read_input(report,inputs,raws),label)
            records[label] = dict(receipt=r,**d)
            runs[variant].append(d['values'])
        pairs.append(dict(pair=number,**compare(runs['control'][-1],runs['candidate'][-1])))
    averages = {variant:{key:mean(run[key] for run in values) for key in u.METRICS} for variant,values in runs.items()}
    result = dict(status='COMPLETE',completed_pairs=args.pairs,pairs=pairs,records=records,binary_pins=pins,source_labels=sources,parameters=u.PARAMS,hits=u.HITS,input_hashes=inputs,metric_means=averages,aggregate=compare(averages['control'],averages['candidate']),interpretation='Incremental local comparison with accepted C7; not a cumulative or formal score. Signed improvement means inside categories, then equal category weight; no dropped runs or overhead subtraction.')
    for path,raw in raws.items(): assert u.snapshot(path) == raw
    with out.open('x',encoding='utf-8') as stream:
        json.dump(result,stream,indent=2,allow_nan=False); stream.write('\n')
    print(json.dumps(dict(output=str(out),aggregate=result['aggregate']),indent=2))

if __name__ == '__main__': main()
