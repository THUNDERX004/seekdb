/* Copyright (c) 2026. Licensed under the Apache License, Version 2.0. */
// Frozen public-API fixture: compile this IDENTICAL TU against each variant.
// No production .cpp inclusion, private access, or CJK implementation copy.
#include <algorithm>
#include <cstdint>
#include <cstdio>
#include <optional>
#include <stdexcept>
#include <string>
#include <map>
#include <memory>
#include <vector>

#include "lib/allocator/page_arena.h"
#include "lib/charset/ob_charset.h"
#include "lib/oblog/ob_log.h"
#include "lib/rc/context.h"
#include "storage/fts/dict/ob_ft_dict.h"
#include "storage/fts/ik/ob_ik_cjk_processor.h"

using namespace oceanbase;
using namespace oceanbase::common;
using namespace oceanbase::storage;

namespace {
using Type = ObFTCharUtil::CharType;
constexpr int kCases = 20;
int cases = 0;
int step_label = -1;

void need(bool value, const char *why)
{ if (!value) throw std::runtime_error(why); }

std::string hex(const std::string &s)
{
  static const char digits[] = "0123456789abcdef";
  std::string out;
  for (unsigned char c : s) { out += digits[c >> 4]; out += digits[c & 15]; }
  return out;
}

// Input construction only. Every input is a valid Unicode scalar.
std::string u8(uint32_t c)
{
  need(c <= 0x10ffff && !(c >= 0xd800 && c <= 0xdfff), "bad fixture scalar");
  std::string s;
  if (c < 128) s += static_cast<char>(c);
  else if (c < 2048) {
    s += static_cast<char>(0xc0 | (c >> 6)); s += static_cast<char>(0x80 | (c & 63));
  } else if (c < 65536) {
    s += static_cast<char>(0xe0 | (c >> 12));
    s += static_cast<char>(0x80 | ((c >> 6) & 63)); s += static_cast<char>(0x80 | (c & 63));
  } else {
    s += static_cast<char>(0xf0 | (c >> 18)); s += static_cast<char>(0x80 | ((c >> 12) & 63));
    s += static_cast<char>(0x80 | ((c >> 6) & 63)); s += static_cast<char>(0x80 | (c & 63));
  }
  return s;
}

struct Atom { std::string bytes; Type type; };
using Atoms = std::vector<Atom>;
const Atom a{u8(0x4e2d), Type::CHINESE}, b{u8(0x6587), Type::CHINESE},
           c{u8(0x56fd), Type::CHINESE}, x{"A", Type::ENGLISH_LETTER},
           n{"7", Type::ARABIC_LETTER}, j{u8(0x3042), Type::OTHER_CJK},
           k{u8(0xac00), Type::OTHER_CJK}, f{u8(0xff21), Type::ENGLISH_LETTER},
           nul{std::string(1, '\0'), Type::USELESS}, space{" ", Type::USELESS},
           dot{".", Type::USELESS}, two{u8(0xe9), Type::USELESS},
           four{u8(0x1f642), Type::USELESS};

Atoms repeat(const Atoms &pattern, int size)
{
  Atoms out;
  for (int i = 0; i < size; ++i) out.push_back(pattern.at(i % pattern.size()));
  return out;
}
std::string join(const Atoms &atoms, int begin, int end)
{
  std::string out;
  for (int i = begin; i < end; ++i) out += atoms.at(i).bytes;
  return out;
}

struct Fields {
  const ObIFTDict *dict;
  int64_t count, start, end;
  uint32_t base, check;
  bool match, prefix;
  bool operator==(const Fields &o) const
  {
    return dict == o.dict && count == o.count && start == o.start && end == o.end
        && base == o.base && check == o.check && match == o.match && prefix == o.prefix;
  }
};
Fields fields(const ObDATrieHit &h)
{ return {h.dict_, h.char_cnt_, h.start_pos_, h.end_pos_, h.base_idx_, h.current_check_,
          h.is_match_, h.is_prefix_}; }

struct Node {
  uint32_t id = 0, parent = 0;
  int chars = 0;
  bool terminal = false, strict_prefix = false;
};

// Synthetic immutable word dictionary, NOT a replacement for production CJK.
// State IDs have disjoint ranges for each actual child dictionary object.
class WordDict final : public ObIFTDict {
public:
  WordDict(int identity, const std::vector<Atoms> &words) : identity_(identity)
  {
    for (const Atoms &word : words) {
      std::string key;
      for (size_t i = 0; i < word.size(); ++i) {
        key += word[i].bytes;
        Node &node = nodes_[key];
        node.chars = static_cast<int>(i + 1);
        node.terminal = node.terminal || i + 1 == word.size();
        node.strict_prefix = node.strict_prefix || i + 1 < word.size();
      }
    }
    uint32_t next = static_cast<uint32_t>(identity * 100000);
    for (auto &item : nodes_) item.second.id = ++next;
    for (auto &item : nodes_) {
      const std::string &key = item.first;
      std::string parent;
      for (const auto &p : nodes_) {
        if (p.first.size() < key.size() && key.compare(0, p.first.size(), p.first) == 0
            && p.first.size() > parent.size()) parent = p.first;
      }
      item.second.parent = parent.empty() ? 0 : nodes_.at(parent).id;
      states_.emplace(item.second.id, key);
    }
  }
  int init() override { return OB_SUCCESS; }
  int match(const ObString &word, bool &yes) const override
  {
    const auto it = nodes_.find(std::string(word.ptr(), word.length()));
    yes = it != nodes_.end() && it->second.terminal;
    return OB_SUCCESS;
  }
  int match(const ObString &ch, ObDATrieHit &hit) const override
  { return match_with_hit(ch, hit, hit); }
  int match_with_hit(const ObString &ch, const ObDATrieHit &last, ObDATrieHit &out) const override
  {
    // Snapshot before writes: the public caller legitimately aliases these.
    const Fields in = fields(last);
    need(in.dict == this, "wrong child dict identity after relocation/compaction");
    std::string key;
    if (in.base != 0) {
      const auto old = states_.find(in.base);
      need(old != states_.end(), "child state belongs to a different dictionary");
      key = old->second;
    }
    key.append(ch.ptr(), ch.length());
    out.dict_ = this;
    out.char_cnt_ = in.count; out.start_pos_ = in.start; out.end_pos_ = in.end;
    out.base_idx_ = in.base; out.current_check_ = in.check;
    out.set_unmatch();
    const auto it = nodes_.find(key);
    if (it != nodes_.end()) {
      out.char_cnt_ = in.count + 1; out.end_pos_ = in.end + ch.length();
      out.base_idx_ = it->second.id; out.current_check_ = it->second.parent;
      out.is_match_ = it->second.terminal;
      // Both legal terminal conventions: strict leaf and DAT-like retained leaf.
      out.is_prefix_ = it->second.strict_prefix || (identity_ % 2 == 0 && it->second.terminal);
    }
    return OB_SUCCESS;
  }
  const std::map<std::string, Node> &nodes() const { return nodes_; }
  int identity() const { return identity_; }
private:
  const int identity_;
  std::map<std::string, Node> nodes_;
  std::map<uint32_t, std::string> states_;
};

struct Call { bool root, alias; std::string bytes; Fields before, after; int ret; };

class Dictionary final : public ObIFTDict {
public:
  explicit Dictionary(const std::vector<Atoms> &words) : words_(words)
  {
    std::map<std::string, std::vector<Atoms>> groups;
    for (const Atoms &word : words_) groups[word.at(0).bytes].push_back(word);
    int id = 1;
    for (const auto &g : groups) children_.emplace(g.first, std::make_unique<WordDict>(id++, g.second));
  }
  int init() override { return OB_SUCCESS; }
  int match(const ObString &word, bool &yes) const override
  {
    yes = false;
    for (const Atoms &w : words_) yes = yes || join(w, 0, static_cast<int>(w.size()))
                                                  == std::string(word.ptr(), word.length());
    return OB_SUCCESS;
  }
  int match(const ObString &ch, ObDATrieHit &hit) const override
  {
    const Fields before = fields(hit);
    const auto it = children_.find(std::string(ch.ptr(), ch.length()));
    int ret = OB_SUCCESS;
    if (it == children_.end()) hit.set_unmatch();
    else { hit.dict_ = it->second.get(); ret = hit.dict_->match(ch, hit); }
    return record(true, true, ch, before, hit, ret);
  }
  int match_with_hit(const ObString &ch, const ObDATrieHit &last, ObDATrieHit &hit) const override
  {
    need(&last == &hit, "processor continuation must use alias API");
    const Fields before = fields(last);
    need(id(before.dict) > 0, "invalid continuation dict pointer");
    const int ret = before.dict->match_with_hit(ch, last, hit);
    return record(false, &last == &hit, ch, before, hit, ret);
  }
  void begin(bool fail_root, int64_t fail_start) const
  { calls.clear(); fail_root_ = fail_root; fail_start_ = fail_start; fired = false; }
  int id(const ObIFTDict *p) const
  {
    if (p == this) return 0;
    for (const auto &child : children_) if (p == child.second.get()) return child.second->identity();
    need(false, "unrecognized actual dictionary pointer"); return -1;
  }
  const WordDict *child(const std::string &first) const
  {
    const auto it = children_.find(first);
    return it == children_.end() ? nullptr : it->second.get();
  }
  // Oracle membership uses whole WORDS, not the synthetic transition machinery.
  bool word(const std::string &key) const
  {
    for (const Atoms &w : words_) if (join(w, 0, static_cast<int>(w.size())) == key) return true;
    return false;
  }
  bool prefix(const std::string &key) const
  {
    for (const Atoms &w : words_) {
      const std::string full = join(w, 0, static_cast<int>(w.size()));
      if (full.size() >= key.size() && full.compare(0, key.size(), key) == 0) return true;
    }
    return false;
  }
  mutable std::vector<Call> calls;
  mutable bool fired = false;
private:
  int record(bool root, bool alias, const ObString &ch, const Fields &before,
             ObDATrieHit &out, int ret) const
  {
    if (ret == OB_SUCCESS && fail_start_ >= 0 && root == fail_root_ && before.start == fail_start_) {
      need(out.is_match() || out.is_prefix(), "fault must follow a VALID state mutation");
      need(out.end_pos_ > before.end, "fault did not mutate hit");
      fired = true; ret = OB_ERR_UNEXPECTED;
    }
    calls.push_back({root, alias, std::string(ch.ptr(), ch.length()), before, fields(out), ret});
    return ret;
  }
  const std::vector<Atoms> words_;
  std::map<std::string, std::unique_ptr<WordDict>> children_;
  mutable bool fail_root_ = false;
  mutable int64_t fail_start_ = -1;
};

// This oracle enumerates document substrings; it maintains NO active-hit list.
Fields oracle_hit(const Dictionary &dict, const Atoms &text, const std::vector<int64_t> &off,
                  int start, int end)
{
  const WordDict *child = dict.child(text.at(start).bytes);
  need(child != nullptr, "oracle prefix has no child");
  const Node &node = child->nodes().at(join(text, start, end));
  return {child, end - start, off.at(start), off.at(end), node.id, node.parent,
          dict.word(join(text, start, end)),
          node.strict_prefix || (child->identity() % 2 == 0 && node.terminal)};
}

void print_fields(const Dictionary &dict, const Fields &h)
{
  std::printf("%d,%lld,%lld,%lld,%u,%u,%d,%d", dict.id(h.dict),
      static_cast<long long>(h.count), static_cast<long long>(h.start),
      static_cast<long long>(h.end), h.base, h.check, int(h.match), int(h.prefix));
}

struct Token { int64_t offset, length, chars; };
bool token_less(const Token &l, const Token &r)
{ return l.offset < r.offset || (l.offset == r.offset && l.length > r.length); }

struct Document {
  const char *name;
  Atoms atoms;
  int reset_at = -1;
  int fail_at = -1;
  int fail_start = -1;
  bool fail_root = false;
  int minimum_live = 0;
};

void run_document(Dictionary &dict, ObIKCJKProcessor &processor, ObArenaAllocator &arena,
                  const Document &doc, bool smart)
{
  ++cases; step_label = -1;
  const int size = static_cast<int>(doc.atoms.size());
  const std::string text = join(doc.atoms, 0, size);
  std::vector<int64_t> off(1, 0);
  for (const Atom &atom : doc.atoms) off.push_back(off.back() + atom.bytes.size());
  TokenizeContext ctx(CS_TYPE_UTF8MB4_BIN, arena, text.data(), text.size(), smart);
  const int init_ret = ctx.init();
  std::printf("CASE\t%d\t%s\tsmart=%d\tchars=%d\tinit=%d\ttext=%s\n",
              cases, doc.name, int(smart), size, init_ret, hex(text).c_str());
  need(init_ret == OB_SUCCESS, "real context init");
  need(dict.init() == OB_SUCCESS, "synthetic dictionary init");
  std::vector<Token> expected;
  int floor = 0, peak_live = 0, handle = 0;
  for (int at = 0; at < size; ++at) {
    step_label = at;
    if (at == doc.reset_at) {
      const int ret = ctx.reset_resource();
      std::printf("R\t%d\t%d\treset=%d\n", cases, at, ret);
      need(ret == OB_SUCCESS && ctx.token_list().is_empty(), "context resource reset");
      expected.clear(); handle = 0;
    }
    const char *ch = nullptr; uint8_t len = 0; Type type = Type::USELESS;
    need(ctx.current_char(ch, len) == OB_SUCCESS && ctx.current_char_type(type) == OB_SUCCESS,
         "real context current char");
    need(ch == text.data() + off.at(at) && len == doc.atoms[at].bytes.size()
        && type == doc.atoms[at].type, "context byte/character classification mismatch");
    need(ctx.get_cursor() == off.at(at) && ctx.get_end_cursor() == off.at(at + 1)
        && ctx.is_last() == (at + 1 == size) && !ctx.iter_end()
        && ctx.is_smart() == smart && ctx.handle_size() == handle, "context state mismatch");
    const bool fault = at == doc.fail_at;
    dict.begin(doc.fail_root, fault ? off.at(doc.fail_start) : -1);
    const int ret = processor.do_process(ctx, ch, len, type);
    for (size_t i = 0; i < dict.calls.size(); ++i) {
      const Call &call = dict.calls[i];
      std::printf("D\t%d\t%d\t%zu\t%s\talias=%d\tbytes=%s\tret=%d\tin=",
                  cases, at, i, call.root ? "root" : "extend", int(call.alias), hex(call.bytes).c_str(), call.ret);
      print_fields(dict, call.before); std::printf("\tout="); print_fields(dict, call.after); std::printf("\n");
    }
    need(ret == (fault ? OB_ERR_UNEXPECTED : OB_SUCCESS), "do_process return mismatch");
    need(dict.fired == fault, "injection reachability mismatch");

    // Enumerate previous substrings to derive complete ordered public call inputs.
    size_t call_index = 0;
    int extensions = 0;
    bool stopped = false;
    if (type != Type::USELESS) {
      for (int start = floor; start < at; ++start) {
        if (!dict.prefix(join(doc.atoms, start, at))) continue;
        need(call_index < dict.calls.size(), "missing continuation");
        const Call &call = dict.calls.at(call_index++);
        need(!call.root && call.alias && call.bytes == doc.atoms[at].bytes
            && call.before == oracle_hit(dict, doc.atoms, off, start, at),
             "unstable continuation order or incomplete hit identity");
        Fields after = call.before;
        after.match = false; after.prefix = false;
        if (dict.prefix(join(doc.atoms, start, at + 1)))
          after = oracle_hit(dict, doc.atoms, off, start, at + 1);
        need(call.after == after, "continuation output full-field mismatch");
        ++extensions;
        if (fault && !doc.fail_root && start == doc.fail_start) { stopped = true; break; }
        need(call.ret == OB_SUCCESS, "unexpected continuation error");
      }
      if (!stopped) {
        need(call_index < dict.calls.size(), "missing root call");
        const Call &call = dict.calls.at(call_index++);
        const Fields before{&dict, 0, off.at(at), off.at(at), 0, 0, false, false};
        Fields after = before;
        if (dict.prefix(doc.atoms[at].bytes)) after = oracle_hit(dict, doc.atoms, off, at, at + 1);
        need(call.root && call.alias && call.bytes == doc.atoms[at].bytes
             && call.before == before && call.after == after, "root full-field mismatch");
        need(call.ret == (fault ? OB_ERR_UNEXPECTED : OB_SUCCESS), "root return mismatch");
      }
    }
    need(call_index == dict.calls.size(), "extra dictionary calls after clear/error/last");
    peak_live = std::max(peak_live, extensions);

    // Independent complete token oracle: explicit word membership of all substrings.
    if (type != Type::USELESS) {
      for (int start = floor; start <= at; ++start) {
        if (fault && (doc.fail_root ? start == at : start >= doc.fail_start)) continue;
        if (dict.word(join(doc.atoms, start, at + 1)))
          expected.push_back({off[start], off[at + 1] - off[start], at + 1 - start});
      }
    }
    std::sort(expected.begin(), expected.end(), token_less);
    expected.erase(std::unique(expected.begin(), expected.end(), [](const Token &l, const Token &r) {
      return l.offset == r.offset && l.length == r.length;
    }), expected.end());
    auto &actual = ctx.token_list().tokens();
    need(actual.size() == static_cast<int64_t>(expected.size()), "complete token count mismatch");
    size_t ti = 0;
    for (auto it = actual.begin(); it != actual.end(); ++it, ++ti) {
      need(ti < expected.size(), "token traversal bound");
      const ObIKToken &token = *it;
      const Token &want = expected[ti];
      need(token.ptr_ == text.data() && token.offset_ == want.offset && token.length_ == want.length
           && token.char_cnt_ == want.chars && token.type_ == ObIKTokenType::IK_CHINESE_TOKEN,
           "token tuple/order/backing mismatch");
      need(token.offset_ >= 0 && token.length_ > 0
           && token.offset_ + token.length_ <= static_cast<int64_t>(text.size()), "token backing bound");
      std::printf("T\t%d\t%d\t%zu\tptr=fulltext\toffset=%lld\tlength=%lld\tchars=%lld\ttype=%d\thex=%s\n",
          cases, at, ti, static_cast<long long>(token.offset_), static_cast<long long>(token.length_),
          static_cast<long long>(token.char_cnt_), int(token.type_),
          hex(text.substr(static_cast<size_t>(token.offset_), static_cast<size_t>(token.length_))).c_str());
    }
    need(ti == expected.size() && ctx.result_list().empty(), "complete list traversal");
    if (type == Type::USELESS || fault) floor = at + 1;
    const int next = ctx.step_next();
    std::printf("R\t%d\t%d\tprocess=%d\tstep=%d\tcursor=%lld\ttokens=%zu\n",
                cases, at, ret, next, static_cast<long long>(ctx.get_cursor()), expected.size());
    need(next == (at + 1 == size ? OB_ITER_END : OB_SUCCESS), "step_next result");
    if (next == OB_SUCCESS) ++handle;
  }
  const char *end = nullptr; uint8_t end_len = 0; Type end_type = Type::USELESS;
  const int char_ret = ctx.current_char(end, end_len), type_ret = ctx.current_char_type(end_type);
  need(ctx.iter_end() && char_ret == OB_ITER_END && type_ret == OB_ITER_END, "final context end");
  need(peak_live >= doc.minimum_live, "required live-prefix growth not observed");
  std::printf("END\t%d\tchar=%d\ttype=%d\tpeak_extensions=%d\n", cases, char_ret, type_ret, peak_live);
  // ctx and its tokens die BEFORE text/arena. The next document reuses processor.
}

std::vector<Atoms> words()
{
  std::vector<Atoms> out{{b}, {c}, {x}, {n}, {j}, {k}, {f}, {x,a}, {x,a,b},
                         {n,a}, {j,k}, {k,f}, {f,a}, {a,nul,a}, {a,space,b}};
  for (int length : {1,3,9,65,129,160}) out.push_back(repeat({a}, length));
  for (int length : {2,7,16,96,168}) out.push_back(repeat({a,b,c}, length));
  for (int length : {2,4,9}) out.push_back(repeat({b,c,a}, length));
  for (int length : {5,17,80,165}) out.push_back(repeat({c,a,b}, length));
  return out;
}

std::vector<Document> documents()
{
  return {
    {"long-equal-symbol-prefixes", repeat({a},132), -1,-1,-1,false,96},
    {"mixed-child-stable-survivors", repeat({a,b,c},120), -1,-1,-1,false,8},
    {"delimiter-and-nul-flush", {a,a,nul,a,a,space,b,c,dot,a,b}},
    {"valid-utf8-1-2-3-4-byte", {x,a,b,two,a,four,j,k,f,a,n,a,nul,x,a}},
    {"leaf-and-prefix-retention", {b,c,a,b,c,a,b,c,a}},
    {"last-character-unfinished-prefix", repeat({a},10)},
    {"no-hits-after-last-clear", repeat({Atom{"Z",Type::ENGLISH_LETTER}},8)},
    {"resource-reset-preserves-live-prefixes", repeat({a,b,c},24), 12},
    {"continuation-error-after-mutation-recovery", repeat({a},96), -1,70,31,false},
    {"root-error-after-mutation-recovery", repeat({a},32), -1,12,12,true}
  };
}

class ContextScope final {
public:
  ContextScope()
  {
    lib::ContextParam p;
    p.set_mem_attr("R30CjkHits", ObCtxIds::DEFAULT_CTX_ID).set_properties(lib::USE_TL_PAGE_OPTIONAL);
    need(CURRENT_CONTEXT->CREATE_CONTEXT(context_, p) == OB_SUCCESS && context_ != nullptr, "CREATE_CONTEXT");
    flow_.emplace(context_);
    if (flow_->init() != OB_SUCCESS) {
      flow_.reset(); DESTROY_CONTEXT(context_); context_ = nullptr;
      need(false, "Flow::init");
    }
  }
  ~ContextScope()
  {
    if (flow_) { flow_->deinit(); flow_.reset(); }
    if (context_ != nullptr) DESTROY_CONTEXT(context_);
  }
private:
  lib::MemoryContext context_ = nullptr;
  std::optional<lib::Flow> flow_;
};
} // namespace

int main()
{
  try {
    OB_LOGGER.set_log_level("ERROR");
    ContextScope context;
    need(ObCharset::get_charset(CS_TYPE_UTF8MB4_BIN) != nullptr, "real UTF8MB4 charset unavailable");
    const auto docs = documents();
    need(docs.size() == 10, "fixed document schedule changed");
    for (bool smart : {false,true}) {
      Dictionary dict(words());
      ObArenaAllocator arena;
      ObIKCJKProcessor processor(dict, arena);
      for (const Document &doc : docs) run_document(dict, processor, arena, doc, smart);
    }
    need(cases == kCases, "fixed case count");
    std::printf("PASS\tcases=%d\n", cases);
    return std::fflush(stdout) == 0 && !std::ferror(stdout) ? 0 : 1;
  } catch (const std::exception &e) {
    std::fprintf(stderr, "FAIL\tcase=%d\tstep=%d\t%s\n", cases, step_label, e.what());
    return 1;
  }
}
