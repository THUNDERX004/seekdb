"""Strict same-machine cumulative comparison against official source baseline."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
from statistics import mean

HERE = Path(__file__).resolve().parent
FTS = HERE.parent
HELPER = FTS / 'round19-evidence/summarize-template.py'
BASELINE = '5bce9e06d1281347ad61344e4b01fab9158c58a2'
CANDIDATE = 'f56ddd03e66826919d8d9192bc4c0afece8843dd'

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--pairs', required=True, type=int, choices=(1, 2, 3))
    a = p.parse_args()
    spec = importlib.util.spec_from_file_location('strict_pair_util', HELPER)
    u = importlib.util.module_from_spec(spec); spec.loader.exec_module(u)
    u.PINS = {'control': 'bae4a3b9e1b4662d4021b28d5adc085764beb6cf02122eacd57b8e16b6fe1762',
              'candidate': 'c7fcc8676875246a38bc4135f29e6f52b85a9d29a9563679003d5b6140666b01'}
    out = HERE / ('cumulative-' + str(a.pairs) + 'pair.json')
    u.require(not out.exists(), 'Immutable output exists')
    inputs, raw_inputs, records = {}, {}, {}
    runs = {'control': [], 'candidate': []}
    pairs = []
    def comparison(c, n):
        d = u.comparison(c, n)
        d.pop('incremental_score_equivalents')
        return d
    for i in range(1, a.pairs + 1):
        for v in runs:
            label = 'r25-cumulative-' + ('original' if v == 'control' else v) + '-a' + str(i)
            report = FTS / (label + '-report.txt')
            receipt = FTS / (label + '-experiment.json')
            r = u.receipt(u.read_input(receipt, inputs, raw_inputs), label, v, report)
            u.require(r['source_commit'] == (BASELINE if v == 'control' else CANDIDATE), 'Wrong source revision')
            d = u.report(u.read_input(report, inputs, raw_inputs), label)
            records[label] = dict(receipt=r, **d)
            runs[v].append(d['values'])
        pairs.append(dict(pair=i, **comparison(runs['control'][-1], runs['candidate'][-1])))
    means = {v: {k: mean(r[k] for r in rr) for k in u.METRICS} for v, rr in runs.items()}
    result = dict(status='COMPLETE', pairs=pairs, completed_pairs=a.pairs,
                  baseline_source=BASELINE, candidate_source=CANDIDATE, binary_pins=u.PINS,
                  parameters=u.PARAMS, hits=u.HITS, records=records, input_hashes=inputs,
                  helper_sha256=hashlib.sha256(HELPER.read_bytes()).hexdigest(),
                  metric_means=means, aggregate=comparison(means['control'], means['candidate']),
                  interpretation='Cumulative local source-baseline comparison; not fixed CI baseline, formal score, or proof of 50/50.',
                  method='Ratio of per-metric run means, then arithmetic metric means inside categories and equal category weighting; all negative values retained, no sample removal or SELECT1 subtraction.')
    for path, raw in raw_inputs.items():
        u.require(u.snapshot(path) == raw, 'Input changed during validation')
    with out.open('x', encoding='utf-8') as f:
        json.dump(result, f, indent=2, allow_nan=False); f.write('\n')
    print(json.dumps(dict(output=str(out), aggregate=result['aggregate']), indent=2))

if __name__ == '__main__':
    main()
