# Round25 cumulative two-pair offline archive

This helper packages the four completed r25-cumulative-{original,candidate}-a{1,2} runs, their five exact text artifacts each, cumulative-1pair.json and cumulative-2pair.json, summarize.py and its exact imported round19 utility. Historical inputs are read as bytes, never imported/executed or overwritten. Per-file gzip retains CRLF/LF and records raw/packed SHA256 and sizes.

Only the new competition-round25-cumulative asset directory and top sections in the two existing FTS reports may be published. No compiler, native executable, server, SQL, benchmark, profiler or Git operation is invoked. Earlier archives and official benchmark/scoring/build/CI files remain untouched. Only new report sections and document preimage/postimage hashes are archived, avoiding full history backups.

Prepare once from the workspace root:

    .venv/Scripts/python.exe -B setup/fts/round25-cumulative-archive/package.py

Review the read-only publication plan, then publish the authorized paths:

    .venv/Scripts/python.exe -B setup/fts/round25-cumulative-archive/publish_docs.py
    .venv/Scripts/python.exe -B setup/fts/round25-cumulative-archive/publish_docs.py --execute

Verify without running workloads or writing a receipt:

    .venv/Scripts/python.exe -B setup/fts/round25-cumulative-archive/verify_package.py --package-dir D:/Projects/OceanBase/seekdb/docs/developer-guide/assets/fts-performance/competition-round25-cumulative --source-root C:/Users/11946/Documents/ChatGPT/OceanBase比赛/setup/fts

The immutable final comparison is the result of two same-machine cumulative source-baseline pairs. It is distinct from fixed CI baseline scoring. Raw input-validation logs contain local scorer output for both variants; they do not establish a formal/full-score result. No timing correction, SELECT1 subtraction, outlier removal, incremental-result addition, stability or statistical significance claim is made.

Original report git_head=f56ddd03e identifies the harness checkout, not the executed baseline binary. Unchanged execution receipts pin source 5bce9e06... with binary bae4a3b9... and source f56ddd03... with binary c7fcc867.... Mutable current binaries are not rehashed as historical oracles. Four benchmark/input-validation actions do not constitute new full functional regression execution. Earlier accepted-change correctness evidence remains separately archived.

Mutable status, publication and verification receipts stay outside the immutable package. Parent owns review/commit/push.
