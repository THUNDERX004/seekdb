"""Freeze completed round25 bytes and report insertions; never run summarizers."""
import ast
from datetime import datetime, timezone
from decimal import Decimal
import gzip
import io
import json
from pathlib import Path

from verify_package import digest, require, verify
from publish_docs import ASSET_REL, DOCS, REPO, insert, unchanged

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
BASELINE = '5bce9e06d1281347ad61344e4b01fab9158c58a2'
CANDIDATE = 'f56ddd03e66826919d8d9192bc4c0afece8843dd'
PINS = {
    'control': 'bae4a3b9e1b4662d4021b28d5adc085764beb6cf02122eacd57b8e16b6fe1762',
    'candidate': 'c7fcc8676875246a38bc4135f29e6f52b85a9d29a9563679003d5b6140666b01',
}
PARAMS = dict(rows=20000, batch=500, rounds=3000, query_rounds=200,
              samples=3, warmup=30, skip_load=0)
HITS = dict(query_cn_hits=8001, query_beng_hits=11000, query_mixed_hits=7332, query_limit_hits=20)
UTILITY = 'round19-evidence/summarize-template.py'
UTILITY_SHA = '0aca605abda2fea4ab7b32335c5fe04302895748e8f63a6ce46887b04b822035'
SUMMARIZER_SHA = '8141b9c1aec34a7ce0acd1614b32dd1412919534d200d2ce24e7308adc6da7bf'
SPAN_MANIFEST = 'docs/developer-guide/assets/fts-performance/competition-round19-span/manifest.json'


def load(path):
    return json.loads(path.read_bytes())


def identity(raw):
    return dict(bytes=len(raw), sha256=digest(raw))


def write_new(path, raw):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(raw)


def write_json(name, obj):
    write_new(HERE / name, (json.dumps(obj, ensure_ascii=False, indent=2,
                                      allow_nan=False) + '\n').encode('utf-8'))


def raw_report_fields(raw):
    fields = {}
    for line in raw.decode('utf-8-sig').splitlines():
        if ':' in line:
            key, value = line.split(':', 1)
            key, value = key.strip(), value.strip()
            require(key not in fields, 'Duplicate raw report field')
            fields[key] = value
    return fields


def validate_comparison(rel, expected_pairs, helper_raw):
    raw = (ROOT / rel).read_bytes()
    data = json.loads(raw)
    require(data['status'] == 'COMPLETE' and data['completed_pairs'] == expected_pairs
            and len(data['pairs']) == expected_pairs, 'Incomplete comparison')
    require(data['baseline_source'] == BASELINE and data['candidate_source'] == CANDIDATE
            and data['binary_pins'] == PINS, 'Unexpected identity')
    require(data['parameters'] == PARAMS and data['hits'] == HITS, 'Fixed parameter/hit mismatch')
    require(data['helper_sha256'] == digest(helper_raw) == UTILITY_SHA, 'Imported utility changed')
    labels = {f'r25-cumulative-{variant}-a{i}' for variant in ['original', 'candidate']
              for i in range(1, expected_pairs + 1)}
    require(set(data['records']) == labels, 'Comparison records differ from explicit scope')
    expected_hash_inputs = {label + '-' + suffix for label in labels
                            for suffix in ['report.txt', 'experiment.json']}
    require(set(data['input_hashes']) == expected_hash_inputs, 'Comparison input list differs')
    for source, pin in data['input_hashes'].items():
        require(identity((ROOT / source).read_bytes()) == pin, 'Immutable input changed: ' + source)
    for label, record in data['records'].items():
        receipt = load(ROOT / (label + '-experiment.json'))
        require(receipt == record['receipt'] and receipt['label'] == label, 'Receipt differs')
        variant = 'control' if '-original-' in label else 'candidate'
        require(receipt['source_commit'] == (BASELINE if variant == 'control' else CANDIDATE)
                and receipt['binary_sha256'] == PINS[variant], 'Execution identity differs')
        require(receipt['log_level'] == 'WARN' and
                type(receipt['affinity_mask']) is int and type(receipt['affinity_mask_verified']) is int
                and receipt['affinity_mask'] == receipt['affinity_mask_verified'] == 15, 'Wrong environment')
        require([x['action'] for x in receipt['actions']] == ['benchmark', 'input-validation']
                and all(x['exit_code'] == 0 for x in receipt['actions']), 'Missing/failed actions')
        require(Path(receipt['report']).resolve() == (ROOT / (label + '-report.txt')).resolve(), 'Report path mismatch')
        fields = raw_report_fields((ROOT / (label + '-report.txt')).read_bytes())
        require(set(fields) == set(record['values']) | set(record['text_fields']), 'Raw report fields differ')
        for key, value in record['values'].items():
            require(Decimal(fields[key]) == Decimal(str(value)), 'Raw numeric report differs: ' + key)
        for key, value in record['text_fields'].items():
            require(fields[key] == value, 'Historical text metadata differs: ' + key)
        require(all(record['values'][k] == v for k, v in PARAMS.items()) and
                all(record['values'][k] == v for k, v in HITS.items()), 'Recorded fixed inputs differ')
    return data, dict(source=rel, **identity(raw), input_hashes_verified=len(expected_hash_inputs),
                     raw_report_fields='ALL MATCH', receipts='ALL MATCH',
                     performance_recalculation='NOT RUN; existing results preserved verbatim')


def main():
    require(not (HERE / 'archive').exists() and not (HERE / 'status.json').exists(),
            'Existing preparation is immutable; inspect rather than overwrite')
    prior = load(ROOT / 'round19-span-archive/status.json')
    read_only = {
        SPAN_MANIFEST: '89dd6e060d058095ce2dcb261aeddf84cc421d913c484e67614814e00d763c81',
        'docs/developer-guide/assets/fts-performance/competition-round19-template/manifest.json':
            '4bd645f547b062a91dfcda96379170fef688542fd82ad047f63c0bd8a953a5ab',
        'src/storage/blocksstable/encoding/ob_string_diff_decoder.cpp':
            '6140f8f5d70b5108312df925d3f9bba4b2212a94f8c1d32f6c5ebf3c98113499',
        'unittest/storage/encoding/test_stringdiff_batch.cpp':
            '0cbd3e08a391b4b2f5ddb88fdfc773d5312589250fb5ab4a97f96632852e73c9',
    }
    state = dict(status='PREPARING_CUMULATIVE_ARCHIVE', created_utc=datetime.now(timezone.utc).isoformat(),
                 protected_preimages=prior['protected_preimages'],
                 protected_reference_paths_absent=prior['protected_reference_paths_absent'],
                 read_only_identity_pins=read_only,
                 baseline_verification='Parent supplied official source identity; no remote/ancestry/Git operation by archiver',
                 documents_preimages={rel: identity((REPO / rel).read_bytes()) for rel in DOCS},
                 scope='New C: round25-cumulative-archive; new D: round25 assets; two existing report top sections only',
                 execution='Offline files only; no build/native/runtime/SQL/benchmark/profile/Git')
    unchanged(state)
    helper_raw = (ROOT / UTILITY).read_bytes()
    summarize_raw = (ROOT / 'round25-cumulative/summarize.py').read_bytes()
    require(digest(summarize_raw) == SUMMARIZER_SHA and digest(helper_raw) == UTILITY_SHA, 'Exact summarizer/helper pin mismatch')
    # Inspect the import target as syntax, never execute either historical module.
    tree = ast.parse(summarize_raw, filename='round25-cumulative/summarize.py')
    helper_assignments = [node for node in tree.body if isinstance(node, ast.Assign)
                          and any(isinstance(t, ast.Name) and t.id == 'HELPER' for t in node.targets)]
    require(len(helper_assignments) == 1 and isinstance(helper_assignments[0].value, ast.BinOp)
            and isinstance(helper_assignments[0].value.op, ast.Div)
            and isinstance(helper_assignments[0].value.left, ast.Name)
            and helper_assignments[0].value.left.id == 'FTS'
            and isinstance(helper_assignments[0].value.right, ast.Constant)
            and helper_assignments[0].value.right.value == UTILITY, 'Imported helper target changed')
    comparisons, receipts = [], []
    for n in [1, 2]:
        data, receipt = validate_comparison(f'round25-cumulative/cumulative-{n}pair.json', n, helper_raw)
        comparisons.append(data)
        receipts.append(receipt)
    final = comparisons[-1]
    require(comparisons[0]['pairs'] == final['pairs'][:1], 'Historical first-pair snapshot differs')
    # No computed performance statistics: check exact supplied final fields only.
    require(final['aggregate']['category_improvements'] == {
        'build': 0.1982659128483732, 'tokenize': 0.1749444817166721, 'query': 0.41144971484051784
    } and final['aggregate']['overall_improvement'] == 0.2615533698018544, 'Parent supplied final result differs')
    inputs = []
    for variant in ['original', 'candidate']:
        for n in [1, 2]:
            label = f'r25-cumulative-{variant}-a{n}'
            for suffix in ['report.txt', 'experiment.json', 'benchmark.log', 'input-validation.log', 'server.log']:
                source = label + '-' + suffix
                require((ROOT / source).is_file(), 'Missing full run artifact: ' + source)
                if suffix == 'server.log':
                    require((ROOT / source).stat().st_size < 1024 * 1024, 'Server log unexpectedly large; inspect first')
                inputs.append(source)
    inputs += ['round25-cumulative/cumulative-1pair.json', 'round25-cumulative/cumulative-2pair.json',
               'round25-cumulative/summarize.py', UTILITY]
    write_json('status.json', state)
    write_json('source-identities.json', dict(
        official_baseline_source=BASELINE, accepted_candidate_source=CANDIDATE,
        historical_binary_pins=PINS, requested_and_verified_affinity_mask=15, log_level='WARN',
        parameters=PARAMS, hits=HITS,
        summarizer=dict(source='round25-cumulative/summarize.py', **identity(summarize_raw)),
        frozen_imported_utility=dict(source=UTILITY, **identity(helper_raw)),
        historical_report_git_head={label: r['text_fields']['git_head'] for label, r in final['records'].items()},
        report_git_head_interpretation='Harness checkout marker, not the executed original binary source; preserved unchanged',
        historical_source_binary_proof='Recorded receipts only; no current mutable binary rehash/Git reconstruction',
        parent_verified_accepted_span_docs_commit='e9ccee3e65932ba4c474ba98fd5dff7fafddaa45',
        read_only_identity_pins=read_only,
        protected_preimages=state['protected_preimages'],
        protected_reference_paths_absent=state['protected_reference_paths_absent']))
    write_json('input-verification.json', dict(status='PASS', comparison_snapshots=receipts,
        import_target='Statically inspected; matches exact frozen utility',
        summarizers_imported_or_rerun=False, timing_or_statistical_recalculation=False))
    write_json('method-and-limits.json', dict(status='COMPLETE local cumulative two-pair observation',
        primary_comparison='round25-cumulative/cumulative-2pair.json', completed_pairs=2,
        interpretation=final['interpretation'], method=final['method'],
        recorded_aggregate=final['aggregate'],
        limits=['No formal/platform/full-score or stability/statistical significance claim',
                'No raw timing corrections, outlier removal, SELECT1 subtraction or individual-value clipping',
                'No addition of earlier incremental results or single-change causal attribution',
                'Four recorded benchmark/input-validation actions; no new full SQL/native suite execution',
                'Fixed-CI-constant local scorer text retained for both variants; not a formal score',
                'Binary/source identity from historical receipts; report git_head denotes harness checkout',
                'No current binary/library hashes used as a historical execution oracle'],
        archiver='Offline bytes only; official protected files and earlier archives untouched'))
    rows = '\n'.join('| ' + x['metric'] + ' | ' + format(x['control'], '.6f') +
                     ' | ' + format(x['candidate'], '.6f') + ' | ' +
                     format(100 * x['improvement'], '+.6f') + '% |' for x in final['aggregate']['metrics'])
    pair_rows = '\n'.join('| ' + str(p['pair']) + ' | ' + ' | '.join(
        format(100 * p['category_improvements'][k], '+.6f') + '%' for k in ['build', 'tokenize', 'query']) +
        ' | ' + format(100 * p['overall_improvement'], '+.6f') + '% |' for p in final['pairs'])
    doc_ops = []
    for lang in ['en', 'zh-CN']:
        text = (HERE / ('report-template.' + lang + '.md')).read_bytes().decode('utf-8')
        section = text.replace('§', chr(96)).replace('@@ROWS@@', rows).replace('@@PAIRS@@', pair_rows)
        section_raw = section.replace('\r\n', '\n').encode('utf-8')
        section_name = 'report.' + lang + '.md'
        write_new(HERE / section_name, section_raw)
        rel = 'docs/developer-guide/' + lang + '/fts-performance.md'
        before = (REPO / rel).read_bytes()
        require(identity(before) == state['documents_preimages'][rel], 'Document changed during preparation')
        after = insert(before, section_raw)
        doc_ops.append(dict(path=rel, section=section_name, preimage_sha256=digest(before),
                            section_sha256=digest(section_raw), postimage_sha256=digest(after)))
    write_json('document-identities.json', doc_ops)
    own = ['package.py', 'verify_package.py', 'publish_docs.py', 'README.md',
           'report-template.en.md', 'report-template.zh-CN.md', 'report.en.md', 'report.zh-CN.md',
           'source-identities.json', 'input-verification.json', 'method-and-limits.json',
           'document-identities.json', 'selection.json']
    inputs += ['round25-cumulative-archive/' + x for x in own]
    require(len(inputs) == len(set(inputs)), 'Duplicate archive inputs')
    inputs.sort()
    write_json('selection.json', dict(method='Explicit four completed labels and named frozen helpers', files=inputs,
        exclusions=['Any later pair or unrelated experiment', 'Binaries/EXE/PDB/OBJ/LIB/DLL/RES/TMP',
                    'Runtime/data/secrets', 'Previous archive duplication',
                    'Full report-history backups', 'Mutable status/publication/verification receipts']))
    archive = HERE / 'archive'
    archive.mkdir()
    entries = []
    for source in inputs:
        raw = (ROOT / source).read_bytes()
        out = io.BytesIO()
        with gzip.GzipFile(fileobj=out, filename='', mode='wb', mtime=0, compresslevel=9) as stream:
            stream.write(raw)
        packed = out.getvalue()
        target = 'files/' + source + '.gz'
        write_new(archive / target, packed)
        entries.append(dict(source=source, path=target, raw_bytes=len(raw), raw_sha256=digest(raw),
                            packed_bytes=len(packed), packed_sha256=digest(packed)))
    manifest = dict(schema_version=1, experiment='round25-cumulative-source-baseline',
        created_utc=datetime.now(timezone.utc).isoformat(), completed_pairs=2,
        source_root=str(ROOT), checkout_root=str(REPO),
        source_baseline=BASELINE, candidate_source=CANDIDATE, historical_binary_pins=PINS,
        comparison='round25-cumulative/cumulative-2pair.json (immutable verbatim)',
        encoding='Exact raw-byte per-file gzip; empty gzip filename; mtime=0; no newline conversion',
        interpretation='Local cumulative source-baseline observation; no formal/full-score/stability claim',
        summarizers='Exact script and frozen imported utility preserved, neither imported nor rerun by archiver',
        execution_by_archiver='Offline files only; no Git/build/native/runtime/SQL/benchmark/profile', files=entries)
    manifest_raw = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    write_new(archive / 'manifest.json', manifest_raw)
    write_new(archive / 'COMPLETE.json', (json.dumps(dict(status='COMPLETE', file_count=len(entries),
              manifest_sha256=digest(manifest_raw)), indent=2) + '\n').encode('utf-8'))
    write_json('publication-plan.json', dict(repository=str(REPO), asset_directory=ASSET_REL,
        manifest_sha256=digest(manifest_raw), documents=doc_ops))
    result = verify(archive, ROOT)
    unchanged(state)
    write_json('verification.json', result)
    print(json.dumps(result, ensure_ascii=True))


if __name__ == '__main__':
    main()
