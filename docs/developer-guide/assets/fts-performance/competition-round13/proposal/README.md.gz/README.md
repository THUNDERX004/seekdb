# round13: bounded sort descriptor cache — staging only

This package proposes a cache in `ObSortOpImpl::Compare` for **one through four
sort descriptors**, used only by the stored-row comparator when encoded-key
comparison is inactive. It copies the original field index, direction and exact
datum comparator function pointer at successful initialization. There is no new
comparison algorithm, key encoding, SQL special case, allocation or wire flag.
The parent must independently review, apply and measure it; no speedup is claimed.

## Scope and application

Source snapshot: `D:\Projects\OceanBase\seekdb`, HEAD
`ecbf498d120dabaa01b60b89c49aa18a6b9926a1`, branch
`codex/fts-performance-competition`; the official competition baseline
`5bce9e06d1281347ad61344e4b01fab9158c58a2` was confirmed as an ancestor.
`manifest.json` records the observed parent worktree status as context only.
The two sort files matched their HEAD blobs after CRLF normalization. The package
does not bundle, overwrite or attempt to reapply the parent's round11/12 work.

Only these existing source files are replacement candidates:

* `src/sql/engine/sort/ob_sort_op_impl.h`
* `src/sql/engine/sort/ob_sort_op_impl.cpp`

`src/` contains full replacements, `original/src/` exact original raw snapshots.
`source.patch` contains just the two-source change. `regression.patch` separately
adds the two files under `unittest/sql/engine/sort/`. No CMake/CI/benchmark change
or fixture is included. Original raw SHA256, raw Git object IDs, HEAD Git object
IDs, normalized Git object IDs, byte sizes and changed-file hashes are all in
`manifest.json`. Git object IDs are content identities; raw SHA256 is the exact
Windows checkout guard. Preserve the originals' CRLF when using full replacement
files. A patch is LF-normalized and is preferable if the checkout format changes.

Before parent application, compare each live sort source raw SHA256 with
`original_raw_sha256`. If it differs, stop and rebase/review rather than replacing
the file. A newer parent HEAD alone is not a conflict when these bytes agree.
The parent may run `git apply --check --whitespace=error-all <absolute-source.patch>`
and then apply it in its chosen checkpoint. This agent has only run the check.

## Important correction to the performance premise

`D:\Projects\OceanBase\seekdb\src\oblib\lib\container\ob_iarray.h:47-56`
imports the one-argument `at()` from `ObIArrayWrap`. The actual methods at
`src/oblib/lib/container/ob_array_wrap.h:41-61` are **inline**, not virtual.
Only their `extra_access_check()` hook is virtual and is called inside
`#ifndef NDEBUG`; `count()` is inline too. The virtual two-argument `at(idx,obj)`
is not the overload used here. Thus this is **not removal of two virtual calls
per column in a release build**. It consolidates metadata, avoids repeated
array/data-pointer loads (and debug hooks in non-NDEBUG builds), and adds an
eligibility branch. A compiler may already eliminate some original work.
The extra per-comparator storage and instructions could regress performance.
This bounded experiment remains useful only if the parent's unchanged workload
shows a repeatable net benefit. No new platform results are required by or
claimed in this package.

## Lifetime, mutation and initialization audit

Evidence below refers to the original snapshots' one-based source lines under
`D:\Projects\OceanBase\seekdb` unless marked staged. The cache remains local to
the comparator and does not borrow new pointers into arrays or row storage.

| Evidence | Consequence |
| --- | --- |
| `src/sql/code_generator/ob_static_engine_cg.cpp:1492-1516`; `src/sql/engine/sort/ob_sort_op.cpp:420-425` | Code generation fills both arrays before execution; sort init passes the completed plan spec arrays. No descriptor mutation in the sort execution/rescan path was found. |
| `src/sql/engine/sort/ob_sort_op_impl.cpp:719-727` | `Compare::init` runs before rows/heaps are used; cache initialization does not depend on the outer object's array pointers being assigned. |
| `src/sql/engine/aggregate/ob_aggregate_processor.cpp:889-896,1067-1074` | Ordered aggregate sorts receive already-prepared `ObAggrInfo` arrays; both explicitly disable encoded keys. `ObAggrInfo::assign` at 336-337 is metadata preparation, not mutation through an active comparator. |
| `src/sql/das/iter/ob_das_sort_iter.cpp:80-119,126-142`; `src/sql/das/ob_das_attach_define.h:127-147` | DAS constructs a fresh sort with ctdef-owned arrays and encoded keys disabled; reuse resets/destroys it before reinitialization. |
| `src/sql/engine/basic/ob_stat_collector_op.cpp:68-69`; `src/sql/engine/px/datahub/components/ob_dh_sample.cpp:239-246,277-279` | Statistics/sampling sorts also use completed spec metadata. No later descriptor writes were found in these execution paths. |
| `src/sql/engine/sort/ob_sort_op_impl.cpp:2730-2773` | Prefix sort builds suffix-array helpers before calling base init. Cache indices are relative to those helpers, exactly like the old comparator, not full-array indices. |
| `src/sql/engine/sort/ob_sort_op_impl.cpp:805-840,852-864`; `src/sql/engine/sort/ob_sort_op.cpp:87-95` | `reuse()` retains the same descriptors/cache. `reset()` reconstructs `Compare`; rescan resets then initializes again. New successful init always refreshes cache and its count, including small-to-large transitions. |
| `src/sql/engine/sort/ob_sort_op_impl.h:485,488-520,651`; `src/oblib/lib/container/ob_heap.h:31,68` | `Compare` is noncopyable; the sort wrappers and heap keep references, so no cache pointers can refer to a moved/copied temporary. Its containing sort is also noncopyable. |

The contract is that descriptor values and function pointers do not mutate while
an initialized sort is active. The inspected callers satisfy this; a future
caller that changes direction/index/function must reset/reinitialize. The
existing outer sort already snapshots descriptor count and builds heaps/ranges
from it. Public comparator members still exist, but no assignments replacing its
array pointers outside `Compare::init` were found. Concurrent metadata mutation
is not a supported use of this proposal.

## Comparator equivalence and boundaries

Original `src/sql/engine/sort/ob_sort_op_impl.cpp:396-433` is the sole comparison
body with a new branch. Its preceding prior-error, initialization/null,
`fast_check_status()` and encoded-key branches are unchanged. Its original final
generic loop remains byte-for-byte unchanged. The expression comparator,
`with_ties_cmp` overloads, pointer/chunk reversing adapters and adaptive encoded
sort implementation remain unchanged.

For an eligible range, descriptor `i` contains exactly the old
`sort_collations_->at(i).field_idx_`, `.is_ascending_` and
`sort_cmp_funs_->at(i).cmp_func_`. Both loops visit the same `i` in the same order,
stop on the same first nonzero comparison or failure, pass identical datums and
`access_ctx_`, and apply identical sign/direction rules. NULL/collation/LOB rules
remain in the original function. No tie-breaker, normalization or function
substitution is introduced: equal keys still return false in either direction.
No stronger ordering/error guarantee is claimed than the original comparator.

The existing pointer-order fallback for prior errors/status failures and the
8192-call status-check cadence are unchanged. If the datum function fails during
this call, both old and new loops leave the same `less` and error state; later
calls follow the existing error branch. `init()` still returns its local error
without resetting `ret_`; reset/reinit behavior outside cache refresh is unchanged.

The cache holds **all** columns when total count is 1..4. It is selected only for
`0 <= cmp_start_ <= cmp_end_ <= cached_column_count_`. Ranges are not captured at
init: partition/window/topN switches at original cpp 1440-1467,1492-1528 and
2418-2506 keep their original coordinates and limits. Empty in-range intervals
perform no function calls. Zero columns, >4 columns, or out-of-cache ranges use
the original generic path; the guard does not validate, clamp or reinterpret
previously invalid ranges.

Encoded comparison remains higher priority. Cache descriptors are prepared even
when encoding is initially enabled, because cpp 1458-1460,1510-1512,1860-1862 can
disable it. Cache contents describe the same arrays as the original fallback;
the existing change of `enable_encode_sortkey_` remains authoritative. SQL hints
alone cannot prove that dynamic fallback executed; parent path evidence is needed.

The old check at cpp 372 compared function-array count to itself. It is corrected
to compare collation and function counts **before any cache fill or context
setup**. This is directly needed for safe eager reads of all cached descriptors.
Valid inputs retain behavior. Malformed unequal counts now return
`OB_INVALID_ARGUMENT`, including encoded mode and >4 columns, rather than being
accepted or reaching an invalid access. No null-function/index checks are added.

The cache uses four inline records plus an int64 count, with no allocation. On a
usual 64-bit ABI that is 72 additional bytes; no `sizeof` or native measurement
has been run. Cache eligibility/range checks also affect the >4 generic path.

## Staged regression and original recording compatibility

`unittest/sql/engine/sort/test_sort_compare_init.cpp` calls the actual public
`Compare::init` and expects `OB_INVALID_ARGUMENT`/uninited state for both mismatch
directions, 0/1, 3/4 and 4/5 boundaries, with encoded mode off/on: 12 scenarios.
It intentionally contains no copied comparator algorithm. It is a staged gtest
translation unit, not wired into CMake and not compiled; the parent may add it to
an existing compatible SQL unit harness. It is expected to fail the old typo
invariant and pass the candidate, not to produce a baseline fixture.

`unittest/sql/engine/sort/test_sort_metadata.py` designs a deterministic SQL
differential using 1027 rows, one ordinary indexed table and BENG/IK tables.
It compares complete ordered rows, column metadata and warnings exactly against
an independently recorded official original. Failure/unsupported syntax is fatal;
it never converts failure into a skipped/pass case. SQL errors are not expected
for this valid-input suite. The script starts no process, compiles nothing and
collects no timings. When explicitly run it creates/drops only its dedicated
`sort_metadata_r13` database on port 2891 and writes a required new plan report.

Coverage design:

* 1..4 keys and 5/6-key generic fallback, ASC/DESC, nonleading fields and expression
  keys; signed/unsigned extremes, exact decimals, Unicode case/collation ties,
  binary NUL/FF, empty values and NULLs. A unique final ID gives deterministic
  complete output; tie-only queries project identical rows for equal keys.
* TopN and LIMIT/OFFSET around 256/257, empty/singleton input, offset past end;
  ordered `GROUP_CONCAT` forces aggregate shared sorting without encoded keys.
* GROUP BY/DISTINCT/UNION, ranked window partitions, partition topN, prefix-sort
  candidate and correlated rescans. These target partial comparison intervals,
  reset/reuse and shared-sort consumers; actual operators require plan review.
* Indexed OR/AND and result sort plus BENG/IK ranked/OR queries target DAS/index
  merge consumers. The current optimizer may choose another path; a passing
  result does not prove index-merge coverage.
* Default and rowset 1/256/513, plus explicit
  `OPT_PARAM('enable_newsort' 'false'/'true')` modes. The hint is supported by
  `ob_hint.h:106`, `ob_hint.cpp:628-646`, `ob_optimizer_util.cpp:6951-6954`.
  TopN can still forbid encoding (`ob_log_sort.cpp:93`); inspect plans to classify.

The initial workload contains 378 statements. Review original/candidate plan
reports for ordinary shared SORT, encoded and unencoded sort, prefix/partition
and topN, ordered aggregate and DAS sort consumers. If a requested path is absent,
report it as uncovered and obtain a supported plan or focused execution harness;
do not claim all requested paths from SQL text alone. External spill, cancellation,
datum-function failure and dynamic encoded fallback are statically audited here,
but not forced by this suite. Parent must validate them if needed before merging.

Parent-only recording example, from the auxiliary workspace, after independently
starting/verifying the official-original binary on dedicated port 2891:

```powershell
$test = 'C:\Users\11946\Documents\ChatGPT\OceanBase比赛\setup\fts\round13-sort-proposal\unittest\sql\engine\sort\test_sort_metadata.py'
# Set $originalBinarySha256 from the verified running original binary.
& .venv/Scripts/python.exe $test --port 2891 `
  --record 'C:\Users\11946\Documents\ChatGPT\OceanBase比赛\setup\fts\round13-original-sort-expected.json.gz' `
  --record-source-commit 5bce9e06d1281347ad61344e4b01fab9158c58a2 `
  --record-source-binary-sha256 $originalBinarySha256 `
  --plans 'C:\Users\11946\Documents\ChatGPT\OceanBase比赛\setup\fts\round13-original-sort-plans.json'
```

After parent separately applies/builds the candidate and selects it on the same
dedicated port, run the same script with `--expected` pointing to that original
fixture and a distinct **new** `--plans` output. Use `SEEKDB_TEST_PASSWORD` if
needed; no credentials are read from repository files or printed. `--record`
requires provenance and uses exclusive creation, refuses existing paths, and
never auto-records on a missing fixture. Its declared binary SHA is caller-supplied
provenance, not proof inferred from a SQL version string. Never record a candidate.
No fixture has been generated in this package.

## Static evidence and remaining validation

`audit_stage.py` parses Python AST without running its SQL entry point, enumerates
the workload, verifies original/candidate identities and full-file write set,
checks patch bytes and verifies unchanged comparator surroundings. With `--seal`
it updates only package regression.patch/static-audit.json/manifest.json.
`static-audit.json` records what was actually checked. The manifest inventory
lists every artifact except itself with SHA256; unexpected files are rejected,
so older artifacts/fixtures cannot silently enter the package.

Performed: source/contract inspection, AST and workload enumeration, raw/normalized
hash checks, and read-only `git apply --check --whitespace=error-all` for both
patches. Not performed: C++ compile/link, native test, DB/SQL, build, benchmark,
platform validation or fixture recording. Acceptance still needs the parent's
original result recording, candidate correctness/path evidence and independent
unchanged-workload measurements. The largest practical risk is no release-build
gain (or regression), given the actual inline array implementation.
