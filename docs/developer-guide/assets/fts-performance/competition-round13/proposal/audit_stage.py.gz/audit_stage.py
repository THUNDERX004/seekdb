"""Offline package audit. --seal writes only round13 auxiliary audit artifacts."""
import argparse
import ast
import difflib
import hashlib
import json
from pathlib import Path
import runpy

HERE = Path(__file__).resolve().parent


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def blob(raw):
    return hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()


def lf(raw):
    return raw.replace(b"\r\n", b"\n")


def source_patch(path, old, new):
    return ("diff --git a/" + path + " b/" + path + "\n"
            + "index " + blob(old) + ".." + blob(new) + " 100644\n"
            + "".join(difflib.unified_diff(old.decode().splitlines(True), new.decode().splitlines(True),
                                           "a/" + path, "b/" + path)))


def audit(seal):
    manifest = json.loads((HERE / "manifest.json").read_bytes())
    expected_files = {
        "README.md", "prepare_stage.py", "audit_stage.py", "manifest.json",
        "source.patch", "regression.patch", "static-audit.json",
        "original/src/sql/engine/sort/ob_sort_op_impl.h",
        "original/src/sql/engine/sort/ob_sort_op_impl.cpp",
        "src/sql/engine/sort/ob_sort_op_impl.h",
        "src/sql/engine/sort/ob_sort_op_impl.cpp",
        "unittest/sql/engine/sort/test_sort_compare_init.cpp",
        "unittest/sql/engine/sort/test_sort_metadata.py",
    }
    actual = {p.relative_to(HERE).as_posix() for p in HERE.rglob("*") if p.is_file()}
    missing = expected_files - actual
    if actual - expected_files or (missing - {"static-audit.json"} if seal else missing):
        raise ValueError(("Unexpected/missing artifacts", sorted(actual - expected_files), sorted(missing)))
    assert len(manifest["source_files"]) == 2
    assert set(manifest["source_write_set"]) == {
        "src/sql/engine/sort/ob_sort_op_impl.h", "src/sql/engine/sort/ob_sort_op_impl.cpp"}
    patches, source_checks = [], []
    for entry in manifest["source_files"]:
        path = entry["path"]
        original, changed = (HERE / entry["snapshot"]).read_bytes(), (HERE / path).read_bytes()
        assert digest(original) == entry["original_raw_sha256"]
        assert digest(changed) == entry["changed_raw_sha256"]
        assert blob(original) == entry["original_raw_git_blob"]
        assert blob(changed) == entry["changed_raw_git_blob"]
        assert blob(lf(original)) == entry["original_lf_git_blob"] == entry["head_git_blob"]
        assert blob(lf(changed)) == entry["changed_lf_git_blob"]
        # Only these two source bytes need remain identical if the parent commits.
        assert (Path(manifest["source_root"]) / path).read_bytes() == original
        assert changed.count(b"\r\n") == changed.count(b"\n")
        patches.append(source_patch(path, lf(original), lf(changed)))
        source_checks.append({"path": path, "raw_hashes_verified": True,
                              "live_D_source_matches_snapshot": True})
        if path.endswith(".cpp"):
            old, new = lf(original).decode(), lf(changed).decode()
            start = "bool ObSortOpImpl::Compare::operator()(\n"
            # Match actual signature whitespace by splitting after the row comparator.
            old_tail = old[old.index("bool ObSortOpImpl::Compare::operator()(", old.index(start) + 1):]
            new_tail = new[new.index("bool ObSortOpImpl::Compare::operator()(", new.index(start) + 1):]
            assert old_tail == new_tail
            old_body = old[old.index(start):old.index(old_tail)]
            new_body = new[new.index(start):new.index(new_tail)]
            cache_start = new_body.index("  } else if (cached_column_count_ > 0")
            cache_end = new_body.index("  } else {\n    const ObDatum *lcells", cache_start)
            assert new_body[:cache_start] + new_body[cache_end:] == old_body
            assert "sort_collations->count() != sort_cmp_funs->count()" in new
            assert "sort_cmp_funs->count() != sort_cmp_funs->count()" not in new
    assert (HERE / "source.patch").read_bytes() == "".join(patches).encode()
    regressions = []
    for path in manifest["new_regression_files"]:
        content = (HERE / path).read_text(encoding="utf-8")
        regressions.append("diff --git a/" + path + " b/" + path + "\nnew file mode 100644\n"
                           + "".join(difflib.unified_diff([], content.splitlines(True),
                                                         "/dev/null", "b/" + path)))
    regression_raw = "".join(regressions).encode()
    if seal:
        (HERE / "regression.patch").write_bytes(regression_raw)
    else:
        assert (HERE / "regression.patch").read_bytes() == regression_raw
    for path in HERE.rglob("*.py"):
        ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    sql = runpy.run_path(str(HERE / "unittest/sql/engine/sort/test_sort_metadata.py"),
                         run_name="offline_audit_only")
    workload = list(sql["cases"]())
    assert len(workload) == 378
    assert len({case["id"] for case in workload}) == len(workload)
    assert len(list(sql["documents"]())) == 1027
    assert not any("\n+" in case["sql"] for case in workload)
    checks = {"schema_version": 1, "source_checks": source_checks,
              "source_patch_matches_full_files": True,
              "generic_storedrow_body_unchanged_after_removing_cache_branch": True,
              "other_comparison_overloads_and_all_later_cpp_unchanged": True,
              "python_ast_parsed": True, "python_main_or_capture_executed": False,
              "sql_case_count": len(workload), "sql_row_count": 1027,
              "workload_sha256": sql["signature"](workload),
              "fixture_created": False,
              "native_build_sql_perf_executed": False,
              "git_apply_check": "run separately; see README and parent tool transcript",
              "limitations": ["C++ not compiled", "SQL dialect and operator coverage not executed",
                              "No performance evidence; release at(i) is inline"]}
    if seal:
        (HERE / "static-audit.json").write_text(json.dumps(checks, indent=2) + "\n", encoding="utf-8")
        manifest["artifact_inventory"] = [
            {"path": path, "bytes": (HERE / path).stat().st_size,
             "sha256": digest((HERE / path).read_bytes())}
            for path in sorted(expected_files - {"manifest.json"})]
        (HERE / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    else:
        assert json.loads((HERE / "static-audit.json").read_bytes()) == checks
        assert {e["path"] for e in manifest["artifact_inventory"]} == expected_files - {"manifest.json"}
        for entry in manifest["artifact_inventory"]:
            raw = (HERE / entry["path"]).read_bytes()
            assert len(raw) == entry["bytes"] and digest(raw) == entry["sha256"]
    print(json.dumps({"artifact_count": len(expected_files), "inventory_entries": 12,
                      "sql_case_count": len(workload), "workload_sha256": checks["workload_sha256"],
                      "sealed": seal, "checks": "PASS offline only"}, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seal", action="store_true")
    audit(parser.parse_args().seal)
