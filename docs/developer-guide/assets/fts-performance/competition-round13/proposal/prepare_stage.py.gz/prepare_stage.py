"""Create round13 artifacts in this directory only; never apply them to source."""
from datetime import datetime, timezone
import difflib
import hashlib
import json
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
SOURCE = Path(r"D:\Projects\OceanBase\seekdb")
FILES = ("src/sql/engine/sort/ob_sort_op_impl.h",
         "src/sql/engine/sort/ob_sort_op_impl.cpp")
BASELINE = "5bce9e06d1281347ad61344e4b01fab9158c58a2"


def git(*args):
    return subprocess.check_output(["git", "-C", str(SOURCE), *args]).decode().strip()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def blob(raw):
    return hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()


def replace_once(text, old, new):
    if text.count(old) != 1:
        raise ValueError("Source marker missing or ambiguous: " + old[:120])
    return text.replace(old, new)


def patch(path, old, new):
    return ("diff --git a/" + path + " b/" + path + "\n"
            + "index " + blob(old.encode()) + ".." + blob(new.encode()) + " 100644\n"
            + "".join(difflib.unified_diff(old.splitlines(True), new.splitlines(True),
                                           "a/" + path, "b/" + path)))


def main():
    # Fail rather than mix a previous package with a new snapshot.
    for name in ("original", "src", "source.patch", "manifest.json"):
        if (HERE / name).exists():
            raise FileExistsError(HERE / name)
    head = git("rev-parse", "HEAD")
    branch = git("branch", "--show-current")
    git("merge-base", "--is-ancestor", BASELINE, "HEAD")
    before_status = git("status", "--short")
    changes, source_manifest = [], []
    for path in FILES:
        raw = (SOURCE / path).read_bytes()
        old = raw.decode().replace("\r\n", "\n")
        head_blob = git("rev-parse", "HEAD:" + path)
        if blob(old.encode()) != head_blob:
            raise ValueError("Sort source has uncommitted changes: " + path)
        new = old
        if path.endswith(".h"):
            new = replace_once(new,
                "  private:\n    int64_t cnt_;\n    DISALLOW_COPY_AND_ASSIGN(Compare);",
                "  private:\n"
                "    static const int64_t MAX_CACHED_SORT_COLUMNS = 4;\n"
                "    struct CachedSortColumn\n"
                "    {\n"
                "      uint32_t field_idx_;\n"
                "      bool is_ascending_;\n"
                "      common::ObDatumCmpFuncType cmp_func_;\n"
                "    };\n"
                "    // Sort descriptors are fixed until reset/re-init; ranges remain dynamic.\n"
                "    int64_t cached_column_count_;\n"
                "    CachedSortColumn cached_columns_[MAX_CACHED_SORT_COLUMNS];\n"
                "    int64_t cnt_;\n"
                "    DISALLOW_COPY_AND_ASSIGN(Compare);")
        else:
            new = replace_once(new,
                "    exec_ctx_(nullptr), access_ctx_(nullptr), cmp_count_(0), cmp_start_(0), cmp_end_(0)\n",
                "    exec_ctx_(nullptr), access_ctx_(nullptr), cmp_count_(0), cmp_start_(0), cmp_end_(0),\n"
                "    cached_column_count_(0)\n")
            new = replace_once(new,
                "sort_cmp_funs->count() != sort_cmp_funs->count()",
                "sort_collations->count() != sort_cmp_funs->count()")
            new = replace_once(new,
                "    cmp_end_ = sort_cmp_funs_->count();\n"
                "    enable_encode_sortkey_ = enable_encode_sortkey;\n",
                "    cmp_end_ = sort_cmp_funs_->count();\n"
                "    enable_encode_sortkey_ = enable_encode_sortkey;\n"
                "    cached_column_count_ = cnt_ <= MAX_CACHED_SORT_COLUMNS ? cnt_ : 0;\n"
                "    for (int64_t i = 0; i < cached_column_count_; ++i) {\n"
                "      const ObSortFieldCollation &collation = sort_collations_->at(i);\n"
                "      cached_columns_[i].field_idx_ = collation.field_idx_;\n"
                "      cached_columns_[i].is_ascending_ = collation.is_ascending_;\n"
                "      cached_columns_[i].cmp_func_ = sort_cmp_funs_->at(i).cmp_func_;\n"
                "    }\n")
            new = replace_once(new,
                "    less = cmp != 0 ? (cmp < 0) : (l_cell.len_ - r_cell.len_) < 0;\n"
                "  } else {\n",
                "    less = cmp != 0 ? (cmp < 0) : (l_cell.len_ - r_cell.len_) < 0;\n"
                "  } else if (cached_column_count_ > 0 && cmp_start_ >= 0\n"
                "             && cmp_start_ <= cmp_end_ && cmp_end_ <= cached_column_count_) {\n"
                "    const ObDatum *lcells = l->cells();\n"
                "    const ObDatum *rcells = r->cells();\n"
                "    int cmp = 0;\n"
                "    for (int64_t i = cmp_start_; 0 == cmp && i < cmp_end_ && OB_SUCC(ret); i++) {\n"
                "      const CachedSortColumn &column = cached_columns_[i];\n"
                "      const int64_t idx = column.field_idx_;\n"
                "      if (OB_FAIL(column.cmp_func_(lcells[idx], rcells[idx], cmp, access_ctx_))) {\n"
                "      } else if (cmp < 0) {\n"
                "        less = column.is_ascending_;\n"
                "      } else if (cmp > 0) {\n"
                "        less = !column.is_ascending_;\n"
                "      }\n"
                "    }\n"
                "  } else {\n")
        newline = "CRLF" if b"\r\n" in raw else "LF"
        changed = new.replace("\n", "\r\n").encode() if newline == "CRLF" else new.encode()
        original_path, changed_path = HERE / "original" / path, HERE / path
        original_path.parent.mkdir(parents=True, exist_ok=True)
        changed_path.parent.mkdir(parents=True, exist_ok=True)
        original_path.write_bytes(raw)
        changed_path.write_bytes(changed)
        source_manifest.append({"path": path, "head_git_blob": head_blob,
                                "original_raw_git_blob": blob(raw),
                                "original_raw_sha256": sha(raw), "original_bytes": len(raw),
                                "original_lf_git_blob": blob(old.encode()),
                                "snapshot": "original/" + path,
                                "changed_raw_git_blob": blob(changed),
                                "changed_raw_sha256": sha(changed), "changed_bytes": len(changed),
                                "changed_lf_git_blob": blob(new.encode()), "line_endings": newline})
        changes.append(patch(path, old, new))
    (HERE / "source.patch").write_bytes("".join(changes).encode())
    regression_paths = sorted(p.relative_to(HERE).as_posix() for p in (HERE / "unittest").rglob("*")
                              if p.is_file())
    regression = []
    for path in regression_paths:
        text = (HERE / path).read_text(encoding="utf-8")
        regression.append("diff --git a/" + path + " b/" + path + "\nnew file mode 100644\n"
                          + "".join(difflib.unified_diff([], text.splitlines(True),
                                                        "/dev/null", "b/" + path)))
    (HERE / "regression.patch").write_bytes("".join(regression).encode())
    if head != git("rev-parse", "HEAD") or before_status != git("status", "--short"):
        raise ValueError("Parent checkout changed during snapshot; review before use")
    manifest = {"schema_version": 1, "purpose": "round13 <=4 sort descriptor cache; staging only",
                "created_utc": datetime.now(timezone.utc).isoformat(),
                "source_root": str(SOURCE), "source_head": head, "source_branch": branch,
                "official_baseline": BASELINE, "observed_source_status": before_status.splitlines(),
                "source_files": source_manifest, "new_regression_files": regression_paths,
                "source_write_set": list(FILES), "fixture_created": False,
                "build_native_sql_perf_run": False}
    (HERE / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"source_head": head, "source_write_set": list(FILES),
                      "regression_files": regression_paths}, indent=2))


if __name__ == "__main__":
    main()
