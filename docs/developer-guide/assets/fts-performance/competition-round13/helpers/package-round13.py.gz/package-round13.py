#!/usr/bin/env python3
"""Archive and verify round13 sort-cache evidence; compress raw files losslessly."""
import argparse
import gzip
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path(r"D:\Projects\OceanBase\seekdb")
OFFICIAL = "5bce9e06d1281347ad61344e4b01fab9158c58a2"
PARENT = "e68cd70067a0fd255bd24930e2227ec9e135ffad"
BASELINE_SHA = "bae4a3b9e1b4662d4021b28d5adc085764beb6cf02122eacd57b8e16b6fe1762"
CANDIDATE_SHA = "83ae72ac7ea56d2ecbe04e948424a5fad587d6b2f8156ca56c2a39f628e2b23c"
CONTROL_SHA = "9c239e363020a77c201c31456c940084f948d5b5741ec73472af55632c9b91da"
PATCH_SHA = "676b6f853d4993a61fd7b51b8977179f6ccec256a52c8521a68298beedd967fe"


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n",
                    encoding="utf-8", newline="\n")


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--decision", choices=("reject",), required=True)
    args = p.parse_args()
    output = ROOT / "docs/developer-guide/assets/fts-performance/competition-round13"
    if output.exists():
        raise FileExistsError("Refusing to overwrite: " + str(output))

    comparison = json.loads((HERE / "round13-sort-three-pair-comparison.json").read_text())
    source_meta = json.loads((HERE / "round13-sort-binary.json").read_text())
    require(source_meta["source_parent"] == PARENT, "Candidate parent mismatch")
    require(source_meta["binary_sha256"] == CANDIDATE_SHA, "Candidate executable provenance")
    patch = (HERE / "round13-sort-source.patch").read_bytes()
    require(sha(patch) == PATCH_SHA, "Exact candidate patch mismatch")
    require(source_meta["source_patch_sha256"] == PATCH_SHA, "Patch metadata mismatch")

    files = []
    # Preserve all round13 root logs, reports, metadata, plans and patch files.
    files.extend((path, path.name) for path in sorted(HERE.iterdir())
                 if path.is_file() and path.name.startswith("round13-"))
    files.append((HERE / "experiment-competition.py", "helpers/experiment-competition.py"))
    files.append((HERE / "package-round13.py", "helpers/package-round13.py"))
    proposal = HERE / "round13-sort-proposal"
    files.extend((path, "proposal/" + path.relative_to(proposal).as_posix())
                 for path in sorted(proposal.rglob("*")) if path.is_file())
    helper = HERE / "round13-native-helper"
    allowed = {".json", ".py", ".ps1", ".cpp", ".h", ".md", ".rsp", ".log"}
    files.extend((path, "native-helper/" + path.relative_to(helper).as_posix())
                 for path in sorted(helper.rglob("*"))
                 if path.is_file() and path.suffix.lower() in allowed)
    fixture = ROOT / "unittest/sql/engine/sort/sort_metadata_expected.json.gz"
    driver = ROOT / "unittest/sql/engine/sort/test_sort_metadata.py"
    files.extend(((fixture, "regression/sort_metadata_expected.json.gz"),
                  (driver, "regression/test_sort_metadata.py")))
    build_log = HERE / "round13-sort-cache-build.log"
    if build_log.is_file():
        files.append((build_log, "build/round13-sort-cache-build.log"))
    names = [name for _, name in files]
    require(len(names) == len(set(names)), "Duplicate archive path")
    for path, name in files:
        require(path.is_file() and not path.is_symlink(), "Missing/symlink input: " + str(path))

    fixture_data = json.loads(gzip.decompress(fixture.read_bytes()))
    require(fixture_data["original"] == {"commit": OFFICIAL, "binary_sha256": BASELINE_SHA},
            "Independent original provenance")
    require(len(fixture_data["results"]) == 315, "Fixture case count")
    require(fixture_data["workload_sha256"] == "f513d19f9a26a29750880825f3e60ac6afb132da6a049f48fd9148de124053a4",
            "Final workload identity")

    experiments = [json.loads(path.read_text()) for path in HERE.glob("round13-sort-bench-*-experiment.json")]
    by_label = {item["label"]: item for item in experiments}
    for i in (1, 2, 3):
        for role, binary_sha in (("candidate", CANDIDATE_SHA), ("control", CONTROL_SHA)):
            item = by_label[f"round13-sort-bench-{role}-{i}"]
            require(item["binary_sha256"] == binary_sha, "Benchmark binary identity")
            require(all(action["exit_code"] == 0 for action in item["actions"]), "Incomplete run")
            require(item["log_level"] == "WARN", "Benchmark log level")
        require(by_label[f"round13-sort-bench-candidate-{i}"]["source_commit"] == PARENT + "+" + PATCH_SHA,
                "Candidate source provenance")

    output.mkdir(parents=True)
    payloads = {}
    for path, name in files:
        raw = path.read_bytes()
        archived = name + ".gz"
        packed = gzip.compress(raw, mtime=0)
        target = output / archived
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(packed)
        payloads[archived] = {"sha256": sha(packed), "raw_sha256": sha(raw), "raw_bytes": len(raw)}

    manifest = {
        "official_baseline": OFFICIAL,
        "parent_commit": PARENT,
        "production_decision": "reject cache; both sort production files restored byte-for-byte",
        "candidate_patch_sha256": PATCH_SHA,
        "candidate_binary_sha256": CANDIDATE_SHA,
        "control_binary_sha256": CONTROL_SHA,
        "official_fixture_cases": 315,
        "official_fixture_sha256": sha(fixture.read_bytes()),
        "candidate_sql_result": "PASS: all 315 complete ordered rows, metadata and warnings",
        "direct_production_init_test": "PASS: 12 invalid count scenarios, 8 valid init and 8 reset scenarios",
        "three_pair_comparison": comparison,
        "decision_reason": "Overall time reduction is only 0.4536%; query category regresses 2.9049%, and the first two pairs regress overall. Build/tokenize movements are treated as noise unrelated to this sort-only change.",
        "formal_score": None,
        "limitations": [
            "Local Windows evidence only; no new official platform score or Linux CI claim.",
            "The official original crashed when enable_newsort was explicitly forced on; that mode and its failures are retained but excluded from the 315-case fixture. Default, rowset-size and encode-off modes remain.",
            "Plan coverage confirms SORT, TOP-N SORT, MERGE GROUP BY, WINDOW FUNCTION and TEXT RETRIEVAL SCAN; not every operator execution branch is proven.",
            "The direct native test calls real Compare::init but does not compare Datum rows; SQL complete-result comparison covers the exercised sort plans.",
            "All six full-load scored runs and all negative metrics are retained; no clipping, fastest-sample choice or SELECT1 subtraction.",
            "All archive members are deterministic gzip; manifest records both compressed and original-byte SHA256."
        ],
        "files": payloads,
    }
    write_json(output / "manifest.json", manifest)
    for name, record in payloads.items():
        packed = (output / name).read_bytes()
        require(sha(packed) == record["sha256"], "Archive digest mismatch: " + name)
        require(sha(gzip.decompress(packed)) == record["raw_sha256"], "Raw digest mismatch: " + name)

    for language in ("en", "zh-CN"):
        report = ROOT / f"docs/developer-guide/{language}/fts-performance.md"
        old = report.read_text(encoding="utf-8")
        require("Round-13 sort-cache experiment" not in old and "第十三轮排序缓存实验" not in old,
                "Round13 report already exists")
        if language == "en":
            section = "## Round-13 sort-cache experiment (2026-11-04)\n\n"
            section += "Decision: **reject the sort descriptor cache** and restore both production files. Three full adjacent pairs against the saved parent show only **0.4536%** equal-category time reduction, while the query category is **2.9049% slower** and the first two pairs regress overall. The small aggregate gain comes from build/tokenize movements unrelated to the sort-only change and is not a stable FTS benefit. There is no new formal score.\n\n"
            section += "Before rejection, the candidate built successfully, matched all 315 official-original complete SQL results, metadata and warnings, and passed a direct production-linked initialization test (12 invalid-count cases, 8 valid initializations and 8 resets). Plans included ordinary SORT, TOP-N SORT, MERGE GROUP BY, windows and text retrieval. Forcing `enable_newsort` on crashed the original executable; those failed recordings are preserved and that mode is excluded, while default, rowset-size and encode-off cases remain.\n\n"
            section += "The [round-13 evidence manifest](../assets/fts-performance/competition-round13/manifest.json) includes both exact source snapshots, the candidate patch and executable identity, original fixture and plans, the native linker receipt, all six complete benchmark reports and failed original attempts. The rejected cache is not present in the production source.\n\n"
        else:
            section = "## 第十三轮排序缓存实验（2026-11-04）\n\n"
            section += "决定：**撤回排序描述符缓存**，两个生产文件已按原始字节恢复。三组完整相邻对照的三类等权综合耗时仅下降 **0.4536%**，查询类反而**退化 2.9049%**，且前两组综合均退化。微小总提升来自与排序改动无关的构建/分词波动，不能证明稳定全文检索收益；没有新的正式成绩。\n\n"
            section += "撤回前候选构建成功，315 组官方原版完整 SQL 结果、列元数据和 warning 全部一致；直接链接生产代码的初始化测试通过（12 个错误计数、8 次有效初始化、8 次 reset）。计划覆盖普通 SORT、TOP-N SORT、MERGE GROUP BY、窗口及全文扫描。官方原版在强制开启 `enable_newsort` 时断连崩溃；失败完整保留并从 fixture 排除，默认、rowset 大小和关闭编码模式仍全部测试。\n\n"
            section += "[第十三轮证据清单](../assets/fts-performance/competition-round13/manifest.json)包含原始/候选源码快照、精确补丁与二进制身份、原版 fixture 和执行计划、生产依赖 native 链接凭证、全部六份完整基准报告及原版失败记录。生产源码中不保留已撤回的缓存。\n\n"
        title, rest = old.split("\n", 1)
        report.write_text(title + "\n\n" + section + rest.lstrip("\n"),
                          encoding="utf-8", newline="\n")
    print("Packaged and verified", len(payloads), "round13 raw evidence files")


def require(ok, message):
    if not ok:
        raise ValueError(message)


if __name__ == "__main__":
    main()
