param(
    [Parameter(Mandatory = $true)][string]$SourceRoot,
    [Parameter(Mandatory = $true)][string]$OutputDir,
    [string]$BuildDir,
    [string]$Python = 'python.exe',
    [switch]$Build,
    [switch]$Run
)
$ErrorActionPreference = 'Stop'
if ($Run -and -not $Build) { throw '-Run requires -Build.' }
$env:PYTHONUTF8 = '1'
if ($Build) {
    $checkerVs = 'C:\Program Files\Microsoft Visual Studio\2022\BuildTools'
    Import-Module (Join-Path $checkerVs 'Common7\Tools\Microsoft.VisualStudio.DevShell.dll')
    Enter-VsDevShell -VsInstallPath $checkerVs -SkipAutomaticLocation `
        -DevCmdArguments '-arch=amd64 -host_arch=amd64 -vcvars_ver=14.44 -winsdk=10.0.26100.0'
}
$helperArgs = @(
    (Join-Path $PSScriptRoot 'prepare_sort_compare_init.py'),
    '--source-root', $SourceRoot, '--output-dir', $OutputDir
)
if ($BuildDir) { $helperArgs += @('--build-dir', $BuildDir) }
if ($Build) { $helperArgs += '--build' }
if ($Run) { $helperArgs += '--run' }
& $Python @helperArgs
exit $LASTEXITCODE
