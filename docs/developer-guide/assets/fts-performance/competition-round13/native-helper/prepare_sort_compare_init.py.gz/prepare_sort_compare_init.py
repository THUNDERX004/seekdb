"""Plan or explicitly compile/link/run the pinned round13 Compare::init adapter.

Plan mode only reads the source/build checkout and writes helper-owned files.
It never calls CMake or Ninja. Build mode requires a completed candidate build.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

HERE = Path(__file__).resolve().parent
DEFAULT_ROOT = Path(r"D:\Projects\OceanBase\seekdb")
DEFAULT_PROPOSAL = Path(
    r"C:\Users\11946\Documents\ChatGPT\OceanBase比赛\setup\fts\round13-sort-proposal")
ROUND12 = HERE.parent / "round12-native-helper"
ROUND12_SETTINGS_SHA = "f8de1396187287b3c4021760a84992310e5f44f859a5e1a9b67a4d6cc1d41802"
SOURCE_FILES = (
    "src/sql/engine/sort/ob_sort_op_impl.h",
    "src/sql/engine/sort/ob_sort_op_impl.cpp",
)
TEST_REL = "unittest/sql/engine/sort/test_sort_compare_init.cpp"
ADAPTER_REL = "testpins/test_sort_compare_init_main.cpp"
MAIN_OBJ = "src/observer/CMakeFiles/ob_main.dir/main.cpp.obj"
SQL_OBJ = "src/sql/CMakeFiles/ob_sql.dir/Unity/unity_ob_sql_ob_sql_engine_0_c___cxx.cxx.obj"
SQL_UNITY = "unity_ob_sql_ob_sql_engine_0_c___cxx.cxx"
SQL_ARCHIVE = "src/sql/ob_sql_static.lib"


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def json_write(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def windows_args(command):
    """Decode MS CRT quoting without starting a process or using shell parsing."""
    result, index = [], 0
    while index < len(command):
        while index < len(command) and command[index] in " \t\r\n":
            index += 1
        if index == len(command):
            break
        arg, quoted = [], False
        while index < len(command):
            if command[index] in " \t\r\n" and not quoted:
                break
            slashes = 0
            while index < len(command) and command[index] == "\\":
                slashes += 1
                index += 1
            if index < len(command) and command[index] == '"':
                arg.append("\\" * (slashes // 2))
                if slashes % 2:
                    arg.append('"')
                elif quoted and index + 1 < len(command) and command[index + 1] == '"':
                    arg.append('"')
                    index += 1
                else:
                    quoted = not quoted
                index += 1
            else:
                arg.append("\\" * slashes)
                if index < len(command) and command[index] in " \t\r\n" and not quoted:
                    break
                if index < len(command):
                    arg.append(command[index])
                    index += 1
        require(not quoted, "Unterminated Windows command quote")
        result.append("".join(arg))
    return result


def response_write(path, args):
    encoded = subprocess.list2cmdline(args)
    require(windows_args(encoded) == args, "Response-file quoting round trip failed")
    Path(path).write_text(encoded + "\n", encoding="utf-8")


def ninja_expand(value, variables):
    def replace(match):
        key = match.group(1)
        if key in ("$", " ", ":"):
            return key
        key = key[1:-1] if key.startswith("{") else key
        require(key in variables, "Unsupported Ninja variable: " + key)
        return variables[key]
    return re.sub(r"\$(\$| |:|\{[^}]+\}|[A-Za-z_][A-Za-z_0-9]*)", replace, value)


def ninja_blocks(path):
    lines = Path(path).read_text(encoding="utf-8").splitlines()
    require(not any(line.endswith("$") for line in lines),
            "Ninja continuation appeared; recapture deliberately")
    blocks = []
    for index, line in enumerate(lines):
        if line.startswith(("build ", "rule ")):
            values = {}
            for following in lines[index + 1:]:
                if not following.startswith("  "):
                    break
                key, separator, value = following.strip().partition(" = ")
                require(bool(separator), "Unsupported Ninja binding")
                values[key] = value
            blocks.append((line, values))
    return blocks


def normalize_path(value):
    return value.replace("\\", "/")


def capture_records(root, build_dir, round12):
    compile_path = build_dir / "compile_commands.json"
    commands = json.loads(compile_path.read_text(encoding="utf-8"))
    main_records = [entry for entry in commands
                    if normalize_path(entry.get("output", "")) == MAIN_OBJ]
    sql_records = [entry for entry in commands
                   if normalize_path(entry.get("output", "")) == SQL_OBJ]
    require(len(main_records) == 1 and len(sql_records) == 1,
            "Expected one production main.cpp and SQL engine unity compile record")
    require(Path(sql_records[0]["file"]).name == SQL_UNITY,
            "SQL engine unity source identity changed")

    blocks = ninja_blocks(build_dir / "build.ninja")
    link_edges = [(line, values) for line, values in blocks
                  if line.startswith("build src/observer/seekdb.exe:")]
    archive_edges = [(line, values) for line, values in blocks
                     if line.startswith("build " + SQL_ARCHIVE + ":")]
    require(len(link_edges) == 1 and len(archive_edges) == 1,
            "Expected one seekdb executable edge and one SQL archive edge")

    link_edge, link_values = link_edges[0]
    link_rule_name, link_tail = link_edge.split(": ", 1)[1].split(" ", 1)
    link_inputs = ninja_expand(link_tail.split(" |", 1)[0], {}).split()
    require(link_inputs.count(MAIN_OBJ) == 1 and all(item.endswith(".obj") for item in link_inputs),
            "Production main object is not uniquely replaceable in the executable edge")
    require(link_values.get("PRE_LINK") == "cd .", "Unexpected seekdb PRE_LINK action")

    archive_edge, archive_values = archive_edges[0]
    archive_rule_name, archive_tail = archive_edge.split(": ", 1)[1].split(" ", 1)
    archive_inputs = ninja_expand(archive_tail.split(" |", 1)[0], {}).split()
    require(archive_inputs.count(SQL_OBJ) == 1 and len(archive_inputs) > 1,
            "SQL engine unity object is not uniquely present in the production archive edge")

    rule_blocks = ninja_blocks(build_dir / "CMakeFiles/rules.ninja")
    def get_rule(name):
        found = [values for line, values in rule_blocks if line == "rule " + name]
        require(len(found) == 1, "Ninja rule missing or duplicated: " + name)
        return found[0]

    link_rule = get_rule(link_rule_name)
    archive_rule = get_rule(archive_rule_name)
    require(link_rule.get("rspfile_content") == "$in $LINK_PATH $LINK_LIBRARIES",
            "Unexpected executable response-file contract")
    require(archive_rule.get("rspfile_content") == "$in $LINK_PATH $LINK_LIBRARIES",
            "Unexpected SQL archive response-file contract")

    selected_link = {key: link_values[key] for key in (
        "LINK_FLAGS", "LINK_PATH", "LINK_LIBRARIES", "PRE_LINK", "POST_BUILD", "TARGET_FILE")}
    previous = round12["records"]
    require(link_rule_name == previous["link_rule_name"]
            and link_rule == previous["link_rule"]
            and selected_link == previous["link_variables"]
            and link_inputs == previous["explicit_objects"],
            "Seekdb Ninja link edge differs from the frozen round12 capture")
    libraries = windows_args(ninja_expand(selected_link["LINK_LIBRARIES"], {}))
    require(sum(normalize_path(item) == SQL_ARCHIVE
                or normalize_path(item).endswith("/" + SQL_ARCHIVE) for item in libraries) == 1,
            "The real SQL production archive is not a unique seekdb link input")

    return {
        "main_compile_record": main_records[0],
        "sql_compile_record": sql_records[0],
        "sql_archive_edge": archive_edge,
        "sql_archive_rule_name": archive_rule_name,
        "sql_archive_rule": archive_rule,
        "sql_archive_values": archive_values,
        "sql_archive_inputs": archive_inputs,
        "link_edge": link_edge,
        "link_rule_name": link_rule_name,
        "link_rule": link_rule,
        "link_variables": selected_link,
        "explicit_objects": link_inputs,
    }


def verify_helper_manifest():
    path = HERE / "manifest.json"
    if not path.is_file():
        return
    manifest = json.loads(path.read_text(encoding="utf-8"))
    for item in manifest["files"]:
        file_path = HERE / item["path"]
        require(file_path.is_file() and sha(file_path) == item["sha256"],
                "Prepared helper file changed: " + item["path"])


def write_helper_manifest():
    files = []
    for path in sorted(HERE.rglob("*")):
        if (not path.is_file() or path.name == "manifest.json"
                or "__pycache__" in path.parts or path.suffix == ".pyc"):
            continue
        files.append({"path": path.relative_to(HERE).as_posix(),
                      "bytes": path.stat().st_size, "sha256": sha(path)})
    material = "".join(f"{item['path']}\0{item['sha256']}\0{item['bytes']}\n" for item in files)
    tree_digest = hashlib.sha256(material.encode("utf-8")).hexdigest()
    json_write(HERE / "manifest.json", {
        "schema_version": 1,
        "purpose": "round13 Compare::init native helper; plan-only preparation",
        "files": files,
        "helper_tree_sha256": tree_digest,
        "compile": "NOT RUN",
        "link": "NOT RUN",
        "native": "NOT RUN",
        "sql": "NOT RUN",
        "benchmark": "NOT RUN",
    })


def capture_helper(root, build_dir, proposal, records):
    require(not (HERE / "manifest.json").exists(), "Helper has already been sealed")
    proposal_manifest_path = proposal / "manifest.json"
    proposal_manifest = json.loads(proposal_manifest_path.read_text(encoding="utf-8"))
    source_entries = {item["path"]: item for item in proposal_manifest["source_files"]}
    for rel in SOURCE_FILES:
        entry = source_entries[rel]
        staged = proposal / rel
        require(sha(staged) == entry["changed_raw_sha256"], "Staged production source hash mismatch: " + rel)
        destination = HERE / "sortsource" / rel
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(staged, destination)
    staged_test = proposal / TEST_REL
    inventory = {item["path"]: item for item in proposal_manifest["artifact_inventory"]}
    require(TEST_REL in inventory and sha(staged_test) == inventory[TEST_REL]["sha256"],
            "Staged gtest source hash differs from its proposal manifest")
    shutil.copyfile(staged_test, HERE / "testpins/test_sort_compare_init.original.cpp")

    round12_manifest = json.loads((ROUND12 / "manifest.json").read_text(encoding="utf-8"))
    round12_settings_path = ROUND12 / "build-settings.json"
    require(sha(round12_settings_path) == ROUND12_SETTINGS_SHA,
            "Frozen round12 build-settings SHA changed")
    require(any(item["path"] == "build-settings.json" and item["sha256"] == ROUND12_SETTINGS_SHA
                for item in round12_manifest["artifact_files"]),
            "Round12 manifest does not pin the expected production settings")
    round12_settings = json.loads(round12_settings_path.read_text(encoding="utf-8"))
    require(root == Path(round12_settings["source_root"]).resolve()
            and build_dir == Path(round12_settings["build_dir"]).resolve(),
            "Source/build paths differ from the frozen round12 production configuration")

    build_files = [build_dir / "compile_commands.json", build_dir / "build.ninja",
                   build_dir / "CMakeFiles/rules.ninja"]
    settings = {
        "schema_version": 1,
        "source_root": str(root),
        "build_dir": str(build_dir),
        "configuration": round12_settings["configuration"],
        "environment_required": round12_settings["environment_required"],
        "round12_settings_sha256": ROUND12_SETTINGS_SHA,
        "round13_proposal_manifest_sha256": sha(proposal_manifest_path),
        "build_file_sha256": {str(path): sha(path) for path in build_files},
        "records": records,
        "production_source_pins": [
            {"path": rel, "sha256": source_entries[rel]["changed_raw_sha256"],
             "original_sha256": source_entries[rel]["original_raw_sha256"]}
            for rel in SOURCE_FILES
        ],
        "staged_test_sha256": inventory[TEST_REL]["sha256"],
        "adapter_sha256": sha(HERE / ADAPTER_REL),
        "sql_unity_sha256": sha(Path(records["sql_compile_record"]["file"])),
        "capture_mode": "read-only CMake/Ninja extraction; no compiler/linker/Ninja execution",
        "limitations": [
            "Build requires the D: sort sources to match the candidate SHA and the completed candidate SQL production archive.",
            "Object/archive mtime checks are freshness guards, not archive-content proof.",
            "The adapter checks init state only and does not invoke row comparison operators.",
        ],
    }
    json_write(HERE / "build-settings.json", settings)
    pins = {
        "schema_version": 1,
        "source_root": str(root),
        "source_branch_at_staging": proposal_manifest["source_branch"],
        "source_head_at_staging": proposal_manifest["source_head"],
        "official_baseline": proposal_manifest["official_baseline"],
        "proposal_manifest_sha256": sha(proposal_manifest_path),
        "source_patch_sha256": sha(proposal / "source.patch"),
        "production_sources": settings["production_source_pins"],
        "original_gtest_path": TEST_REL,
        "original_gtest_sha256": inventory[TEST_REL]["sha256"],
        "adapter_path": ADAPTER_REL,
        "adapter_sha256": settings["adapter_sha256"],
        "gtest_registration": "not added by this helper; original source retained for provenance",
    }
    json_write(HERE / "testpins/pins.json", pins)


def input_status(root, settings):
    status = []
    for pin in settings["production_source_pins"]:
        path = root / pin["path"]
        actual = sha(path) if path.is_file() else None
        status.append({"role": "production_candidate", "path": str(path),
                       "sha256": actual, "matches_candidate": actual == pin["sha256"],
                       "matches_original": actual == pin["original_sha256"]})
    for rel, expected in ((ADAPTER_REL, settings["adapter_sha256"]),
                          ("testpins/test_sort_compare_init.original.cpp", settings["staged_test_sha256"])):
        path = HERE / rel
        actual = sha(path) if path.is_file() else None
        status.append({"role": "helper_test_input", "path": str(path),
                       "sha256": actual, "matches": actual == expected})
    return status


def full_build_path(value, build_dir):
    path = Path(value)
    return path if path.is_absolute() else build_dir / path


def compile_args(record, source, obj, pdb, stage_root):
    tokens = windows_args(record["command"])
    require(Path(tokens[0]).name.lower() == "clang-cl.exe", "Expected captured clang-cl frontend")
    args, replaced = [], {"object": 0, "pdb": 0, "source": 0}
    for arg in tokens[1:]:
        if arg.startswith("/Fo"):
            require(normalize_path(arg[3:]) == normalize_path(record["output"]),
                    "Unexpected captured object output path")
            arg = "/Fo" + obj.as_posix()
            replaced["object"] += 1
        elif arg.startswith("/Fd"):
            arg = "/Fd" + pdb.as_posix()
            replaced["pdb"] += 1
        elif arg == record["file"]:
            arg = source.as_posix()
            replaced["source"] += 1
        args.append(arg)
    require(replaced == {"object": 1, "pdb": 1, "source": 1}, "Compile substitution was not exact")
    args.insert(0, "/I" + stage_root.as_posix())
    require("-c" in args and "--" in args, "Expected production compile-only contract")
    return tokens[0], args, replaced


def build_commands(root, build_dir, output, settings, records, status, build_mode, run_mode):
    require(records == settings["records"], "Relevant CMake/Ninja records drifted; recapture deliberately")
    for path_text, expected in settings["build_file_sha256"].items():
        require(sha(path_text) == expected, "Captured CMake/Ninja file changed: " + path_text)
    sql_unity = Path(records["sql_compile_record"]["file"])
    require(sha(sql_unity) == settings["sql_unity_sha256"], "SQL unity membership/source changed")
    unity_text = sql_unity.read_text(encoding="utf-8").replace("\\", "/")
    require("src/sql/engine/sort/ob_sort_op_impl.cpp" in unity_text,
            "Captured SQL unity does not include the sort implementation")

    if build_mode:
        require(os.name == "nt", "Captured ABI requires native Windows x64")
        require(all(item.get("matches_candidate", item.get("matches", False)) for item in status),
                "D: candidate sort source or pinned adapter/test source hash does not match")
        for key, expected in settings["environment_required"].items():
            value = os.environ.get(key, "").rstrip("\\/")
            require(value.lower() == expected.lower(),
                    f"{key}={value!r}, expected {expected!r}; use the PowerShell wrapper")
        require(bool(os.environ.get("INCLUDE")) and bool(os.environ.get("LIB")),
                "VS x64 INCLUDE/LIB missing")

    sql_obj = full_build_path(SQL_OBJ, build_dir)
    sql_archive = build_dir / SQL_ARCHIVE
    source_paths = [root / item["path"] for item in settings["production_source_pins"]]
    production_fresh = (sql_obj.is_file() and sql_archive.is_file()
                        and all(sql_obj.stat().st_mtime_ns >= path.stat().st_mtime_ns
                                for path in source_paths if path.is_file())
                        and sql_archive.stat().st_mtime_ns >= sql_obj.stat().st_mtime_ns)
    if build_mode:
        require(all(path.is_file() for path in source_paths), "Pinned production source is missing")
        require(production_fresh,
                "Candidate SQL unity/archive is not newer than both candidate sources; finish the production build first")

    compiler, comp_args, replacements = compile_args(
        records["main_compile_record"], HERE / ADAPTER_REL,
        output / "sort_compare_init_main.obj", output / "sort_compare_init_compile.pdb",
        HERE / "sortsource/src")
    link_objects = [full_build_path(item, build_dir).as_posix()
                    for item in records["explicit_objects"] if item != MAIN_OBJ]
    libraries = windows_args(ninja_expand(records["link_variables"]["LINK_LIBRARIES"], {}))
    require(all(item.lower().endswith(".lib") for item in libraries), "Unexpected link library expression")
    libraries = [full_build_path(item, build_dir).as_posix()
                 if "/" in item or "\\" in item else item for item in libraries]
    link_args = [(output / "sort_compare_init_main.obj").as_posix()] + link_objects
    link_args += windows_args(ninja_expand(records["link_variables"]["LINK_PATH"], {})) + libraries
    require(not any(normalize_path(item).endswith("/" + MAIN_OBJ) for item in link_args),
            "Original main object survived adapter substitution")

    rule = records["link_rule"]["command"]
    match = re.fullmatch(r'.+? /C "\$PRE_LINK && (.+) && \$POST_BUILD"', rule)
    require(match is not None, "Unexpected CMake executable link wrapper")
    variables = {
        "OBJECT_DIR": subprocess.list2cmdline([(output / "link-intermediate").as_posix()]),
        "RSP_FILE": subprocess.list2cmdline([(output / "link-inputs.rsp").as_posix()]),
        "TARGET_FILE": subprocess.list2cmdline([(output / "sort_compare_init.exe").as_posix()]),
        "TARGET_IMPLIB": subprocess.list2cmdline([(output / "sort_compare_init.lib").as_posix()]),
        "TARGET_PDB": subprocess.list2cmdline([(output / "sort_compare_init_link.pdb").as_posix()]),
        "MANIFESTS": "",
        "LINK_FLAGS": records["link_variables"]["LINK_FLAGS"],
    }
    link_command = windows_args(ninja_expand(match.group(1), variables))
    require("vs_link_exe" in link_command and "--manifests" in link_command,
            "Production CMake manifest-link wrapper was not retained")
    require(any(Path(arg).name.lower() == "lld-link.exe" for arg in link_command),
            "Production lld-link command was not retained")

    artifacts = []
    for item in link_objects + libraries + [sql_obj.as_posix(), sql_archive.as_posix()]:
        if "/" in item or "\\" in item:
            path = Path(item)
            artifacts.append({"path": str(path), "exists": path.is_file(),
                              "bytes": path.stat().st_size if path.is_file() else None,
                              "mtime_ns": path.stat().st_mtime_ns if path.is_file() else None})
    if build_mode:
        require(all(item["exists"] for item in artifacts),
                "A completed production link artifact is missing; no rebuild attempted")
    dlls = sorted((build_dir / "src/observer").glob("*.dll"))
    require(bool(dlls), "No bundled production runtime DLLs found")

    output.mkdir(parents=True, exist_ok=False) if not output.exists() else None
    response_write(output / "compile.rsp", comp_args)
    response_write(output / "link-inputs.rsp", link_args)
    compile_command = [compiler, "@" + (output / "compile.rsp").as_posix()]
    commands = {
        "cwd": str(output),
        "compile": compile_command,
        "link": link_command,
        "replaced_main_object": MAIN_OBJ,
        "retained_production_sql_archive": str(sql_archive),
        "compile_replacements": replacements,
        "response_sha256": {name: sha(output / name) for name in ("compile.rsp", "link-inputs.rsp")},
    }
    json_write(output / "commands.json", commands)
    receipt = {
        "mode": "build" if build_mode else "plan-only",
        "source_root": str(root),
        "build_dir": str(build_dir),
        "input_hashes": status,
        "candidate_source_hashes_match": all(item.get("matches_candidate", False) for item in status[:2]),
        "production_sql_fresh_by_mtime_only": production_fresh,
        "link_artifacts": artifacts,
        "runtime_dll_sources": [str(path) for path in dlls],
        "compile": "NOT RUN",
        "link": "NOT RUN",
        "native_test": "NOT RUN",
        "sql": "NOT RUN",
        "benchmark": "NOT RUN",
    }
    json_write(output / "receipt.json", receipt)
    if not build_mode:
        print("PLAN ONLY:", output,
              "candidate_source_hashes_match=", receipt["candidate_source_hashes_match"])
        return

    environment = os.environ.copy()
    temporary = output / "tmp"
    temporary.mkdir()
    environment["TMP"] = environment["TEMP"] = str(temporary)
    phases = (("compile", compile_command), ("link", link_command))
    for phase, command in phases:
        if phase == "link":
            (output / "link-intermediate").mkdir()
        with (output / (phase + ".log")).open("wb") as log:
            completed = subprocess.run(command, cwd=output, env=environment,
                                       stdout=log, stderr=subprocess.STDOUT)
        receipt[phase] = {"exit_code": completed.returncode,
                          "log_sha256": sha(output / (phase + ".log"))}
        json_write(output / "receipt.json", receipt)
        require(completed.returncode == 0,
                f"{phase} failed; see {output / (phase + '.log')}; no retry/fallback")

    receipt["runtime_dlls"] = []
    for dll in dlls:
        target = output / dll.name
        shutil.copy2(dll, target)
        receipt["runtime_dlls"].append({"name": dll.name, "sha256": sha(target)})
    receipt["executable_sha256"] = sha(output / "sort_compare_init.exe")
    if run_mode:
        with (output / "native.log").open("wb") as log:
            completed = subprocess.run([str(output / "sort_compare_init.exe")], cwd=output,
                                       env=environment, stdout=log, stderr=subprocess.STDOUT)
        receipt["native_test"] = {"exit_code": completed.returncode,
                                  "log_sha256": sha(output / "native.log")}
        json_write(output / "receipt.json", receipt)
        require(completed.returncode == 0,
                f"native adapter failed; see {output / 'native.log'}")
        print((output / "native.log").read_text(encoding="utf-8", errors="replace"), end="")
    json_write(output / "receipt.json", receipt)
    print("COMPILED AND LINKED" + (" AND RAN" if run_mode else " - NOT RUN"),
          output / "sort_compare_init.exe")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-root", type=Path, default=DEFAULT_ROOT)
    parser.add_argument("--build-dir", type=Path)
    parser.add_argument("--proposal-dir", type=Path, default=DEFAULT_PROPOSAL)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--capture", action="store_true",
                        help="One-time plan-only import of staged source/test pins and CMake/Ninja records")
    parser.add_argument("--build", action="store_true", help="Compile adapter and link; idle host only")
    parser.add_argument("--run", action="store_true", help="Run native adapter after --build")
    args = parser.parse_args()
    require(not args.run or args.build, "--run requires --build")
    root = args.source_root.resolve()
    build_dir = (args.build_dir or root / "build_fts_competition").resolve()
    output = args.output_dir.resolve()
    require(not output.is_relative_to(root) and not root.is_relative_to(output),
            "Output must be outside the source/build checkout")
    require(output.is_relative_to(HERE) and output != HERE,
            "Output must be a dedicated child directory of this helper")

    if args.capture:
        require(not (HERE / "build-settings.json").exists(), "Capture already completed")
        require(not output.exists() or not any(output.iterdir()), "Capture output must be new and empty")
        round12_path = ROUND12 / "build-settings.json"
        require(sha(round12_path) == ROUND12_SETTINGS_SHA, "Frozen round12 settings SHA changed")
        round12 = json.loads(round12_path.read_text(encoding="utf-8"))
        require(root == Path(round12["source_root"]).resolve()
                and build_dir == Path(round12["build_dir"]).resolve(),
                "Capture paths differ from the frozen round12 setup")
        records = capture_records(root, build_dir, round12)
        capture_helper(root, build_dir, args.proposal_dir.resolve(), records)

    verify_helper_manifest()
    settings_path = HERE / "build-settings.json"
    require(settings_path.is_file(), "Run the initial --capture plan first")
    settings = json.loads(settings_path.read_text(encoding="utf-8"))
    require(root == Path(settings["source_root"]).resolve()
            and build_dir == Path(settings["build_dir"]).resolve(),
            "Source/build paths differ from captured CMake configuration")
    records = capture_records(root, build_dir,
                              json.loads((ROUND12 / "build-settings.json").read_text(encoding="utf-8")))
    status = input_status(root, settings)
    if output.exists():
        require(not any(output.iterdir()), "Use a new empty output directory for each plan/build")
    build_commands(root, build_dir, output, settings, records, status, args.build, args.run)
    if args.capture:
        write_helper_manifest()


if __name__ == "__main__":
    try:
        main()
    except (RuntimeError, OSError, ValueError, KeyError, IndexError) as error:
        print("ERROR:", error, file=sys.stderr)
        sys.exit(1)
