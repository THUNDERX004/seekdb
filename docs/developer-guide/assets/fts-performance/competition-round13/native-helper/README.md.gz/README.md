# Round13 production `Compare::init` helper

This helper compiles a standalone `main` adapter and links it through the real
Windows x64 CMake/Ninja `seekdb.exe` edge, replacing only
`src/observer/CMakeFiles/ob_main.dir/main.cpp.obj`. All production libraries,
including `ob_sql_static.lib`, remain the exact artifacts from the completed
candidate build. The adapter calls the production `ObSortOpImpl::Compare::init`
and uses a real `ObExecContext`; it does not copy or stub the implementation.

The staged candidate sources are pinned under `sortsource/`. Build mode refuses
to run until both source files in the D: checkout match those candidate SHA256
values and the SQL engine unity object/archive timestamps are newer than the
candidate files. This prevents linking the old sort implementation. Timestamps
are only a freshness guard, not proof of archive contents; use the completed
round13 production build and retain its provenance. Relevant CMake/Ninja
commands and the frozen round12 production build settings are hash-pinned.

The original staged `test_sort_compare_init.cpp` is retained under `testpins/`
for its source SHA and provenance. It is a gtest translation unit and is not
registered here. `test_sort_compare_init_main.cpp` is a separate executable
adapter that covers the same six count mismatches in both encoded modes
(12 invalid-count scenarios), plus successful 1/4/5-column init, reset, and
reinit across changing counts. The adapter never invokes a row comparator:
real datum comparison requires initialized datum rows and comparison context,
so comparator ordering/NULL/LOB behavior is outside this helper's evidence.

## Prepare a plan

Run from PowerShell after round13 source integration. This operation only reads
the D: checkout/build and writes plan files under this helper:

```powershell
$helper = 'C:/Users/11946/Documents/ChatGPT/OceanBase比赛/setup/fts/round13-native-helper'
$python = 'C:/Users/11946/Documents/ChatGPT/OceanBase比赛/.venv/Scripts/python.exe'
& "$helper/build_sort_compare_init.ps1" -SourceRoot D:/Projects/OceanBase/seekdb `
    -OutputDir "$helper/parent-plan-1" -Python $python
```

## Compile, link, and optionally run

Use a new empty output directory and wait until the parent build/performance
work is idle. `-Build` compiles the adapter and links it once; it does not run
the executable. `-Run` is an explicit separate native execution of the adapter.
No CMake/Ninja build, SQL, database, or benchmark is started by this helper.

```powershell
$helper = 'C:/Users/11946/Documents/ChatGPT/OceanBase比赛/setup/fts/round13-native-helper'
$python = 'C:/Users/11946/Documents/ChatGPT/OceanBase比赛/.venv/Scripts/python.exe'
& "$helper/build_sort_compare_init.ps1" -SourceRoot D:/Projects/OceanBase/seekdb `
    -OutputDir "$helper/parent-build-1" -Python $python -Build -Run
```

The wrapper selects the same Visual Studio BuildTools, MSVC 14.44, Windows
SDK 10.0.26100.0, and x64 environment as the frozen round12 helper. All
objects, response files, EXE, PDBs, logs, and copied production runtime DLLs
stay in the selected helper output directory. The actual seekdb post-build DLL
bundling command is excluded because it writes into the production build.
Each plan/build requires a new empty output directory inside this helper.

The `example-plan/` receipt records that the current D: sort source hashes match
the candidate and that the SQL unity object/archive timestamps are newer. The
timestamps are not proof of archive contents, and the plan is not compilation,
link, or test evidence. The D: source hashes observed during preparation
changed from the original snapshot to the staged candidate; this helper did
not write the checkout. No compiler, linker, native executable, SQL, database,
Ninja build, or benchmark was run while preparing this helper.
## Parent validation addendum (2026-11-04)

The parent later applied the candidate, completed the production seekdb build,
then compiled and linked `parent-build-1/sort_compare_init.exe` against the real
SQL/storage/charset libraries. Both phases exited zero. The first explicit
`-Run` invocation exposed a helper-only `NameError` (`args` was not in the
builder function scope) after linking; the parent fixed the function argument
and manually ran the already-linked executable. It passed 12 mismatched-count
scenarios, 8 valid initialization calls and 8 resets. `parent-build-1/receipt.json`
is the original build receipt and still says `native_test: NOT RUN`; the separate
`native-run.json` and `native-run.log` record the later execution. The direct
test calls `Compare::init`; it does not execute row comparisons or validate
NULL/LOB datum ordering. The helper source was fixed, but its full wrapper was
not rerun after the fix because the production sort sources were subsequently
restored.
