/* Copyright (c) 2025 OceanBase. Licensed under the Apache License, Version 2.0. */
#include <cstdio>

#include "lib/allocator/ob_allocator.h"
#include "lib/container/ob_array.h"
#include "sql/engine/ob_exec_context.h"
#include "sql/engine/sort/ob_sort_op_impl.h"

namespace oceanbase
{
namespace sql
{

template <typename T>
int append_defaults(common::ObArray<T> &items, const int64_t count)
{
  int ret = OB_SUCCESS;
  for (int64_t i = 0; OB_SUCC(ret) && i < count; ++i) {
    ret = items.push_back(T());
  }
  return ret;
}

int fail(const char *case_name, const int64_t mode, const int actual, const int expected)
{
  std::fprintf(stderr, "FAIL %s encoded=%lld actual=%d expected=%d\n",
               case_name, static_cast<long long>(mode), actual, expected);
  return 1;
}

} // namespace sql
} // namespace oceanbase

int main()
{
  using namespace oceanbase;
  using namespace oceanbase::sql;
  common::ObArenaAllocator allocator;
  ObExecContext exec_ctx(allocator);
  const int64_t mismatches[][2] = {{0, 1}, {1, 0}, {3, 4}, {4, 3}, {4, 5}, {5, 4}};
  int failures = 0;
  int invalid_cases = 0;
  int valid_inits = 0;
  int resets = 0;

  for (int64_t mode = 0; mode < 2; ++mode) {
    for (const auto &counts : mismatches) {
      common::ObArray<ObSortFieldCollation> collations;
      common::ObArray<ObSortCmpFunc> functions;
      int ret = append_defaults(collations, counts[0]);
      if (OB_SUCC(ret)) {
        ret = append_defaults(functions, counts[1]);
      }
      if (OB_FAIL(ret)) {
        failures += fail("prepare_invalid", mode, ret, OB_SUCCESS);
      } else {
        ObSortOpImpl::Compare compare;
        ret = compare.init(&collations, &functions, &exec_ctx, mode != 0);
        if (OB_INVALID_ARGUMENT != ret) {
          failures += fail("invalid_count", mode, ret, OB_INVALID_ARGUMENT);
        } else if (compare.is_inited()) {
          failures += fail("invalid_left_inited", mode, 1, 0);
        }
      }
      ++invalid_cases;
    }
  }

  for (int64_t mode = 0; mode < 2; ++mode) {
    common::ObArray<ObSortFieldCollation> collations[3];
    common::ObArray<ObSortCmpFunc> functions[3];
    const int64_t counts[] = {1, 4, 5};
    bool prepared = true;
    for (int64_t i = 0; i < 3; ++i) {
      int ret = append_defaults(collations[i], counts[i]);
      if (OB_SUCC(ret)) {
        ret = append_defaults(functions[i], counts[i]);
      }
      if (OB_FAIL(ret)) {
        failures += fail("prepare_valid", mode, ret, OB_SUCCESS);
        prepared = false;
        break;
      }
    }
    if (prepared) {
      ObSortOpImpl::Compare compare;
      const int64_t sequence[] = {0, 1, 2, 0};
      for (const int64_t index : sequence) {
        const int ret = compare.init(&collations[index], &functions[index], &exec_ctx, mode != 0);
        if (OB_SUCCESS != ret) {
          failures += fail("valid_init", mode, ret, OB_SUCCESS);
        } else if (!compare.is_inited()) {
          failures += fail("valid_not_inited", mode, 0, 1);
        }
        ++valid_inits;
        compare.reset();
        if (compare.is_inited()) {
          failures += fail("reset_left_inited", mode, 1, 0);
        }
        ++resets;
      }
    }
  }

  if (failures == 0) {
    std::printf("PASS invalid_count_scenarios=%d valid_init_calls=%d reset_calls=%d\n",
                invalid_cases, valid_inits, resets);
  }
  return failures == 0 ? 0 : 1;
}
