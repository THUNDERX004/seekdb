// Generated from the source definitions listed in extraction.json.
// The validation, decoder, classification and context method bodies are verbatim.
#include <algorithm>
#include <array>
#include <cassert>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <iomanip>
#include <iostream>
#include <memory>
#include <random>
#include <sstream>
#include <stdexcept>
#include <string>
#include <type_traits>
#include <vector>
using uchar = unsigned char;
using ulong = unsigned long;
using uint16 = uint16_t;
using uint32 = uint32_t;
#if defined(_MSC_VER) && !defined(__clang__)
#define __attribute__(...)
#define ALWAYS_INLINE __forceinline
#else
#define ALWAYS_INLINE __attribute__((always_inline)) inline
#endif
#if defined(__BYTE_ORDER__) && __BYTE_ORDER__ == __ORDER_BIG_ENDIAN__
#define WORDS_BIGENDIAN
#endif
#define OB_FAIL(expr) ((ret = (expr)) != OB_SUCCESS)
#define OB_SUCC(code) ((code) == OB_SUCCESS)
#define OB_ISNULL(value) ((value) == nullptr)
#define OB_NOT_NULL(value) ((value) != nullptr)
#define OB_LIKELY(value) (value)
#define OB_UNLIKELY(value) (value)
#define UNUSED(value) ((void)(value))
#define STORAGE_FTS_LOG(...) ((void)0)
#define LOG_WARN(...) ((void)0)
#define ob_charset_assert(value) assert(value)

#define ob_wc_t ulong

#define OB_CS_ILSEQ	0     /* Wrong by sequence: wb_wc                   */

#define OB_CS_ILUNI	0     /* Cannot encode Unicode to charset: wc_mb    */

#define OB_CS_TOOSMALL  -101  /* Need at least one byte:    wc_mb and mb_wc */

#define OB_CS_TOOSMALL2 -102  /* Need at least two bytes:   wc_mb and mb_wc */

#define OB_CS_TOOSMALL3 -103  /* Need at least three bytes: wc_mb and mb_wc */

#define OB_CS_TOOSMALL4 -104  /* Need at least 4 bytes: wc_mb and mb_wc */

constexpr int OB_SUCCESS = 0;

constexpr int OB_INVALID_ARGUMENT = -4002;

constexpr int OB_ERR_UNEXPECTED = -4016;

constexpr int OB_NOT_SUPPORTED = -4007;

constexpr int OB_NOT_INIT = -4006;

constexpr int OB_UNEXPECT_INTERNAL_ERROR = -4388;

constexpr int OB_ITER_END = -4008;

enum ObCharsetType
{
  CHARSET_SESSION_CACHE_NOT_LOADED_MARK = -2,
  CHARSET_ANY = -1,
  CHARSET_INVALID = 0,
  CHARSET_BINARY = 1,
  CHARSET_UTF8MB4 = 2,
  CHARSET_GBK = 3,
  CHARSET_UTF16 = 4,
  CHARSET_GB18030 = 5,
  CHARSET_LATIN1 = 6,
  CHARSET_GB18030_2022 = 7,
  CHARSET_ASCII = 8,
  CHARSET_TIS620 = 9,
  CHARSET_UTF16LE = 10,
  CHARSET_SJIS = 11,
  CHARSET_BIG5 = 12,
  CHARSET_HKSCS = 13,
  CHARSET_HKSCS31 = 14,
  CHARSET_DEC8 = 15,
  CHARSET_GB2312 = 16,
  CHARSET_UJIS = 17,
  CHARSET_EUCKR = 18,
  CHARSET_EUCJPMS = 19,
  CHARSET_CP932 = 20,
  CHARSET_CP850 = 21,
  CHARSET_HP8 = 22,
  CHARSET_MACROMAN = 23,
  CHARSET_SWE7 = 24,
  CHARSET_MAX,
}
;

enum ObCollationType
{
  CS_TYPE_INVALID = 0,
  CS_TYPE_BIG5_CHINESE_CI = 1,
  CS_TYPE_DEC8_SWEDISH_CI = 3,
  CS_TYPE_CP850_GENERAL_CI = 4,
  CS_TYPE_LATIN1_GERMAN1_CI = 5,
  CS_TYPE_HP8_ENGLISH_CI = 6,
  CS_TYPE_LATIN1_SWEDISH_CI = 8,
  CS_TYPE_SWE7_SWEDISH_CI = 10,
  CS_TYPE_ASCII_GENERAL_CI = 11,
  CS_TYPE_UJIS_JAPANESE_CI = 12,
  CS_TYPE_SJIS_JAPANESE_CI = 13,
  CS_TYPE_LATIN1_DANISH_CI = 15,

  CS_TYPE_TIS620_THAI_CI = 18,
  CS_TYPE_EUCKR_KOREAN_CI = 19,
  CS_TYPE_GB2312_CHINESE_CI = 24,
  CS_TYPE_GBK_CHINESE_CI = 28,
  CS_TYPE_LATIN1_GERMAN2_CI = 31,
  CS_TYPE_MACROMAN_GENERAL_CI = 39,
  CS_TYPE_UTF8MB4_GENERAL_CI = 45,
  CS_TYPE_UTF8MB4_BIN = 46,
  CS_TYPE_LATIN1_BIN = 47,
  CS_TYPE_LATIN1_GENERAL_CI = 48,
  CS_TYPE_LATIN1_GENERAL_CS = 49,
  CS_TYPE_MACROMAN_BIN = 53,
  CS_TYPE_UTF16_GENERAL_CI = 54,
  CS_TYPE_UTF16_BIN = 55,
  CS_TYPE_UTF16LE_GENERAL_CI = 56,
  CS_TYPE_UTF16LE_BIN = 62,
  CS_TYPE_BINARY = 63,
  CS_TYPE_ASCII_BIN = 65,
  CS_TYPE_DEC8_BIN = 69,
  CS_TYPE_HP8_BIN = 72,
  CS_TYPE_CP850_BIN = 80,
  CS_TYPE_SWE7_BIN = 82,
  CS_TYPE_BIG5_BIN = 84,
  CS_TYPE_EUCKR_BIN = 85,
  CS_TYPE_GB2312_BIN = 86,
  CS_TYPE_GBK_BIN = 87,
  CS_TYPE_SJIS_BIN = 88,

  CS_TYPE_TIS620_BIN = 89,
  CS_TYPE_UJIS_BIN = 91,
  CS_TYPE_LATIN1_SPANISH_CI = 94,
  CS_TYPE_CP932_JAPANESE_CI = 95,
  CS_TYPE_CP932_BIN = 96,
  CS_TYPE_EUCJPMS_JAPANESE_CI = 97,
  CS_TYPE_EUCJPMS_BIN = 98,
  CS_TYPE_COLLATION_FREE = 100, // mysql does not use this in the middle
  CS_TYPE_UTF16_UNICODE_CI = 101,
  CS_TYPE_UTF16_ICELANDIC_UCA_CI = 102,
  CS_TYPE_UTF16_LATVIAN_UCA_CI = 103,
  CS_TYPE_UTF16_ROMANIAN_UCA_CI = 104,
  CS_TYPE_UTF16_SLOVENIAN_UCA_CI = 105,
  CS_TYPE_UTF16_POLISH_UCA_CI = 106,
  CS_TYPE_UTF16_ESTONIAN_UCA_CI = 107,
  CS_TYPE_UTF16_SPANISH_UCA_CI = 108,
  CS_TYPE_UTF16_SWEDISH_UCA_CI = 109,
  CS_TYPE_UTF16_TURKISH_UCA_CI = 110,
  CS_TYPE_UTF16_CZECH_UCA_CI = 111,
  CS_TYPE_UTF16_DANISH_UCA_CI = 112,
  CS_TYPE_UTF16_LITHUANIAN_UCA_CI = 113,
  CS_TYPE_UTF16_SLOVAK_UCA_CI = 114,
  CS_TYPE_UTF16_SPANISH2_UCA_CI = 115,
  CS_TYPE_UTF16_ROMAN_UCA_CI = 116,
  CS_TYPE_UTF16_PERSIAN_UCA_CI = 117,
  CS_TYPE_UTF16_ESPERANTO_UCA_CI = 118,
  CS_TYPE_UTF16_HUNGARIAN_UCA_CI = 119,
  CS_TYPE_UTF16_SINHALA_UCA_CI = 120,
  CS_TYPE_UTF16_GERMAN2_UCA_CI = 121,
  CS_TYPE_UTF16_CROATIAN_UCA_CI = 122,
  CS_TYPE_UTF16_UNICODE_520_CI = 123,
  CS_TYPE_UTF16_VIETNAMESE_CI  = 124,
  CS_TYPE_ANY = 125, // unused in mysql
  CS_TYPE_HKSCS_BIN = 152,
  CS_TYPE_HKSCS31_BIN = 153,
  CS_TYPE_GB18030_2022_BIN = 216, // unused in mysql
  CS_TYPE_GB18030_2022_PINYIN_CI = 217, // unused in mysql
  CS_TYPE_GB18030_2022_PINYIN_CS = 218, // unused in mysql
  CS_TYPE_GB18030_2022_RADICAL_CI = 219, // unused in mysql
  CS_TYPE_GB18030_2022_RADICAL_CS = 220, // unused in mysql
  CS_TYPE_GB18030_2022_STROKE_CI = 221, // unused in mysql
  CS_TYPE_GB18030_2022_STROKE_CS = 222, // unused in mysql
  CS_TYPE_UTF8MB4_UNICODE_CI = 224,
  CS_TYPE_UTF8MB4_ICELANDIC_UCA_CI,
  CS_TYPE_UTF8MB4_LATVIAN_UCA_CI ,
  CS_TYPE_UTF8MB4_ROMANIAN_UCA_CI ,
  CS_TYPE_UTF8MB4_SLOVENIAN_UCA_CI,
  CS_TYPE_UTF8MB4_POLISH_UCA_CI  ,
  CS_TYPE_UTF8MB4_ESTONIAN_UCA_CI ,
  CS_TYPE_UTF8MB4_SPANISH_UCA_CI ,
  CS_TYPE_UTF8MB4_SWEDISH_UCA_CI ,
  CS_TYPE_UTF8MB4_TURKISH_UCA_CI ,
  CS_TYPE_UTF8MB4_CZECH_UCA_CI  ,
  CS_TYPE_UTF8MB4_DANISH_UCA_CI  ,
  CS_TYPE_UTF8MB4_LITHUANIAN_UCA_CI,
  CS_TYPE_UTF8MB4_SLOVAK_UCA_CI  ,
  CS_TYPE_UTF8MB4_SPANISH2_UCA_CI,
  CS_TYPE_UTF8MB4_ROMAN_UCA_CI,
  CS_TYPE_UTF8MB4_PERSIAN_UCA_CI ,
  CS_TYPE_UTF8MB4_ESPERANTO_UCA_CI,
  CS_TYPE_UTF8MB4_HUNGARIAN_UCA_CI,
  CS_TYPE_UTF8MB4_SINHALA_UCA_CI ,
  CS_TYPE_UTF8MB4_GERMAN2_UCA_CI ,
  CS_TYPE_UTF8MB4_CROATIAN_UCA_CI,
  CS_TYPE_UTF8MB4_UNICODE_520_CI ,
  CS_TYPE_UTF8MB4_VIETNAMESE_CI  ,
  CS_TYPE_GB18030_CHINESE_CI = 248,
  CS_TYPE_GB18030_BIN = 249,
  CS_TYPE_GB18030_CHINESE_CS = 251,
  CS_TYPE_UTF8MB4_0900_AI_CI = 255,
  CS_TYPE_UTF8MB4_DE_PB_0900_AI_CI ,
  CS_TYPE_UTF8MB4_IS_0900_AI_CI   ,
  CS_TYPE_UTF8MB4_LV_0900_AI_CI   ,
  CS_TYPE_UTF8MB4_RO_0900_AI_CI   ,
  CS_TYPE_UTF8MB4_SL_0900_AI_CI   ,
  CS_TYPE_UTF8MB4_PL_0900_AI_CI   ,
  CS_TYPE_UTF8MB4_ET_0900_AI_CI   ,
  CS_TYPE_UTF8MB4_ES_0900_AI_CI   ,
  CS_TYPE_UTF8MB4_SV_0900_AI_CI   ,
  CS_TYPE_UTF8MB4_TR_0900_AI_CI   ,
  CS_TYPE_UTF8MB4_CS_0900_AI_CI   ,
  CS_TYPE_UTF8MB4_DA_0900_AI_CI   ,
  CS_TYPE_UTF8MB4_LT_0900_AI_CI   ,
  CS_TYPE_UTF8MB4_SK_0900_AI_CI   ,
  CS_TYPE_UTF8MB4_ES_TRAD_0900_AI_CI,
  CS_TYPE_UTF8MB4_LA_0900_AI_CI   ,
  CS_TYPE_UTF8MB4_EO_0900_AI_CI  = 273 ,
  CS_TYPE_UTF8MB4_HU_0900_AI_CI   ,
  CS_TYPE_UTF8MB4_HR_0900_AI_CI   ,
  CS_TYPE_UTF8MB4_VI_0900_AI_CI  = 277 ,
  CS_TYPE_UTF8MB4_0900_AS_CS   ,
  CS_TYPE_UTF8MB4_DE_PB_0900_AS_CS ,
  CS_TYPE_UTF8MB4_IS_0900_AS_CS   ,
  CS_TYPE_UTF8MB4_LV_0900_AS_CS   ,
  CS_TYPE_UTF8MB4_RO_0900_AS_CS   ,
  CS_TYPE_UTF8MB4_SL_0900_AS_CS   ,
  CS_TYPE_UTF8MB4_PL_0900_AS_CS   ,
  CS_TYPE_UTF8MB4_ET_0900_AS_CS   ,
  CS_TYPE_UTF8MB4_ES_0900_AS_CS   ,
  CS_TYPE_UTF8MB4_SV_0900_AS_CS   ,
  CS_TYPE_UTF8MB4_TR_0900_AS_CS   ,
  CS_TYPE_UTF8MB4_CS_0900_AS_CS   ,
  CS_TYPE_UTF8MB4_DA_0900_AS_CS   ,
  CS_TYPE_UTF8MB4_LT_0900_AS_CS   ,
  CS_TYPE_UTF8MB4_SK_0900_AS_CS   ,
  CS_TYPE_UTF8MB4_ES_TRAD_0900_AS_CS,
  CS_TYPE_UTF8MB4_LA_0900_AS_CS  ,
  CS_TYPE_UTF8MB4_EO_0900_AS_CS  = 296,
  CS_TYPE_UTF8MB4_HU_0900_AS_CS   ,
  CS_TYPE_UTF8MB4_HR_0900_AS_CS   ,
  CS_TYPE_UTF8MB4_VI_0900_AS_CS = 300,
  CS_TYPE_UTF8MB4_JA_0900_AS_CS = 303,
  CS_TYPE_UTF8MB4_JA_0900_AS_CS_KS ,
  CS_TYPE_UTF8MB4_0900_AS_CI   ,
  CS_TYPE_UTF8MB4_RU_0900_AI_CI   ,
  CS_TYPE_UTF8MB4_RU_0900_AS_CS   ,
  CS_TYPE_UTF8MB4_ZH_0900_AS_CS = 308 ,
  CS_TYPE_UTF8MB4_0900_BIN,
  CS_TYPE_UTF8MB4_NB_0900_AI_CI   ,
  CS_TYPE_UTF8MB4_NB_0900_AS_CS   ,
  CS_TYPE_UTF8MB4_NN_0900_AI_CI   ,
  CS_TYPE_UTF8MB4_NN_0900_AS_CS   ,
  CS_TYPE_UTF8MB4_SR_LATN_0900_AI_CI,
  CS_TYPE_UTF8MB4_SR_LATN_0900_AS_CS,
  CS_TYPE_UTF8MB4_BS_0900_AI_CI   ,
  CS_TYPE_UTF8MB4_BS_0900_AS_CS   ,
  CS_TYPE_UTF8MB4_BG_0900_AI_CI   ,
  CS_TYPE_UTF8MB4_BG_0900_AS_CS   ,
  CS_TYPE_UTF8MB4_GL_0900_AI_CI   ,
  CS_TYPE_UTF8MB4_GL_0900_AS_CS   ,
  CS_TYPE_UTF8MB4_MN_CYRL_0900_AI_CI,
  CS_TYPE_UTF8MB4_MN_CYRL_0900_AS_CS,
  //pinyin order (occupied)
  CS_TYPE_PINYIN_BEGIN_MARK,
  CS_TYPE_UTF8MB4_ZH_0900_AS_CS_CPY, //308 in mysql 8.0
  CS_TYPE_GBK_ZH_0900_AS_CS,
  CS_TYPE_UTF16_ZH_0900_AS_CS,
  CS_TYPE_GB18030_ZH_0900_AS_CS,
  CS_TYPE_LATIN1_ZH_0900_AS_CS,
  CS_TYPE_GB18030_2022_ZH_0900_AS_CS,
  CS_TYPE_ASCII_ZH_0900_AS_CS,
  CS_TYPE_TIS620_ZH_0900_AS_CS,
  CS_TYPE_UTF16LE_ZH_0900_AS_CS,
  CS_TYPE_SJIS_ZH_0900_AS_CS,
  CS_TYPE_BIG5_ZH_0900_AS_CS,
  CS_TYPE_HKSCS_ZH_0900_AS_CS,
  CS_TYPE_HKSCS31_ZH_0900_AS_CS,
  CS_TYPE_DEC8_ZH_0900_AS_CS,
  CS_TYPE_GB2312_ZH_0900_AS_CS, // invalid
  CS_TYPE_UJIS_ZH_0900_AS_CS, // invalid
  CS_TYPE_EUCKR_ZH_0900_AS_CS, // invalid
  CS_TYPE_EUCJPMS_ZH_0900_AS_CS, // invalid
  CS_TYPE_CP932_ZH_0900_AS_CS, // invalid
  CS_TYPE_CP850_ZH_0900_AS_CS, // invalid
  CS_TYPE_HP8_ZH_0900_AS_CS, // invalid
  CS_TYPE_MACROMAN_ZH_0900_AS_CS, // invalid
  CS_TYPE_SWE7_ZH_0900_AS_CS, // invalid

  //radical-stroke order
  CS_TYPE_RADICAL_BEGIN_MARK,
  CS_TYPE_UTF8MB4_ZH2_0900_AS_CS,
  CS_TYPE_GBK_ZH2_0900_AS_CS,
  CS_TYPE_UTF16_ZH2_0900_AS_CS,
  CS_TYPE_GB18030_ZH2_0900_AS_CS,
  CS_TYPE_LATIN1_ZH2_0900_AS_CS,
  CS_TYPE_GB18030_2022_ZH2_0900_AS_CS,
  CS_TYPE_ASCII_ZH2_0900_AS_CS,
  CS_TYPE_TIS620_ZH2_0900_AS_CS,
  CS_TYPE_UTF16LE_ZH2_0900_AS_CS,
  CS_TYPE_SJIS_ZH2_0900_AS_CS,
  CS_TYPE_BIG5_ZH2_0900_AS_CS,
  CS_TYPE_HKSCS_ZH2_0900_AS_CS,
  CS_TYPE_HKSCS31_ZH2_0900_AS_CS,
  CS_TYPE_DEC8_ZH2_0900_AS_CS,
  CS_TYPE_GB2312_ZH2_0900_AS_CS, // invalid
  CS_TYPE_UJIS_ZH2_0900_AS_CS, //invalid
  CS_TYPE_EUCKR_ZH2_0900_AS_CS, // invalid
  CS_TYPE_EUCJPMS_ZH2_0900_AS_CS, // invalid
  CS_TYPE_CP932_ZH2_0900_AS_CS, // invalid
  CS_TYPE_CP850_ZH2_0900_AS_CS, // invalid
  CS_TYPE_HP8_ZH2_0900_AS_CS, // invalid
  CS_TYPE_MACROMAN_ZH2_0900_AS_CS, // invalid
  CS_TYPE_SWE7_ZH2_0900_AS_CS, // invalid
  //stroke order
  CS_TYPE_STROKE_BEGIN_MARK,
  CS_TYPE_UTF8MB4_ZH3_0900_AS_CS,
  CS_TYPE_GBK_ZH3_0900_AS_CS,
  CS_TYPE_UTF16_ZH3_0900_AS_CS,
  CS_TYPE_GB18030_ZH3_0900_AS_CS,
  CS_TYPE_LATIN1_ZH3_0900_AS_CS,
  CS_TYPE_GB18030_2022_ZH3_0900_AS_CS,
  CS_TYPE_ASCII_ZH3_0900_AS_CS,
  CS_TYPE_TIS620_ZH3_0900_AS_CS,
  CS_TYPE_UTF16LE_ZH3_0900_AS_CS,
  CS_TYPE_SJIS_ZH3_0900_AS_CS,
  CS_TYPE_BIG5_ZH3_0900_AS_CS,
  CS_TYPE_HKSCS_ZH3_0900_AS_CS,
  CS_TYPE_HKSCS31_ZH3_0900_AS_CS,
  CS_TYPE_DEC8_ZH3_0900_AS_CS,
  CS_TYPE_GB2312_ZH3_0900_AS_CS, // invalid
  CS_TYPE_UJIS_ZH3_0900_AS_CS, // invalid
  CS_TYPE_EUCKR_ZH3_0900_AS_CS, // invalid
  CS_TYPE_EUCJPMS_ZH3_0900_AS_CS, // invalid
  CS_TYPE_CP932_ZH3_0900_AS_CS, // invalid
  CS_TYPE_CP850_ZH3_0900_AS_CS, // invalid
  CS_TYPE_HP8_ZH3_0900_AS_CS, // invalid
  CS_TYPE_MACROMAN_ZH3_0900_AS_CS, // invalid
  CS_TYPE_SWE7_ZH3_0900_AS_CS, // invalid
  CS_TYPE_MAX
}
;


struct ObCharsetInfo;
struct ObCharsetHandler {
  size_t (*well_formed_len)(const ObCharsetInfo *, const char *, const char *, size_t, int *);
};
struct ObCharsetInfo { const ObCharsetHandler *cset; };

#define IS_CONTINUATION_BYTE(code) (((code) >> 6) == 0x02)

static int ob_valid_mbcharlen_utf8mb3(const uchar *s, const uchar *e)
{
  uchar c;
  ob_charset_assert(s < e);
  c= s[0];
  if (c < 0x80)
    return 1;
  if (c < 0xc2)
    return OB_CS_ILSEQ;
  if (c < 0xe0)
  {
    if (s+2 > e) /* We need 2 characters */
      return OB_CS_TOOSMALL2;
    if (!(IS_CONTINUATION_BYTE(s[1])))
      return OB_CS_ILSEQ;
    return 2;
  }
  ob_charset_assert(c < 0xf0);
  if (s+3 > e) /* We need 3 characters */
    return OB_CS_TOOSMALL3;
  if (!(IS_CONTINUATION_BYTE(s[1]) && IS_CONTINUATION_BYTE(s[2]) && (c >= 0xe1 || s[1] >= 0xa0)))
    return OB_CS_ILSEQ;
  return 3;
}

static inline int ob_valid_mbcharlen_utf8mb4(const ObCharsetInfo *cs __attribute__((unused)), const uchar *s, const uchar *e)
{
  uchar c;
  if (s >= e)
    return OB_CS_TOOSMALL;
  c= s[0];
  if (c < 0xf0)
    return ob_valid_mbcharlen_utf8mb3(s, e);
  if (c < 0xf5)
  {
    if (s + 4 > e) /* We need 4 characters */
      return OB_CS_TOOSMALL4;
    if (!(IS_CONTINUATION_BYTE(s[1]) &&
          IS_CONTINUATION_BYTE(s[2]) &&
          IS_CONTINUATION_BYTE(s[3]) &&
          (c >= 0xf1 || s[1] >= 0x90) &&
          (c <= 0xf3 || s[1] <= 0x8F)))
      return OB_CS_ILSEQ;
    return 4;
  }
  return OB_CS_ILSEQ;
}

static inline size_t ob_well_formed_len_utf8mb4(const ObCharsetInfo *cs,
                                         const char *b, const char *e,
                                         size_t pos, int *error)
{
  const char *b_start= b;
  *error= 0;
  while (pos)
  {
    int mb_len;
    if ((mb_len= ob_valid_mbcharlen_utf8mb4(cs, (uchar*) b, (uchar*) e)) <= 0)
    {
      *error= b < e ? 1 : 0;
      break;
    }
    b+= mb_len;
    pos--;
  }
  return (size_t) (b - b_start);
}

static int ob_mb_wc_utf8mb4(const ObCharsetInfo *cs __attribute__((unused)),
                 ob_wc_t * pwc, const uchar *s, const uchar *e)
{
  uchar c;
  if (s >= e)
    return OB_CS_TOOSMALL;
  c= s[0];
  if (c < 0x80)
  {
    *pwc= c;
    return 1;
  }
  else if (c < 0xc2)
    return OB_CS_ILSEQ;
  else if (c < 0xe0)
  {
    if (s + 2 > e) /* We need 2 characters */
      return OB_CS_TOOSMALL2;
    if (!(IS_CONTINUATION_BYTE(s[1])))
      return OB_CS_ILSEQ;
    *pwc= ((ob_wc_t) (c & 0x1f) << 6) | (ob_wc_t) (s[1] ^ 0x80);
    return 2;
  }
  else if (c < 0xf0)
  {
    if (s + 3 > e) /* We need 3 characters */
      return OB_CS_TOOSMALL3;
    if (!(IS_CONTINUATION_BYTE(s[1]) && IS_CONTINUATION_BYTE(s[2]) &&
          (c >= 0xe1 || s[1] >= 0xa0)))
      return OB_CS_ILSEQ;
    *pwc= ((ob_wc_t) (c & 0x0f) << 12)   |
          ((ob_wc_t) (s[1] ^ 0x80) << 6) |
           (ob_wc_t) (s[2] ^ 0x80);
    return 3;
  }
  else if (c < 0xf5)
  {
    if (s + 4 > e) /* We need 4 characters */
      return OB_CS_TOOSMALL4;
    if (!(IS_CONTINUATION_BYTE(s[1]) &&
          IS_CONTINUATION_BYTE(s[2]) &&
          IS_CONTINUATION_BYTE(s[3]) &&
          (c >= 0xf1 || s[1] >= 0x90) &&
          (c <= 0xf3 || s[1] <= 0x8F)))
      return OB_CS_ILSEQ;
    *pwc = ((ob_wc_t) (c & 0x07) << 18)    |
           ((ob_wc_t) (s[1] ^ 0x80) << 12) |
           ((ob_wc_t) (s[2] ^ 0x80) << 6)  |
            (ob_wc_t) (s[3] ^ 0x80);
    return 4;
  }
  return OB_CS_ILSEQ;
}

template <bool RANGE_CHECK, bool SUPPORT_MB4>
static ALWAYS_INLINE int ob_mb_wc_utf8_prototype(ob_wc_t *pwc, const unsigned char *s,
                                                 const unsigned char *e) {
  if (RANGE_CHECK && s >= e) return OB_CS_TOOSMALL;

  unsigned char c = s[0];
  if (c < 0x80) {
    *pwc = c;
    return 1;
  }

  if (c < 0xe0) {
    if (c < 0xc2)  // Resulting code point would be less than 0x80.
      return OB_CS_ILSEQ;

    if (RANGE_CHECK && s + 2 > e) return OB_CS_TOOSMALL2;

    if ((s[1] & 0xc0) != 0x80)  // Next byte must be a continuation byte.
      return OB_CS_ILSEQ;

    *pwc = ((ob_wc_t)(c & 0x1f) << 6) + (ob_wc_t)(s[1] & 0x3f);
    return 2;
  }

  if (c < 0xf0) {
    if (RANGE_CHECK && s + 3 > e) return OB_CS_TOOSMALL3;

    // Next two bytes must be continuation bytes.
    uint16 two_bytes;
    memcpy(&two_bytes, s + 1, sizeof(two_bytes));
    if ((two_bytes & 0xc0c0) != 0x8080)  // Endianness does not matter.
      return OB_CS_ILSEQ;

    *pwc = ((ob_wc_t)(c & 0x0f) << 12) + ((ob_wc_t)(s[1] & 0x3f) << 6) +
           (ob_wc_t)(s[2] & 0x3f);
    if (*pwc < 0x800) return OB_CS_ILSEQ;
    /*
      According to RFC 3629, UTF-8 should prohibit characters between
      U+D800 and U+DFFF, which are reserved for surrogate pairs and do
      not directly represent characters.
    */
    if (*pwc >= 0xd800 && *pwc <= 0xdfff) return OB_CS_ILSEQ;
    return 3;
  }

  if (SUPPORT_MB4) {
    if (RANGE_CHECK && s + 4 > e) /* We need 4 characters */
      return OB_CS_TOOSMALL4;

    /*
      This byte must be of the form 11110xxx, and the next three bytes
      must be continuation bytes.
    */
    uint32 four_bytes;
    memcpy(&four_bytes, s, sizeof(four_bytes));
#ifdef WORDS_BIGENDIAN
    if ((four_bytes & 0xf8c0c0c0) != 0xf0808080)
#else
    if ((four_bytes & 0xc0c0c0f8) != 0x808080f0)
#endif
      return OB_CS_ILSEQ;

    *pwc = ((ob_wc_t)(c & 0x07) << 18) + ((ob_wc_t)(s[1] & 0x3f) << 12) +
           ((ob_wc_t)(s[2] & 0x3f) << 6) + (ob_wc_t)(s[3] & 0x3f);
    if (*pwc < 0x10000 || *pwc > 0x10ffff) return OB_CS_ILSEQ;
    return 4;
  }

  return OB_CS_ILSEQ;
}

namespace common {
template<ObCharsetType cs_type>
inline int ob_charset_char_len(const unsigned char *s, const unsigned char *e)
{
  return OB_LIKELY(s < e) ? 1 : OB_CS_TOOSMALL;
}

template<>
inline int ob_charset_char_len<CHARSET_UTF8MB4>(const unsigned char *s, const unsigned char *e)
{
  int mb_len = OB_CS_TOOSMALL;
  if (OB_LIKELY(s < e)) {
    unsigned char c = *s;
    if (c < 0x80) {
      mb_len = 1;
    } else if (c < 0xc2) {
      mb_len = 1;
    } else if (c < 0xe0) {
      mb_len = 2;
    } else if (c < 0xf0) {
      mb_len = 3;
    } else if (c < 0xf8) {
      mb_len = 4;
    } else {
      mb_len = 1;
    }
    if (s + mb_len > e) {
      mb_len = OB_CS_TOOSMALL;
    }
  }
  return mb_len;
}

template<ObCharsetType cs_type>
inline int ob_charset_decode_unicode(const unsigned char *s, const unsigned char *e, ob_wc_t &unicode_value)
{
  unicode_value = 0;
  return ob_charset_char_len<CHARSET_BINARY>(s, e);
}

template<ObCharsetType cs_type>
inline int ob_charset_encode_unicode(ob_wc_t unicode_value, unsigned char *buf, unsigned char *buf_end)
{
  UNUSED(unicode_value);
  UNUSED(buf);
  UNUSED(buf_end);
  return OB_CS_ILUNI;
}

template<>
inline int ob_charset_decode_unicode<CHARSET_BINARY>(
    const unsigned char *s,
    const unsigned char *e,
    ob_wc_t &unicode_value)
{
  if (s >= e) {
    unicode_value = 0;
    return OB_CS_TOOSMALL;
  } else {
    unicode_value = *s;
    return 1;
  }
}

template<>
inline int ob_charset_decode_unicode<CHARSET_UTF8MB4>(
    const unsigned char *s,
    const unsigned char *e,
    ob_wc_t &unicode_value)
{
  return ob_mb_wc_utf8_prototype<true, true>(&unicode_value, s, e);
}

}
using namespace common;


static uint64_t charset_lookups = 0;
class ObCharset {
public:
  static const ObCharsetInfo *get_charset(ObCollationType coll) {
    ++charset_lookups;
    static const ObCharsetHandler handler{ob_well_formed_len_utf8mb4};
    static const ObCharsetInfo info{&handler};
    switch (coll) {
      case CS_TYPE_UTF8MB4_GENERAL_CI:
      case CS_TYPE_UTF8MB4_BIN:
      case CS_TYPE_UTF8MB4_UNICODE_CI:
      case CS_TYPE_BINARY: // ASCII-only stub coverage; no binary charset integration claim.
        return &info;
      default: return nullptr;
    }
  }
  static bool is_valid_collation(int64_t);
  static ObCharsetType charset_type_by_coll(ObCollationType);
  static int first_valid_char(ObCollationType, const char *, int64_t, int64_t &);
  static ObCharsetType collation_charset_map[CS_TYPE_MAX];
};
ObCharsetType ObCharset::collation_charset_map[CS_TYPE_MAX] = {};

bool ObCharset::is_valid_collation(int64_t collation_type_int)
{
  ObCollationType collation_type = static_cast<ObCollationType>(collation_type_int);
  return CS_TYPE_BINARY == collation_type
      || CS_TYPE_UTF8MB4_GENERAL_CI == collation_type
      || CS_TYPE_UTF8MB4_BIN == collation_type
      || CS_TYPE_UTF8MB4_UNICODE_CI == collation_type;
}

ObCharsetType ObCharset::charset_type_by_coll(ObCollationType collation_type)
{
  ObCharsetType charset_type = CHARSET_INVALID;
  switch(collation_type) {
    case CS_TYPE_UTF8MB4_GENERAL_CI:
    case CS_TYPE_UTF8MB4_BIN:
    case CS_TYPE_UTF8MB4_UNICODE_CI: {
      charset_type = CHARSET_UTF8MB4;
      break;
    }
    case CS_TYPE_BINARY: {
      charset_type = CHARSET_BINARY;
      break;
    }
    default: {
      break;
    }
  }
  if (charset_type == CHARSET_INVALID) {
    if (is_valid_collation(collation_type)) {
      charset_type = ObCharset::collation_charset_map[collation_type];
    }
  }
  return charset_type;
}

int ObCharset::first_valid_char(
    const ObCollationType collation_type,
    const char *buf,
    const int64_t buf_size,
    int64_t &char_len)
{
  int ret = OB_SUCCESS;
  if (OB_UNLIKELY(collation_type <= CS_TYPE_INVALID ||
                  collation_type >= CS_TYPE_MAX)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (OB_ISNULL(get_charset(collation_type))) {
    ret = OB_NOT_SUPPORTED;
  } else if (OB_UNLIKELY(NULL == buf)) {
    ret = OB_NOT_INIT;
  } else if (buf_size <= 0) {
    char_len = 0;
  } else {
    int error = 0;
    int64_t len = 0;
    const ObCharsetInfo *cs = get_charset(collation_type);
    if (OB_ISNULL(cs->cset)) {
      ret = OB_ERR_UNEXPECTED;
    } else {
      len = static_cast<int64_t>(cs->cset->well_formed_len(cs, buf, buf + buf_size, 1, &error));
      if (OB_LIKELY(0 == error)) {
        char_len = len;
      } else {
        ret = OB_INVALID_ARGUMENT;
        LOG_WARN("invalid encoding found");
      }
    }
  }
  return ret;
}

class ObUnicodeBlockUtils final
{
public:
  static bool is_unicode_cn_number(const ob_wc_t unicode);

  static bool is_alpha(const ob_wc_t unicode);

  static bool is_arabic(const ob_wc_t unicode);

  static bool check_high_surrogate(const ob_wc_t unicode);

  static bool check_high_private_use_surrogate(const ob_wc_t unicode);

  static bool check_low_surrogate(const ob_wc_t unicode);

  static bool check_letter_connector(const ob_wc_t unicode);

  static bool check_num_connector(const ob_wc_t unicode);

  static bool check_ignore_as_single(const ob_wc_t unicode);

  static bool is_chinese(const ob_wc_t unicode);

  static bool is_other_cjk(const ob_wc_t unicode);

  static bool is_surrogate(const ob_wc_t unicode);

  static bool is_convertable_fullwidth(const ob_wc_t unicode);

private:
  // Do compare with u8 char
  // only for static number
  static ob_wc_t get_unicode_from_u8(const char *input, const uint8_t char_len);
}
;

bool ObUnicodeBlockUtils::is_alpha(const ob_wc_t unicode)
{
  bool is_ascii_alpha
      = (unicode >= 0x41 && unicode <= 0x5a) || (unicode >= 0x61 && unicode <= 0x7a);
  bool is_fw_alpha
      = (unicode >= 0xFF21 && unicode <= 0xFF3A) || (unicode >= 0xFF41 && unicode <= 0xFF5A);
  return is_ascii_alpha || is_fw_alpha;
}

bool ObUnicodeBlockUtils::is_arabic(const ob_wc_t unicode)
{
  bool is_ascii_arabic = (unicode >= 0x30 && unicode <= 0x39);
  bool is_fw_arabic = (unicode >= 0xFF10 && unicode <= 0xFF19);
  return is_ascii_arabic || is_fw_arabic;
}

bool ObUnicodeBlockUtils::is_chinese(const ob_wc_t unicode)
{
  // variables name keep same with it's code block name, skip code style.
  bool CJK_UNIFIED_IDEOGRAPHS = (unicode >= 0x4E00 && unicode <= 0x9FFF);
  bool CJK_COMPATIBILITY_IDEOGRAPHS = (unicode >= 0xF900 && unicode <= 0xFAFF);
  bool CJK_UNIFIED_IDEOGRAPHS_EXTENSION_A = (unicode >= 0x3400 && unicode <= 0x4DBF);
  return CJK_UNIFIED_IDEOGRAPHS || CJK_COMPATIBILITY_IDEOGRAPHS
         || CJK_UNIFIED_IDEOGRAPHS_EXTENSION_A;
}

bool ObUnicodeBlockUtils::is_other_cjk(const ob_wc_t unicode)
{
  // variables name keep same with it's code block name, skip code style.
  bool HALFWIDTH_AND_FULLWIDTH_FORMS = (unicode >= 0xFF00 && unicode <= 0xFFEF);

  bool HANGUL_SYLLABLES = (unicode >= 0xAC00 && unicode <= 0xD7AF);
  bool HANGUL_JAMO = (unicode >= 0x1100 && unicode <= 0x11FF);
  bool HANGUL_COMPATIBILITY_JAMO = (unicode >= 0x3130 && unicode <= 0x318f);

  bool HIRAGANA = (unicode >= 0x3040 && unicode <= 0x309F);
  bool KATAKANA = (unicode >= 0x30A0 && unicode <= 0x30FF);
  bool KATAKANA_PHONETIC_EXTENSIONS = (unicode >= 0x31F0 && unicode <= 0x31FF);

  return HALFWIDTH_AND_FULLWIDTH_FORMS || HANGUL_SYLLABLES || HANGUL_JAMO
         || HANGUL_COMPATIBILITY_JAMO || HIRAGANA || KATAKANA || KATAKANA_PHONETIC_EXTENSIONS;
}

bool ObUnicodeBlockUtils::check_high_surrogate(const ob_wc_t unicode)
{
  return unicode >= 0xD800 && unicode <= 0xDBFF;
}

bool ObUnicodeBlockUtils::check_low_surrogate(const ob_wc_t unicode)
{
  return unicode >= 0xDC00 && unicode <= 0xDFFF;
}

struct ObIAllocator {};
struct LeafList { explicit LeafList(ObIAllocator &) {} };

namespace baseline {
class ObFTCharUtil
{
public:
  enum class CharType : int8_t
  {
    USELESS = 0,
    ARABIC_LETTER = 1,
    ENGLISH_LETTER = 2,
    CHINESE = 3,
    OTHER_CJK = 4,
    SURROGATE_HIGH = 5,
    SURROGATE_LOW = 6,
  };

  static int classify_first_char(ObCollationType coll_type,
                                 const char *input,
                                 const uint8_t char_len,
                                 CharType &type);

  static int check_cn_number(ObCollationType coll_type,
                             const char *input,
                             const uint8_t char_len,
                             bool &is_cn_number);

  static int check_num_connector(ObCollationType coll_type,
                                 const char *input,
                                 const uint8_t char_len,
                                 bool &is_connector);

  static int check_letter_connector(ObCollationType coll_type,
                                    const char *input,
                                    const uint8_t char_len,
                                    bool &is_connector);

  // some cjk word should be ignored
  static int is_ignore_single_cjk(ObCollationType coll_type,
                                  const char *input,
                                  const uint8_t char_len,
                                  bool &ignore);

private:
  template <ObCharsetType CS_TYPE>
  static int do_classify(const char *input, const uint8_t char_len, CharType &type);

private:
  /*************************  Alpha: english letter abc *********************/
  template <ObCharsetType CS_TYPE>
  static typename std::enable_if<(CS_TYPE == CHARSET_UTF8MB4 || CS_TYPE == CHARSET_UTF16
                                  || CS_TYPE == CHARSET_UTF16LE),
                                 int>::type
  is_alpha(const char *input, const uint8_t char_len, bool &is_alpha);
  /****************************************************************************************/

  /*************************  Arabic: num letter 123 *********************/

  template <ObCharsetType CS_TYPE>
  static typename std::enable_if<(CS_TYPE == CHARSET_UTF8MB4 || CS_TYPE == CHARSET_UTF16
                                  || CS_TYPE == CHARSET_UTF16LE),
                                 int>::type
  is_arabic(const char *input, const uint8_t char_len, bool &is_arabic);
  /****************************************************************************************/

  /*************************  Chinese: Characters *********************/
  template <ObCharsetType CS_TYPE>
  static typename std::enable_if<(CS_TYPE == CHARSET_UTF8MB4 || CS_TYPE == CHARSET_UTF16
                                  || CS_TYPE == CHARSET_UTF16LE),
                                 int>::type
  is_chinese(const char *input, const uint8_t char_len, bool &is_chinese);
  /****************************************************************************************/

  /*************************  Other CJK:  Japanese Korean Chinese *********************/
  template <ObCharsetType CS_TYPE>
  static typename std::enable_if<(CS_TYPE == CHARSET_UTF8MB4 || CS_TYPE == CHARSET_UTF16
                                  || CS_TYPE == CHARSET_UTF16LE),
                                 int>::type
  is_other_cjk(const char *input, const uint8_t char_len, bool &is_other_cjk);
  /****************************************************************************************/

  /*************************  Surrogate: only for UTF16 *********************/
  template <ObCharsetType CS_TYPE>
  static
      typename std::enable_if<(CS_TYPE == CHARSET_UTF16 || CS_TYPE == CHARSET_UTF16LE), int>::type
      is_surrogate_high(const char *input, const uint8_t char_len, bool &is_surrogate_high);

  template <ObCharsetType CS_TYPE>
  static
      typename std::enable_if<(CS_TYPE == CHARSET_UTF16 || CS_TYPE == CHARSET_UTF16LE), int>::type
      is_surrogate_low(const char *input, const uint8_t char_len, bool &is_surrogate_low);

  template <ObCharsetType CS_TYPE>
  static
      typename std::enable_if<!(CS_TYPE == CHARSET_UTF16 || CS_TYPE == CHARSET_UTF16LE), int>::type
      is_surrogate_high(const char *input, const uint8_t char_len, bool &is_surrogate_high);

  template <ObCharsetType CS_TYPE>
  static
      typename std::enable_if<!(CS_TYPE == CHARSET_UTF16 || CS_TYPE == CHARSET_UTF16LE), int>::type
      is_surrogate_low(const char *input, const uint8_t char_len, bool &is_surrogate_low);
  /****************************************************************************************/

  /*************************  Ignore: some char should not output itself *********************/
  template <ObCharsetType CS_TYPE>
  static typename std::enable_if<(CS_TYPE == CHARSET_UTF8MB4 || CS_TYPE == CHARSET_UTF16
                                  || CS_TYPE == CHARSET_UTF16LE),
                                 int>::type
  is_ignore(const char *input, const uint8_t char_len, bool &ignore);
  /****************************************************************************************/

  /*************************  CN Number: one two three two *********************/
  template <ObCharsetType CS_TYPE>
  static typename std::enable_if<(CS_TYPE == CHARSET_UTF8MB4 || CS_TYPE == CHARSET_UTF16
                                  || CS_TYPE == CHARSET_UTF16LE),
                                 int>::type
  is_cn_number(const char *input, const uint8_t char_len, bool &is_cn_number);
  /****************************************************************************************/

  /*************************  English letter connector: #,-@ *********************/
  template <ObCharsetType CS_TYPE>
  static typename std::enable_if<(CS_TYPE == CHARSET_UTF8MB4 || CS_TYPE == CHARSET_UTF16
                                  || CS_TYPE == CHARSET_UTF16LE),
                                 int>::type
  is_letter_connector(const char *input, const uint8_t char_len, bool &is_connector);
  /****************************************************************************************/

  /*************************  Number letter connector: ,. *********************/
  template <ObCharsetType CS_TYPE>
  static typename std::enable_if<(CS_TYPE == CHARSET_UTF8MB4 || CS_TYPE == CHARSET_UTF16
                                  || CS_TYPE == CHARSET_UTF16LE),
                                 int>::type
  is_num_connector(const char *input, const uint8_t char_len, bool &is_connector);
  /****************************************************************************************/

private:
  // only for unicode charset
  template <ObCharsetType CS_TYPE>
  static typename std::enable_if<(CS_TYPE == CHARSET_UTF8MB4 || CS_TYPE == CHARSET_UTF16
                                  || CS_TYPE == CHARSET_UTF16LE),
                                 int>::type
  decode_unicode(const char *input, const uint8_t char_len, ob_wc_t &unicode)
  {
    int ret = OB_SUCCESS;
    if (OB_ISNULL(input)) {
      ret = OB_INVALID_ARGUMENT;
      STORAGE_FTS_LOG(WARN, "Invalid input", K(input), K(ret));
    } else {
      const unsigned char *ustart = reinterpret_cast<const unsigned char *>(input);
      const unsigned char *uend = reinterpret_cast<const unsigned char *>(&input[char_len]);
      int code_size = common::ob_charset_decode_unicode<CS_TYPE>(ustart, uend, unicode);
      if (code_size < 0) {
        ret = OB_UNEXPECT_INTERNAL_ERROR;
        STORAGE_FTS_LOG(WARN, "Failed to decode unicode", K(code_size), K(ret));
      }
    }
    return ret;
  }
}; // End of class.

template <ObCharsetType CS_TYPE>
inline typename std::enable_if<(CS_TYPE == CHARSET_UTF8MB4 || CS_TYPE == CHARSET_UTF16
                                || CS_TYPE == CHARSET_UTF16LE),
                               int>::type
ObFTCharUtil::is_alpha(const char *input, const uint8_t char_len, bool &is_alpha)
{
  int ret = OB_SUCCESS;
  ob_wc_t unicode = 0;
  if (OB_FAIL(decode_unicode<CS_TYPE>(input, char_len, unicode))) {
  } else {
    is_alpha = ObUnicodeBlockUtils::is_alpha(unicode);
  }
  return ret;
}

template <ObCharsetType CS_TYPE>
inline typename std::enable_if<(CS_TYPE == CHARSET_UTF8MB4 || CS_TYPE == CHARSET_UTF16
                                || CS_TYPE == CHARSET_UTF16LE),
                               int>::type
ObFTCharUtil::is_arabic(const char *input, const uint8_t char_len, bool &is_arabic)
{
  int ret = OB_SUCCESS;
  ob_wc_t unicode = 0;
  if (OB_FAIL(decode_unicode<CS_TYPE>(input, char_len, unicode))) {
  } else {
    is_arabic = ObUnicodeBlockUtils::is_arabic(unicode);
  }
  return ret;
}

template <ObCharsetType CS_TYPE>
inline typename std::enable_if<(CS_TYPE == CHARSET_UTF8MB4 || CS_TYPE == CHARSET_UTF16
                                || CS_TYPE == CHARSET_UTF16LE),
                               int>::type
ObFTCharUtil::is_chinese(const char *input, const uint8_t char_len, bool &is_chinese)
{
  int ret = OB_SUCCESS;
  ob_wc_t unicode = 0;
  if (OB_FAIL(decode_unicode<CS_TYPE>(input, char_len, unicode))) {
  } else {
    is_chinese = ObUnicodeBlockUtils::is_chinese(unicode);
  }
  return ret;
}

template <ObCharsetType CS_TYPE>
inline typename std::enable_if<(CS_TYPE == CHARSET_UTF8MB4 || CS_TYPE == CHARSET_UTF16
                                || CS_TYPE == CHARSET_UTF16LE),
                               int>::type
ObFTCharUtil::is_other_cjk(const char *input, const uint8_t char_len, bool &is_other_cjk)
{
  int ret = OB_SUCCESS;
  ob_wc_t unicode = 0;
  if (OB_FAIL(decode_unicode<CS_TYPE>(input, char_len, unicode))) {
  } else {
    is_other_cjk = ObUnicodeBlockUtils::is_other_cjk(unicode);
  }
  return ret;
}

template <ObCharsetType CS_TYPE>
inline typename std::enable_if<(CS_TYPE == CHARSET_UTF16 || CS_TYPE == CHARSET_UTF16LE), int>::type
ObFTCharUtil::is_surrogate_high(const char *input, const uint8_t char_len, bool &is_surrogate_high)
{
  int ret = OB_SUCCESS;
  ob_wc_t unicode = 0;
  if (OB_FAIL(decode_unicode<CS_TYPE>(input, char_len, unicode))) {
  } else {
    is_surrogate_high = ObUnicodeBlockUtils::check_high_surrogate(unicode);
  }
  return ret;
}

template <ObCharsetType CS_TYPE>
inline typename std::enable_if<(CS_TYPE == CHARSET_UTF16 || CS_TYPE == CHARSET_UTF16LE), int>::type
ObFTCharUtil::is_surrogate_low(const char *input, const uint8_t char_len, bool &is_surrogate_low)
{
  int ret = OB_SUCCESS;
  ob_wc_t unicode = 0;
  if (OB_FAIL(decode_unicode<CS_TYPE>(input, char_len, unicode))) {
  } else {
    is_surrogate_low = ObUnicodeBlockUtils::check_low_surrogate(unicode);
  }
  return ret;
}

template <ObCharsetType CS_TYPE>
inline typename std::enable_if<!(CS_TYPE == CHARSET_UTF16 || CS_TYPE == CHARSET_UTF16LE), int>::type
ObFTCharUtil::is_surrogate_high(const char *input, const uint8_t char_len, bool &is_surrogate_high)
{
  int ret = OB_SUCCESS;
  is_surrogate_high = false;
  return ret;
}

template <ObCharsetType CS_TYPE>
inline typename std::enable_if<!(CS_TYPE == CHARSET_UTF16 || CS_TYPE == CHARSET_UTF16LE), int>::type
ObFTCharUtil::is_surrogate_low(const char *input, const uint8_t char_len, bool &is_surrogate_low)
{
  int ret = OB_SUCCESS;
  is_surrogate_low = false;
  return ret;
}

template <ObCharsetType CS_TYPE>
inline typename std::enable_if<(CS_TYPE == CHARSET_UTF8MB4 || CS_TYPE == CHARSET_UTF16
                                || CS_TYPE == CHARSET_UTF16LE),
                               int>::type
ObFTCharUtil::is_ignore(const char *input, const uint8_t char_len, bool &ignore)
{
  int ret = OB_SUCCESS;
  ob_wc_t unicode = 0;
  if (OB_FAIL(decode_unicode<CS_TYPE>(input, char_len, unicode))) {
  } else {
    ignore = ObUnicodeBlockUtils::check_ignore_as_single(unicode);
  }
  return ret;
}

template <ObCharsetType CS_TYPE>
inline typename std::enable_if<(CS_TYPE == CHARSET_UTF8MB4 || CS_TYPE == CHARSET_UTF16
                                || CS_TYPE == CHARSET_UTF16LE),
                               int>::type
ObFTCharUtil::is_cn_number(const char *input, const uint8_t char_len, bool &is_cn_number)
{
  int ret = OB_SUCCESS;
  ob_wc_t unicode = 0;
  if (OB_FAIL(decode_unicode<CS_TYPE>(input, char_len, unicode))) {
  } else {
    is_cn_number = ObUnicodeBlockUtils::is_unicode_cn_number(unicode);
  }
  return ret;
}

template <ObCharsetType CS_TYPE>
inline typename std::enable_if<(CS_TYPE == CHARSET_UTF8MB4 || CS_TYPE == CHARSET_UTF16
                                || CS_TYPE == CHARSET_UTF16LE),
                               int>::type
ObFTCharUtil::is_letter_connector(const char *input, const uint8_t char_len, bool &is_connector)
{
  int ret = OB_SUCCESS;
  ob_wc_t unicode = 0;
  if (OB_FAIL(decode_unicode<CS_TYPE>(input, char_len, unicode))) {
  } else {
    is_connector = ObUnicodeBlockUtils::check_letter_connector(unicode);
  }
  return ret;
}

template <ObCharsetType CS_TYPE>
inline typename std::enable_if<(CS_TYPE == CHARSET_UTF8MB4 || CS_TYPE == CHARSET_UTF16
                                || CS_TYPE == CHARSET_UTF16LE),
                               int>::type
ObFTCharUtil::is_num_connector(const char *input, const uint8_t char_len, bool &is_connector)
{
  int ret = OB_SUCCESS;
  ob_wc_t unicode = 0;
  if (OB_FAIL(decode_unicode<CS_TYPE>(input, char_len, unicode))) {
  } else {
    is_connector = ObUnicodeBlockUtils::check_num_connector(unicode);
  }
  return ret;
}

// Support GBK

// Implementation of some frame;

inline int ObFTCharUtil::check_cn_number(ObCollationType coll_type,
                                         const char *input,
                                         const uint8_t char_len,
                                         bool &is_cn_number)
{
  int ret = OB_SUCCESS;
  ObCharsetType cs_type = ObCharset::charset_type_by_coll(coll_type);

  switch (cs_type) {
  case CHARSET_UTF8MB4: {
    ret = ObFTCharUtil::is_cn_number<CHARSET_UTF8MB4>(input, char_len, is_cn_number);
    break;
  }
  default:
    ret = OB_NOT_SUPPORTED;
    STORAGE_FTS_LOG(WARN, "Not supported charset type", K(ret), K(cs_type));
  }
  return ret;
}

inline int ObFTCharUtil::check_num_connector(ObCollationType coll_type,
                                             const char *input,
                                             const uint8_t char_len,
                                             bool &is_connector)
{
  int ret = OB_SUCCESS;
  ObCharsetType cs_type = ObCharset::charset_type_by_coll(coll_type);

  switch (cs_type) {
  case CHARSET_UTF8MB4: {
    ret = ObFTCharUtil::is_num_connector<CHARSET_UTF8MB4>(input, char_len, is_connector);
    break;
  }
  default:
    ret = OB_NOT_SUPPORTED;
    STORAGE_FTS_LOG(WARN, "Not supported charset type", K(ret), K(cs_type));
  }
  return ret;
}

inline int ObFTCharUtil::check_letter_connector(ObCollationType coll_type,
                                                const char *input,
                                                const uint8_t char_len,
                                                bool &is_connector)
{
  int ret = OB_SUCCESS;
  ObCharsetType cs_type = ObCharset::charset_type_by_coll(coll_type);

  switch (cs_type) {
  case CHARSET_UTF8MB4: {
    // ret = ObFTCharUtil::do_check_letter_connector<CHARSET_UTF8MB4>(input, char_len,
    // is_connector);
    ret = ObFTCharUtil::is_letter_connector<CHARSET_UTF8MB4>(input, char_len, is_connector);
    break;
  }
  default:
    ret = OB_NOT_SUPPORTED;
    STORAGE_FTS_LOG(WARN, "Not supported charset type", K(ret), K(cs_type));
  }
  return ret;
}

inline int ObFTCharUtil::is_ignore_single_cjk(ObCollationType coll_type,
                                              const char *input,
                                              const uint8_t char_len,
                                              bool &ignore)
{
  int ret = OB_SUCCESS;
  ObCharsetType cs_type = ObCharset::charset_type_by_coll(coll_type);

  switch (cs_type) {
  case CHARSET_UTF8MB4: {
    ret = ObFTCharUtil::is_ignore<CHARSET_UTF8MB4>(input, char_len, ignore);
    break;
  }
  default:
    ret = OB_NOT_SUPPORTED;
    STORAGE_FTS_LOG(WARN, "Not supported charset type", K(ret), K(cs_type));
    break;
  }
  return ret;
}

template <ObCharsetType CS_TYPE>
inline int ObFTCharUtil::do_classify(const char *input, const uint8_t char_len, CharType &type)
{
  int ret = OB_SUCCESS;
  ob_wc_t unicode = 0;
  type = CharType::USELESS;

  // Every predicate examines the same character. Decode it once while keeping
  // the classification order, including UTF-16-only surrogate handling.
  if (OB_FAIL(decode_unicode<CS_TYPE>(input, char_len, unicode))) {
  } else if (ObUnicodeBlockUtils::is_alpha(unicode)) {
    type = CharType::ENGLISH_LETTER;
  } else if (ObUnicodeBlockUtils::is_arabic(unicode)) {
    type = CharType::ARABIC_LETTER;
  } else if (ObUnicodeBlockUtils::is_chinese(unicode)) {
    type = CharType::CHINESE;
  } else if (ObUnicodeBlockUtils::is_other_cjk(unicode)) {
    type = CharType::OTHER_CJK;
  } else if ((CS_TYPE == CHARSET_UTF16 || CS_TYPE == CHARSET_UTF16LE)
             && ObUnicodeBlockUtils::check_high_surrogate(unicode)) {
    type = CharType::SURROGATE_HIGH;
  } else if ((CS_TYPE == CHARSET_UTF16 || CS_TYPE == CHARSET_UTF16LE)
             && ObUnicodeBlockUtils::check_low_surrogate(unicode)) {
    type = CharType::SURROGATE_LOW;
  }
  return ret;
}

inline int ObFTCharUtil::classify_first_char(ObCollationType coll_type,
                                             const char *input,
                                             const uint8_t char_len,
                                             CharType &type)
{
  int ret = OB_SUCCESS;
  ObCharsetType cs_type = ObCharset::charset_type_by_coll(coll_type);

  switch (cs_type) {
  case CHARSET_UTF8MB4: {
    ret = do_classify<CHARSET_UTF8MB4>(input, char_len, type);
    break;
  }
  case CHARSET_UTF16: {
    ret = do_classify<CHARSET_UTF16>(input, char_len, type);
    break;
  }
  case CHARSET_UTF16LE: {
    ret = do_classify<CHARSET_UTF16LE>(input, char_len, type);
    break;
  }
  default:
    ret = OB_NOT_SUPPORTED;
    STORAGE_FTS_LOG(WARN, "Not supported charset type", K(ret), K(cs_type));
    break;
  }
  return ret;
}



// Only unrelated object layout and container dependencies are stubbed here.
class TokenizeContext {
public:
  TokenizeContext(ObCollationType, ObIAllocator &, const char *, int64_t, bool);
  int init();
  int prepare_next_char();
  int step_next();
  ObCollationType coll_type_;
  const char *fulltext_;
  int64_t fulltext_len_, cursor_, next_char_len_;
  ObFTCharUtil::CharType next_char_type_;
  uint32_t handle_size_;
  bool is_smart_;

  LeafList token_list_, result_list_;
};

TokenizeContext::TokenizeContext(ObCollationType coll_type,
                                 ObIAllocator &allocator,
                                 const char *fulltext,
                                 int64_t fulltext_len,
                                 bool is_smart)
    : coll_type_(coll_type), fulltext_(fulltext), fulltext_len_(fulltext_len), cursor_(0),
      next_char_len_(0), handle_size_(0), is_smart_(is_smart), token_list_(allocator),
      result_list_(allocator)
{
}

int TokenizeContext::init()
{
  int ret = OB_SUCCESS;

  if (OB_ISNULL(fulltext_) || fulltext_len_ <= 0) {
    ret = OB_INVALID_ARGUMENT;
  } else if (OB_FAIL(prepare_next_char())) {
  }
  return ret;
}

int TokenizeContext::prepare_next_char()
{
  int ret = OB_SUCCESS;
  if (OB_FAIL(ObCharset::first_valid_char(coll_type_,
                                          fulltext_ + cursor_,
                                          fulltext_len_ - cursor_,
                                          next_char_len_))) {
  } else if (OB_FAIL(ObFTCharUtil::classify_first_char(coll_type_,
                                                       fulltext_ + cursor_,
                                                       next_char_len_,
                                                       next_char_type_))) {
  }
  return ret;
}

int TokenizeContext::step_next()
{
  int ret = OB_SUCCESS;
  if (cursor_ >= fulltext_len_) {
    ret = OB_ITER_END;
  } else if (cursor_ + next_char_len_ >= fulltext_len_) {
    cursor_ = fulltext_len_;
    next_char_len_ = 0;
    ret = OB_ITER_END;
  } else if (cursor_ < fulltext_len_ && 0 == next_char_len_) {
    // should not happen
    ret = OB_UNEXPECT_INTERNAL_ERROR;
  } else {
    cursor_ += next_char_len_;
    handle_size_++;
    if (OB_FAIL(prepare_next_char())) {
    } else {
    }
  }
  return ret;
}

}

namespace candidate {
class ObFTCharUtil
{
public:
  enum class CharType : int8_t
  {
    USELESS = 0,
    ARABIC_LETTER = 1,
    ENGLISH_LETTER = 2,
    CHINESE = 3,
    OTHER_CJK = 4,
    SURROGATE_HIGH = 5,
    SURROGATE_LOW = 6,
  };

  static int classify_first_char(ObCollationType coll_type,
                                 const char *input,
                                 const uint8_t char_len,
                                 CharType &type);

  template <ObCharsetType CS_TYPE>
  static void classify_unicode(const ob_wc_t unicode, CharType &type);

  static int check_cn_number(ObCollationType coll_type,
                             const char *input,
                             const uint8_t char_len,
                             bool &is_cn_number);

  static int check_num_connector(ObCollationType coll_type,
                                 const char *input,
                                 const uint8_t char_len,
                                 bool &is_connector);

  static int check_letter_connector(ObCollationType coll_type,
                                    const char *input,
                                    const uint8_t char_len,
                                    bool &is_connector);

  // some cjk word should be ignored
  static int is_ignore_single_cjk(ObCollationType coll_type,
                                  const char *input,
                                  const uint8_t char_len,
                                  bool &ignore);

private:
  template <ObCharsetType CS_TYPE>
  static int do_classify(const char *input, const uint8_t char_len, CharType &type);

private:
  /*************************  Alpha: english letter abc *********************/
  template <ObCharsetType CS_TYPE>
  static typename std::enable_if<(CS_TYPE == CHARSET_UTF8MB4 || CS_TYPE == CHARSET_UTF16
                                  || CS_TYPE == CHARSET_UTF16LE),
                                 int>::type
  is_alpha(const char *input, const uint8_t char_len, bool &is_alpha);
  /****************************************************************************************/

  /*************************  Arabic: num letter 123 *********************/

  template <ObCharsetType CS_TYPE>
  static typename std::enable_if<(CS_TYPE == CHARSET_UTF8MB4 || CS_TYPE == CHARSET_UTF16
                                  || CS_TYPE == CHARSET_UTF16LE),
                                 int>::type
  is_arabic(const char *input, const uint8_t char_len, bool &is_arabic);
  /****************************************************************************************/

  /*************************  Chinese: Characters *********************/
  template <ObCharsetType CS_TYPE>
  static typename std::enable_if<(CS_TYPE == CHARSET_UTF8MB4 || CS_TYPE == CHARSET_UTF16
                                  || CS_TYPE == CHARSET_UTF16LE),
                                 int>::type
  is_chinese(const char *input, const uint8_t char_len, bool &is_chinese);
  /****************************************************************************************/

  /*************************  Other CJK:  Japanese Korean Chinese *********************/
  template <ObCharsetType CS_TYPE>
  static typename std::enable_if<(CS_TYPE == CHARSET_UTF8MB4 || CS_TYPE == CHARSET_UTF16
                                  || CS_TYPE == CHARSET_UTF16LE),
                                 int>::type
  is_other_cjk(const char *input, const uint8_t char_len, bool &is_other_cjk);
  /****************************************************************************************/

  /*************************  Surrogate: only for UTF16 *********************/
  template <ObCharsetType CS_TYPE>
  static
      typename std::enable_if<(CS_TYPE == CHARSET_UTF16 || CS_TYPE == CHARSET_UTF16LE), int>::type
      is_surrogate_high(const char *input, const uint8_t char_len, bool &is_surrogate_high);

  template <ObCharsetType CS_TYPE>
  static
      typename std::enable_if<(CS_TYPE == CHARSET_UTF16 || CS_TYPE == CHARSET_UTF16LE), int>::type
      is_surrogate_low(const char *input, const uint8_t char_len, bool &is_surrogate_low);

  template <ObCharsetType CS_TYPE>
  static
      typename std::enable_if<!(CS_TYPE == CHARSET_UTF16 || CS_TYPE == CHARSET_UTF16LE), int>::type
      is_surrogate_high(const char *input, const uint8_t char_len, bool &is_surrogate_high);

  template <ObCharsetType CS_TYPE>
  static
      typename std::enable_if<!(CS_TYPE == CHARSET_UTF16 || CS_TYPE == CHARSET_UTF16LE), int>::type
      is_surrogate_low(const char *input, const uint8_t char_len, bool &is_surrogate_low);
  /****************************************************************************************/

  /*************************  Ignore: some char should not output itself *********************/
  template <ObCharsetType CS_TYPE>
  static typename std::enable_if<(CS_TYPE == CHARSET_UTF8MB4 || CS_TYPE == CHARSET_UTF16
                                  || CS_TYPE == CHARSET_UTF16LE),
                                 int>::type
  is_ignore(const char *input, const uint8_t char_len, bool &ignore);
  /****************************************************************************************/

  /*************************  CN Number: one two three two *********************/
  template <ObCharsetType CS_TYPE>
  static typename std::enable_if<(CS_TYPE == CHARSET_UTF8MB4 || CS_TYPE == CHARSET_UTF16
                                  || CS_TYPE == CHARSET_UTF16LE),
                                 int>::type
  is_cn_number(const char *input, const uint8_t char_len, bool &is_cn_number);
  /****************************************************************************************/

  /*************************  English letter connector: #,-@ *********************/
  template <ObCharsetType CS_TYPE>
  static typename std::enable_if<(CS_TYPE == CHARSET_UTF8MB4 || CS_TYPE == CHARSET_UTF16
                                  || CS_TYPE == CHARSET_UTF16LE),
                                 int>::type
  is_letter_connector(const char *input, const uint8_t char_len, bool &is_connector);
  /****************************************************************************************/

  /*************************  Number letter connector: ,. *********************/
  template <ObCharsetType CS_TYPE>
  static typename std::enable_if<(CS_TYPE == CHARSET_UTF8MB4 || CS_TYPE == CHARSET_UTF16
                                  || CS_TYPE == CHARSET_UTF16LE),
                                 int>::type
  is_num_connector(const char *input, const uint8_t char_len, bool &is_connector);
  /****************************************************************************************/

private:
  // only for unicode charset
  template <ObCharsetType CS_TYPE>
  static typename std::enable_if<(CS_TYPE == CHARSET_UTF8MB4 || CS_TYPE == CHARSET_UTF16
                                  || CS_TYPE == CHARSET_UTF16LE),
                                 int>::type
  decode_unicode(const char *input, const uint8_t char_len, ob_wc_t &unicode)
  {
    int ret = OB_SUCCESS;
    if (OB_ISNULL(input)) {
      ret = OB_INVALID_ARGUMENT;
      STORAGE_FTS_LOG(WARN, "Invalid input", K(input), K(ret));
    } else {
      const unsigned char *ustart = reinterpret_cast<const unsigned char *>(input);
      const unsigned char *uend = reinterpret_cast<const unsigned char *>(&input[char_len]);
      int code_size = common::ob_charset_decode_unicode<CS_TYPE>(ustart, uend, unicode);
      if (code_size < 0) {
        ret = OB_UNEXPECT_INTERNAL_ERROR;
        STORAGE_FTS_LOG(WARN, "Failed to decode unicode", K(code_size), K(ret));
      }
    }
    return ret;
  }
}; // End of class.

template <ObCharsetType CS_TYPE>
inline typename std::enable_if<(CS_TYPE == CHARSET_UTF8MB4 || CS_TYPE == CHARSET_UTF16
                                || CS_TYPE == CHARSET_UTF16LE),
                               int>::type
ObFTCharUtil::is_alpha(const char *input, const uint8_t char_len, bool &is_alpha)
{
  int ret = OB_SUCCESS;
  ob_wc_t unicode = 0;
  if (OB_FAIL(decode_unicode<CS_TYPE>(input, char_len, unicode))) {
  } else {
    is_alpha = ObUnicodeBlockUtils::is_alpha(unicode);
  }
  return ret;
}

template <ObCharsetType CS_TYPE>
inline typename std::enable_if<(CS_TYPE == CHARSET_UTF8MB4 || CS_TYPE == CHARSET_UTF16
                                || CS_TYPE == CHARSET_UTF16LE),
                               int>::type
ObFTCharUtil::is_arabic(const char *input, const uint8_t char_len, bool &is_arabic)
{
  int ret = OB_SUCCESS;
  ob_wc_t unicode = 0;
  if (OB_FAIL(decode_unicode<CS_TYPE>(input, char_len, unicode))) {
  } else {
    is_arabic = ObUnicodeBlockUtils::is_arabic(unicode);
  }
  return ret;
}

template <ObCharsetType CS_TYPE>
inline typename std::enable_if<(CS_TYPE == CHARSET_UTF8MB4 || CS_TYPE == CHARSET_UTF16
                                || CS_TYPE == CHARSET_UTF16LE),
                               int>::type
ObFTCharUtil::is_chinese(const char *input, const uint8_t char_len, bool &is_chinese)
{
  int ret = OB_SUCCESS;
  ob_wc_t unicode = 0;
  if (OB_FAIL(decode_unicode<CS_TYPE>(input, char_len, unicode))) {
  } else {
    is_chinese = ObUnicodeBlockUtils::is_chinese(unicode);
  }
  return ret;
}

template <ObCharsetType CS_TYPE>
inline typename std::enable_if<(CS_TYPE == CHARSET_UTF8MB4 || CS_TYPE == CHARSET_UTF16
                                || CS_TYPE == CHARSET_UTF16LE),
                               int>::type
ObFTCharUtil::is_other_cjk(const char *input, const uint8_t char_len, bool &is_other_cjk)
{
  int ret = OB_SUCCESS;
  ob_wc_t unicode = 0;
  if (OB_FAIL(decode_unicode<CS_TYPE>(input, char_len, unicode))) {
  } else {
    is_other_cjk = ObUnicodeBlockUtils::is_other_cjk(unicode);
  }
  return ret;
}

template <ObCharsetType CS_TYPE>
inline typename std::enable_if<(CS_TYPE == CHARSET_UTF16 || CS_TYPE == CHARSET_UTF16LE), int>::type
ObFTCharUtil::is_surrogate_high(const char *input, const uint8_t char_len, bool &is_surrogate_high)
{
  int ret = OB_SUCCESS;
  ob_wc_t unicode = 0;
  if (OB_FAIL(decode_unicode<CS_TYPE>(input, char_len, unicode))) {
  } else {
    is_surrogate_high = ObUnicodeBlockUtils::check_high_surrogate(unicode);
  }
  return ret;
}

template <ObCharsetType CS_TYPE>
inline typename std::enable_if<(CS_TYPE == CHARSET_UTF16 || CS_TYPE == CHARSET_UTF16LE), int>::type
ObFTCharUtil::is_surrogate_low(const char *input, const uint8_t char_len, bool &is_surrogate_low)
{
  int ret = OB_SUCCESS;
  ob_wc_t unicode = 0;
  if (OB_FAIL(decode_unicode<CS_TYPE>(input, char_len, unicode))) {
  } else {
    is_surrogate_low = ObUnicodeBlockUtils::check_low_surrogate(unicode);
  }
  return ret;
}

template <ObCharsetType CS_TYPE>
inline typename std::enable_if<!(CS_TYPE == CHARSET_UTF16 || CS_TYPE == CHARSET_UTF16LE), int>::type
ObFTCharUtil::is_surrogate_high(const char *input, const uint8_t char_len, bool &is_surrogate_high)
{
  int ret = OB_SUCCESS;
  is_surrogate_high = false;
  return ret;
}

template <ObCharsetType CS_TYPE>
inline typename std::enable_if<!(CS_TYPE == CHARSET_UTF16 || CS_TYPE == CHARSET_UTF16LE), int>::type
ObFTCharUtil::is_surrogate_low(const char *input, const uint8_t char_len, bool &is_surrogate_low)
{
  int ret = OB_SUCCESS;
  is_surrogate_low = false;
  return ret;
}

template <ObCharsetType CS_TYPE>
inline typename std::enable_if<(CS_TYPE == CHARSET_UTF8MB4 || CS_TYPE == CHARSET_UTF16
                                || CS_TYPE == CHARSET_UTF16LE),
                               int>::type
ObFTCharUtil::is_ignore(const char *input, const uint8_t char_len, bool &ignore)
{
  int ret = OB_SUCCESS;
  ob_wc_t unicode = 0;
  if (OB_FAIL(decode_unicode<CS_TYPE>(input, char_len, unicode))) {
  } else {
    ignore = ObUnicodeBlockUtils::check_ignore_as_single(unicode);
  }
  return ret;
}

template <ObCharsetType CS_TYPE>
inline typename std::enable_if<(CS_TYPE == CHARSET_UTF8MB4 || CS_TYPE == CHARSET_UTF16
                                || CS_TYPE == CHARSET_UTF16LE),
                               int>::type
ObFTCharUtil::is_cn_number(const char *input, const uint8_t char_len, bool &is_cn_number)
{
  int ret = OB_SUCCESS;
  ob_wc_t unicode = 0;
  if (OB_FAIL(decode_unicode<CS_TYPE>(input, char_len, unicode))) {
  } else {
    is_cn_number = ObUnicodeBlockUtils::is_unicode_cn_number(unicode);
  }
  return ret;
}

template <ObCharsetType CS_TYPE>
inline typename std::enable_if<(CS_TYPE == CHARSET_UTF8MB4 || CS_TYPE == CHARSET_UTF16
                                || CS_TYPE == CHARSET_UTF16LE),
                               int>::type
ObFTCharUtil::is_letter_connector(const char *input, const uint8_t char_len, bool &is_connector)
{
  int ret = OB_SUCCESS;
  ob_wc_t unicode = 0;
  if (OB_FAIL(decode_unicode<CS_TYPE>(input, char_len, unicode))) {
  } else {
    is_connector = ObUnicodeBlockUtils::check_letter_connector(unicode);
  }
  return ret;
}

template <ObCharsetType CS_TYPE>
inline typename std::enable_if<(CS_TYPE == CHARSET_UTF8MB4 || CS_TYPE == CHARSET_UTF16
                                || CS_TYPE == CHARSET_UTF16LE),
                               int>::type
ObFTCharUtil::is_num_connector(const char *input, const uint8_t char_len, bool &is_connector)
{
  int ret = OB_SUCCESS;
  ob_wc_t unicode = 0;
  if (OB_FAIL(decode_unicode<CS_TYPE>(input, char_len, unicode))) {
  } else {
    is_connector = ObUnicodeBlockUtils::check_num_connector(unicode);
  }
  return ret;
}

// Support GBK

// Implementation of some frame;

inline int ObFTCharUtil::check_cn_number(ObCollationType coll_type,
                                         const char *input,
                                         const uint8_t char_len,
                                         bool &is_cn_number)
{
  int ret = OB_SUCCESS;
  ObCharsetType cs_type = ObCharset::charset_type_by_coll(coll_type);

  switch (cs_type) {
  case CHARSET_UTF8MB4: {
    ret = ObFTCharUtil::is_cn_number<CHARSET_UTF8MB4>(input, char_len, is_cn_number);
    break;
  }
  default:
    ret = OB_NOT_SUPPORTED;
    STORAGE_FTS_LOG(WARN, "Not supported charset type", K(ret), K(cs_type));
  }
  return ret;
}

inline int ObFTCharUtil::check_num_connector(ObCollationType coll_type,
                                             const char *input,
                                             const uint8_t char_len,
                                             bool &is_connector)
{
  int ret = OB_SUCCESS;
  ObCharsetType cs_type = ObCharset::charset_type_by_coll(coll_type);

  switch (cs_type) {
  case CHARSET_UTF8MB4: {
    ret = ObFTCharUtil::is_num_connector<CHARSET_UTF8MB4>(input, char_len, is_connector);
    break;
  }
  default:
    ret = OB_NOT_SUPPORTED;
    STORAGE_FTS_LOG(WARN, "Not supported charset type", K(ret), K(cs_type));
  }
  return ret;
}

inline int ObFTCharUtil::check_letter_connector(ObCollationType coll_type,
                                                const char *input,
                                                const uint8_t char_len,
                                                bool &is_connector)
{
  int ret = OB_SUCCESS;
  ObCharsetType cs_type = ObCharset::charset_type_by_coll(coll_type);

  switch (cs_type) {
  case CHARSET_UTF8MB4: {
    // ret = ObFTCharUtil::do_check_letter_connector<CHARSET_UTF8MB4>(input, char_len,
    // is_connector);
    ret = ObFTCharUtil::is_letter_connector<CHARSET_UTF8MB4>(input, char_len, is_connector);
    break;
  }
  default:
    ret = OB_NOT_SUPPORTED;
    STORAGE_FTS_LOG(WARN, "Not supported charset type", K(ret), K(cs_type));
  }
  return ret;
}

inline int ObFTCharUtil::is_ignore_single_cjk(ObCollationType coll_type,
                                              const char *input,
                                              const uint8_t char_len,
                                              bool &ignore)
{
  int ret = OB_SUCCESS;
  ObCharsetType cs_type = ObCharset::charset_type_by_coll(coll_type);

  switch (cs_type) {
  case CHARSET_UTF8MB4: {
    ret = ObFTCharUtil::is_ignore<CHARSET_UTF8MB4>(input, char_len, ignore);
    break;
  }
  default:
    ret = OB_NOT_SUPPORTED;
    STORAGE_FTS_LOG(WARN, "Not supported charset type", K(ret), K(cs_type));
    break;
  }
  return ret;
}

template <ObCharsetType CS_TYPE>
inline void ObFTCharUtil::classify_unicode(const ob_wc_t unicode, CharType &type)
{
  type = CharType::USELESS;
  if (ObUnicodeBlockUtils::is_alpha(unicode)) {
    type = CharType::ENGLISH_LETTER;
  } else if (ObUnicodeBlockUtils::is_arabic(unicode)) {
    type = CharType::ARABIC_LETTER;
  } else if (ObUnicodeBlockUtils::is_chinese(unicode)) {
    type = CharType::CHINESE;
  } else if (ObUnicodeBlockUtils::is_other_cjk(unicode)) {
    type = CharType::OTHER_CJK;
  } else if ((CS_TYPE == CHARSET_UTF16 || CS_TYPE == CHARSET_UTF16LE)
             && ObUnicodeBlockUtils::check_high_surrogate(unicode)) {
    type = CharType::SURROGATE_HIGH;
  } else if ((CS_TYPE == CHARSET_UTF16 || CS_TYPE == CHARSET_UTF16LE)
             && ObUnicodeBlockUtils::check_low_surrogate(unicode)) {
    type = CharType::SURROGATE_LOW;
  }
}

template <ObCharsetType CS_TYPE>
inline int ObFTCharUtil::do_classify(const char *input, const uint8_t char_len, CharType &type)
{
  int ret = OB_SUCCESS;
  ob_wc_t unicode = 0;
  // Preserve the original output value even when decoding fails.
  type = CharType::USELESS;
  if (OB_FAIL(decode_unicode<CS_TYPE>(input, char_len, unicode))) {
  } else {
    classify_unicode<CS_TYPE>(unicode, type);
  }
  return ret;
}

inline int ObFTCharUtil::classify_first_char(ObCollationType coll_type,
                                             const char *input,
                                             const uint8_t char_len,
                                             CharType &type)
{
  int ret = OB_SUCCESS;
  ObCharsetType cs_type = ObCharset::charset_type_by_coll(coll_type);

  switch (cs_type) {
  case CHARSET_UTF8MB4: {
    ret = do_classify<CHARSET_UTF8MB4>(input, char_len, type);
    break;
  }
  case CHARSET_UTF16: {
    ret = do_classify<CHARSET_UTF16>(input, char_len, type);
    break;
  }
  case CHARSET_UTF16LE: {
    ret = do_classify<CHARSET_UTF16LE>(input, char_len, type);
    break;
  }
  default:
    ret = OB_NOT_SUPPORTED;
    STORAGE_FTS_LOG(WARN, "Not supported charset type", K(ret), K(cs_type));
    break;
  }
  return ret;
}



// Only unrelated object layout and container dependencies are stubbed here.
class TokenizeContext {
public:
  TokenizeContext(ObCollationType, ObIAllocator &, const char *, int64_t, bool);
  int init();
  int prepare_next_char();
  int step_next();
  ObCollationType coll_type_;
  const char *fulltext_;
  int64_t fulltext_len_, cursor_, next_char_len_;
  ObFTCharUtil::CharType next_char_type_;
  uint32_t handle_size_;
  bool is_smart_;

  bool utf8_fast_path_;

  LeafList token_list_, result_list_;
};

TokenizeContext::TokenizeContext(ObCollationType coll_type,
                                 ObIAllocator &allocator,
                                 const char *fulltext,
                                 int64_t fulltext_len,
                                 bool is_smart)
    : coll_type_(coll_type), fulltext_(fulltext), fulltext_len_(fulltext_len), cursor_(0),
      next_char_len_(0), handle_size_(0), is_smart_(is_smart), utf8_fast_path_(false),
      token_list_(allocator),
      result_list_(allocator)
{
}

int TokenizeContext::init()
{
  int ret = OB_SUCCESS;
  // Keep the first character on the original path, including charset initialization.
  utf8_fast_path_ = false;

  if (OB_ISNULL(fulltext_) || fulltext_len_ <= 0) {
    ret = OB_INVALID_ARGUMENT;
  } else if (OB_FAIL(prepare_next_char())) {
  } else {
    utf8_fast_path_ = coll_type_ == CS_TYPE_UTF8MB4_GENERAL_CI
        || coll_type_ == CS_TYPE_UTF8MB4_BIN
        || coll_type_ == CS_TYPE_UTF8MB4_UNICODE_CI;
  }
  return ret;
}

int TokenizeContext::prepare_next_char()
{
  int ret = OB_SUCCESS;
  if (utf8_fast_path_ && cursor_ < fulltext_len_) {
    const unsigned char *begin = reinterpret_cast<const unsigned char *>(fulltext_ + cursor_);
    ob_wc_t unicode = 0;
    const int char_len = common::ob_charset_decode_unicode<CHARSET_UTF8MB4>(
        begin, begin + (fulltext_len_ - cursor_), unicode);
    // Positive lengths imply the original validator accepts the same character.
    // In particular, ILSEQ is zero: surrogate encodings must retain the fallback.
    if (char_len > 0) {
      next_char_len_ = char_len;
      ObFTCharUtil::classify_unicode<CHARSET_UTF8MB4>(unicode, next_char_type_);
      return OB_SUCCESS;
    }
  }
  if (OB_FAIL(ObCharset::first_valid_char(coll_type_,
                                          fulltext_ + cursor_,
                                          fulltext_len_ - cursor_,
                                          next_char_len_))) {
  } else if (OB_FAIL(ObFTCharUtil::classify_first_char(coll_type_,
                                                       fulltext_ + cursor_,
                                                       next_char_len_,
                                                       next_char_type_))) {
  }
  return ret;
}

int TokenizeContext::step_next()
{
  int ret = OB_SUCCESS;
  if (cursor_ >= fulltext_len_) {
    ret = OB_ITER_END;
  } else if (cursor_ + next_char_len_ >= fulltext_len_) {
    cursor_ = fulltext_len_;
    next_char_len_ = 0;
    ret = OB_ITER_END;
  } else if (cursor_ < fulltext_len_ && 0 == next_char_len_) {
    // should not happen
    ret = OB_UNEXPECT_INTERNAL_ERROR;
  } else {
    cursor_ += next_char_len_;
    handle_size_++;
    if (OB_FAIL(prepare_next_char())) {
    } else {
    }
  }
  return ret;
}

}

// Test data generators and assertions only. The implementation under test above
// is extracted verbatim from seekdb, including the old and proposed context code.
namespace {
uint64_t cases = 0, positive = 0, zero = 0, negative = 0;
uint64_t scalars = 0, surrogates = 0, one_byte = 0, two_byte = 0;
uint64_t boundary3 = 0, boundary4 = 0, truncations = 0, random_count = 0;
ObIAllocator allocator;
const std::array<ObCollationType, 3> utf8_collations{
  CS_TYPE_UTF8MB4_GENERAL_CI, CS_TYPE_UTF8MB4_BIN, CS_TYPE_UTF8MB4_UNICODE_CI
};

[[noreturn]] void fail(const char *what, const uchar *s, size_t size)
{
  std::ostringstream message;
  message << what << " case=" << cases << " bytes=";
  for (size_t i = 0; i < size; ++i) {
    message << std::hex << std::setfill('0') << std::setw(2) << unsigned(s[i]);
  }
  throw std::runtime_error(message.str());
}

// Independent encoding generates test inputs/expected codepoints, never a
// replacement for the validator or decoder being tested.
size_t encode(uint32_t cp, std::array<uchar, 8> &out)
{
  if (cp < 0x80) {
    out[0] = uchar(cp); return 1;
  } else if (cp < 0x800) {
    out[0] = uchar(0xc0 | (cp >> 6));
    out[1] = uchar(0x80 | (cp & 0x3f)); return 2;
  } else if (cp < 0x10000) {
    out[0] = uchar(0xe0 | (cp >> 12));
    out[1] = uchar(0x80 | ((cp >> 6) & 0x3f));
    out[2] = uchar(0x80 | (cp & 0x3f)); return 3;
  }
  out[0] = uchar(0xf0 | (cp >> 18));
  out[1] = uchar(0x80 | ((cp >> 12) & 0x3f));
  out[2] = uchar(0x80 | ((cp >> 6) & 0x3f));
  out[3] = uchar(0x80 | (cp & 0x3f)); return 4;
}

void check_case(const uchar *input, size_t size, int64_t expected_cp = -1, bool surrogate = false)
{
  ++cases;
  // Exact-sized allocation with an unaligned start: ASan can detect reads past
  // the logical end instead of silently accepting padding in a large buffer.
  std::unique_ptr<uchar[]> allocation(new uchar[size + 1]);
  uchar *s = allocation.get() + 1;
  if (size) std::memcpy(s, input, size);
  const uchar *end = s + size;
  ob_wc_t cp = 0;
  const int n = common::ob_charset_decode_unicode<CHARSET_UTF8MB4>(s, end, cp);
  int error = -1;
  const size_t validated = ob_well_formed_len_utf8mb4(nullptr,
      reinterpret_cast<const char *>(s), reinterpret_cast<const char *>(end), 1, &error);
  if (n > 0) {
    ++positive;
    ob_wc_t old_cp = 0, handler_cp = 0;
    const int old_n = common::ob_charset_decode_unicode<CHARSET_UTF8MB4>(s, s + n, old_cp);
    const int handler_n = ob_mb_wc_utf8mb4(nullptr, &handler_cp, s, s + n);
    if (error != 0 || validated != size_t(n)
        || ob_valid_mbcharlen_utf8mb4(nullptr, s, end) != n
        || old_n != n || old_cp != cp || handler_n != n || handler_cp != cp) {
      fail("positive decode does not imply identical old validation/decoding", s, size);
    }
  } else if (n == 0) {
    ++zero;
  } else {
    ++negative;
  }
  if (expected_cp >= 0) {
    if (cp != ob_wc_t(expected_cp) || (surrogate ? n != 0 : n <= 0)) {
      fail("unexpected scalar/surrogate decoder result", s, size);
    }
  }
  if (surrogate && (validated != 3 || error != 0)) {
    fail("surrogate acceptance of original validator changed", s, size);
  }

  // Prefix with a real valid first character to enable exactly the proposed
  // init transition, then exercise the actual old/new prepare method bodies.
  std::unique_ptr<char[]> document(new char[size + 1]);
  document[0] = 'A';
  if (size) std::memcpy(document.get() + 1, s, size);
  const auto coll = utf8_collations[cases % utf8_collations.size()];
  baseline::TokenizeContext old_context(coll, allocator, document.get(), int64_t(size + 1), false);
  candidate::TokenizeContext new_context(coll, allocator, document.get(), int64_t(size + 1), false);
  charset_lookups = 0;
  const int old_init = old_context.init();
  const uint64_t old_init_lookups = charset_lookups;
  charset_lookups = 0;
  const int new_init = new_context.init();
  if (old_init != OB_SUCCESS || new_init != old_init || old_init_lookups != 2
      || charset_lookups != old_init_lookups || !new_context.utf8_fast_path_) {
    fail("first character did not retain original path", s, size);
  }
  old_context.cursor_ = new_context.cursor_ = 1;
  old_context.next_char_len_ = new_context.next_char_len_ = 91;
  old_context.next_char_type_ = baseline::ObFTCharUtil::CharType::OTHER_CJK;
  new_context.next_char_type_ = candidate::ObFTCharUtil::CharType::OTHER_CJK;
  charset_lookups = 0;
  const int old_ret = old_context.prepare_next_char();
  const uint64_t old_lookups = charset_lookups;
  charset_lookups = 0;
  const int new_ret = new_context.prepare_next_char();
  if (new_ret != old_ret || new_context.next_char_len_ != old_context.next_char_len_
      || int(new_context.next_char_type_) != int(old_context.next_char_type_)) {
    fail("prepare return/length/type differs", s, size);
  }
  if ((n > 0 && charset_lookups != 0) || (n <= 0 && charset_lookups != old_lookups)) {
    fail("fast success or complete fallback lookup path differs", s, size);
  }
  if (surrogate && (old_ret != OB_SUCCESS || old_context.next_char_len_ != 3
      || int(old_context.next_char_type_) != 0)) {
    fail("surrogate must retain success/length3/USELESS", s, size);
  }
  if (size == 0 && (new_ret != OB_UNEXPECT_INTERNAL_ERROR
      || new_context.next_char_len_ != 0 || int(new_context.next_char_type_) != 0)) {
    fail("classification failure did not retain USELESS assignment", s, size);
  }
  if (size != 0 && error != 0 && (new_ret != OB_INVALID_ARGUMENT
      || new_context.next_char_len_ != 91 || int(new_context.next_char_type_) != 4)) {
    fail("validation failure modified cached length/type", s, size);
  }
}

void check_stream(const std::vector<uchar> &input)
{
  char empty = 0;
  const char *s = input.empty() ? &empty : reinterpret_cast<const char *>(input.data());
  for (const auto coll : utf8_collations) {
    baseline::TokenizeContext old_context(coll, allocator, s, int64_t(input.size()), true);
    candidate::TokenizeContext new_context(coll, allocator, s, int64_t(input.size()), true);
    old_context.next_char_type_ = baseline::ObFTCharUtil::CharType::OTHER_CJK;
    new_context.next_char_type_ = candidate::ObFTCharUtil::CharType::OTHER_CJK;
    int old_ret = old_context.init(), new_ret = new_context.init();
    for (size_t step = 0; step <= input.size() + 1; ++step) {
      if (old_ret != new_ret || old_context.cursor_ != new_context.cursor_
          || old_context.next_char_len_ != new_context.next_char_len_
          || int(old_context.next_char_type_) != int(new_context.next_char_type_)
          || old_context.handle_size_ != new_context.handle_size_) {
        fail("init/step stream state differs", input.data(), input.size());
      }
      if (old_ret != OB_SUCCESS) break;
      old_ret = old_context.step_next(); new_ret = new_context.step_next();
      if (step == input.size() + 1) fail("stream did not terminate", input.data(), input.size());
    }
    if (new_ret != OB_SUCCESS && new_context.cursor_ == 0 && new_context.utf8_fast_path_) {
      fail("failed init enabled UTF8 cache", input.data(), input.size());
    }
  }
}

void control_cases()
{
  const char text[] = "AB";
  for (const auto coll : {CS_TYPE_INVALID, CS_TYPE_BINARY, CS_TYPE_GBK_CHINESE_CI,
                          CS_TYPE_UTF16_GENERAL_CI, CS_TYPE_UTF16LE_GENERAL_CI}) {
    baseline::TokenizeContext old_context(coll, allocator, text, 2, false);
    candidate::TokenizeContext new_context(coll, allocator, text, 2, false);
    old_context.next_char_type_ = baseline::ObFTCharUtil::CharType::OTHER_CJK;
    new_context.next_char_type_ = candidate::ObFTCharUtil::CharType::OTHER_CJK;
    const int old_ret = old_context.init(), new_ret = new_context.init();
    if (old_ret != new_ret || new_context.utf8_fast_path_
        || old_context.next_char_len_ != new_context.next_char_len_
        || int(old_context.next_char_type_) != int(new_context.next_char_type_)) {
      fail("non-whitelisted collation or failed init changed", reinterpret_cast<const uchar *>(text), 2);
    }
  }
  for (const auto coll : utf8_collations) {
    candidate::TokenizeContext context(coll, allocator, text, 2, false);
    if (context.init() != OB_SUCCESS) throw std::runtime_error("init failed");
    charset_lookups = 0;
    if (context.init() != OB_SUCCESS || charset_lookups != 2) {
      throw std::runtime_error("repeated init did not use original first-character path");
    }
    candidate::TokenizeContext null_context(coll, allocator, nullptr, 3, false);
    if (null_context.init() != OB_INVALID_ARGUMENT || null_context.utf8_fast_path_) {
      throw std::runtime_error("null input enabled fast path");
    }
  }
  for (const auto cp : {0xff10UL, 0xff19UL, 0xff21UL, 0xff3aUL, 0xff41UL, 0xff5aUL}) {
    candidate::ObFTCharUtil::CharType type;
    candidate::ObFTCharUtil::classify_unicode<CHARSET_UTF8MB4>(cp, type);
    const int expected = cp < 0xff20 ? 1 : 2;
    if (int(type) != expected) throw std::runtime_error("fullwidth classification priority changed");
  }
  candidate::ObFTCharUtil::CharType type;
  candidate::ObFTCharUtil::classify_unicode<CHARSET_UTF16>(0xd800, type);
  if (int(type) != 5) throw std::runtime_error("UTF16 high surrogate classification changed");
  candidate::ObFTCharUtil::classify_unicode<CHARSET_UTF16LE>(0xdfff, type);
  if (int(type) != 6) throw std::runtime_error("UTF16LE low surrogate classification changed");
  candidate::ObFTCharUtil::classify_unicode<CHARSET_UTF8MB4>(0xd800, type);
  if (int(type) != 0) throw std::runtime_error("UTF8 acquired UTF16 surrogate classification");
}
} // namespace

int main(int argc, char **argv)
{
  try {
    const uint64_t requested_random = argc > 1 ? std::stoull(argv[1]) : 250000;
    control_cases();
    std::array<uchar, 8> bytes{};
    check_case(bytes.data(), 0);
    for (uint32_t cp = 0; cp <= 0x10ffff; ++cp) {
      if (cp >= 0xd800 && cp <= 0xdfff) continue;
      const size_t size = encode(cp, bytes);
      check_case(bytes.data(), size, cp); ++scalars;
    }
    for (uint32_t cp = 0xd800; cp <= 0xdfff; ++cp) {
      const size_t size = encode(cp, bytes);
      check_case(bytes.data(), size, cp, true); ++surrogates;
    }
    for (unsigned a = 0; a < 256; ++a) {
      bytes[0] = uchar(a); check_case(bytes.data(), 1); ++one_byte;
      for (unsigned b = 0; b < 256; ++b) {
        bytes[1] = uchar(b); check_case(bytes.data(), 2); ++two_byte;
      }
    }
    for (const unsigned a : {0xdf, 0xe0, 0xe1, 0xec, 0xed, 0xee, 0xef, 0xf0}) {
      bytes[0] = uchar(a);
      for (unsigned b = 0; b < 256; ++b) {
        bytes[1] = uchar(b);
        for (unsigned c = 0; c < 256; ++c) {
          bytes[2] = uchar(c); check_case(bytes.data(), 3); ++boundary3;
        }
      }
    }
    const std::array<unsigned, 10> tails{0x00, 0x7f, 0x80, 0x8f, 0x90, 0x9f, 0xa0, 0xbf, 0xc0, 0xff};
    for (const unsigned a : {0xf0, 0xf1, 0xf3, 0xf4, 0xf5, 0xf7, 0xf8, 0xff}) {
      bytes[0] = uchar(a);
      for (unsigned b = 0; b < 256; ++b) {
        bytes[1] = uchar(b);
        for (const unsigned c : tails) {
          bytes[2] = uchar(c);
          check_case(bytes.data(), 3); ++truncations;
          for (const unsigned d : tails) {
            bytes[3] = uchar(d); check_case(bytes.data(), 4); ++boundary4;
          }
        }
      }
    }
    std::mt19937_64 random(0x526f756e643130ULL);
    for (uint64_t index = 0; index < requested_random; ++index) {
      const size_t size = size_t(random() % 9);
      for (size_t j = 0; j < size; ++j) bytes[j] = uchar(random());
      check_case(bytes.data(), size); ++random_count;
      // A canonical first character followed by arbitrary (possibly invalid)
      // bytes proves that the fast decoder does not validate the whole suffix.
      uint32_t cp = uint32_t(random() % 0x110000);
      if (cp >= 0xd800 && cp <= 0xdfff) cp = 0xfffd;
      const size_t prefix = encode(cp, bytes);
      const size_t suffix = size_t(random() % 5);
      for (size_t j = 0; j < suffix; ++j) bytes[prefix + j] = uchar(random());
      check_case(bytes.data(), prefix + suffix, cp); ++random_count;
      if (index < 2000) check_stream(std::vector<uchar>(bytes.begin(), bytes.begin() + prefix + suffix));
    }
    const std::vector<std::vector<uchar>> streams{
        {}, {'A', 'B', ' ', '9', 0, 'Z'},
        {0xed, 0xa0, 0x80, 'A'}, {'A', 0xed, 0xbf, 0xbf, 'B'},
        {'A', 0xe4, 0xb8, 0xad, 'B', 0xf4, 0x8f, 0xbf, 0xbf},
        {'A', 0xe0, 0x80, 0x80}, {'A', 0xf4, 0x90, 0x80, 0x80},
        {'A', 0xf0, 0x90, 0x80}, {'A', 0xff}};
    for (const auto &stream : streams) {
      check_stream(stream);
    }
    std::cout << "PASS cases=" << cases << " positive=" << positive << " zero=" << zero
              << " negative=" << negative << " scalar=" << scalars << " surrogate=" << surrogates
              << " all1=" << one_byte << " all2=" << two_byte << " boundary3=" << boundary3
              << " boundary4=" << boundary4 << " truncation3=" << truncations
              << " random=" << random_count << "\n";
    return 0;
  } catch (const std::exception &error) {
    std::cerr << "FAIL " << error.what() << "\n";
    return 1;
  }
}
