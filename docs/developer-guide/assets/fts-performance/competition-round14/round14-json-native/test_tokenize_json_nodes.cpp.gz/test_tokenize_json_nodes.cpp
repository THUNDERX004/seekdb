/* Copyright (c) 2025 OceanBase. Licensed under the Apache License, Version 2.0. */
// Link this TU with the completed, selected production build. No builder,
// allocator-page, JSON printer, or binary-serialization algorithm is copied.
#include <algorithm>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <limits>
#include <stdexcept>
#include <string>
#include <vector>

#include "lib/allocator/ob_allocator.h"
#include "common/json_type/ob_json_bin.h"
#include "common/json_type/ob_json_tree.h"
#include "storage/fts/ob_fts_parser_helper.h"

using namespace oceanbase;
using namespace oceanbase::common;
using namespace oceanbase::storage;


namespace {
std::string context;
int64_t checks = 0;
int64_t successes = 0;
int64_t failure_cases = 0;
int64_t swept_blocks = 0;

void require(const bool ok, const char *message)
{
  ++checks;
  if (!ok) { throw std::runtime_error(context + ": " + message); }
}

// Arena semantics, with real exact-base free validation. Freed blocks stay
// quarantined/poisoned until reset so stale pointers cannot become valid again.
// The tracking metadata uses the CRT and is outside the injected allocator.
class TrackingAllocator final : public ObIAllocator
{
  struct Block { unsigned char *raw; int64_t size; bool freed; };
  static constexpr int64_t GUARD = 32;
  static constexpr int64_t MAX_CALLS = 16384;
  static constexpr int64_t MAX_BYTES = 64 * 1024 * 1024;
public:
  explicit TrackingAllocator(const int64_t fail_at = 0) : fail_at_(fail_at) {}
  ~TrackingAllocator() override { release(); }
  void *alloc(const int64_t size) override
  {
    ++calls_;
    if (calls_ == fail_at_) { ++injected_; return nullptr; }
    if (size <= 0 || calls_ > MAX_CALLS || size > MAX_BYTES - owned_) {
      bad_ = true; return nullptr;
    }
    auto *raw = static_cast<unsigned char *>(std::malloc(static_cast<size_t>(size + 2 * GUARD)));
    if (raw == nullptr) { bad_ = true; return nullptr; }
    std::memset(raw, 0xa5, static_cast<size_t>(size + 2 * GUARD));
    std::memset(raw + GUARD, 0xcc, static_cast<size_t>(size));
    blocks_.push_back({raw, size, false});
    owned_ += size;
    live_bytes_ += size;
    ++live_;
    return raw + GUARD;
  }
  void *alloc(const int64_t size, const ObMemAttr &) override { return alloc(size); }
  void free(void *ptr) override
  {
    if (ptr == nullptr) { return; }
    for (auto &block : blocks_) {
      if (ptr == block.raw + GUARD) {
        if (block.freed) { ++double_frees_; bad_ = true; return; }
        if (!guards_ok(block)) { bad_ = true; }
        block.freed = true;
        --live_;
        live_bytes_ -= block.size;
        ++frees_;
        std::memset(ptr, 0xdd, static_cast<size_t>(block.size));
        return;
      }
    }
    // Includes interior batch-node pointers and unrelated allocations.
    ++nonbase_frees_;
    bad_ = true;
  }
  void *realloc(const void *, const int64_t, const ObMemAttr &) override
  { ++unexpected_reallocs_; bad_ = true; return nullptr; }
  void *realloc(void *, const int64_t, const int64_t) override
  { ++unexpected_reallocs_; bad_ = true; return nullptr; }
  int64_t total() const override { return owned_; }
  int64_t used() const override { return live_bytes_; }
  bool contains_live(const void *ptr, const size_t length) const
  {
    const auto addr = reinterpret_cast<uintptr_t>(ptr);
    for (const auto &block : blocks_) {
      const auto begin = reinterpret_cast<uintptr_t>(block.raw + GUARD);
      if (!block.freed && addr >= begin && length <= static_cast<size_t>(block.size)
          && addr - begin <= static_cast<size_t>(block.size) - length) { return true; }
    }
    return false;
  }
  void check() const
  {
    require(!bad_ && double_frees_ == 0 && nonbase_frees_ == 0 && unexpected_reallocs_ == 0,
            "allocator failure, non-base/double free, or unexpected realloc");
    for (const auto &block : blocks_) {
      require(guards_ok(block), "allocator red-zone damaged");
      if (block.freed) {
        const auto *data = block.raw + GUARD;
        require(std::all_of(data, data + block.size, [](unsigned char c) { return c == 0xdd; }),
                "write after free detected in quarantined block");
      }
    }
  }
  void finish_arena()
  {
    check();
    swept_blocks += live_;
    release();
    require(live_ == 0 && used() == 0 && total() == 0, "arena reset left owned memory");
  }
  int64_t calls() const { return calls_; }
  int64_t injected() const { return injected_; }
  int64_t frees() const { return frees_; }
  int64_t live() const { return live_; }
private:
  static bool guards_ok(const Block &block)
  {
    for (int64_t i = 0; i < GUARD; ++i) {
      if (block.raw[i] != 0xa5 || block.raw[GUARD + block.size + i] != 0xa5) { return false; }
    }
    return true;
  }
  void release()
  {
    for (const auto &block : blocks_) { std::free(block.raw); }
    blocks_.clear(); owned_ = 0; live_ = 0; live_bytes_ = 0;
  }
  std::vector<Block> blocks_;
  int64_t fail_at_ = 0;
  int64_t calls_ = 0;
  int64_t injected_ = 0;
  int64_t frees_ = 0;
  int64_t live_ = 0;
  int64_t owned_ = 0;
  int64_t live_bytes_ = 0;
  int64_t double_frees_ = 0;
  int64_t nonbase_frees_ = 0;
  int64_t unexpected_reallocs_ = 0;
  bool bad_ = false;
};

struct Entry { std::string key; int64_t count; bool null_ptr = false; };
using Entries = std::vector<Entry>;

std::string bytes(const ObString &value)
{
  return value.length() == 0 ? std::string() : std::string(value.ptr(), value.length());
}

Entries entries(const int64_t count, const bool mixed)
{
  const std::vector<std::string> special = {
    std::string("a\0b\0", 4), "\"\\/\b\f\n\r\t", "",
    "\xe4\xb8\xad\xe6\x96\x87", "\xf0\x9f\x98\x80\xf0\xa0\x80\x80",
    "caf\xc3\xa9", "e\xcc\x81", "null", std::string("\x01\x1f", 2),
    std::string("\0", 1), "trailing ", "doc_len", "tokens"
  };
  const int64_t counts[] = {1, 2, 127, 128, 32767, 32768, 2147483647LL,
                           4294967297LL, 1099511627783LL};
  Entries result;
  result.reserve(static_cast<size_t>(count));
  for (int64_t i = 0; i < count; ++i) {
    result.push_back({mixed && i < static_cast<int64_t>(special.size())
                     ? special[static_cast<size_t>(i)] : "token_" + std::to_string(i),
                     counts[i % (sizeof(counts) / sizeof(counts[0]))], false});
  }
  return result;
}

class InputMap final
{
public:
  explicit InputMap(const Entries &input) : input_(input)
  {
    require(words_.create(2053, "JsonNodesR14", "JsonNodesR14") == OB_SUCCESS, "map create");
    ObObjMeta meta;
    meta.set_varchar();
    meta.set_collation_type(CS_TYPE_BINARY); // Byte-distinct keys including U+0000.
    for (const auto &entry : input_) {
      require(!entry.null_ptr || entry.key.empty(), "null pointer must have zero length");
      const ObFTWord key(entry.key.size(), entry.null_ptr ? nullptr : entry.key.data(), meta);
      require(words_.set_refactored(key, entry.count) == OB_SUCCESS, "map insert");
      require(entry.count >= 0 && doc_length_ <= INT64_MAX - entry.count, "document count overflow");
      doc_length_ += entry.count;
    }
    require(words_.size() == static_cast<int64_t>(input_.size()), "unique cardinality changed");
    for (auto it = words_.begin(); it != words_.end(); ++it) {
      expected_.push_back({bytes(it->first.get_word().get_string()), it->second, false});
    }
  }
  ~InputMap() { words_.destroy(); }
  const ObFTWordMap &words() const { return words_; }
  const Entries &expected() const { return expected_; }
  int64_t doc_length() const { return doc_length_; }
private:
  // Key backing bytes must stay valid for the map and the returned JSON tree.
  Entries input_;
  ObFTWordMap words_;
  Entries expected_;
  int64_t doc_length_ = 0;
};

// This frame and the real helper are gone before any validation/serialization.
// No private-field access and no parser global startup are needed.
int build_once(TrackingAllocator &allocator, const InputMap &input,
               const bool detail, ObIJsonBase *&output)
{
  ObFTParser parser;
  require(parser.init(ObString::make_string("space")) == OB_SUCCESS, "parser init");
  ObFTParserProperty property;
  ObFTParseHelper helper;
  require(helper.init(&allocator, parser, property) == OB_SUCCESS, "helper fast init");
  require(allocator.calls() == 0, "setup allocated through builder allocator");
  return detail ? helper.make_detail_json(input.words(), input.doc_length(), output)
                : helper.make_token_array_json(input.words(), output);
}

__declspec(noinline) void overwrite_stack()
{
  volatile unsigned char scratch[8192];
  for (size_t i = 0; i < sizeof(scratch); ++i) { scratch[i] = static_cast<unsigned char>(i); }
}

void check_tree(ObIJsonBase *root, const InputMap &input, const bool detail,
                const TrackingAllocator &allocator)
{
  require(root != nullptr && allocator.contains_live(root, sizeof(ObJsonNode)), "root not live");
  require(static_cast<ObJsonNode *>(root)->get_parent() == nullptr, "root parent");
  ObIJsonBase *array = root;
  if (detail) {
    require(root->json_type() == ObJsonNodeType::J_OBJECT && root->element_count() == 2, "detail root");
    ObIJsonBase *length = nullptr;
    require(root->get_object_value(ObString::make_string("doc_len"), length) == OB_SUCCESS,
            "doc_len lookup");
    require(length != nullptr && allocator.contains_live(length, sizeof(ObJsonInt)), "doc_len not live");
    require(length->json_type() == ObJsonNodeType::J_INT && length->get_int() == input.doc_length(),
            "doc_len count/type");
    require(static_cast<ObJsonNode *>(length)->get_parent() == root, "doc_len parent");
    require(root->get_object_value(ObString::make_string("tokens"), array) == OB_SUCCESS,
            "tokens lookup");
    require(array != nullptr && allocator.contains_live(array, sizeof(ObJsonArray)), "array not live");
    require(static_cast<ObJsonNode *>(array)->get_parent() == root, "tokens parent");
  }
  require(array->json_type() == ObJsonNodeType::J_ARRAY
          && array->element_count() == input.expected().size(), "array size/type");
  for (size_t i = 0; i < input.expected().size(); ++i) {
    ObIJsonBase *node = nullptr;
    require(array->get_array_element(i, node) == OB_SUCCESS && node != nullptr, "array element");
    require(allocator.contains_live(node, sizeof(ObJsonNode)), "element storage not live after return");
    require(static_cast<ObJsonNode *>(node)->get_parent() == array, "element parent");
    const Entry &expected = input.expected()[i];
    if (detail) {
      require(node->json_type() == ObJsonNodeType::J_OBJECT && node->element_count() == 1, "token object");
      ObString key;
      ObIJsonBase *value = nullptr;
      require(node->get_object_value(static_cast<uint64_t>(0), key, value) == OB_SUCCESS,
              "token key/value");
      require(bytes(key) == expected.key, "complete key bytes/order");
      require(value != nullptr && allocator.contains_live(value, sizeof(ObJsonInt)), "count storage not live");
      require(value->json_type() == ObJsonNodeType::J_INT && value->get_int() == expected.count,
              "token count/type");
      require(static_cast<ObJsonNode *>(value)->get_parent() == node, "count parent");
    } else {
      require(node->json_type() == ObJsonNodeType::J_STRING, "token string type");
      require(bytes(static_cast<ObJsonString *>(node)->value()) == expected.key, "complete string bytes/order");
    }
  }
}

struct Serialized { std::string print; std::string binary; };
Serialized serialize_after_return(ObIJsonBase *root)
{
  // Serialization has an independent allocator and is never failure-injected.
  ObArenaAllocator arena;
  ObJsonBuffer printed(&arena);
  require(root->print(printed, true, 0, false, 0) == OB_SUCCESS, "real JSON print");
  ObString raw;
  require(root->get_raw_binary(raw, &arena) == OB_SUCCESS, "real JSON binary serialization");
  Serialized result{std::string(printed.ptr(), printed.length()), bytes(raw)};
  require(!result.binary.empty() && !result.print.empty(), "serialization empty");
  // Independently consume the binary using the real binary reader/printer.
  ObJsonBin binary(raw.ptr(), raw.length(), &arena);
  require(binary.reset_iter() == OB_SUCCESS, "binary reset_iter");
  ObJsonBuffer reprinted(&arena);
  require(binary.print(reprinted, true, 0, false, 0) == OB_SUCCESS, "binary JSON print");
  require(result.print == std::string(reprinted.ptr(), reprinted.length()), "binary round-trip print");
  return result;
}

void print_hex(const std::string &value)
{
  static const char digits[] = "0123456789abcdef";
  for (const unsigned char c : value) { std::putchar(digits[c >> 4]); std::putchar(digits[c & 15]); }
}

int64_t success_case(const std::string &id, const InputMap &input, const bool detail)
{
  context = id;
  TrackingAllocator allocator;
  ObJsonInt sentinel(-7654321);
  ObIJsonBase *root = &sentinel;
  const int ret = build_once(allocator, input, detail, root);
  require(ret == OB_SUCCESS && root != &sentinel, "builder success/output");
  const int64_t allocations = allocator.calls();
  require(allocations > 0 && allocator.injected() == 0, "success allocation accounting");
  overwrite_stack();
  allocator.check();
  check_tree(root, input, detail, allocator);
  const Serialized first = serialize_after_return(root);
  overwrite_stack();
  const Serialized second = serialize_after_return(root);
  require(first.print == second.print && first.binary == second.binary, "repeated complete serialization");
  require(allocator.calls() == allocations, "serialization allocated through builder allocator");
  check_tree(root, input, detail, allocator);
  allocator.check();
  // This record contains every output byte, not a hash/count-only assertion.
  std::printf("RESULT\t%s\t", id.c_str());
  print_hex(first.print); std::putchar('\t'); print_hex(first.binary); std::putchar('\n');
  std::printf("SUCCESS\t%s\tallocations=%lld\tfree_calls=%lld\tlive_before_reset=%lld\n",
              id.c_str(), static_cast<long long>(allocations), static_cast<long long>(allocator.frees()),
              static_cast<long long>(allocator.live()));
  allocator.finish_arena();
  ++successes;
  return allocations;
}

void fail_allocations(const std::string &id, const InputMap &input, const bool detail,
                      const int64_t observed_allocations, const bool strict_cleanup)
{
  require(observed_allocations > 0 && observed_allocations <= 16384, "failure sweep bound");
  for (int64_t ordinal = 1; ordinal <= observed_allocations; ++ordinal) {
    context = id + "/fail_" + std::to_string(ordinal);
    TrackingAllocator allocator(ordinal);
    ObJsonInt sentinel(-7654321);
    ObIJsonBase *output = &sentinel;
    const int ret = build_once(allocator, input, detail, output);
    require(allocator.injected() == 1, "requested builder allocation was not reached");
    require(ret == OB_ALLOCATE_MEMORY_FAILED, "failure did not return allocation error");
    require(output == &sentinel && sentinel.value() == -7654321 && sentinel.get_parent() == nullptr,
            "error changed output/sentinel");
    allocator.check();
    const int64_t residual = allocator.live();
    if (strict_cleanup) { require(residual == 0, "candidate error path left live builder allocations"); }
    std::printf("FAILPOINT\t%s\tordinal=%lld\tret=%d\tallocations=%lld\tfree_calls=%lld"
                "\tlive_before_reset=%lld\tunchanged=1\n", id.c_str(),
                static_cast<long long>(ordinal), ret, static_cast<long long>(allocator.calls()),
                static_cast<long long>(allocator.frees()), static_cast<long long>(residual));
    allocator.finish_arena();
    ++failure_cases;
  }
}
} // namespace

int main(const int argc, char **argv)
{
  const bool strict = argc == 2 && std::strcmp(argv[1], "--require-empty-on-error") == 0;
  if (argc != 1 && !strict) {
    std::fprintf(stderr, "Usage: test_tokenize_json_nodes.exe [--require-empty-on-error]\n");
    return 2;
  }
  try {
    for (const bool mixed : {false, true}) {
      for (const int64_t count : {0, 1, 2, 31, 257, 1025}) {
        const InputMap input(entries(count, mixed));
        for (const bool detail : {false, true}) {
          const std::string id = std::string(mixed ? "mixed" : "ascii") + "/U" + std::to_string(count)
                                 + (detail ? "/all" : "/default");
          const int64_t allocations = success_case(id, input, detail);
          if (count == 1 || count == 2 || count == 31) {
            fail_allocations(id, input, detail, allocations, strict);
          }
        }
      }
    }
    // Zero-length nullptr-backed key differs from an embedded U+0000 key.
    // This directly tests builder behavior; real tokenizers need not emit it.
    for (const bool null_ptr : {false, true}) {
      const InputMap input(Entries{{"", INT64_MAX, null_ptr}});
      for (const bool detail : {false, true}) {
        const std::string id = std::string(null_ptr ? "null_pointer_key" : "empty_key")
                               + (detail ? "/all" : "/default");
        const int64_t allocations = success_case(id, input, detail);
        fail_allocations(id, input, detail, allocations, strict);
      }
    }
    std::printf("PASS\tsuccess_cases=%lld\tfailure_cases=%lld\tchecks=%lld\tarena_swept_blocks=%lld"
                "\tstrict_error_cleanup=%d\n", static_cast<long long>(successes),
                static_cast<long long>(failure_cases), static_cast<long long>(checks),
                static_cast<long long>(swept_blocks), strict ? 1 : 0);
    if (std::fflush(stdout) != 0 || std::ferror(stdout)) { return 1; }
    return 0;
  } catch (const std::exception &error) {
    std::fprintf(stderr, "FAIL %s\n", error.what());
    return 1;
  }
}
