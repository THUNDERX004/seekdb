param(
    [string]$SourceRoot = 'D:/Projects/OceanBase/seekdb',
    [Parameter(Mandatory = $true)][string]$OutputDir,
    [Parameter(Mandatory = $true)][ValidateSet('original', 'candidate')][string]$Variant,
    [string]$BuildDir,
    [string]$Python = 'python.exe',
    [switch]$Capture,
    [switch]$Build
)
$ErrorActionPreference = 'Stop'
if ($Capture -and $Build) { throw '-Capture is plan-only.' }
$env:PYTHONUTF8 = '1'
if ($Build) {
    $jsonVs = 'C:\Program Files\Microsoft Visual Studio\2022\BuildTools'
    Import-Module (Join-Path $jsonVs 'Common7\Tools\Microsoft.VisualStudio.DevShell.dll')
    Enter-VsDevShell -VsInstallPath $jsonVs -SkipAutomaticLocation `
        -DevCmdArguments '-arch=amd64 -host_arch=amd64 -vcvars_ver=14.44 -winsdk=10.0.26100.0'
}
$jsonArgs = @(
    (Join-Path $PSScriptRoot 'prepare_tokenize_json_nodes.py'),
    '--source-root', $SourceRoot, '--output-dir', $OutputDir, '--variant', $Variant
)
if ($BuildDir) { $jsonArgs += @('--build-dir', $BuildDir) }
if ($Capture) { $jsonArgs += '--capture' }
if ($Build) { $jsonArgs += '--build' }
& $Python @jsonArgs
exit $LASTEXITCODE
