"""Explicit parent-only native checks and optional independent full-byte comparison.

No build, SQL, database startup, timing, benchmark, or candidate auto-recording.
Original and candidate allocation ordinals are intentionally NOT cross-matched.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

HERE = Path(__file__).resolve().parent
MAX_LOG = 32 * 1024 * 1024


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def fields(tokens):
    result = {}
    for token in tokens:
        key, sep, value = token.partition("=")
        require(sep and key not in result and re.fullmatch(r"-?\d+", value), "Invalid count field")
        result[key] = int(value)
    return result


def expected_ids():
    result = {f"{profile}/U{count}/{mode}" for profile in ("ascii", "mixed")
              for count in (0, 1, 2, 31, 257, 1025) for mode in ("all", "default")}
    result |= {f"{profile}/{mode}" for profile in ("empty_key", "null_pointer_key")
               for mode in ("all", "default")}
    return result


def needs_failpoints(case_id):
    return (case_id.startswith(("empty_key/", "null_pointer_key/"))
            or any(f"/U{count}/" in case_id for count in (1, 2, 31)))


def parse_log(path, strict):
    require(path.stat().st_size <= MAX_LOG, "Native output exceeded bounded log size")
    results, successes, failpoints, summary = {}, {}, {}, None
    for line in path.read_bytes().splitlines():
        # Production logging remains preserved verbatim in stdout/stderr logs.
        if not line.startswith((b"RESULT\t", b"SUCCESS\t", b"FAILPOINT\t", b"PASS\t")):
            continue
        tokens = line.decode("ascii").split("\t")
        kind = tokens[0]
        if kind == "RESULT":
            require(len(tokens) == 4 and tokens[1] not in results, "Invalid/duplicate complete output record")
            require(all(re.fullmatch(r"(?:[0-9a-f]{2})+", value) for value in tokens[2:]), "Invalid hex record")
            printed, binary = bytes.fromhex(tokens[2]), bytes.fromhex(tokens[3])
            # This is a second structural check, independent of the native tree checks.
            decoded = json.loads(printed.decode("utf-8"))
            require(isinstance(decoded, dict if tokens[1].endswith("/all") else list), "Wrong JSON shape")
            results[tokens[1]] = {"print_hex": printed.hex(), "binary_hex": binary.hex()}
        elif kind == "SUCCESS":
            require(tokens[1] not in successes, "Duplicate success record")
            successes[tokens[1]] = fields(tokens[2:])
        elif kind == "FAILPOINT":
            record = fields(tokens[2:])
            require(record["ordinal"] not in failpoints.setdefault(tokens[1], {}), "Duplicate failpoint")
            failpoints[tokens[1]][record["ordinal"]] = record
        else:
            require(summary is None, "Duplicate PASS")
            summary = fields(tokens[1:])
    require(set(results) == expected_ids() and set(successes) == expected_ids(), "Incomplete success corpus")
    require(summary and summary["success_cases"] == len(results), "Missing/incorrect PASS success count")
    expected_sweeps = {case_id for case_id in results if needs_failpoints(case_id)}
    require(set(failpoints) == expected_sweeps, "Missing/extra failpoint sweep")
    errors = set()
    for case_id, sweep in failpoints.items():
        count = successes[case_id]["allocations"]
        require(0 < count <= 16384 and set(sweep) == set(range(1, count + 1)),
                "Every observed allocation ordinal must fail in THIS build: " + case_id)
        for record in sweep.values():
            errors.add(record["ret"])
            require(record["ret"] < 0 and record["unchanged"] == 1, "Bad failpoint error/sentinel")
            require(record["allocations"] >= record["ordinal"], "Unreached failpoint")
            if strict:
                require(record["live_before_reset"] == 0, "Candidate cleanup left a live allocation")
    require(len(errors) == 1, "Allocation failure error code changed within run")
    require(summary["failure_cases"] == sum(len(sweep) for sweep in failpoints.values()), "Failure summary mismatch")
    require(summary["strict_error_cleanup"] == int(strict), "Strict cleanup mode mismatch")
    return results, {"success": successes, "failpoints": failpoints, "summary": summary,
                     "allocation_error": next(iter(errors))}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--build-output", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path, help="New child directory of this helper")
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--check-only", action="store_true",
                      help="Candidate invariants/failpoints only; native original byte comparison remains pending")
    mode.add_argument("--record-original", type=Path, help="New immutable original-fixture path under helper")
    mode.add_argument("--compare", type=Path, help="Previously recorded independent ORIGINAL fixture")
    parser.add_argument("--build-evidence", type=Path, required=True,
                        help="Parent's existing completed-build provenance JSON, copied/hash-recorded verbatim")
    parser.add_argument("--execute", action="store_true", help="Explicitly execute native helper only")
    parser.add_argument("--timeout", type=int, default=180)
    args = parser.parse_args()
    require(args.execute, "Execution is parent-controlled; pass --execute explicitly when serial host is idle")
    require(1 <= args.timeout <= 600, "Timeout must be 1..600 seconds")
    build = args.build_output.resolve()
    output = args.output_dir.resolve()
    require(build.is_relative_to(HERE) and build != HERE, "Build output must be under helper")
    require(output.is_relative_to(HERE) and output != HERE and not output.exists(), "Use a new helper-owned run directory")
    require(not output.is_relative_to(build) and not build.is_relative_to(output), "Keep build and run directories separate")
    receipt_path = build / "receipt.json"
    receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
    strict = args.record_original is None
    variant = "candidate" if strict else "original"
    require(receipt.get("variant") == variant and receipt.get("build_succeeded"), "Wrong/incomplete build receipt")
    executable = build / "test_tokenize_json_nodes.exe"
    require(sha(executable) == receipt["executable_sha256"], "Native executable hash mismatch")
    require(sha(HERE / "test_tokenize_json_nodes.cpp") == receipt["test_sha256"], "Test source drifted")
    for dll in receipt["runtime_dlls"]:
        require(sha(build / dll["name"]) == dll["sha256"], "Native DLL drifted")
    evidence = args.build_evidence.resolve()
    evidence_bytes = evidence.read_bytes()
    require(isinstance(json.loads(evidence_bytes), dict), "Build evidence must be a JSON object")
    fixture_path = None
    if not args.check_only:
        fixture_path = (args.compare or args.record_original).resolve()
        require(fixture_path.is_relative_to(HERE) and fixture_path != HERE, "Fixture must be under helper")
        require(not fixture_path.is_relative_to(output), "Keep fixture independent of run output")
    if args.compare:
        original_bytes = fixture_path.read_bytes()
        original_hash = hashlib.sha256(original_bytes).hexdigest()
        original = json.loads(original_bytes)
        require(original.get("role") == "independent-original-recording" and original.get("native_exit_code") == 0,
                "Comparison requires a successful independent original recording")
        require(original["test_sha256"] == receipt["test_sha256"], "Original/candidate test source differs")
        require(original["settings_sha256"] == receipt["settings_sha256"], "Original/candidate captured configuration differs")
        require(set(original["results"]) == expected_ids(), "Original fixture corpus incomplete")
    elif args.record_original:
        require(not fixture_path.exists(), "Original fixture exists; refusing overwrite")
        require(fixture_path.parent.is_dir(), "Create the fixture parent explicitly")
    output.mkdir()
    (output / "build-evidence.json").write_bytes(evidence_bytes)
    (output / "build-receipt.json").write_bytes(receipt_path.read_bytes())
    command = [str(executable)] + (["--require-empty-on-error"] if strict else [])
    run = {"role": variant, "command": command, "cwd": str(output),
           "run_mode": "candidate-invariants" if args.check_only else
                       "native-full-byte-differential" if args.compare else "original-recording",
           "executable_sha256": sha(executable), "build_receipt_sha256": sha(receipt_path),
           "parent_build_evidence_sha256": sha(output / "build-evidence.json"),
           "test_sha256": receipt["test_sha256"], "settings_sha256": receipt["settings_sha256"],
           "native": "PENDING", "output_validation": "PENDING", "sql": "NOT RUN", "performance": "NOT RUN"}
    write_json(output / "run.json", run)
    environment = os.environ.copy()
    temporary = output / "tmp"
    temporary.mkdir()
    environment["TMP"] = environment["TEMP"] = str(temporary)
    environment["PATH"] = str(build) + os.pathsep + environment.get("PATH", "")
    try:
        with (output / "stdout.log").open("wb") as stdout, (output / "stderr.log").open("wb") as stderr:
            completed = subprocess.run(command, cwd=output, env=environment, stdout=stdout, stderr=stderr,
                                       timeout=args.timeout)
        run["native_exit_code"] = completed.returncode
        run["native"] = "PASS" if completed.returncode == 0 else "FAIL"
    except subprocess.TimeoutExpired:
        run["native"] = "TIMEOUT"
        write_json(output / "run.json", run)
        raise RuntimeError("Native helper timed out; logs preserved")
    run["log_sha256"] = {name: sha(output / name) for name in ("stdout.log", "stderr.log")}
    write_json(output / "run.json", run)
    require(completed.returncode == 0, "Native helper failed; logs preserved")
    results, accounting = parse_log(output / "stdout.log", strict)
    run["output_validation"] = "PASS"
    write_json(output / "run.json", run)
    write_json(output / "allocation-accounting.json", accounting)
    serialized = output / "serialized"
    serialized.mkdir()
    for case_id, result in results.items():
        name = case_id.replace("/", "__")
        (serialized / (name + ".print.json")).write_bytes(bytes.fromhex(result["print_hex"]))
        (serialized / (name + ".bin")).write_bytes(bytes.fromhex(result["binary_hex"]))
    # Compare byte-for-byte, including order, whitespace, escaped bytes, and
    # complete binary representation. Nothing is sorted or normalized here.
    if args.compare:
        require(sha(fixture_path) == original_hash, "Original fixture changed during candidate execution")
        mismatches = [case_id for case_id in expected_ids() if results[case_id] != original["results"][case_id]]
        require(accounting["allocation_error"] == original["allocation_error"], "Allocation failure error differs")
        run["original_fixture_sha256"] = original_hash
        run["comparison"] = {"equal": not mismatches, "mismatches": sorted(mismatches), "cases": len(results),
                             "compared": "every print and binary byte; allocation ordinals checked within each build only"}
        write_json(output / "run.json", run)
        require(not mismatches, "Complete original/candidate output differs: " + ", ".join(sorted(mismatches)))
    elif args.record_original:
        fixture = {"schema_version": 1, "role": "independent-original-recording", "native_exit_code": 0,
                   "test_sha256": receipt["test_sha256"], "settings_sha256": receipt["settings_sha256"],
                   "executable_sha256": receipt["executable_sha256"], "build_receipt_sha256": sha(receipt_path),
                   "parent_build_evidence_sha256": sha(output / "build-evidence.json"),
                   "stdout_sha256": sha(output / "stdout.log"), "stderr_sha256": sha(output / "stderr.log"),
                   "allocation_error": accounting["allocation_error"], "results": results}
        with fixture_path.open("x", encoding="utf-8") as stream:
            json.dump(fixture, stream, ensure_ascii=False, indent=2)
            stream.write("\n")
        run["original_fixture_sha256"] = sha(fixture_path)
        write_json(output / "run.json", run)
    else:
        run["comparison"] = {
            "status": "PENDING", "native_original_available": False,
            "reason": "Candidate-only checks requested; no native original fixture was used or generated.",
            "complete_output_saved": True, "cases": len(results),
        }
        write_json(output / "run.json", run)
    print("PASS", variant, "success_cases=", len(results), "failure_cases=", accounting["summary"]["failure_cases"],
          "complete_bytes=", "compared" if args.compare else "saved; native differential PENDING"
          if args.check_only else "original recorded", "evidence=", output / "run.json")


if __name__ == "__main__":
    try:
        main()
    except (RuntimeError, OSError, ValueError, KeyError) as error:
        print("ERROR:", error, file=sys.stderr)
        sys.exit(1)
