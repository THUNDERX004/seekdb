"""Prepare native response files; compile/link only with explicit --build.

Reads an existing completed seekdb build, replaces only the main object, and
never builds seekdb, edits its checkout, runs a native test, or invokes SQL.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = Path(r"D:\Projects\OceanBase\seekdb")
PROPOSAL = HERE.parent / "round14-tokenize-proposal"
MAIN_OBJ = "src/observer/CMakeFiles/ob_main.dir/main.cpp.obj"
SOURCE_RELS = ("src/storage/fts/ob_fts_parser_helper.cpp",
               "src/oblib/common/json_type/ob_json_tree.h")
CONTEXT_RELS = (
    "src/data_plane/api/data_plane/fts/ob_fts_parser_helper.h",
    "src/data_plane/api/data_plane/fts/ob_fts_struct.h",
    "src/storage/fts/ob_fts_parser_helper.h",
    "src/storage/fts/ob_fts_struct.cpp",
    "src/oblib/common/json_type/ob_json_base.h",
    "src/oblib/common/json_type/ob_json_bin.h",
    "src/oblib/common/json_type/ob_json_tree.cpp",
    "src/oblib/common/json_type/ob_json_base.cpp",
    "src/oblib/common/json_type/ob_json_bin.cpp",
    "src/oblib/lib/alloc/ob_iallocator.h",
    "src/oblib/lib/container/ob_vector.ipp",
)


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def json_write(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def windows_args(command):
    """Decode MS CRT quoting without a shell (same infrastructure as round12)."""
    result, index = [], 0
    while index < len(command):
        while index < len(command) and command[index] in " \t\r\n":
            index += 1
        if index == len(command):
            break
        arg, quoted = [], False
        while index < len(command):
            if command[index] in " \t\r\n" and not quoted:
                break
            slashes = 0
            while index < len(command) and command[index] == "\\":
                slashes += 1
                index += 1
            if index < len(command) and command[index] == '"':
                arg.append("\\" * (slashes // 2))
                if slashes % 2:
                    arg.append('"')
                elif quoted and index + 1 < len(command) and command[index + 1] == '"':
                    arg.append('"')
                    index += 1
                else:
                    quoted = not quoted
                index += 1
            else:
                arg.append("\\" * slashes)
                if index < len(command) and command[index] in " \t\r\n" and not quoted:
                    break
                if index < len(command):
                    arg.append(command[index])
                    index += 1
        require(not quoted, "Unterminated command quote")
        result.append("".join(arg))
    return result


def response_write(path, args):
    encoded = subprocess.list2cmdline(args)
    require(windows_args(encoded) == args, "Response-file quote round trip failed")
    path.write_text(encoded + "\n", encoding="utf-8")


def ninja_expand(value, variables):
    def replace(match):
        key = match.group(1)
        if key in ("$", " ", ":"):
            return key
        key = key[1:-1] if key.startswith("{") else key
        require(key in variables, "Unsupported Ninja variable: " + key)
        return variables[key]
    return re.sub(r"\$(\$| |:|\{[^}]+\}|[A-Za-z_][A-Za-z_0-9]*)", replace, value)


def ninja_blocks(path):
    lines = path.read_text(encoding="utf-8").splitlines()
    require(not any(line.endswith("$") for line in lines), "Ninja continuation needs deliberate adaptation")
    blocks = []
    for index, line in enumerate(lines):
        if line.startswith(("build ", "rule ")):
            variables = {}
            for following in lines[index + 1:]:
                if not following.startswith("  "):
                    break
                key, sep, value = following.strip().partition(" = ")
                require(bool(sep), "Unsupported Ninja binding")
                variables[key] = value
            blocks.append((line, variables))
    return blocks


def extract_records(build_dir):
    commands = json.loads((build_dir / "compile_commands.json").read_text(encoding="utf-8"))
    units = [item for item in commands
             if "/ob_storage.dir/" in item.get("output", "").replace("\\", "/")
             and Path(item["file"]).name == "unity_ob_storage_ob_storage_fts_0_c___cxx.cxx"]
    require(len(units) == 1, "Expected one production FTS unity compile record")
    edges = [(line, values) for line, values in ninja_blocks(build_dir / "build.ninja")
             if line.startswith("build ") and ": CXX_EXECUTABLE_LINKER__seekdb_" in line]
    require(len(edges) == 1, "Expected one seekdb link edge")
    edge, variables = edges[0]
    rule_name, tail = edge.split(": ", 1)[1].split(" ", 1)
    inputs = ninja_expand(tail.split(" |", 1)[0], {}).split()
    require(inputs.count(MAIN_OBJ) == 1 and all(path.endswith(".obj") for path in inputs),
            "Original main object not uniquely replaceable")
    rules = [values for line, values in ninja_blocks(build_dir / "CMakeFiles/rules.ninja")
             if line == "rule " + rule_name]
    require(len(rules) == 1, "Executable link rule missing")
    require(variables.get("PRE_LINK") == "cd .", "Nontrivial PRE_LINK needs adaptation")
    require(rules[0].get("rspfile_content") == "$in $LINK_PATH $LINK_LIBRARIES",
            "Unexpected response-file contract")
    selected = {key: variables[key] for key in (
        "LINK_FLAGS", "LINK_PATH", "LINK_LIBRARIES", "PRE_LINK", "POST_BUILD", "TARGET_FILE")}
    return {"compile_record": units[0], "link_rule_name": rule_name,
            "link_rule": rules[0], "link_variables": selected, "explicit_objects": inputs}


def full_build_path(value, build_dir):
    path = Path(value)
    return path if path.is_absolute() else build_dir / path


def capture(root, build_dir, records):
    require(not (HERE / "build-settings.json").exists(), "Capture exists; do not overwrite provenance")
    manifest_path = PROPOSAL / "manifest.json"
    proposal = json.loads(manifest_path.read_text(encoding="utf-8"))
    pins = []
    for entry in proposal["source_files"]:
        rel = entry["path"]
        require(rel in SOURCE_RELS, "Unexpected proposal source")
        original = PROPOSAL / entry["snapshot"]
        candidate = PROPOSAL / rel
        require(sha(original) == entry["original_raw_sha256"], "Original snapshot hash mismatch")
        require(sha(candidate) == entry["changed_raw_sha256"], "Candidate snapshot hash mismatch")
        pins.append({"path": rel, "original_sha256": sha(original), "candidate_sha256": sha(candidate)})
    require({pin["path"] for pin in pins} == set(SOURCE_RELS), "Incomplete proposal pins")
    unity = Path(records["compile_record"]["file"])
    require("src/storage/fts/ob_fts_parser_helper.cpp" in unity.read_text(encoding="utf-8").replace("\\", "/"),
            "FTS unity does not include real builders")
    json_write(HERE / "build-settings.json", {
        "schema_version": 1, "source_root": str(root), "build_dir": str(build_dir),
        "configuration": "Existing Windows x64 RelWithDebInfo clang-cl C++20 /MD production configuration",
        "records": records, "unity_sha256": sha(unity),
        "proposal_manifest_sha256": sha(manifest_path),
        "production_source_pins": pins,
        "context_pins": [{"path": rel, "sha256": sha(root / rel)} for rel in CONTEXT_RELS],
        "test_sha256": sha(HERE / "test_tokenize_json_nodes.cpp"),
        "build_file_sha256": {str(build_dir / rel): sha(build_dir / rel)
                              for rel in ("compile_commands.json", "build.ninja", "CMakeFiles/rules.ninja")},
        "environment_required": {"VSCMD_ARG_TGT_ARCH": "x64", "VCToolsVersion": "14.44.35207",
                                 "WindowsSDKVersion": "10.0.26100.0"},
        "capture": "File reads only; no compiler/linker/native/SQL/performance execution",
        "parent_control_context": {
            "path": str(root / "build_fts_r14_control_observer/seekdb.exe"),
            "reported_by": "Parent; control server snapshot for independent SQL fixtures",
            "native_original_link_artifacts_available": False,
            "used_for_native_link": False,
            "identity_verified_by_helper": False,
        },
        "identity_limit": "Source hashes and timestamps do not establish archive provenance. Parent owns completed-build identity.",
    })


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-root", type=Path, default=ROOT)
    parser.add_argument("--build-dir", type=Path)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--variant", choices=("original", "candidate"), required=True)
    parser.add_argument("--capture", action="store_true", help="Initial read-only configuration/source capture")
    parser.add_argument("--build", action="store_true", help="Compile helper TU and link once; never run")
    args = parser.parse_args()
    require(not args.capture or not args.build, "Capture is plan-only")
    root = args.source_root.resolve()
    build_dir = (args.build_dir or root / "build_fts_competition").resolve()
    output = args.output_dir.resolve()
    require(root == ROOT.resolve(), "Use the selected D: checkout")
    require(build_dir == (ROOT / "build_fts_competition").resolve(), "Use the normal production libraries")
    require(output.is_relative_to(HERE) and output != HERE, "Output must be a dedicated child of this helper")
    require(not output.exists() or not any(output.iterdir()), "Use a new empty output directory")
    records = extract_records(build_dir)
    if args.capture:
        capture(root, build_dir, records)
    settings = json.loads((HERE / "build-settings.json").read_text(encoding="utf-8"))
    require(records == settings["records"], "Relevant CMake/Ninja records drifted; no silent fallback")
    for path, expected in settings["build_file_sha256"].items():
        require(sha(path) == expected, "Captured CMake/Ninja file drifted: " + path)
    require(sha(Path(records["compile_record"]["file"])) == settings["unity_sha256"], "FTS unity changed")
    require(sha(HERE / "test_tokenize_json_nodes.cpp") == settings["test_sha256"], "Captured test changed")
    status = []
    for pin in settings["production_source_pins"]:
        path = root / pin["path"]
        actual = sha(path)
        status.append({"path": str(path), "sha256": actual,
                       "matches_selected": actual == pin[args.variant + "_sha256"]})
    for pin in settings["context_pins"]:
        path = root / pin["path"]
        actual = sha(path)
        status.append({"path": str(path), "sha256": actual, "matches_selected": actual == pin["sha256"]})

    record = records["compile_record"]
    production_obj = full_build_path(record["output"], build_dir)
    archive = build_dir / "src/storage/ob_storage_static.lib"
    oblib = build_dir / "src/oblib/oblib.lib"
    # Object/archive freshness is only a guard; it is not a source-identity proof.
    fresh = (production_obj.is_file() and archive.is_file() and oblib.is_file()
             and all(production_obj.stat().st_mtime_ns >= (root / rel).stat().st_mtime_ns
                     for rel in SOURCE_RELS + (CONTEXT_RELS[0], CONTEXT_RELS[1]))
             and archive.stat().st_mtime_ns >= production_obj.stat().st_mtime_ns
             and oblib.stat().st_mtime_ns >= (root / SOURCE_RELS[1]).stat().st_mtime_ns)
    if args.build:
        require(os.name == "nt", "Captured ABI is native Windows x64")
        require(all(item["matches_selected"] for item in status), "Source/header pins do not match selected variant")
        require(fresh, "Finish the matching production build first (timestamp guard failed)")
        for key, expected in settings["environment_required"].items():
            require(os.environ.get(key, "").rstrip("\\/").lower() == expected.lower(), "Wrong VS environment: " + key)
        require(os.environ.get("INCLUDE") and os.environ.get("LIB"), "VS INCLUDE/LIB missing")

    tokens = windows_args(record["command"])
    compiler, compile_args = tokens[0], []
    replacements = {"source": 0, "object": 0, "pdb": 0}
    require(Path(compiler).name.lower() == "clang-cl.exe", "Expected clang-cl")
    for token in tokens[1:]:
        if token.startswith("/Fo"):
            require(token[3:].replace("\\", "/") == record["output"].replace("\\", "/"), "Unexpected /Fo")
            token = "/Fo" + (output / "tokenize_json_nodes.obj").as_posix()
            replacements["object"] += 1
        elif token.startswith("/Fd"):
            token = "/Fd" + (output / "tokenize_compile.pdb").as_posix()
            replacements["pdb"] += 1
        elif token == record["file"]:
            token = (HERE / "test_tokenize_json_nodes.cpp").as_posix()
            replacements["source"] += 1
        compile_args.append(token)
    require(replacements == {"source": 1, "object": 1, "pdb": 1}, "Compile substitution not exact")
    require("-c" in compile_args and "--" in compile_args, "Expected compile-only source contract")
    libraries = windows_args(ninja_expand(records["link_variables"]["LINK_LIBRARIES"], {}))
    require(all(item.lower().endswith(".lib") for item in libraries), "Unexpected link library expression")
    libraries = [full_build_path(item, build_dir).as_posix() if "/" in item or "\\" in item else item
                 for item in libraries]
    require(archive.as_posix() in libraries and oblib.as_posix() in libraries, "Real storage/JSON libraries absent")
    link_args = [(output / "tokenize_json_nodes.obj").as_posix()]
    link_args += [full_build_path(item, build_dir).as_posix() for item in records["explicit_objects"] if item != MAIN_OBJ]
    link_args += windows_args(ninja_expand(records["link_variables"]["LINK_PATH"], {})) + libraries
    rule = records["link_rule"]["command"]
    match = re.fullmatch(r'.+? /C "\$PRE_LINK && (.+) && \$POST_BUILD"', rule)
    require(match is not None, "Unexpected CMake link wrapper")
    variables = {
        "OBJECT_DIR": subprocess.list2cmdline([(output / "link-intermediate").as_posix()]),
        "RSP_FILE": subprocess.list2cmdline([(output / "link-inputs.rsp").as_posix()]),
        "TARGET_FILE": subprocess.list2cmdline([(output / "test_tokenize_json_nodes.exe").as_posix()]),
        "TARGET_IMPLIB": subprocess.list2cmdline([(output / "tokenize_json_nodes.lib").as_posix()]),
        "TARGET_PDB": subprocess.list2cmdline([(output / "tokenize_link.pdb").as_posix()]),
        "MANIFESTS": "", "LINK_FLAGS": records["link_variables"]["LINK_FLAGS"],
    }
    link_command = windows_args(ninja_expand(match.group(1), variables))
    require("vs_link_exe" in link_command and "--manifests" in link_command, "Production manifest wrapper lost")
    require(all("$" not in arg for arg in link_command), "Unexpanded Ninja variable")
    artifacts = [Path(item) for item in link_args[1:] if ("/" in item or "\\" in item)
                 and not item.startswith(("-LIBPATH:", "/LIBPATH:"))]
    require(all(path.is_file() for path in artifacts), "Production artifact missing; no rebuild attempted")
    dlls = sorted((build_dir / "src/observer").glob("*.dll"))
    require(dlls, "No bundled production DLLs")
    output.mkdir(parents=True, exist_ok=True)
    response_write(output / "compile.rsp", compile_args)
    response_write(output / "link-inputs.rsp", link_args)
    commands = {"cwd": str(output), "compile": [compiler, "@" + (output / "compile.rsp").as_posix()],
                "link": link_command, "compile_replacements": replacements,
                "replaced_main_object": MAIN_OBJ, "retained_storage_archive": str(archive),
                "retained_json_archive": str(oblib), "no_production_source_recompilation": True}
    json_write(output / "commands.json", commands)
    receipt = {
        "schema_version": 1, "variant": args.variant, "mode": "build" if args.build else "plan-only",
        "settings_sha256": sha(HERE / "build-settings.json"), "test_sha256": settings["test_sha256"],
        "input_hashes": status, "selected_source_hashes_match": all(item["matches_selected"] for item in status),
        "production_fresh_by_mtime_only": fresh,
        "commands_sha256": sha(output / "commands.json"),
        "response_sha256": {name: sha(output / name) for name in ("compile.rsp", "link-inputs.rsp")},
        "link_artifacts": [{"path": str(path), "bytes": path.stat().st_size,
                            "mtime_ns": path.stat().st_mtime_ns} for path in artifacts],
        "runtime_dll_sources": [str(path) for path in dlls],
        "compile": "NOT RUN", "link": "NOT RUN", "native": "NOT RUN", "sql": "NOT RUN", "performance": "NOT RUN",
    }
    json_write(output / "receipt.json", receipt)
    if not args.build:
        print("PLAN ONLY:", output, "selected_source_hashes_match=", receipt["selected_source_hashes_match"])
        return
    environment = os.environ.copy()
    temporary = output / "tmp"
    temporary.mkdir()
    environment["TMP"] = environment["TEMP"] = str(temporary)
    # Record linked production bytes, not only timestamps. This still requires
    # independent completed-build provenance from the parent.
    pinned_artifacts = sorted(set(artifacts + [production_obj]), key=str)
    receipt["production_sha256_before"] = {str(path): sha(path) for path in pinned_artifacts}
    json_write(output / "receipt.json", receipt)
    for phase in ("compile", "link"):
        if phase == "link":
            (output / "link-intermediate").mkdir()
        with (output / (phase + ".log")).open("wb") as log:
            completed = subprocess.run(commands[phase], cwd=output, env=environment,
                                       stdout=log, stderr=subprocess.STDOUT)
        receipt[phase] = {"exit_code": completed.returncode, "log_sha256": sha(output / (phase + ".log"))}
        json_write(output / "receipt.json", receipt)
        require(completed.returncode == 0, phase + " failed; inspect log; no retry or fallback")
    receipt["production_sha256_after"] = {str(path): sha(path) for path in pinned_artifacts}
    require(receipt["production_sha256_before"] == receipt["production_sha256_after"], "Production artifacts changed during helper build")
    require(all(sha(item["path"]) == item["sha256"] for item in status), "Production source changed during helper build")
    receipt["runtime_dlls"] = []
    for dll in dlls:
        target = output / dll.name
        shutil.copy2(dll, target)
        require(sha(target) == sha(dll), "DLL copy differs")
        receipt["runtime_dlls"].append({"name": dll.name, "sha256": sha(target)})
    receipt["executable_sha256"] = sha(output / "test_tokenize_json_nodes.exe")
    receipt["build_succeeded"] = True
    json_write(output / "receipt.json", receipt)
    print("COMPILED AND LINKED; NOT RUN:", output / "test_tokenize_json_nodes.exe")


if __name__ == "__main__":
    try:
        main()
    except (RuntimeError, OSError, ValueError, KeyError) as error:
        print("ERROR:", error, file=sys.stderr)
        sys.exit(1)
