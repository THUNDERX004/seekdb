# Round14 production TOKENIZE JSON native regression

Auxiliary files only. This directory never applies a patch, rebuilds seekdb,
changes its source/build/CI, starts a database, or runs SQL/performance work.
Preparation did not execute the build scripts, compiler, linker, or native test.
The parent must compile and run serially after its server build finishes.

`test_tokenize_json_nodes.cpp` calls the actual linked
`ObFTParseHelper::make_detail_json` and `make_token_array_json`. It uses the
public parser/property fast-init API with the built-in `space` descriptor. It
does not segment text or initialize the parser dictionary hub. No production
algorithm is copied into the test and no private fields, stubs, alternative
serializer, or unresolved-symbol suppression are used.

The current/staged proposal is in `../round14-tokenize-proposal`. Original and
candidate hashes for its two production files are pinned in
`build-settings.json`; both original snapshots and candidate files were checked
against the proposal manifest. The test is compiled against the selected D:
checkout's headers and links its normal, completed `build_fts_competition`
libraries. It does **not** compile staged production `.cpp` files into a second
implementation. A candidate build requires the candidate source hashes; an
original build requires the original source hashes. Unrelated context files,
including the currently dirty data-plane FTS header, are separately pinned to
the bytes read during preparation. No existing file is changed.

The captured build configuration matches the previously successful round12
infrastructure: native Windows x64, clang-cl 18.1.8, C++20, `/MD`, VS toolset
14.44.35207 and SDK 10.0.26100.0. The production FTS unity compile command is
retained, replacing only the test source and object/PDB destinations. Linking
retains the actual ordered storage, JSON/oblib, SQL, allocator, observer, share,
Rust and third-party libraries, replacing only the production `main.cpp` object.
The normal CMake `vs_link_exe`, RC, MT and lld-link wrapper is retained; production
PRE_LINK/POST_BUILD actions are not run. No CMake configure/build or Ninja
command is executed. All generated response files, objects, PDBs, executable,
logs, manifest intermediates and temporary files remain below this directory.
DLLs are copied only from the completed production build's executable directory.

## Native coverage and bounds

* Both DEFAULT and ALL builders succeed at U = 0, 1, 2, 31, 257 and 1025, for
  ASCII and mixed key corpora: 24 success cases. Four additional success cases
  cover a zero-length non-null key and a zero-length nullptr-backed key, each
  with count/doc_len `INT64_MAX`. Total: 28 success cases.
* Mixed keys contain embedded U+0000, a single NUL byte, quotes, backslash,
  slash, every short JSON control escape, other control bytes, an empty key,
  BMP Chinese, supplementary Unicode, precomposed/decomposed accents, the
  literal `null`, trailing whitespace, and `tokens`/`doc_len`. Distinct input
  keys use the real map with binary collation. Counts span integer encoding
  boundaries and values beyond 32 bits. `INT64_MAX` gets a separate single-key
  case so summing document counts cannot overflow.
* Tree validation follows the real map's iteration order and checks every key,
  type, count, doc_len, array length, and parent pointer. Map/key storage remains
  alive as required by the original builders' borrowing contract.
* The helper object and builder call frame are gone, and an 8 KiB volatile stack
  buffer is overwritten, before validation and serialization. Real `print()`
  and `get_raw_binary()` run twice. A real `ObJsonBin` reader prints the resulting
  binary and must reproduce the original print bytes. Serialization allocations
  use a separate arena; the builder allocation count must not change.
* Each implementation first measures its own successful builder allocation
  count for each case. It then fails **every** observed allocation ordinal for
  U = 1, 2, 31 in each corpus/mode, and for the two empty-key cases/modes.
  Original/candidate allocation ordinals or totals are never assumed equal.
  Each failure must be reached exactly once, return
  `OB_ALLOCATE_MEMORY_FAILED`, and leave the caller's output pointer and actual
  stack sentinel node unchanged.
* Tracking uses exact-base frees, detects double/interior/unrelated frees,
  red-zone damage, and writes to quarantined poisoned freed blocks. Returned
  tree/count pointers must lie in live allocator blocks. This tests batch
  lifetime after builder return without accidentally accepting recycled storage.
* Original error paths may retain already-created child nodes until caller
  arena reset. Their residual block count is reported, and the reset must
  reclaim all memory. Candidate runs additionally use
  `--require-empty-on-error`, requiring zero live builder blocks **before** arena
  reset at every injected failure. Neither mode recursively destroys successful
  child nodes: batched child nodes are interior addresses, and production uses
  caller arena lifetime. The test then performs a bounded arena sweep.
* Each individual arena permits at most 16,384 allocation attempts and 64 MiB
  total allocated payload; red zones add 64 bytes per successful allocation.
  Input U is capped by this fixed corpus at 1025. Native execution has a
  parent-configurable 1..600 second timeout (default 180). Only the builder's
  allocator calls are injected; CRT/map/global and serialization allocations
  are intentionally outside this fault domain.

## Parent commands — not run during preparation

Use a new output directory on every invocation. The wrapper imports the same
VS x64 environment as earlier native helpers **only with `-Build`**. Without
`-Build`, it writes a reviewable plan only. These commands are for the parent
after its serial server build completes:

```powershell
$helper = 'C:/Users/11946/Documents/ChatGPT/OceanBase比赛/setup/fts/round14-json-native'
$python = 'C:/Users/11946/Documents/ChatGPT/OceanBase比赛/.venv/Scripts/python.exe'

# Candidate already applied: generate a plan, then compile/link separately.
& "$helper/build_tokenize_json_nodes.ps1" -Variant candidate `
  -OutputDir "$helper/candidate-plan-1" -Python $python
& "$helper/build_tokenize_json_nodes.ps1" -Variant candidate `
  -OutputDir "$helper/candidate-build-1" -Python $python -Build
```

For an independent native original recording, the parent needs a completed
production build matching the two original source/header pins, and must build
the original native executable from that state. The helper never restores
source or starts such a build:

```powershell
# Only when the parent has independently prepared matching ORIGINAL artifacts.
& "$helper/build_tokenize_json_nodes.ps1" -Variant original `
  -OutputDir "$helper/original-build-1" -Python $python -Build
```

The matched no-JSON server snapshot
`D:/Projects/OceanBase/seekdb/build_fts_r14_control_observer/seekdb.exe` is recorded
in `build-settings.json` as parent-supplied control context. It can support the
parent's separate SQL differential; it cannot replace storage/JSON link
libraries or be relabeled as this native original executable. If matching
original libraries/native output are unavailable, candidate native checks may
be run directly, but original-vs-candidate native comparison remains pending.

The direct candidate command below runs all native checks and emits complete
ASCII hex records to stdout. The first two lines set a helper-owned working
directory and DLL lookup path so production libraries cannot write logs in D:.
The Python runner below is preferred when a native original fixture is ready.

```powershell
Push-Location -LiteralPath "$helper/candidate-build-1"
try {
  & './test_tokenize_json_nodes.exe' --require-empty-on-error
  if ($LASTEXITCODE -ne 0) { throw "native regression failed: $LASTEXITCODE" }
} finally { Pop-Location }
```

## Independent complete-output recording and comparison

The native executable emits `RESULT<TAB>case_id<TAB>print_hex<TAB>binary_hex`
containing **every** byte. `SUCCESS`, `FAILPOINT` and final `PASS` records report
allocation, cleanup, failure, and check counts. No output is reduced to hit
counts, lengths, hashes, normalized JSON, or a reconstructed expected algorithm.

`run_tokenize_json_nodes.py` is separate from building and requires `--execute`.
First run a hash-verified **original** native executable with
`--record-original`. Its receipt must say `variant=original` and successful
compile/link; this prevents accidentally recording the candidate as its own
oracle. The fixture path must not exist. Recording never happens as a fallback
to a failed comparison.

Provide `--build-evidence` as a path to the parent's actual existing JSON
provenance for the corresponding completed production build; do not substitute
the example-plan receipt or invent successful-build evidence. Its exact bytes
are copied and hashed, together with the native build receipt, executable,
DLLs, source pins and stdout/stderr. Supplied evidence is an audit attachment,
not an automatic proof that the archive was compiled from those sources.

```powershell
& $python "$helper/run_tokenize_json_nodes.py" `
  --build-output "$helper/original-build-1" --output-dir "$helper/original-run-1" `
  --record-original "$helper/original-complete-output.json" `
  --build-evidence '<actual original completed-build evidence.json>' --execute

& $python "$helper/run_tokenize_json_nodes.py" `
  --build-output "$helper/candidate-build-1" --output-dir "$helper/candidate-run-1" `
  --compare "$helper/original-complete-output.json" `
  --build-evidence '<actual candidate completed-build evidence.json>' --execute
```

The candidate runner requires candidate receipt identity, enables strict error
cleanup, and compares every print/binary byte against the independently saved
original fixture for exactly the same 28 case IDs. It checks each build's own
complete failure-ordinal sweep, and compares allocation error codes across
builds; it never compares allocation counts by ordinal across implementations.
It preserves raw stdout/stderr, per-case complete `.print.json` and `.bin`
files, full allocation accounting, build receipts/evidence, and a `run.json`
comparison result. Original fixture bytes are rehashed after candidate execution.
No original fixture or runtime result was generated during preparation.

## Limits and status

Static checks cover Python AST parsing, PowerShell parsing, source/API inspection,
captured-source hashes, and existing compile/link configuration identity. No
compile, link, native run, SQL, or performance result is claimed. Parent must
resolve real compiler/dependency/runtime issues, and may need to recapture
deliberately if the toolchain, relevant headers, or build records change.

Timestamp guards and recorded production archive hashes do not establish
archive/source identity; the parent's completed-build provenance is required.
No Linux coverage, parser segmentation/SQL behavior, SQL NULL input semantics,
allocation failures in the serializer or map, general allocator correctness,
ASan/UBSan coverage, or performance conclusion is provided by this helper.
Quarantined freed storage/guards catch some lifetime errors; they cannot detect
every invalid read. The extra nullptr/empty key maps test direct builder
robustness, and are not a claim that real parsers produce those tokens. Broader
SQL original/candidate fixtures remain independent work.
