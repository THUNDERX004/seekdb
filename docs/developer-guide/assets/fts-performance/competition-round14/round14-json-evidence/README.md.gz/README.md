# Round 14 JSON-batching comparison

All three full control/candidate pairs are complete. Before any report was read as successful, the summarizer required each experiment JSON to contain exactly one benchmark and one input-validation action, both with exit code 0. Control b3 was already complete when inspected; its report timestamp is `2026-11-04 18:46:34`.

The ratio-of-three-means equal-class reduction is **+0.360468%**: build **+0.123684%**, tokenize **-0.923193%**, query **+1.880912%**. Positive means reduced time; all negative values are retained. **Final decision: rejected, as confirmed by the parent.** The tokenize class regresses and pair directions are mixed; these results do not establish stable overall benefit.

The parent confirms both production files, `src/storage/fts/ob_fts_parser_helper.cpp` and `src/oblib/common/json_type/ob_json_tree.h`, were restored exactly and `git diff --exit-code` passed. This is recorded parent confirmation; no checkout or Git check was rerun by this auxiliary task. Historical candidate hashes and measurements below remain preserved.

## Method and all nine metrics

For each metric, compute `(mean(control_b1..b3) - mean(candidate_b1..b3)) / mean(control_b1..b3)`. Average the three build metrics, two tokenize metrics and four query metrics inside their classes, then average the three class values with equal 1/3 weights. This retains regressions at every level. It is neither an average of all nine metrics nor an average of the three per-pair overall reductions. No samples or pairs were dropped; calculations use report precision without intermediate rounding.

All six reports use ROWS=20000, BATCH=500, ROUNDS=3000, QUERY_ROUNDS=200, SAMPLES=3, WARMUP=30, SKIP_LOAD=0. Hits agree: CN=8001, BENG=11000, mixed=7332, LIMIT=20.

| Metric | Unit | Control three-run mean | Candidate three-run mean | Reduction |
| --- | --- | ---: | ---: | ---: |
| `build_ik_all_sec` | sec | 8.098666667 | 7.887666667 | +2.605367% |
| `build_ik_content_sec` | sec | 6.161333333 | 6.147333333 | +0.227224% |
| `build_beng_en_sec` | sec | 3.575000000 | 3.663000000 | -2.461538% |
| `tokenize_ik_avg_ms` | ms | 0.139566667 | 0.134966667 | +3.295916% |
| `tokenize_beng_avg_ms` | ms | 0.103066667 | 0.108366667 | -5.142303% |
| `query_cn_avg_ms` | ms | 0.964300000 | 0.935833333 | +2.952055% |
| `query_beng_avg_ms` | ms | 1.238266667 | 1.243566667 | -0.428018% |
| `query_mixed_avg_ms` | ms | 1.020766667 | 1.011633333 | +0.894752% |
| `query_limit_avg_ms` | ms | 2.287533333 | 2.193633333 | +4.104858% |

## Per-pair totals and stability

Each pair uses the identical within-class and equal-class formula, with that pair's control as denominator. The last column is the requested per-pair overall total, not the aggregate ratio-of-three-means.

| Pair | Build reduction | Tokenize reduction | Query reduction | Overall reduction |
| --- | ---: | ---: | ---: | ---: |
| b1 | +2.790330% | -2.099971% | -2.955501% | -0.755047% |
| b2 | +2.517632% | -3.151277% | +7.668012% | +2.344789% |
| b3 | -4.975109% | +2.092430% | -0.659898% | -1.180859% |

One pair improves overall and two regress. Build and tokenize class directions also reverse between pairs; query improves in b2 and regresses in b1/b3. The aggregate is small and tokenize regresses. These are descriptive stability observations from three local pairs; no statistical significance or causal attribution is claimed.

| Pair | Report build_total_sec control | Report build_total_sec candidate | Build-total reduction (unscored) |
| --- | ---: | ---: | ---: |
| b1 | 18.140 | 17.582 | +3.076075% |
| b2 | 18.260 | 17.680 | +3.176342% |
| b3 | 17.647 | 18.357 | -4.023347% |

`comparison.json` retains every per-pair metric, all metric reductions, the class/overall totals, report auxiliary fields and benchmark action wall times. Build totals and harness wall times do not enter the performance formula. Local fixed-baseline scores in input-validation logs are not official scores and are not used here.

## Source and executable provenance

Official baseline context is `upstream/2026-competition` at `5bce9e06d1281347ad61344e4b01fab9158c58a2`. Both experiment metadata sets supply `f602f6d7f0b4fc3377b038b67fe622cd04cd2146` as the source commit label. The control is the saved same-configuration f602 binary **before JSON batching**. The candidate is **f602 plus the round14 proposal patch**; no new candidate commit is implied by the common source_commit label.

- Control executable SHA-256: `58a14c4b3cfb44464882de1d87b0f8018c76595a563e039ff3cbd8be2351f07d`.
- Candidate executable SHA-256: `104a228d0c9f6b26087824d7ff4a10d3d96f1398a617a1e500f9d9bae54a2321`.
- `round14-tokenize-proposal/source.patch` SHA-256: `1a9cfcf4c5be69808c66b7dbf5b5b189acbf2582a65556826c99dfa0915c0266`.

| Archived source path | Original raw SHA-256 | Changed raw SHA-256 |
| --- | --- | --- |
| `src/storage/fts/ob_fts_parser_helper.cpp` | `191c8b361cfef10bb7288edaad5fdd8aa2822108860c00cd6ae210e568396df3` | `b76eeeb9bf9a8be6ad803dd3c4053d457c9fc6e4ceaf0d3b3186560a40db5b88` |
| `src/oblib/common/json_type/ob_json_tree.h` | `f7fd75187cf022901b9a9e4366778e7fb002231e003cb52974584583451e1ed0` | `5176ceb1c13b3e3037d63d748124f3c2f771620044346a39e71c2dd9c7f92ee9` |

The proposal manifest was created earlier at source_head `a01e9cde9951b999073d6c1cf2407064d72897a4`. The two archived original/changed source files and patch still match its recorded hashes; this is not a claim that the entire older staging inventory remains unchanged or that the live checkout was inspected. Original HEAD Git blob IDs and changed LF-normalized Git blob IDs are enumerated in comparison.json.

Report `git_head` and `git_dirty` describe the checkout when the harness ran, including when it ran the saved control executable. All six reports have git_dirty=1; this does not make the control a JSON-batching binary. Executable hashes, source label and patch identity are recorded separately. The same-build-configuration relationship is supplied by parent/task context and the saved control identity. This summary did not rehash binaries, query Git, read current production files or rebuild anything.

## Correctness status

The candidate b1 metadata and seven PASS logs record successful hot-path, configuration, collation, MATCH batching, map concurrency, stopword concurrency and dictionary-prefix regression suites. Their exact outputs and exit codes are retained in comparison.json.

The parent reports the **1560-case complete JSON/metadata/warnings/error fixture comparison passed**. This task inspected only the independent original fixture metadata/count: commit `5bce9e06d1281347ad61344e4b01fab9158c58a2`, original binary SHA-256 `bae4a3b9e1b4662d4021b28d5adc085764beb6cf02122eacd57b8e16b6fe1762`, and compressed fixture SHA-256 `e87f9ca69192116ed37cb376e4a55b18da1b7e47b9f30a306a5d51388c4771ab`. Its workload hash is recorded in comparison.json. The candidate comparison was not rerun and no standalone pass receipt is bundled; that pass remains attributed to the parent. Matching benchmark hit counts alone do not establish correctness.

**Native build-1 failed before compilation because `build-settings.json` was missing, as confirmed by the parent. No native tests ran.** This package includes no standalone native failure receipt and makes no native allocator-failure, exact-base-free or returned-node-lifetime correctness claim.

## Files and offline verification

- `comparison.json`: all six completed runs, nine-metric and class aggregation, per-pair totals, stability observations, correctness provenance and SHA-256 hashes of every input artifact.
- `summarize.py`: standard-library-only offline parser and calculator. It gates report reading on successful completion metadata and writes only comparison.json and README.md in this auxiliary directory. Default mode refuses differing outputs; `--refresh` updates only these two summaries with the final parent-confirmed disposition.
- `README.md`: this human-readable summary. Raw artifacts remain in place and are not copied.

From the auxiliary workspace, `.venv/Scripts/python.exe -B -X utf8 setup/fts/round14-json-evidence/summarize.py --check` recomputes all values and compares outputs byte-for-byte without writes. It does not run SQL, builds, native tests or performance workloads. This task made no production/test/CI/benchmark changes, did not change stopword evidence, and did not commit or push.
