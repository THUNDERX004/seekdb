"""Offline summary of completed round14 JSON-batching reports.

No builds, SQL, native tests, performance workloads, subprocesses or networking.
Only comparison.json and README.md in this new auxiliary directory are created.
Default mode refuses differing outputs; --refresh updates the two summaries.
--check is entirely read-only.
"""
import argparse
import gzip
import hashlib
import json
import math
import re
from pathlib import Path
from statistics import mean

OUT = Path(__file__).resolve().parent
FTS = OUT.parent
WORKSPACE = FTS.parent.parent
assert OUT.name == "round14-json-evidence" and FTS.name == "fts"
COMMIT = "f602f6d7f0b4fc3377b038b67fe622cd04cd2146"
BASELINE = "5bce9e06d1281347ad61344e4b01fab9158c58a2"
BINARY_HASHES = {
    "control": "58a14c4b3cfb44464882de1d87b0f8018c76595a563e039ff3cbd8be2351f07d",
    "candidate": "104a228d0c9f6b26087824d7ff4a10d3d96f1398a617a1e500f9d9bae54a2321",
}
CLASSES = {
    "build": ["build_ik_all_sec", "build_ik_content_sec", "build_beng_en_sec"],
    "tokenize": ["tokenize_ik_avg_ms", "tokenize_beng_avg_ms"],
    "query": ["query_cn_avg_ms", "query_beng_avg_ms", "query_mixed_avg_ms", "query_limit_avg_ms"],
}
METRICS = [key for keys in CLASSES.values() for key in keys]
PARAMETERS = dict(rows=20000, batch=500, rounds=3000, query_rounds=200, samples=3, warmup=30, skip_load=0)
HITS = dict(query_cn_hits=8001, query_beng_hits=11000, query_mixed_hits=7332, query_limit_hits=20)
SUITES = ["test_hot_path.py", "test_tokenize_config.py", "test_collation.py", "test_match_batches.py",
          "test_map_concurrency.py", "test_stopword_concurrency.py", "test_dictionary_prefixes.py"]


def json_bytes(value):
    return (json.dumps(value, ensure_ascii=False, allow_nan=False, indent=2) + "\n").encode("utf-8")


def reduction(control, candidate):
    assert control > 0 and candidate > 0 and math.isfinite(control + candidate)
    return (control - candidate) / control


def signs(values):
    return dict(positive=sum(x > 0 for x in values), negative=sum(x < 0 for x in values),
                zero=sum(x == 0 for x in values), min=min(values), max=max(values))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--check", action="store_true", help="verify calculations, hashes and existing outputs without writes")
    mode.add_argument("--refresh", action="store_true", help="refresh only comparison.json and README.md with the final parent-confirmed disposition")
    args = parser.parse_args()
    inputs = {}

    def read(path):
        path = path.resolve()
        assert path.is_relative_to(FTS.resolve()), "Reads restricted to auxiliary FTS evidence"
        if path not in inputs:
            inputs[path] = path.read_bytes()
        return inputs[path]

    def text(path):
        return read(path).decode("utf-8-sig")

    # Completion gate: check every metadata record BEFORE opening any report.
    # In particular, control-b3 must not be treated as complete just because a
    # report or experiment JSON exists. Both required actions must have exit 0.
    metadata = {}
    for variant in ("control", "candidate"):
        for n in range(1, 4):
            label = f"r14-json-{variant}-b{n}"
            path = FTS / (label + "-experiment.json")
            if not path.is_file():
                raise SystemExit("WAIT: completion metadata missing; reports not read: " + path.name)
            try:
                record = json.loads(text(path))
            except json.JSONDecodeError as exc:
                raise SystemExit("WAIT: completion metadata incomplete; reports not read: " + path.name) from exc
            for action in ("benchmark", "input-validation"):
                matches = [entry for entry in record.get("actions", []) if entry.get("action") == action]
                if len(matches) != 1 or matches[0].get("exit_code") != 0:
                    raise SystemExit("NOT COMPLETE/SUCCESSFUL: " + label + " " + action + "; reports not read")
            assert record["label"] == label and record["source_commit"] == COMMIT
            assert record["binary_sha256"] == BINARY_HASHES[variant]
            assert record["log_level"] == "WARN" and all(item["exit_code"] == 0 for item in record["actions"])
            metadata[variant, n] = record

    reports, runs = {}, {}
    for (variant, n), record in metadata.items():
        label = record["label"]
        report_path = FTS / (label + "-report.txt")
        assert Path(record["report"]).resolve() == report_path.resolve()
        content = text(report_path)
        assert content.count("FTS Large Benchmark Report") == 1, "Partial or appended report"
        fields = dict(re.findall(r"^([a-zA-Z0-9_]+):\s*(.*?)\s*$", content, re.M))
        assert fields["label"] == label
        for key, expected in {**PARAMETERS, **HITS}.items():
            assert float(fields[key]) == expected, (label, key)
        numbers = {key: float(value) for key, value in fields.items()
                   if re.fullmatch(r"[+-]?(?:\d+\.?\d*|\.\d+)", value)}
        assert all(numbers[key] > 0 for key in METRICS)
        assert "score:" in text(FTS / (label + "-input-validation.log"))
        reports[variant, n] = numbers
        runs[variant, n] = dict(label=label, timestamp_local=fields["timestamp"],
                                source_commit_label=record["source_commit"], binary=record["binary"],
                                binary_sha256=record["binary_sha256"],
                                experiment=label + "-experiment.json", report=label + "-report.txt",
                                report_git_head=fields["git_head"], report_git_dirty=int(fields["git_dirty"]),
                                benchmark_wall_sec=next(item["seconds"] for item in record["actions"] if item["action"] == "benchmark"),
                                completion_exit_codes={item["action"]: item["exit_code"] for item in record["actions"]},
                                metrics={key: numbers[key] for key in METRICS},
                                auxiliary={key: numbers[key] for key in numbers if key not in METRICS and key not in PARAMETERS and key != "git_dirty"})

    pair_results = []
    for n in range(1, 4):
        c, t = reports["control", n], reports["candidate", n]
        rates = {key: reduction(c[key], t[key]) for key in METRICS}
        classes = {category: mean(rates[key] for key in keys) for category, keys in CLASSES.items()}
        pair_results.append(dict(pair=f"b{n}", control=runs["control", n], candidate=runs["candidate", n],
                                 metric_reductions=rates, class_reductions=classes,
                                 overall_reduction=mean(classes.values()),
                                 auxiliary_build_total=dict(scored=False, control_sec=c["build_total_sec"],
                                                           candidate_sec=t["build_total_sec"],
                                                           reduction=reduction(c["build_total_sec"], t["build_total_sec"]))))

    aggregate_metrics = {}
    for key in METRICS:
        c = mean(reports["control", n][key] for n in range(1, 4))
        t = mean(reports["candidate", n][key] for n in range(1, 4))
        aggregate_metrics[key] = dict(unit="sec" if key.endswith("_sec") else "ms", control_mean=c, candidate_mean=t,
                                       reduction=reduction(c, t),
                                       paired_stability=signs([pair["metric_reductions"][key] for pair in pair_results]))
    aggregate_classes = {category: mean(aggregate_metrics[key]["reduction"] for key in keys) for category, keys in CLASSES.items()}
    overall = mean(aggregate_classes.values())

    proposal = FTS / "round14-tokenize-proposal"
    staged_manifest = json.loads(text(proposal / "manifest.json"))
    source_hashes = []
    for entry in staged_manifest["source_files"]:
        original_path = proposal / entry["snapshot"]
        changed_path = proposal / entry["path"]
        assert hashlib.sha256(read(original_path)).hexdigest() == entry["original_raw_sha256"]
        assert hashlib.sha256(read(changed_path)).hexdigest() == entry["changed_raw_sha256"]
        source_hashes.append({key: entry[key] for key in (
            "path", "head_git_blob", "original_raw_sha256", "changed_raw_sha256", "changed_lf_git_blob", "line_endings")})
    patch_path = proposal / "source.patch"
    patch_sha256 = hashlib.sha256(read(patch_path)).hexdigest()
    assert patch_sha256 == next(item["sha256"] for item in staged_manifest["artifact_inventory"] if item["path"] == "source.patch")

    candidate_actions = metadata["candidate", 1]["actions"]
    suite_results = []
    for suite in SUITES:
        action = [item for item in candidate_actions if item["action"] == suite]
        assert len(action) == 1 and action[0]["exit_code"] == 0
        log_path = FTS / ("r14-json-candidate-b1-" + suite + ".log")
        log_text = text(log_path).strip()
        assert log_text.startswith("PASS")
        suite_results.append(dict(suite=suite, exit_code=0, log=log_path.name, recorded_output=log_text))

    fixture_path = FTS / "r14-original-tokenize-json-nodes.json.gz"
    fixture = json.loads(gzip.decompress(read(fixture_path)))
    assert fixture["format"] == 1 and len(fixture["results"]) == 1560
    assert fixture["original"]["commit"] == BASELINE
    fixture_info = dict(path=fixture_path.name, bytes=len(read(fixture_path)),
                        sha256=hashlib.sha256(read(fixture_path)).hexdigest(),
                        workload_sha256=fixture["workload_sha256"], original=fixture["original"], cases=1560,
                        candidate_comparison_status="passed, as reported by parent/task context",
                        claim_limit="Only the original fixture metadata/count were inspected here; candidate comparison was not rerun and no standalone pass receipt is included.")

    artifacts = [dict(path=path.relative_to(WORKSPACE).as_posix(), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
                 for path, data in sorted(inputs.items())]
    result = dict(
        schema_version=1, experiment="round14 TOKENIZE JSON result-node batching",
        acceptance_decision="rejected", formal_platform_score=None,
        decision_basis="Parent confirmed rejection: aggregate tokenize class regresses and pair directions are mixed; no stable overall benefit established.",
        source_restoration=dict(status="both JSON-batching production source files restored exactly",
                                files=["src/storage/fts/ob_fts_parser_helper.cpp", "src/oblib/common/json_type/ob_json_tree.h"],
                                verification="git diff --exit-code passed, as confirmed by parent",
                                independently_rechecked_here=False),
        scope="Offline evidence summary only; no new workload execution, production edits, stopword evidence edits, commits or pushes.",
        completion_gate=dict(all_six_metadata_present=True, benchmark_and_input_validation_exit0=True,
                             metadata_checked_before_any_report_read=True,
                             control_b3_completed_report_timestamp_local=runs["control", 3]["timestamp_local"]),
        provenance=dict(official_baseline_branch="upstream/2026-competition", official_baseline_commit=BASELINE,
                        experiment_source_commit_label=COMMIT, binary_hashes_sha256=BINARY_HASHES,
                        control_source="f602f6d7f0b4fc3377b038b67fe622cd04cd2146 before JSON batching; saved same-configuration control snapshot",
                        candidate_source="f602f6d7f0b4fc3377b038b67fe622cd04cd2146 plus round14-tokenize-proposal/source.patch",
                        same_configuration_basis="Parent/task context and saved control binary identity; no build or configuration changes made here.",
                        proposal_patch=dict(path="round14-tokenize-proposal/source.patch", sha256=patch_sha256),
                        staged_source_hashes=source_hashes, original_staging_manifest_source_head=staged_manifest["source_head"],
                        limits=["Experiment source_commit is a caller-supplied label; patch hash distinguishes the uncommitted candidate source.",
                                "Report git_head/git_dirty describe the checkout used by the harness, including for the saved control; they do not identify executable source or show the control binary contains the patch.",
                                "Staging manifest predates this experiment and names a01e9cde9951b999073d6c1cf2407064d72897a4. Its two source snapshots and patch hashes were checked, not its stale whole-package inventory or live checkout.",
                                "No executable, current production source, Git ancestry or per-run build settings were independently reverified in this auxiliary task."]),
        parameters_all_runs=PARAMETERS, query_hits_all_runs=HITS,
        aggregation=dict(method="ratio_of_three_means", metric_formula="(mean(control_b1,b2,b3) - mean(candidate_b1,b2,b3)) / mean(control_b1,b2,b3)",
                         class_formula="arithmetic mean of the metric reductions within each class",
                         overall_formula="(build_class + tokenize_class + query_class) / 3",
                         classes=CLASSES, negative_reductions_retained=True, intermediate_rounding=False,
                         input_precision="Saved report decimals, without reconstructing unrounded timings from logs.",
                         metrics=aggregate_metrics, class_reductions=aggregate_classes, overall_reduction=overall),
        pairs=pair_results,
        stability=dict(overall_by_pair=signs([pair["overall_reduction"] for pair in pair_results]),
                       classes_by_pair={category: signs([pair["class_reductions"][category] for pair in pair_results]) for category in CLASSES},
                       observation="Small positive aggregate with mixed pair direction: one positive overall pair and two negative overall pairs. Aggregate tokenize class regresses. Repeatable overall benefit is not established by these three descriptive pairs.",
                       limit="Three local pairs are not a statistical significance test or an official platform score. The final rejection is the parent's decision."),
        correctness=dict(candidate_seven_suites=dict(status="passed", evidence="r14-json-candidate-b1-experiment.json and seven PASS logs", suites=suite_results),
                         tokenize_fixture=fixture_info,
                         native=dict(status="build-1 failed before compilation",
                                     reason="missing build-settings.json",
                                     compilation_started=False, native_tests_run=False,
                                     evidence="parent confirmation; no standalone failure receipt included",
                                     native_correctness_claimed=False),
                         query_hits_note="Matching hits are auxiliary evidence, not a substitute for full correctness checks."),
        scoring_note="Existing input-validation local scores are not used as official scores or as evidence of candidate benefit. Per-pair totals mean the same equal-class overall reduction; build_total_sec and benchmark wall time are unscored auxiliaries.",
        raw_artifacts=dict(path_base="workspace_root", workspace_root=str(WORKSPACE), hash_algorithm="SHA-256", count=len(artifacts),
                           copies_created=False, artifacts=artifacts),
    )

    lines = ["# Round 14 JSON-batching comparison", "",
             "All three full control/candidate pairs are complete. Before any report was read as successful, the summarizer required each experiment JSON to contain exactly one benchmark and one input-validation action, both with exit code 0. Control b3 was already complete when inspected; its report timestamp is `" + runs["control", 3]["timestamp_local"] + "`.", "",
             "The ratio-of-three-means equal-class reduction is **{:+.6f}%**: build **{:+.6f}%**, tokenize **{:+.6f}%**, query **{:+.6f}%**. Positive means reduced time; all negative values are retained. **Final decision: rejected, as confirmed by the parent.** The tokenize class regresses and pair directions are mixed; these results do not establish stable overall benefit.".format(overall * 100, *(aggregate_classes[k] * 100 for k in CLASSES)), "",
             "The parent confirms both production files, `src/storage/fts/ob_fts_parser_helper.cpp` and `src/oblib/common/json_type/ob_json_tree.h`, were restored exactly and `git diff --exit-code` passed. This is recorded parent confirmation; no checkout or Git check was rerun by this auxiliary task. Historical candidate hashes and measurements below remain preserved.", "",
             "## Method and all nine metrics", "",
             "For each metric, compute `(mean(control_b1..b3) - mean(candidate_b1..b3)) / mean(control_b1..b3)`. Average the three build metrics, two tokenize metrics and four query metrics inside their classes, then average the three class values with equal 1/3 weights. This retains regressions at every level. It is neither an average of all nine metrics nor an average of the three per-pair overall reductions. No samples or pairs were dropped; calculations use report precision without intermediate rounding.", "",
             "All six reports use ROWS=20000, BATCH=500, ROUNDS=3000, QUERY_ROUNDS=200, SAMPLES=3, WARMUP=30, SKIP_LOAD=0. Hits agree: CN=8001, BENG=11000, mixed=7332, LIMIT=20.", "",
             "| Metric | Unit | Control three-run mean | Candidate three-run mean | Reduction |",
             "| --- | --- | ---: | ---: | ---: |"]
    for key, data in aggregate_metrics.items():
        lines.append(f"| `{key}` | {data['unit']} | {data['control_mean']:.9f} | {data['candidate_mean']:.9f} | {data['reduction'] * 100:+.6f}% |")
    lines += ["", "## Per-pair totals and stability", "",
              "Each pair uses the identical within-class and equal-class formula, with that pair's control as denominator. The last column is the requested per-pair overall total, not the aggregate ratio-of-three-means.", "",
              "| Pair | Build reduction | Tokenize reduction | Query reduction | Overall reduction |",
              "| --- | ---: | ---: | ---: | ---: |"]
    for pair in pair_results:
        lines.append("| {} | {:+.6f}% | {:+.6f}% | {:+.6f}% | {:+.6f}% |".format(pair["pair"], *(pair["class_reductions"][k] * 100 for k in CLASSES), pair["overall_reduction"] * 100))
    lines += ["", "One pair improves overall and two regress. Build and tokenize class directions also reverse between pairs; query improves in b2 and regresses in b1/b3. The aggregate is small and tokenize regresses. These are descriptive stability observations from three local pairs; no statistical significance or causal attribution is claimed.", "",
              "| Pair | Report build_total_sec control | Report build_total_sec candidate | Build-total reduction (unscored) |",
              "| --- | ---: | ---: | ---: |"]
    for pair in pair_results:
        total = pair["auxiliary_build_total"]
        lines.append(f"| {pair['pair']} | {total['control_sec']:.3f} | {total['candidate_sec']:.3f} | {total['reduction'] * 100:+.6f}% |")
    lines += ["", "`comparison.json` retains every per-pair metric, all metric reductions, the class/overall totals, report auxiliary fields and benchmark action wall times. Build totals and harness wall times do not enter the performance formula. Local fixed-baseline scores in input-validation logs are not official scores and are not used here.", "",
              "## Source and executable provenance", "",
              f"Official baseline context is `upstream/2026-competition` at `{BASELINE}`. Both experiment metadata sets supply `{COMMIT}` as the source commit label. The control is the saved same-configuration f602 binary **before JSON batching**. The candidate is **f602 plus the round14 proposal patch**; no new candidate commit is implied by the common source_commit label.", "",
              f"- Control executable SHA-256: `{BINARY_HASHES['control']}`.",
              f"- Candidate executable SHA-256: `{BINARY_HASHES['candidate']}`.",
              f"- `round14-tokenize-proposal/source.patch` SHA-256: `{patch_sha256}`.", "",
              "| Archived source path | Original raw SHA-256 | Changed raw SHA-256 |",
              "| --- | --- | --- |"]
    for entry in source_hashes:
        lines.append(f"| `{entry['path']}` | `{entry['original_raw_sha256']}` | `{entry['changed_raw_sha256']}` |")
    lines += ["", "The proposal manifest was created earlier at source_head `" + staged_manifest["source_head"] + "`. The two archived original/changed source files and patch still match its recorded hashes; this is not a claim that the entire older staging inventory remains unchanged or that the live checkout was inspected. Original HEAD Git blob IDs and changed LF-normalized Git blob IDs are enumerated in comparison.json.", "",
              "Report `git_head` and `git_dirty` describe the checkout when the harness ran, including when it ran the saved control executable. All six reports have git_dirty=1; this does not make the control a JSON-batching binary. Executable hashes, source label and patch identity are recorded separately. The same-build-configuration relationship is supplied by parent/task context and the saved control identity. This summary did not rehash binaries, query Git, read current production files or rebuild anything.", "",
              "## Correctness status", "",
              "The candidate b1 metadata and seven PASS logs record successful hot-path, configuration, collation, MATCH batching, map concurrency, stopword concurrency and dictionary-prefix regression suites. Their exact outputs and exit codes are retained in comparison.json.", "",
              "The parent reports the **1560-case complete JSON/metadata/warnings/error fixture comparison passed**. This task inspected only the independent original fixture metadata/count: commit `" + fixture["original"]["commit"] + "`, original binary SHA-256 `" + fixture["original"]["binary_sha256"] + "`, and compressed fixture SHA-256 `" + fixture_info["sha256"] + "`. Its workload hash is recorded in comparison.json. The candidate comparison was not rerun and no standalone pass receipt is bundled; that pass remains attributed to the parent. Matching benchmark hit counts alone do not establish correctness.", "",
              "**Native build-1 failed before compilation because `build-settings.json` was missing, as confirmed by the parent. No native tests ran.** This package includes no standalone native failure receipt and makes no native allocator-failure, exact-base-free or returned-node-lifetime correctness claim.", "",
              "## Files and offline verification", "",
              "- `comparison.json`: all six completed runs, nine-metric and class aggregation, per-pair totals, stability observations, correctness provenance and SHA-256 hashes of every input artifact.",
              "- `summarize.py`: standard-library-only offline parser and calculator. It gates report reading on successful completion metadata and writes only comparison.json and README.md in this auxiliary directory. Default mode refuses differing outputs; `--refresh` updates only these two summaries with the final parent-confirmed disposition.",
              "- `README.md`: this human-readable summary. Raw artifacts remain in place and are not copied.", "",
              "From the auxiliary workspace, `.venv/Scripts/python.exe -B -X utf8 setup/fts/round14-json-evidence/summarize.py --check` recomputes all values and compares outputs byte-for-byte without writes. It does not run SQL, builds, native tests or performance workloads. This task made no production/test/CI/benchmark changes, did not change stopword evidence, and did not commit or push.", ""]

    outputs = {"comparison.json": json_bytes(result), "README.md": "\n".join(lines).encode("utf-8")}
    for path, data in inputs.items():
        assert path.read_bytes() == data, "Input changed during summary: " + str(path)
    for name, data in outputs.items():
        path = OUT / name
        assert path.parent == OUT
        if path.exists():
            if path.read_bytes() != data:
                assert args.refresh, "Output differs; use --refresh for an authorized summary update: " + name
                path.write_bytes(data)
        else:
            assert not args.check, "Missing output: " + name
            with path.open("xb") as handle:
                handle.write(data)
    print(json.dumps(dict(status="verified" if args.check else "summarized", completed_pairs=3,
                          control_b3_completion_gate="benchmark/input-validation exit0",
                          class_reductions=aggregate_classes, overall_reduction=overall,
                          per_pair_overall=[pair["overall_reduction"] for pair in pair_results],
                          decision="rejected", raw_artifacts=len(artifacts),
                          output_files={name: len(data) for name, data in outputs.items()}), indent=2))


if __name__ == "__main__":
    main()
