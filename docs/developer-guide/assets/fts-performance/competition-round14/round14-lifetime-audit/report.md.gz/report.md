# FTS Round 14: Token Buffer Lifetime Audit

**结论：No proposal。** 在完整 token 消费链上，没有找到同时满足通用生命周期安全和源码证据支持的明确收益的缓冲区复用方案。

## 范围

依据 seekdb 根目录 `AGENTS.md` 与 `.agents/skills/code-review/SKILL.md`，只读检查 D 盘 checkout 的 FTS parser、DAS 索引行生成、表扫描生成列、`TOKENIZE` 和查询 token 化代码。没有读取凭据；没有执行 Git、构建、SQL 或性能操作。源码 HEAD 未通过 Git 查询。

## Token 的所有权与消费

`ObFTParseHelper::segment()` 建立 parser 参数，逐个调用迭代器，并立即把 token 交给 `ObAddWord::process_word()`；之后 `ObFTWordMap` 仍要被遍历以生成索引行或 JSON (`src/storage/fts/ob_fts_parser_helper.cpp:258`, `:293`, `:383`)。`ObFTWord` 只把地址和长度放进 `ObDatum`，没有取得字符串所有权；map 的 hash、比较和键更新之后仍会读这个地址 (`src/data_plane/api/data_plane/fts/ob_fts_struct.h:30`, `:34`, `:50`; `src/storage/fts/ob_fts_struct.cpp:28`, `:41`)。`groupby_word()` 在 collation 相等时会把 map key 换成最新 token (`src/storage/fts/ob_fts_stop_word.cpp:209`, `:213`)。

各 parser 的字节来源并不统一：whitespace 和 ngram 返回输入全文的切片 (`src/storage/fts/ob_whitespace_ft_parser.cpp:121`; `src/storage/fts/utils/ob_ft_ngram_impl.cpp:147`)；IK token 也保存 `fulltext` 指针 (`src/storage/fts/ik/ob_ik_processor.cpp:183`, `:215`)。Basic English normalizer 则调用 `tolower()`，并把结果分配到 parser 调用方提供的 allocator (`src/share/text_analysis/ob_token_stream.cpp:307`, `:309`, `:312`; `src/storage/fts/ob_beng_ft_parser.cpp:50`)。其 parser iterator 被释放时，map key 所指内容仍须存活到消费者完成。

## 生产到归档的路径

**索引构建与 DML。** `ObFTDMLIterator` 从 stored row 取全文及 doc ID；`read_real_string_data()` 使用该 iterator 的 `allocator_` 物化 LOB。`generate_fulltext_word_rows()` 分词后把 map key 直接设入输出 row datum，并浅拷贝 doc ID (`src/sql/das/ob_das_domain_utils.cpp:1185`, `:1203`, `:1020`, `:1030`, `:277`, `:326`, `:327`)。每个文档的 rows 被取尽之前，`ObDomainDMLIterator` 不会调用 `rows_.reuse()` / `allocator_.reuse()`；新 stored row 只在旧 row 集耗尽后读取 (`src/sql/das/ob_das_domain_utils.cpp:699`, `:700`, `:705`, `:715`)。DAS DML iterator 把这些行交给 domain-index 写入流程 (`src/sql/das/ob_das_dml_ctx_define.cpp:112`, `:126`; `src/sql/das/ob_das_update_op.cpp:389`, `:394`)。因此此路径的 token key、row 和该文档读取的 LOB 共用一个有明确逐文档边界的 arena 生命周期。

**表扫描生成 FTS 列。** `fetch_next_fts_index_rows()` 将全文读入函数局部 `tmp_allocator`，然后调用 `ObFTIndexRowCache::segment()`；cache 的 token helper 和输出 rows 却使用独立 `merge_memctx_`。扫描端之后才逐个取 row 并填入输出表达式；cache 只在下一次 `segment()` 时重置 (`src/sql/engine/table/ob_table_scan_op.cpp:3646`, `:3669`, `:3676`, `:3631`, `:3641`; `src/sql/das/ob_das_domain_utils.cpp:70`, `:91`, `:105`, `:133`, `:138`)。所以扫描输入 LOB 的局部 allocator 在 `fetch_next_fts_index_rows()` 返回时结束，而生成行仍待后续读取。若让 map/row 直接借用 token 输入地址，key 会悬空；DML 路径的 arena 边界不能证明扫描路径安全。

**`TOKENIZE` 与查询 token 化。** `eval_tokenize()` 用 `TempAllocGuard` 覆盖 parse、segment、JSON 创建及结果打包；map 在同一调用内被同步转成 JSON，并在临时 allocator 释放前打包为表达式结果 (`src/sql/engine/expr/ob_expr_tokenize.cpp:53`, `:57`, `:67`, `:78`, `:106`, `:113`; `src/sql/engine/expr/ob_expr_json_func_helper.cpp:2098`, `:2100`)。文本检索 merge、legacy merge 和 optimizer 则遍历 token map，将 token 深拷贝到 query token 数组或常量表达式 (`src/sql/das/iter/ob_das_text_retrieval_merge_iter.cpp:252`, `:257`; `src/observer/composition/retrieval/ob_das_legacy_tr_merge_iter.cpp:1139`, `:1144`; `src/sql/optimizer/ob_join_order.cpp:16728`, `:16734`)。这些消费者同样要求 key 在 map 遍历期间有效。

## 方案判断

- 复用 parser 的单 token 输出缓冲区并让 map key 借用它不安全：map 会保留 key 到分词完成之后；扫描生成列还存在局部 LOB allocator 先于 cache rows 结束的具体路径。
- 把 allocator 在调用间共享或提前 reset 也不能满足上述 key 和输出 row 的存活期。当前 per-document/per-evaluation arena 边界是消费者生命周期的一部分，不能仅凭同属一次请求而扩展。
- 独立 scratch buffer 只有在每个仍被 map/row 使用的 key 被复制到稳定所有者后才安全。此时必须保留新增 key 和当前 collation-equivalent key 替换所需的稳定字节；源码没有证明 scratch 方案能普遍减少这些持久化分配。round9 的 lowercase pre-copy 已被记录为无稳定收益并拒绝 (`docs/developer-guide/assets/fts-performance/competition-round9/round9-decision.json`)；本审查不重提该变体。

因此 round14 不建议提交缓冲区复用改动。安全方案若要成立，需先从实际 profile 证明 token 临时分配是主要成本，再设计明确区分 scratch 与 map/row-owned key storage 的实现；这属于待数据支持的后续实验，不是本轮 proposal。

## 验证边界

这是源代码静态生命周期审查。按请求没有运行构建、SQL 或性能测试；本报告不声称有动态性能或运行时验证。
