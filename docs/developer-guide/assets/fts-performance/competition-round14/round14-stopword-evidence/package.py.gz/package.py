"""Package existing evidence only; no subprocesses, SQL, builds, or source edits.

Run with python -B package.py; --check verifies without writing anything.
Only three outputs in this script's own directory can be created. Existing
outputs must match byte-for-byte; they are never overwritten.
"""
import argparse
import hashlib
import json
import math
import re
from pathlib import Path
from statistics import mean

OUT = Path(__file__).resolve().parent
FTS = OUT.parent
WORKSPACE = FTS.parent.parent
assert OUT.name == "round14-stopword-evidence" and FTS.name == "fts"
COMMIT = "f602f6d7f0b4fc3377b038b67fe622cd04cd2146"
BASELINE = "5bce9e06d1281347ad61344e4b01fab9158c58a2"
HASHES = {
    "control": "58a14c4b3cfb44464882de1d87b0f8018c76595a563e039ff3cbd8be2351f07d",
    "candidate": "1f0bc4f8aab6a381fa33b07ca78953c17c4f51e211bb2fa7cbe1d8eab2aaf78f",
    "invalid_control": "3b0265d960838504f08fa0c5aa75d8882d7b84f5851caf7e635a58d0c406cbaf",
    "official_original": "bae4a3b9e1b4662d4021b28d5adc085764beb6cf02122eacd57b8e16b6fe1762",
}
CLASSES = {
    "build": ["build_ik_all_sec", "build_ik_content_sec", "build_beng_en_sec"],
    "tokenize": ["tokenize_ik_avg_ms", "tokenize_beng_avg_ms"],
    "query": ["query_cn_avg_ms", "query_beng_avg_ms", "query_mixed_avg_ms", "query_limit_avg_ms"],
}
PARAMS = dict(rows=20000, batch=500, rounds=3000, query_rounds=200, samples=3, warmup=30, skip_load=0)
HITS = dict(query_cn_hits=8001, query_beng_hits=11000, query_mixed_hits=7332, query_limit_hits=20)


def json_bytes(value):
    return (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n").encode("utf-8")


def reduction(control, candidate):
    assert control > 0 and candidate > 0 and math.isfinite(control + candidate)
    return (control - candidate) / control


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--check", action="store_true", help="read-only recomputation and hash verification")
    args = ap.parse_args()
    # Deliberately shallow inventory: no runtime data, binaries, secrets, or checkout access.
    paths = sorted(FTS.glob("r14-stopword-*"))
    paths += [FTS / name for name in (
        "round14-stopword-build.log", "round14-control-build.log",
        "build-competition.ps1", "experiment-competition.py", "micro-competition.py",
        "round12-original-stopword-record-4-experiment.json",
        "round12-original-stopword-record-4-stopword-ascii.log",
    )]
    paths += [WORKSPACE / "AGENTS.md"]
    assert len(paths) == len(set(paths))
    raw = {}
    entries = []
    for path in sorted(paths):
        assert path.is_file() and path.suffix in (".json", ".txt", ".log", ".py", ".ps1", ".md")
        assert path.stat().st_size < 200000, "Refuse unexpectedly large input"
        data = path.read_bytes()
        relative = path.relative_to(WORKSPACE).as_posix()
        raw[relative] = data
        name = path.name
        if re.match(r"r14-stopword-(control|candidate)-b[123]-", name):
            role = "valid_matched_full_benchmark"
        elif re.match(r"r14-stopword-(control|candidate)-m[123]-", name):
            role = "valid_matched_micro_diagnostic"
        elif name == "r14-stopword-candidate-micro-stopword-ascii.log":
            role = "candidate_sql_correctness_only"
        elif name.startswith("r14-stopword-"):
            role = "invalid_configuration_mismatched_performance"
        elif name.startswith("round12-original-"):
            role = "historical_official_original_sql_fixture_record"
        elif name.endswith("-build.log"):
            role = "historical_build_output"
        elif name == "AGENTS.md":
            role = "baseline_and_workspace_context_snapshot"
        else:
            role = "auxiliary_build_or_measurement_script_snapshot_not_executed"
        entries.append(dict(path=relative, bytes=len(data), sha256=hashlib.sha256(data).hexdigest(), role=role))

    def read(name):
        return raw["setup/fts/" + name].decode("utf-8-sig")

    def load(name):
        return json.loads(read(name))

    def experiment(label, variant, actions, invalid=False):
        record = load(label + "-experiment.json")
        assert record["label"] == label and record["source_commit"] == COMMIT
        expected_hash = HASHES["invalid_control"] if invalid else HASHES[variant]
        assert record["binary_sha256"] == expected_hash and record["log_level"] == "WARN"
        assert [item["action"] for item in record["actions"]] == actions
        assert all(item["exit_code"] == 0 for item in record["actions"])
        return dict(label=label, experiment=label + "-experiment.json", binary=record["binary"],
                    binary_sha256=record["binary_sha256"], actions=record["actions"])

    reports = {}
    full_pairs = []
    for n in range(1, 4):
        pair = dict(pair=f"b{n}")
        for variant in ("control", "candidate"):
            label = f"r14-stopword-{variant}-b{n}"
            item = experiment(label, variant, ["benchmark", "input-validation"])
            text = read(label + "-report.txt")
            assert text.count("FTS Large Benchmark Report") == 1
            fields = dict(re.findall(r"^([a-zA-Z0-9_]+):\s*(.*?)\s*$", text, re.M))
            assert fields["label"] == label
            for key, value in {**PARAMS, **HITS}.items():
                assert float(fields[key]) == value, (label, key)
            assert "score:" in read(label + "-input-validation.log")
            for keys in CLASSES.values():
                for key in keys:
                    assert float(fields[key]) > 0
            reports[variant, n] = fields
            item.update(report=label + "-report.txt", timestamp_local=fields["timestamp"],
                        report_git_head=fields["git_head"], report_git_dirty=int(fields["git_dirty"]),
                        parameters_match=True, hits_match=True)
            pair[variant] = item
        full_pairs.append(pair)

    metrics = {}
    class_rom, class_pairs = {}, {}
    for category, keys in CLASSES.items():
        for key in keys:
            control = [float(reports["control", n][key]) for n in range(1, 4)]
            candidate = [float(reports["candidate", n][key]) for n in range(1, 4)]
            pair_rates = [reduction(c, t) for c, t in zip(control, candidate)]
            metrics[key] = dict(category=category, unit="sec" if key.endswith("_sec") else "ms",
                                control=control, candidate=candidate,
                                control_mean=mean(control), candidate_mean=mean(candidate),
                                ratio_of_means_reduction=reduction(mean(control), mean(candidate)),
                                pair_reductions=pair_rates, historical_mean_pair_reduction=mean(pair_rates))
        class_rom[category] = mean(metrics[key]["ratio_of_means_reduction"] for key in keys)
        class_pairs[category] = mean(metrics[key]["historical_mean_pair_reduction"] for key in keys)
    for n, pair in enumerate(full_pairs):
        pair["class_reductions"] = {category: mean(metrics[key]["pair_reductions"][n] for key in keys)
                                    for category, keys in CLASSES.items()}
        pair["overall_reduction"] = mean(pair["class_reductions"].values())

    micro_pairs = []
    for n in range(1, 4):
        pair = dict(pair=f"m{n}")
        for variant in ("control", "candidate"):
            label = f"r14-stopword-{variant}-m{n}"
            item = experiment(label, variant, ["micro"])
            sample = load(label + "-micro.json")
            assert sample["purpose"] == "Engine-only diagnostic, not scored wall-clock metrics"
            for parser in ("ik", "beng"):
                assert len(sample[parser + "_us"]) == 3 and all(value > 0 for value in sample[parser + "_us"])
            item.update(samples_us={parser: sample[parser + "_us"] for parser in ("ik", "beng")},
                        mean_us={parser: mean(sample[parser + "_us"]) for parser in ("ik", "beng")})
            pair[variant] = item
        pair["parser_reductions"] = {parser: reduction(pair["control"]["mean_us"][parser],
                                                       pair["candidate"]["mean_us"][parser]) for parser in ("ik", "beng")}
        micro_pairs.append(pair)
    micro_totals = {}
    for parser in ("ik", "beng"):
        c = mean(pair["control"]["mean_us"][parser] for pair in micro_pairs)
        t = mean(pair["candidate"]["mean_us"][parser] for pair in micro_pairs)
        micro_totals[parser] = dict(control_mean_us=c, candidate_mean_us=t,
                                    ratio_of_means_reduction=reduction(c, t),
                                    historical_mean_pair_reduction=mean(pair["parser_reductions"][parser] for pair in micro_pairs))

    invalid_control = experiment("r14-stopword-control-micro", "control", ["micro"], invalid=True)
    invalid_candidate = experiment("r14-stopword-candidate-micro", "candidate", ["stopword-ascii", "micro"])
    sql_log = read("r14-stopword-candidate-micro-stopword-ascii.log").strip()
    assert sql_log == "PASS 2064 complete ordered TOKENIZE/error cases"
    original = load("round12-original-stopword-record-4-experiment.json")
    assert original["source_commit"] == BASELINE and original["binary_sha256"] == HASHES["official_original"]
    assert original["actions"][0]["exit_code"] == 0
    assert "RECORDED 2064 cases" in read("round12-original-stopword-record-4-stopword-ascii.log")

    manifest = dict(schema_version=1, hash_algorithm="SHA-256", path_base="workspace_root",
                    workspace_root=str(WORKSPACE), raw_artifact_count=len(entries),
                    raw_total_bytes=sum(item["bytes"] for item in entries),
                    copies_of_raw_artifacts_created=False,
                    notes=["Hashes cover complete existing file bytes, including original line endings.",
                           "Historical raw files remain at the listed workspace-relative paths; no binaries or logs copied.",
                           "Script/context hashes are packaging-time snapshots, not proof of build-time file contents.",
                           "Native results from other rounds are intentionally not included."], artifacts=entries)
    manifest_data = json_bytes(manifest)
    overall = mean(class_rom.values())
    historical_overall = mean(class_pairs.values())
    summary = dict(
        schema_version=1, experiment="round14 same-collation stopword shortcut", decision="rejected",
        scope="Offline packaging of existing artifacts only; no new measurements or checkout operations.",
        provenance=dict(
            official_baseline_branch="upstream/2026-competition", official_baseline_commit=BASELINE,
            experiment_source_commit_label=COMMIT, binaries_sha256=HASHES,
            build_output_logs=["round14-stopword-build.log", "round14-control-build.log"],
            build_script="build-competition.ps1", harness="experiment-competition.py",
            recorded_build_context="Windows x64 MSVC/Ninja; competition build tree; RelWithDebInfo; unity ON; LLD ON; standby OFF",
            runtime_context_from_harness=dict(sql_port=2891, rpc_port=2892, cpu_count=4, memory_budget="2G", log_disk_size="2G", log_level="WARN"),
            production_stopword_patch_status="restored (task context; not rechecked against the checkout in this packaging task)",
            shortcut_description="Avoid redundant charset conversion and temporary arena work only when input collation equals the stopword collation; retain existing membership lookup.",
            limits=["source_commit is a caller-supplied label; report git_head/git_dirty describe the checkout, not executable provenance.",
                    "Server startup text reports cached revision 1-a2cd7c9cd33973299d325afe11b738700117e671; it does not supersede recorded executable hashes.",
                    "Matched snapshots share the recorded competition build context; this package has no per-run CMakeCache/compile-command receipt or exact temporary stopword source patch.",
                    "No binaries, checkout files, remote branch, or source restoration were re-read or independently reverified here."]),
        full_benchmark=dict(
            pair_order=["b1", "b2", "b3"], parameters=PARAMS, query_hits_all_six_runs=HITS,
            pairs=full_pairs, metrics=metrics,
            primary_aggregation=dict(method="ratio_of_means", metric_formula="(mean(control_b1..b3) - mean(candidate_b1..b3)) / mean(control_b1..b3)",
                                     class_formula="arithmetic mean of metric reductions within each class",
                                     overall_formula="(build_class + tokenize_class + query_class) / 3",
                                     negative_reductions_retained=True, class_reductions=class_rom, overall_reduction=overall),
            historical_aggregation=dict(method="mean_of_pair_ratios", metric_formula="mean_i((control_bi - candidate_bi) / control_bi)",
                                        class_and_overall_weighting="same equal-class arithmetic means as primary method",
                                        negative_reductions_retained=True, class_reductions=class_pairs, overall_reduction=historical_overall),
            auxiliary_observations=["No samples or pairs excluded for noise. Candidate b1 BENG TOKENIZE sample 3 is 0.1821 ms and remains included.",
                                    "Control b2 BENG build is 3.393 sec versus 2.892 sec in b1/b3; the apparent build gain should not be treated as stable causal proof."]),
        micro_diagnostic=dict(scored=False, unit="microseconds per TOKENIZE call", samples_per_parser_per_run=3,
                              iterations_per_sample_from_script=120000, pairs=micro_pairs, aggregate=micro_totals,
                              interpretation="Small aggregate reductions reverse sign in m2 for both parsers; no repeatable full-workload benefit established."),
        invalid_performance_comparisons=[dict(control=invalid_control, candidate=invalid_candidate,
                                             reason="Earlier control used historical build/fts-runtime-candidate; build configuration differs from the competition candidate. Both carry the same caller-supplied commit label, which does not make them matched binaries.",
                                             excluded_from_all_performance_conclusions=True,
                                             sql_correctness_retained="The candidate SQL pass is independent evidence for the exact same candidate binary hash used in valid matched pairs.")],
        correctness=dict(sql_cases=2064, sql_result=sql_log, candidate_sha256=HASHES["candidate"],
                         evidence="r14-stopword-candidate-micro-stopword-ascii.log",
                         official_original_fixture_record="round12-original-stopword-record-4-experiment.json",
                         fixture_record_source_commit=BASELINE, fixture_record_binary_sha256=HASHES["official_original"],
                         claim="Recorded SQL complete ordered TOKENIZE/error comparison passed; query hit counts are auxiliary checks only.",
                         native_correctness_claimed=False,
                         limits="No current-candidate native checker, allocator-failure, raw-byte, or converted-buffer-lifetime correctness is established by this package. Fixture bytes and exact executed test-source snapshot are not included."),
        formal_platform_score=None,
        scoring_note="Existing input-validation logs contain local scores against a fixed baseline from another environment. They establish accepted parameters/metrics, not an official score or the shortcut's benefit.",
        raw_manifest=dict(path="raw-artifacts-manifest.json", sha256=hashlib.sha256(manifest_data).hexdigest(), count=len(entries)),
    )

    lines = [
        "# Round 14 rejected same-collation stopword experiment", "",
        "This package preserves existing local evidence for the rejected shortcut. The stopword production patch has been restored, as stated in the task context. This auxiliary task only read existing workspace files and computed summaries; it did not build, start a database, run SQL/native/performance workloads, access secrets, change the checkout, commit, or push.", "",
        "The primary equal-class reduction is **{:+.6f}%**: build **{:+.6f}%**, tokenize **{:+.6f}%**, query **{:+.6f}%**. Positive means less time; negative means regression. These measurements do not establish a repeatable overall benefit. There is no new official platform score.".format(overall * 100, *(class_rom[k] * 100 for k in CLASSES)), "",
        "## Included matched evidence", "",
        "All paths below refer to existing files in `setup/fts` unless stated otherwise. No raw logs or binaries were copied. The summary stores all nine report metric values and all micro samples; the manifest hashes every complete raw input file.", "",
        "| Pair | Control label | Candidate label |", "| --- | --- | --- |",
    ]
    for prefix in ("b", "m"):
        for n in range(1, 4):
            lines.append(f"| {prefix}{n} | `r14-stopword-control-{prefix}{n}` | `r14-stopword-candidate-{prefix}{n}` |")
    lines += ["", "The six full runs all completed benchmark and input-validation actions with exit code 0. All use ROWS=20000, BATCH=500, ROUNDS=3000, QUERY_ROUNDS=200, SAMPLES=3, WARMUP=30, SKIP_LOAD=0. Query hits agree in all six reports: CN=8001, BENG=11000, mixed=7332, LIMIT=20. Hits alone do not prove correctness.", "",
              "## Calculation", "",
              "For each of the nine metrics, first take the arithmetic mean across b1/b2/b3 separately for control and candidate. Compute `(control_mean - candidate_mean) / control_mean`. Average the three build metrics, two tokenize metrics, and four query metrics within their classes, then average those three class results with weight 1/3 each. All negative values are retained. This is not an unweighted average of nine metrics. Calculations use saved report precision with no intermediate rounding; displayed percentages are rounded.", "",
              "| Metric | Unit | Control mean | Candidate mean | Reduction |",
              "| --- | --- | ---: | ---: | ---: |"]
    for key, value in metrics.items():
        lines.append(f"| `{key}` | {value['unit']} | {value['control_mean']:.9f} | {value['candidate_mean']:.9f} | {value['ratio_of_means_reduction'] * 100:+.6f}% |")
    lines += ["", "The historical calculation instead averages the three per-pair reductions `(control_bi - candidate_bi) / control_bi` for each metric, then uses the same equal-class weighting. Its overall result is **{:+.6f}%** (build {:+.6f}%, tokenize {:+.6f}%, query {:+.6f}%). It differs because ratios and averaging do not commute; it is retained for traceability, not substituted for the primary ratio-of-means result.".format(historical_overall * 100, *(class_pairs[k] * 100 for k in CLASSES)), "",
              "No noisy result was dropped. In particular, candidate b1 BENG TOKENIZE includes the 0.1821 ms third sample; control b2 BENG build is 3.393 sec compared with 2.892 sec in control b1/b3. These variations limit causal interpretation of small changes.", "",
              "## Micro diagnostics", "",
              "The saved micro script uses SQL BENCHMARK with 120000 TOKENIZE calls per sample, three samples per parser per run. These are diagnostic microseconds per call, excluded from scoring. It is still an end-to-end SQL statement around repeated server evaluations; it is not a direct checker-only timer.", "",
              "| Pair | IK control/candidate mean (us) | IK reduction | BENG control/candidate mean (us) | BENG reduction |",
              "| --- | ---: | ---: | ---: | ---: |"]
    for pair in micro_pairs:
        c, t = pair["control"]["mean_us"], pair["candidate"]["mean_us"]
        lines.append(f"| {pair['pair']} | {c['ik']:.6f} / {t['ik']:.6f} | {pair['parser_reductions']['ik'] * 100:+.6f}% | {c['beng']:.6f} / {t['beng']:.6f} | {pair['parser_reductions']['beng'] * 100:+.6f}% |")
    lines += ["", f"Pooling equal-size samples across m1/m2/m3 gives IK {micro_totals['ik']['ratio_of_means_reduction'] * 100:+.6f}% and BENG {micro_totals['beng']['ratio_of_means_reduction'] * 100:+.6f}%. Both parsers regress in m2; this does not override the full-workload regression.", "",
              "## Explicitly invalid early performance comparison", "",
              "`r14-stopword-control-micro` versus `r14-stopword-candidate-micro` is **invalid for performance comparison** because the control used historical `build/fts-runtime-candidate/seekdb.exe` rather than the matched competition build configuration. It is excluded from every performance aggregate and conclusion. The raw files remain listed and hashed. The candidate's separate SQL correctness log remains usable because its executable hash is identical to the candidate in the six valid pairs.", "",
              "## Provenance and correctness limits", "",
              f"Official baseline context: `upstream/2026-competition` at `{BASELINE}`. Experiment source label: `{COMMIT}`. This task did not query Git or reverify remote ancestry.", "",
              f"- Matched control SHA-256: `{HASHES['control']}`.",
              f"- Candidate SHA-256: `{HASHES['candidate']}`.",
              f"- Invalid historical control SHA-256: `{HASHES['invalid_control']}`.",
              f"- Official-original SQL fixture record binary SHA-256: `{HASHES['official_original']}`.", "",
              "Both valid snapshot paths and hashes are recorded in experiment JSON. Build logs (`round14-stopword-build.log`, `round14-control-build.log`) and `build-competition.ps1` describe the competition build route: Windows x64, MSVC/Ninja, RelWithDebInfo, unity ON, LLD ON, standby OFF. The current harness snapshot uses isolated SQL 2891/RPC 2892, CPU 4, memory/log budgets 2G. These are supporting recorded contexts; the package does not contain per-run CMakeCache/compile-command receipts or the exact temporary stopword patch. Packaging-time script hashes do not certify historical file contents.", "",
              "The shortcut intended to avoid redundant charset conversion and temporary arena work for identical collations while retaining the existing membership lookup. The commit label is caller-supplied; benchmark `git_head`/`git_dirty` describe the checkout and are not binary identity. Startup logs emit cached source revision `1-a2cd7c9cd33973299d325afe11b738700117e671`; executable hashes are preserved separately rather than treating that string as the measured source commit.", "",
              "Correctness evidence is limited to **2064 complete ordered TOKENIZE/error SQL cases**, recorded as passing in `r14-stopword-candidate-micro-stopword-ascii.log`. The associated experiment records the same candidate binary hash as all valid pairs. The historical official-original fixture record is `round12-original-stopword-record-4-experiment.json` with its accompanying 2064-case recording log. Fixture bytes and an exact snapshot of the executed SQL test are not bundled here. **No native correctness is claimed** for this shortcut; native checker, allocation-failure, raw-byte and converted-buffer-lifetime behavior were not established by these SQL results. Native evidence from different rounds is not attributed to this candidate.", "",
              "The existing input-validation logs print local scores against the fixed baseline, including 100/100. They show accepted report parameters/metrics on this machine; they are not official platform scores and do not show that this shortcut improved performance. No formal score is calculated in this package.", "",
              "## Files and offline verification", "",
              "- `summary.json`: raw metric vectors, pair identities, formulas, both aggregation conventions, micro samples, invalid comparison, and claim limits.",
              "- `raw-artifacts-manifest.json`: workspace-relative paths, byte sizes, SHA-256 hashes, and evidence roles for all raw inputs; raw files stay in place.",
              "- `package.py`: offline packaging/recomputation code. It imports only Python's standard library, has no subprocess or network calls, and can create only these three output files in its own directory. It refuses to overwrite differing outputs.", "",
              "From this auxiliary workspace, run `.venv/Scripts/python.exe -B -X utf8 setup/fts/round14-stopword-evidence/package.py --check` to recompute every result and compare all three output files byte-for-byte without writes. It does not run any experiment. Preserve the raw files at their listed paths for verification. The manifest hash recorded in summary.json ties that summary to the raw artifact list.", ""]
    outputs = {"summary.json": json_bytes(summary), "README.md": "\n".join(lines).encode("utf-8"),
               "raw-artifacts-manifest.json": manifest_data}
    # Check all inputs are unchanged between initial read and output creation.
    for relative, data in raw.items():
        assert (WORKSPACE / relative).read_bytes() == data, "Input changed while packaging: " + relative
    for name, data in outputs.items():
        path = OUT / name
        assert path.parent == OUT
        if path.exists():
            assert path.read_bytes() == data, "Output differs; refusing overwrite: " + name
        else:
            assert not args.check, "Missing output: " + name
            with path.open("xb") as handle:
                handle.write(data)
    print(json.dumps(dict(status="verified" if args.check else "packaged", raw_artifacts=len(entries),
                          raw_bytes=manifest["raw_total_bytes"], overall_ratio_of_means=overall,
                          historical_mean_of_pair_ratios=historical_overall,
                          output_files={name: len(data) for name, data in outputs.items()}), indent=2))


if __name__ == "__main__":
    main()
