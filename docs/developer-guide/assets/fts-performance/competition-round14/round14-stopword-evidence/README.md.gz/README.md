# Round 14 rejected same-collation stopword experiment

This package preserves existing local evidence for the rejected shortcut. The stopword production patch has been restored, as stated in the task context. This auxiliary task only read existing workspace files and computed summaries; it did not build, start a database, run SQL/native/performance workloads, access secrets, change the checkout, commit, or push.

The primary equal-class reduction is **-1.075660%**: build **+1.760096%**, tokenize **-2.707820%**, query **-2.279255%**. Positive means less time; negative means regression. These measurements do not establish a repeatable overall benefit. There is no new official platform score.

## Included matched evidence

All paths below refer to existing files in `setup/fts` unless stated otherwise. No raw logs or binaries were copied. The summary stores all nine report metric values and all micro samples; the manifest hashes every complete raw input file.

| Pair | Control label | Candidate label |
| --- | --- | --- |
| b1 | `r14-stopword-control-b1` | `r14-stopword-candidate-b1` |
| b2 | `r14-stopword-control-b2` | `r14-stopword-candidate-b2` |
| b3 | `r14-stopword-control-b3` | `r14-stopword-candidate-b3` |
| m1 | `r14-stopword-control-m1` | `r14-stopword-candidate-m1` |
| m2 | `r14-stopword-control-m2` | `r14-stopword-candidate-m2` |
| m3 | `r14-stopword-control-m3` | `r14-stopword-candidate-m3` |

The six full runs all completed benchmark and input-validation actions with exit code 0. All use ROWS=20000, BATCH=500, ROUNDS=3000, QUERY_ROUNDS=200, SAMPLES=3, WARMUP=30, SKIP_LOAD=0. Query hits agree in all six reports: CN=8001, BENG=11000, mixed=7332, LIMIT=20. Hits alone do not prove correctness.

## Calculation

For each of the nine metrics, first take the arithmetic mean across b1/b2/b3 separately for control and candidate. Compute `(control_mean - candidate_mean) / control_mean`. Average the three build metrics, two tokenize metrics, and four query metrics within their classes, then average those three class results with weight 1/3 each. All negative values are retained. This is not an unweighted average of nine metrics. Calculations use saved report precision with no intermediate rounding; displayed percentages are rounded.

| Metric | Unit | Control mean | Candidate mean | Reduction |
| --- | --- | ---: | ---: | ---: |
| `build_ik_all_sec` | sec | 6.587000000 | 6.552333333 | +0.526289% |
| `build_ik_content_sec` | sec | 4.974333333 | 5.008333333 | -0.683509% |
| `build_beng_en_sec` | sec | 3.059000000 | 2.892666667 | +5.437507% |
| `tokenize_ik_avg_ms` | ms | 0.142366667 | 0.144100000 | -1.217513% |
| `tokenize_beng_avg_ms` | ms | 0.110366667 | 0.115000000 | -4.198127% |
| `query_cn_avg_ms` | ms | 1.015933333 | 1.066066667 | -4.934707% |
| `query_beng_avg_ms` | ms | 1.270500000 | 1.331766667 | -4.822248% |
| `query_mixed_avg_ms` | ms | 1.076133333 | 1.088333333 | -1.133689% |
| `query_limit_avg_ms` | ms | 2.249633333 | 2.209733333 | +1.773622% |

The historical calculation instead averages the three per-pair reductions `(control_bi - candidate_bi) / control_bi` for each metric, then uses the same equal-class weighting. Its overall result is **-1.350677%** (build +1.571349%, tokenize -3.208586%, query -2.414794%). It differs because ratios and averaging do not commute; it is retained for traceability, not substituted for the primary ratio-of-means result.

No noisy result was dropped. In particular, candidate b1 BENG TOKENIZE includes the 0.1821 ms third sample; control b2 BENG build is 3.393 sec compared with 2.892 sec in control b1/b3. These variations limit causal interpretation of small changes.

## Micro diagnostics

The saved micro script uses SQL BENCHMARK with 120000 TOKENIZE calls per sample, three samples per parser per run. These are diagnostic microseconds per call, excluded from scoring. It is still an end-to-end SQL statement around repeated server evaluations; it is not a direct checker-only timer.

| Pair | IK control/candidate mean (us) | IK reduction | BENG control/candidate mean (us) | BENG reduction |
| --- | ---: | ---: | ---: | ---: |
| m1 | 31.589538 / 30.570783 | +3.224977% | 9.292599 / 8.860319 | +4.651868% |
| m2 | 30.569548 / 30.679804 | -0.360674% | 8.977315 / 9.179071 | -2.247393% |
| m3 | 30.684116 / 30.629087 | +0.179340% | 9.204198 / 8.976806 | +2.470530% |

Pooling equal-size samples across m1/m2/m3 gives IK +1.037801% and BENG +1.666719%. Both parsers regress in m2; this does not override the full-workload regression.

## Explicitly invalid early performance comparison

`r14-stopword-control-micro` versus `r14-stopword-candidate-micro` is **invalid for performance comparison** because the control used historical `build/fts-runtime-candidate/seekdb.exe` rather than the matched competition build configuration. It is excluded from every performance aggregate and conclusion. The raw files remain listed and hashed. The candidate's separate SQL correctness log remains usable because its executable hash is identical to the candidate in the six valid pairs.

## Provenance and correctness limits

Official baseline context: `upstream/2026-competition` at `5bce9e06d1281347ad61344e4b01fab9158c58a2`. Experiment source label: `f602f6d7f0b4fc3377b038b67fe622cd04cd2146`. This task did not query Git or reverify remote ancestry.

- Matched control SHA-256: `58a14c4b3cfb44464882de1d87b0f8018c76595a563e039ff3cbd8be2351f07d`.
- Candidate SHA-256: `1f0bc4f8aab6a381fa33b07ca78953c17c4f51e211bb2fa7cbe1d8eab2aaf78f`.
- Invalid historical control SHA-256: `3b0265d960838504f08fa0c5aa75d8882d7b84f5851caf7e635a58d0c406cbaf`.
- Official-original SQL fixture record binary SHA-256: `bae4a3b9e1b4662d4021b28d5adc085764beb6cf02122eacd57b8e16b6fe1762`.

Both valid snapshot paths and hashes are recorded in experiment JSON. Build logs (`round14-stopword-build.log`, `round14-control-build.log`) and `build-competition.ps1` describe the competition build route: Windows x64, MSVC/Ninja, RelWithDebInfo, unity ON, LLD ON, standby OFF. The current harness snapshot uses isolated SQL 2891/RPC 2892, CPU 4, memory/log budgets 2G. These are supporting recorded contexts; the package does not contain per-run CMakeCache/compile-command receipts or the exact temporary stopword patch. Packaging-time script hashes do not certify historical file contents.

The shortcut intended to avoid redundant charset conversion and temporary arena work for identical collations while retaining the existing membership lookup. The commit label is caller-supplied; benchmark `git_head`/`git_dirty` describe the checkout and are not binary identity. Startup logs emit cached source revision `1-a2cd7c9cd33973299d325afe11b738700117e671`; executable hashes are preserved separately rather than treating that string as the measured source commit.

Correctness evidence is limited to **2064 complete ordered TOKENIZE/error SQL cases**, recorded as passing in `r14-stopword-candidate-micro-stopword-ascii.log`. The associated experiment records the same candidate binary hash as all valid pairs. The historical official-original fixture record is `round12-original-stopword-record-4-experiment.json` with its accompanying 2064-case recording log. Fixture bytes and an exact snapshot of the executed SQL test are not bundled here. **No native correctness is claimed** for this shortcut; native checker, allocation-failure, raw-byte and converted-buffer-lifetime behavior were not established by these SQL results. Native evidence from different rounds is not attributed to this candidate.

The existing input-validation logs print local scores against the fixed baseline, including 100/100. They show accepted report parameters/metrics on this machine; they are not official platform scores and do not show that this shortcut improved performance. No formal score is calculated in this package.

## Files and offline verification

- `summary.json`: raw metric vectors, pair identities, formulas, both aggregation conventions, micro samples, invalid comparison, and claim limits.
- `raw-artifacts-manifest.json`: workspace-relative paths, byte sizes, SHA-256 hashes, and evidence roles for all raw inputs; raw files stay in place.
- `package.py`: offline packaging/recomputation code. It imports only Python's standard library, has no subprocess or network calls, and can create only these three output files in its own directory. It refuses to overwrite differing outputs.

From this auxiliary workspace, run `.venv/Scripts/python.exe -B -X utf8 setup/fts/round14-stopword-evidence/package.py --check` to recompute every result and compare all three output files byte-for-byte without writes. It does not run any experiment. Preserve the raw files at their listed paths for verification. The manifest hash recorded in summary.json ties that summary to the raw artifact list.
