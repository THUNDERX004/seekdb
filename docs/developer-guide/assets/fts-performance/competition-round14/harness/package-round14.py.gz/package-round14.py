"""Archive measured rejected experiments and the independent original fixture."""
from pathlib import Path
import ast
import gzip
import hashlib
import importlib.util
import json
import shutil

HERE = Path(__file__).resolve().parent
ROOT = Path(r"D:\Projects\OceanBase\seekdb")
DEST = ROOT / "docs/developer-guide/assets/fts-performance/competition-round14"
if DEST.exists():
    raise FileExistsError(DEST)
DEST.mkdir()
entries = []

def sha(data):
    return hashlib.sha256(data).hexdigest()

def archive(path, rel):
    raw = path.read_bytes()
    target_rel = str(rel).replace("\\", "/")
    packed = len(raw) > 4096 and path.suffix != ".gz"
    encoded = gzip.compress(raw, mtime=0) if packed else raw
    if packed:
        target_rel += ".gz"
    target = DEST / target_rel
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(encoded)
    entries.append(dict(path=target_rel, source=str(path), source_bytes=len(raw),
                        source_sha256=sha(raw), bytes=len(encoded), sha256=sha(encoded), gzip=packed))

for pattern in ("r14-*.json", "r14-*.log", "r14-*-report.txt", "round14-*-build.log"):
    for path in sorted(HERE.glob(pattern)):
        archive(path, Path("raw") / path.name)
for dirname in ("round14-stopword-evidence", "round14-json-evidence", "round14-tokenize-proposal",
                "round14-json-native", "round14-lifetime-audit", "round14-profile-audit"):
    for path in sorted((HERE / dirname).rglob("*")):
        if path.is_file() and "__pycache__" not in path.parts:
            archive(path, Path(dirname) / path.relative_to(HERE / dirname))
for name in ("build-competition.ps1", "experiment-competition.py", "micro-competition.py", "package-round14.py"):
    archive(HERE / name, Path("harness") / name)

test = ROOT / "unittest/storage/fts/test_tokenize_json_nodes.py"
ast.parse(test.read_text(encoding="utf-8"))
spec = importlib.util.spec_from_file_location("r14_definition", test)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
fixture = HERE / "r14-original-tokenize-json-nodes.json.gz"
original = json.loads(gzip.decompress(fixture.read_bytes()))
assert original["original"]["commit"] == module.OFFICIAL
assert original["original"]["binary_sha256"] == "bae4a3b9e1b4662d4021b28d5adc085764beb6cf02122eacd57b8e16b6fe1762"
assert len(original["results"]) == 1560
assert original["workload_sha256"] == module.workload_hash(list(module.cases()))
fixture_target = test.with_name("tokenize_json_nodes_expected.json.gz")
if fixture_target.exists():
    raise FileExistsError(fixture_target)
shutil.copyfile(fixture, fixture_target)

validation = {
    "date": "2026-11-04", "parent_commit": "f602f6d7f0b4fc3377b038b67fe622cd04cd2146",
    "decision": "Both production experiments rejected and restored before the next experiment",
    "json_candidate_binary_sha256": "104a228d0c9f6b26087824d7ff4a10d3d96f1398a617a1e500f9d9bae54a2321",
    "json_sql_original_record": {"label": "r14-json-original-complete", "cases": 1560,
        "binary_sha256": original["original"]["binary_sha256"], "exit_code": 0},
    "json_sql_candidate_compare": {"label": "r14-json-candidate-complete", "cases": 1560, "exit_code": 0,
        "comparison": "complete ordered JSON, metadata, warnings and SQL errors"},
    "fixture": {"path": str(fixture_target.relative_to(ROOT)), "sha256": sha(fixture.read_bytes()),
        "workload_sha256": original["workload_sha256"]},
    "fixture_corrections_before_successful_original_record": [
        "ASCII alias prevents original-server truncation of expression field names inside UTF8",
        "VARCHAR(32768) input retains full corpus; original IK rejects LONGTEXT locators with 1210",
        "Boolean column metadata is serialized explicitly",
        "Only IK untyped NULL retains original 1235 unsupported binary-charset error"
    ],
    "native_status": "Build attempt failed before compile/link because build-settings.json was absent; no native runtime or native byte differential",
    "native_draft_limit": "Archived README describes intended capture, not an accomplished capture; no build-settings.json exists",
    "source_restore_check": "git diff --exit-code for JSON helper, JSON header and stopword cpp passed before round15 edits",
    "stopword_exact_source_limit": "No exact round14 stopword patch was saved; binary identities and measurements survive, so this rejected experiment is not fully source-reproducible",
    "formal_score": "Only user-provided 21.099191573256494/100 (10.549595786628247/50) exists; no new formal evaluation",
    "parameter_and_metric_validation": "Six complete reports per experiment, unchanged official workload; retain all negative reductions"
}
(DEST / "validation.json").write_text(json.dumps(validation, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
manifest = {"schema_version": 1, "files": entries, "validation_sha256": sha((DEST/"validation.json").read_bytes())}
(DEST / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
for item in entries:
    stored = (DEST / item["path"]).read_bytes()
    assert sha(stored) == item["sha256"]
    assert sha(gzip.decompress(stored) if item["gzip"] else stored) == item["source_sha256"]
print("PACKAGED", len(entries), "artifacts; original fixture SHA256", sha(fixture.read_bytes()))
