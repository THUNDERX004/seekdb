param([string]$Label = 'competition-candidate', [switch]$SkipConfigure)
$ErrorActionPreference = 'Stop'
$env:PYTHONUTF8 = '1'
Import-Module 'C:\Program Files\Microsoft Visual Studio\2022\BuildTools\Common7\Tools\Microsoft.VisualStudio.DevShell.dll'
Enter-VsDevShell -VsInstallPath 'C:\Program Files\Microsoft Visual Studio\2022\BuildTools' -SkipAutomaticLocation -DevCmdArguments '-arch=amd64 -host_arch=amd64'
$env:CXX_x86_64_pc_windows_msvc = (Get-Command cl.exe).Source
$ftsCheckout = 'D:\Projects\OceanBase\seekdb'
$ftsTools = Join-Path $ftsCheckout 'deps\3rd\tools'
$ftsCMake = 'C:\Program Files\Microsoft Visual Studio\2022\BuildTools\Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin\cmake.exe'
$ftsNinjaDir = 'C:\Program Files\Microsoft Visual Studio\2022\BuildTools\Common7\IDE\CommonExtensions\Microsoft\CMake\Ninja'
$env:PATH = "C:\Windows\Sysnative\WindowsPowerShell\v1.0;C:\Windows\System32\WindowsPowerShell\v1.0;$ftsTools\llvm18\bin;$ftsTools\win_flex_bison;$ftsNinjaDir;C:\Users\11946\.cargo\bin;C:\Users\11946\anaconda3;" + $env:PATH
Set-Location -LiteralPath $ftsCheckout
$ftsArgs = @(
    '-S', $ftsCheckout,
    '-B', "$ftsCheckout\build_fts_competition",
    '-G', 'Ninja',
    '-DCMAKE_BUILD_TYPE=RelWithDebInfo',
    '-DCMAKE_EXPORT_COMPILE_COMMANDS=ON',
    '-DOB_ENABLE_UNITY=ON',
    '-DOB_USE_LLD=ON',
    '-DOB_ENABLE_STANDBY=OFF',
    "-DOB_VCPKG_DIR=$ftsCheckout\deps\3rd\vcpkg\x64-windows",
    "-DOB_OPENSSL_DIR=$ftsCheckout\deps\3rd\openssl",
    "-DOB_LLVM_DIR=$ftsTools\llvm18",
    "-DPWSH_EXE=$((Get-Process -Id $PID).Path)",
    '-DOB_BUILD_PACKAGE=OFF',
    '-DOB_BUILD_RPM=OFF',
    '-DOB_BUILD_DEB=OFF',
    '-DOB_BUILD_TGZ=OFF',
    '-DOB_BUILD_WIX=OFF'
)
$ErrorActionPreference = 'Continue'
if (-not $SkipConfigure) {
    & $ftsCMake @ftsArgs 2>&1 | Tee-Object -FilePath (Join-Path $PSScriptRoot ($Label + '-configure.log'))
    if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
}
& $ftsCMake --build "$ftsCheckout\build_fts_competition" --target seekdb --parallel 4 2>&1 | Tee-Object -FilePath (Join-Path $PSScriptRoot ($Label + '-build.log'))
exit $LASTEXITCODE
