"""Engine-only diagnostics, excluded from competition scores."""
import argparse
import json
from pathlib import Path
import time
import pymysql

p=argparse.ArgumentParser()
p.add_argument('--label',required=True)
a=p.parse_args()
texts={
 'ik':'OceanBase是一款非常稳定的数据库，全文索引的分词器热路径优化包括解析器实例复用、停用词全局单例、内存池化数据结构等技术，在大量文档索引和查询场景下可以显著降低 CPU 开销。',
 'beng':'The quick brown fox jumps over the lazy dog. Full-text search indexing requires efficient tokenization on the hot path.'}
results={}
with pymysql.connect(host='127.0.0.1',port=2891,user='root',charset='utf8mb4',autocommit=True) as conn:
    with conn.cursor() as cur:
        cur.execute('SET ob_query_timeout=100000000000')
        for parser,text in texts.items():
            cur.execute('SELECT TOKENIZE(%s,%s) AS tokens',(text,parser)); cur.fetchall()
            values=[]
            for _ in range(3):
                start=time.perf_counter()
                cur.execute('SELECT BENCHMARK(120000,TOKENIZE(CONCAT(%s,SUBSTR(RAND(),1,0)),%s)) AS parser_work',(text,parser))
                assert cur.fetchone()==(0,)
                values.append((time.perf_counter()-start)*1e6/120000)
            results[parser+'_us']=values
results['purpose']='Engine-only diagnostic, not scored wall-clock metrics'
Path(__file__).with_name(a.label+'-micro.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
print(json.dumps(results,indent=2))
