"""Run the staged round14 SQL regression against one isolated local binary."""
import argparse
import os
from pathlib import Path
import socket
import subprocess
import time


ROOT = Path(r"D:\Projects\OceanBase\seekdb")
BASE_ROOT = Path(r"C:\Users\11946\AppData\Local\Temp")
PYTHON = Path(r"C:\Users\11946\Documents\ChatGPT\OceanBase比赛\.venv\Scripts\python.exe")
HERE = Path(__file__).resolve().parent
TEST = HERE / "unittest" / "storage" / "fts" / "test_tokenize_json_nodes.py"
PORT = 2891


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--binary", required=True, type=Path)
    parser.add_argument("--label", required=True)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--record", type=Path)
    mode.add_argument("--expected", type=Path)
    parser.add_argument("--source-commit", required=True)
    parser.add_argument("--probe", action="store_true")
    args = parser.parse_args()
    binary = args.binary.resolve()
    output = HERE / (args.label + "-server.log")
    if output.exists():
        raise FileExistsError(output)
    if args.record is not None and args.record.exists():
        raise FileExistsError(args.record)
    with socket.socket() as check:
        if check.connect_ex(("127.0.0.1", PORT)) == 0:
            raise RuntimeError("Dedicated SQL port 2891 is occupied")

    base_dir = BASE_ROOT / ("fts_r14_" + args.label.replace("-", "_"))
    command = [str(binary), "--nodaemon", "--base-dir=" + str(base_dir),
               "--port=2891", "--parameter", "rpc_port=2892", "--parameter",
               "cpu_count=4", "--parameter", "memory_budget=2G", "--parameter",
               "log_disk_size=2G", "--log-level=WARN"]
    environment = os.environ.copy()
    environment.update(PYTHONUTF8="1", PYTHONIOENCODING="utf-8")
    environment.pop("SEEKDB_TEST_PASSWORD", None)
    with output.open("x", encoding="utf-8") as log:
        process = subprocess.Popen(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT,
                                   creationflags=subprocess.CREATE_NO_WINDOW)
        try:
            import pymysql
            for _ in range(120):
                if process.poll() is not None:
                    raise RuntimeError("Isolated seekdb exited: " + str(process.returncode))
                try:
                    with pymysql.connect(host="127.0.0.1", port=PORT, user="root",
                                         connect_timeout=1, charset="utf8mb4") as connection:
                        with connection.cursor() as cursor:
                            cursor.execute("SELECT 1")
                            if cursor.fetchone() != (1,):
                                raise RuntimeError("Readiness query mismatch")
                    break
                except (OSError, pymysql.MySQLError):
                    time.sleep(1)
            else:
                raise TimeoutError("Isolated seekdb did not become ready")

            command = [str(PYTHON), "-X", "utf8", str(TEST), "--port", str(PORT)]
            if args.probe:
                command = [str(PYTHON), "-X", "utf8", str(HERE / "probe_original.py")]
            elif args.record is not None:
                command += ["--record", str(args.record), "--record-source-commit",
                            args.source_commit, "--record-source-binary-sha256",
                            __import__("hashlib").sha256(binary.read_bytes()).hexdigest()]
            else:
                command += ["--expected", str(args.expected)]
            result = subprocess.run(command, cwd=ROOT, env=environment, check=False)
            if result.returncode:
                raise subprocess.CalledProcessError(result.returncode, command)
        finally:
            if process.poll() is None:
                process.terminate()
                try:
                    process.wait(timeout=20)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait()
    print("PASS isolated TOKENIZE fixture run:", args.label)


if __name__ == "__main__":
    main()
