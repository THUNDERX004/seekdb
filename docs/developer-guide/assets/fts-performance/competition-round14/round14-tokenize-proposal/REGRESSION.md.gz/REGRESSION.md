# round14 regression design — staged, not executed

Use the same workload definitions on an independently verified official original
and candidate. Keep fixtures outside this proposal directory. Recording candidate
results, changing evaluation SQL, or changing the performance workload is not a
validation method. The existing FTS regression suites remain unchanged.

## SQL differential already staged

Script: `unittest/storage/fts/test_tokenize_json_nodes.py`, 1560 statements and 257
varying input rows in a dedicated database. Its exact workload hash is recorded
by `static-audit.json`; no expected-results file is supplied.

| Dimension | Coverage and required observation |
| --- | --- |
| Output shape | DEFAULT array and ALL object, exact token array order, retained spelling, per-token counts, doc_len, object key order, result metadata and warnings. Compare complete bytes, not token sets or aggregate checksums. |
| Unique count | Input-generated distinct words at 0/1/2/3/7/8/15/16/31/32/63/64/127/128/255/256/257/511/512/513/997/998/1023/1024/1025/4097; actual U depends on parser and stopwords. Space/BENG provide transparent unique-word cases. Repetition and reverse repetition distinguish U from doc_len. |
| Parsers | space, beng, ik, ngram, ngram2, default parser, nullable parser, trimmed/case-varied names, invalid and version-suffixed names. |
| Token data | Empty/NULL fulltext, whitespace, stopword-only, one token, 2049 repetitions, 1..86-byte/character length cases, signed digit/punctuation strings, quotes/backslashes/control characters, NUL, case/accent equivalence, combining marks, CJK and supplementary code points, width forms. |
| Charset/collation | utf8mb4 binary/general/unicode collation; fixed latin1, gbk, utf16 conversion inputs and malformed UTF8 conversion/error inputs. Compare exact warnings/error results to original; no charset implementation is changed. |
| Attributes | Omitted/empty/default/all, multiple output options, additional_args empty/nonempty, min/max/ngram/IK boundary properties, invalid numeric/string/null/boolean values, unknown properties and top-level options, malformed shapes, duplicate properties, overwritten additional_args and competing errors. No third-argument SQL NULL is required by this result-builder test. |
| JSON consumers | Direct return, JSON_ARRAY, JSON_OBJECT, JSON_LENGTH, JSON_EXTRACT for array/object shapes, JSON_KEYS and typed JSON options. Capture all complete values and metadata. |
| Lifetime | 257 rows with changing parser/text/output, two independent results per row, rowset hints 1/256, INSERT of each JSON into a JSON column followed by full readback, repeated prepared execution changing parser/config. SQL hints alone do not establish execution-path coverage. |
| Failure behavior | Required valid cases fail immediately on SQL errors. Only explicitly designated property/parser/charset cases may return a server SQL error; code, message and SHOW WARNINGS must equal the original. Connection/client failures are never accepted as expected errors. |

Run original recording once (explicit new path and verified provenance), optionally
repeat against the original to establish deterministic complete output, then use
that identical fixture for the candidate. If the official build does not support
a designated success case, report that blocker; do not silently skip, weaken or
replace it with candidate expected results. Review varying-row/prepared/consumer
plans if execution mode coverage is material to acceptance.

## Focused native tests still required from the parent

These are test designs, not compiled artifacts or a copied comparator/serializer.
Link the **real** `ObFTParseHelper::make_*_json`, JSON classes and serializer.
Use a real word map whose key storage has a separate, sufficiently long lifetime.
Do not reimplement production logic in a Python or extracted C++ model.

1. **Result identity and lifetime.** Populate maps with U=0/1/2/31/257/1025,
   including escaped/NUL/Unicode keys and repeated counts. Initialize a real
   helper and serialize the returned tree only after the builder returns.
   Compare complete print and binary results with independently obtained original
   results. Traverse real parent pointers/types/counts, then perform normal
   JSON extraction/packing. Include caller-supplied count extrema if testing the
   public builder directly, without assuming doc_len must equal U.

2. **Exact-base allocation ownership.** Supply a tracking arena-compatible
   `ObIAllocator` which records each allocation base/range and rejects interior
   frees. Verify that cleanup after failure never individually frees embedded
   object/int members or scalar slots, and never destroys unconstructed records.
   After successful serialization, reset the arena to release all tracked blocks;
   do not recursively delete successful children, because the production caller
   already uses arena lifetime. Check destructor/accounting correctness with a
   standard memory-checking build when available to the parent.

3. **Failure sweep.** For U=1/2/31 in each mode, determine the candidate's complete
   sequence of allocation attempts using the tracker, then fail each attempt once.
   Exercise root/count/array creation, block allocation, pointer reserve,
   per-object pair storage and root member storage. Require the expected failure
   code and an unchanged output-root sentinel; clear the arena afterward and
   verify no outstanding tracked blocks. Allocation ordinal identities need not
   match the old code. Add success after each failure with a fresh helper/arena,
   and one serialization/result-copy failure after successful builder return.

4. **Capacity-only reserve.** On an actual `ObJsonArray`, reserve 0, a small count,
   then a larger count. Verify no element, parent, JSON length or serialized value
   changes before append. Appending ordinary individually allocated nodes must
   still work. Reject negative/overflowing counts without allocation. The patched
   call sites only reserve fresh arrays; do not assume vector reserve preserves
   a previously larger capacity when invoked on arbitrary populated arrays.

5. **Boundary ownership and reuse.** Build empty then large then small results in
   separate eval arenas and repeated prepared/batched executions. Verify returned
   datums survive the temp-arena reset exactly as existing pack_json_res promises.
   Assert no pointer from one evaluation is used by another and no dictionary or
   property instance is retained by the local node-block owner.

The failure sweep is a resource/error test, not a latency benchmark. Do not use
SQL to induce process-level allocation exhaustion. The parent can instrument
allocator-call counts on these isolated correctness tests to confirm the removed
calls, but no absolute timing assertion belongs in regression tests.

## Acceptance limits

The staged SQL suite proves observable result/error equality only after both runs
actually succeed. It cannot prove exact free addresses, destructor coverage,
allocation failures, class alignment, compiler compatibility or peak memory.
Static inspection cannot replace those native checks. No platform claim or new
platform run is requested. Performance acceptance remains a separate parent
decision based on its unchanged workload and independently measured results.
