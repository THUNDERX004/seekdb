"""Snapshot two round14 targets and stage changes; never write to D:."""
from datetime import datetime, timezone
import difflib
import hashlib
import json
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
SOURCE = Path(r"D:\Projects\OceanBase\seekdb")
FILES = ("src/storage/fts/ob_fts_parser_helper.cpp",
         "src/oblib/common/json_type/ob_json_tree.h")
CONTEXT = ("src/sql/engine/expr/ob_expr_tokenize.cpp",
           "src/storage/fts/ob_fts_parser_property.cpp",
           "src/oblib/common/json_type/ob_json_tree.cpp",
           "src/oblib/lib/container/ob_vector.ipp",
           "src/oblib/lib/allocator/ob_malloc.h",
           "src/sql/engine/expr/ob_expr_json_func_helper.cpp")
BASELINE = "5bce9e06d1281347ad61344e4b01fab9158c58a2"


def git(*args):
    return subprocess.check_output(["git", "-C", str(SOURCE), *args]).decode().strip()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def blob(raw):
    return hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()


def replace_once(text, old, new):
    if text.count(old) != 1:
        raise ValueError("Missing/ambiguous source marker: " + old[:100])
    return text.replace(old, new)


def patch(path, old, new):
    return ("diff --git a/" + path + " b/" + path + "\n"
            + "index " + blob(old.encode()) + ".." + blob(new.encode()) + " 100644\n"
            + "".join(difflib.unified_diff(old.splitlines(True), new.splitlines(True),
                                           "a/" + path, "b/" + path)))


BATCH = """namespace
{
// Only TOKENIZE uses these result builders. Nodes have the caller's arena
// lifetime; packing the result does not individually destroy/free child nodes.
template <typename Node>
class TokenizeJsonNodeBatch final
{
public:
  explicit TokenizeJsonNodeBatch(ObIAllocator *allocator)
    : allocator_(allocator), buffer_(nullptr), capacity_(0), constructed_(0)
  {}
  ~TokenizeJsonNodeBatch()
  {
    if (nullptr != buffer_) {
      while (constructed_ > 0) {
        --constructed_;
        reinterpret_cast<Node *>(buffer_ + constructed_ * sizeof(Node))->~Node();
      }
      allocator_->free(buffer_);
    }
  }
  int init(const int64_t count)
  {
    int ret = OB_SUCCESS;
    if (count < 0 || count > INT64_MAX / static_cast<int64_t>(sizeof(Node))
        || count > INT64_MAX / static_cast<int64_t>(sizeof(ObJsonNode *))) {
      ret = OB_SIZE_OVERFLOW;
    } else if (count > 0
               && OB_ISNULL(buffer_ = static_cast<char *>(allocator_->alloc(count * sizeof(Node))))) {
      ret = OB_ALLOCATE_MEMORY_FAILED;
    } else {
      capacity_ = count;
    }
    return ret;
  }
  template <typename... Args>
  Node *create(Args &&...args)
  {
    OB_ASSERT(constructed_ < capacity_);
    Node *node = new (buffer_ + constructed_ * sizeof(Node)) Node(std::forward<Args>(args)...);
    ++constructed_;
    return node;
  }
  // Successful trees keep the block until the caller's arena is reset.
  void release() { buffer_ = nullptr; }
private:
  ObIAllocator *allocator_;
  char *buffer_;
  int64_t capacity_;
  int64_t constructed_;
  DISALLOW_COPY_AND_ASSIGN(TokenizeJsonNodeBatch);
};

struct TokenizeDetailJsonNode final
{
  TokenizeDetailJsonNode(ObIAllocator *allocator, const int64_t count)
    : count_(count), token_(allocator)
  {}
  ObJsonInt count_;
  ObJsonObject token_;
};
} // namespace

"""

DETAIL = """int ObFTParseHelper::make_detail_json(
    const ObFTWordMap &words,
    const int64_t doc_length,
    common::ObIJsonBase *&json_root)
{
  int ret = OB_SUCCESS;
  ObJsonObject *root_obj = nullptr;
  ObJsonInt *cnt = nullptr;
  ObJsonArray *token_array = nullptr;
  TokenizeJsonNodeBatch<TokenizeDetailJsonNode> nodes(allocator_);

  if (OB_ISNULL(root_obj = OB_NEWx(ObJsonObject, allocator_, allocator_))) {
    ret = OB_ALLOCATE_MEMORY_FAILED;
  } else if (OB_ISNULL(cnt = OB_NEWx(ObJsonInt, allocator_, doc_length))) {
    ret = OB_ALLOCATE_MEMORY_FAILED;
  } else if (OB_ISNULL(token_array = OB_NEWx(ObJsonArray, allocator_, allocator_))) {
    ret = OB_ALLOCATE_MEMORY_FAILED;
  } else if (OB_FAIL(nodes.init(words.size()))) {
  } else if (OB_FAIL(token_array->reserve(words.size()))) {
  } else {
    for (ObFTWordMap::const_iterator it = words.begin(); OB_SUCC(ret) && it != words.end(); ++it) {
      ObString key = it->first.get_word().get_string();
      TokenizeDetailJsonNode *node = nodes.create(allocator_, it->second);
      if (OB_FAIL(node->token_.add(key, &node->count_))) {
      } else if (OB_FAIL(token_array->append(&node->token_))) {
      }
    }
    if (OB_SUCC(ret)) {
      if (OB_FAIL(root_obj->add(ENTRY_NAME_TOKENS, token_array))) {
      } else if (OB_FAIL(root_obj->add(ENTRY_NAME_DOC_LEN, cnt))) {
      }
    }
  }
  if (OB_SUCC(ret)) {
    json_root = root_obj;
    nodes.release();
  } else {
    OB_DELETEx(ObJsonObject, allocator_, root_obj);
    OB_DELETEx(ObJsonInt, allocator_, cnt);
    OB_DELETEx(ObJsonArray, allocator_, token_array);
  }
  return ret;
}

"""

DEFAULT = """int ObFTParseHelper::make_token_array_json(
    const ObFTWordMap &words,
    common::ObIJsonBase *&json_root)
{
  int ret = OB_SUCCESS;
  ObJsonArray *token_array = nullptr;
  TokenizeJsonNodeBatch<ObJsonString> nodes(allocator_);
  if (OB_UNLIKELY(OB_ISNULL(token_array = OB_NEWx(ObJsonArray, allocator_, allocator_)))) {
    ret = OB_ALLOCATE_MEMORY_FAILED;
  } else if (OB_FAIL(nodes.init(words.size()))) {
  } else if (OB_FAIL(token_array->reserve(words.size()))) {
  } else {
    for (ObFTWordMap::const_iterator it = words.begin(); OB_SUCC(ret) && it != words.end(); ++it) {
      ObString key = it->first.get_word().get_string();
      ObJsonString *token = nodes.create(key);
      if (OB_FAIL(token_array->append(token))) {
      }
    }
  }
  if (OB_SUCC(ret)) {
    json_root = token_array;
    nodes.release();
  } else {
    OB_DELETEx(ObJsonArray, allocator_, token_array);
  }
  return ret;
}

"""


def main():
    for name in ("original", "src", "manifest.json", "source.patch"):
        if (HERE / name).exists():
            raise FileExistsError(HERE / name)
    head, branch = git("rev-parse", "HEAD"), git("branch", "--show-current")
    git("merge-base", "--is-ancestor", BASELINE, "HEAD")
    status = git("status", "--short")
    entries, patches = [], []
    for path in FILES:
        raw = (SOURCE / path).read_bytes()
        old = raw.decode().replace("\r\n", "\n")
        head_blob = git("rev-parse", "HEAD:" + path)
        if blob(old.encode()) != head_blob:
            raise ValueError("Target has uncommitted edits: " + path)
        if path.endswith(".h"):
            new = replace_once(old, "  int append(ObJsonNode *value);\n",
                "  int append(ObJsonNode *value);\n"
                "\n  // Reserve pointer storage only; does not append nodes or change JSON metadata.\n"
                "  int reserve(const int64_t count)\n"
                "  {\n"
                "    return count < 0 || count > INT64_MAX / static_cast<int64_t>(sizeof(ObJsonNode *))\n"
                "           ? OB_SIZE_OVERFLOW : node_vector_.reserve(count);\n"
                "  }\n")
        else:
            new = replace_once(old, '#include "common/json_type/ob_json_tree.h"\n',
                               '#include "common/json_type/ob_json_tree.h"\n#include <utility>\n')
            start = new.index("int ObFTParseHelper::make_detail_json(")
            finish = new.index("int ObFTParseHelper::set_add_word_flag(", start)
            new = new[:start] + BATCH + DETAIL + DEFAULT + new[finish:]
        is_crlf = b"\r\n" in raw
        changed = new.replace("\n", "\r\n").encode() if is_crlf else new.encode()
        snapshot, target = HERE / "original" / path, HERE / path
        snapshot.parent.mkdir(parents=True, exist_ok=True)
        target.parent.mkdir(parents=True, exist_ok=True)
        snapshot.write_bytes(raw)
        target.write_bytes(changed)
        entries.append({"path": path, "head_git_blob": head_blob,
                        "original_raw_sha256": sha(raw), "original_raw_git_blob": blob(raw),
                        "original_bytes": len(raw), "original_lf_git_blob": blob(old.encode()),
                        "snapshot": "original/" + path, "changed_raw_sha256": sha(changed),
                        "changed_raw_git_blob": blob(changed), "changed_lf_git_blob": blob(new.encode()),
                        "changed_bytes": len(changed), "line_endings": "CRLF" if is_crlf else "LF"})
        patches.append(patch(path, old, new))
    (HERE / "source.patch").write_bytes("".join(patches).encode())
    context = []
    for path in CONTEXT:
        raw = (SOURCE / path).read_bytes()
        context.append({"path": path, "raw_sha256": sha(raw), "raw_git_blob": blob(raw),
                        "head_git_blob": git("rev-parse", "HEAD:" + path)})
    for entry in entries:
        if (SOURCE / entry["path"]).read_bytes() != (HERE / entry["snapshot"]).read_bytes():
            raise ValueError("Parent changed target during staging: " + entry["path"])
    manifest = {"schema_version": 1, "purpose": "round14 TOKENIZE result-node batching; staging only",
                "created_utc": datetime.now(timezone.utc).isoformat(), "source_root": str(SOURCE),
                "source_head": head, "source_branch": branch, "official_baseline": BASELINE,
                "observed_source_status": status.splitlines(), "source_files": entries,
                "context_only_files": context, "source_write_set": list(FILES),
                "new_regression_files": ["unittest/storage/fts/test_tokenize_json_nodes.py"],
                "fixture_created": False, "native_build_sql_perf_executed": False}
    (HERE / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"source_head": head, "source_write_set": list(FILES)}, indent=2))


if __name__ == "__main__":
    main()
