# round14: TOKENIZE result-node batching (staging only)

The concrete proposal is to replace per-token JSON node allocations with one
arena-lifetime node block per result, and reserve the result array's pointer
capacity once. It applies to every parser, input and supported configuration;
there is no SQL/input special case or cache surviving an evaluation. It retains
the existing JSON tree classes and serializer. This is a measured-experiment
candidate, **not evidence of a measured CPU improvement**.

## Package and application boundary

Source checkout: `D:\Projects\OceanBase\seekdb`. Snapshot HEAD:
`a01e9cde9951b999073d6c1cf2407064d72897a4`, branch
`codex/fts-performance-competition`. Official remote branch and ancestor:
`upstream/2026-competition`, `5bce9e06d1281347ad61344e4b01fab9158c58a2`.
The parent had already committed round11 at snapshot time. Its uncommitted
round12 state is context in the manifest; none of it is bundled for application.

Exactly two existing production files are changed:

* `src/storage/fts/ob_fts_parser_helper.cpp`: a local node-block owner and changes
  confined to `make_detail_json`/`make_token_array_json` plus `<utility>`.
* `src/oblib/common/json_type/ob_json_tree.h`: additive, nonvirtual, checked
  `ObJsonArray::reserve` forwarding to its existing vector. No data/layout change.

These are disjoint from round12's `ob_fts_stop_word.cpp/.h` and round13's
`ob_sort_op_impl.cpp/.h`. Parser segmentation, property validation, charset
handling, dictionaries, stopword logic, SQL evaluation and packing are unchanged.
No protected evaluation, benchmark, build or CI file is modified.

`src/` contains full replacement files; `original/src/` exact raw originals.
`manifest.json` pins raw SHA256, raw/normalized Git blobs, HEAD blobs, byte sizes
and original line endings. Context files have hashes only, not replacement
copies. `source.patch` is the two-source patch. `regression.patch` independently
adds the SQL script. README, regression design and offline audit are package-only.
There is no fixture in this directory.

Before applying, compare both live raw SHA256 values with
`original_raw_sha256`. If different, rebase/review instead of replacing files.
The parent can use `git apply --check --whitespace=error-all <absolute-source.patch>`
and then apply after its own checkpoint. This agent only runs the check. A newer
parent HEAD alone is harmless when both target byte identities still agree.
Full replacements retain CRLF; patches are LF-normalized.

## Source evidence and size of the avoidable work

Evidence is from the pinned checkout and original snapshots; lines are one-based.

| Existing source | Work removed or preserved |
| --- | --- |
| `src/sql/engine/expr/ob_expr_tokenize.cpp:78-120` | Every evaluation segments into the same word map, then selects one of the two JSON builders. The map's iteration order and counts are already finalized. |
| `src/storage/fts/ob_fts_parser_helper.cpp:443-498` | ALL allocates an `ObJsonObject` and `ObJsonInt` individually for each unique map entry. Each object's one-member array allocation remains separate in this proposal. |
| `src/storage/fts/ob_fts_parser_helper.cpp:500-527` | DEFAULT individually allocates one `ObJsonString` per unique entry. Its string references the existing word bytes, which this patch preserves. |
| `src/oblib/lib/allocator/ob_malloc.h:650-660` | Every `OB_NEWx` performs `pool->alloc(sizeof(T))` followed by placement construction. These are actual allocator interface calls, rather than an assumed virtual array access. |
| `src/oblib/common/json_type/ob_json_tree.cpp:988-1004` | Append sets the parent and maintains serialization sizes, then uses vector push-back. This method is unchanged and still called per token. |
| `src/oblib/lib/container/ob_vector.ipp:338-375` | Unreserved pointer storage repeatedly allocates at geometric capacity boundaries and copies previous pointers. One reserve on a fresh array avoids these growth/copy steps. |

Let U be `words.size()`, the number of unique entries, not `doc_len` or the input
byte count. For U>0, DEFAULT's U scalar-node allocation calls become one block;
ALL's 2U object/count-node allocation calls become one block of paired records.
Both still perform U node constructions and unchanged `add`/`append` operations.
ALL still allocates each token object's member storage; root nodes, map building,
the result array backing storage and JSON serialization are also still present.
U=0 requests no node block and no zero-size array allocation. This gives a clear
O(U) reduction in allocation-call count without claiming overall speedup.

## Attribute-initialization investigation: deliberately unchanged

`ob_expr_tokenize.cpp:179` calls
`ObFTParserJsonProps::tokenize_array_to_props_json`; property cpp 1091-1124
constructs a flattened object and prints it. Expression cpp 372 onward reparses
that string, validates/defaults with `rebuild_props_for_ddl`, and materializes
the typed property. `ob_json_parse.cpp:65-137` also copies the printed string
before in-situ parsing. This is a real extra traversal/allocation sequence.

However, replacing it by direct node consumption is not established equivalent:
numeric/opaque JSON values can change JSON node type during print/reparse;
getters such as property cpp 302-305 distinguish `J_INT`, and currently leave
the output unchanged for other types. Each additional-args group validates
shape immediately, later groups overwrite the stored property string, and final
property validation occurs after all top-level options. Eagerly validating every
group would change error precedence and overwritten-option behavior. Duplicate
keys and borrowed JSON/string lifetime also matter. No attribute fast path is
included, and absent-property defaults are already handled directly. The selected
proposal removes result construction overhead while preserving this pipeline.

## Correctness and lifetime argument

The local `TokenizeJsonNodeBatch<T>` allocates checked space for U objects, then
placement-constructs exactly one slot per unchanged map iteration. It never moves
constructed slots. The ALL record embeds the same `ObJsonObject` and `ObJsonInt`
with the same allocator/count constructor arguments. DEFAULT constructs the same
`ObJsonString(key)`. Alignment follows the caller allocator's existing alignment
contract; `sizeof(T)` preserves alignment between slots, and there is no array
cookie or delete-array operation.

The same `node.add(key,count)` and `array.append(node)` calls preserve parent
pointers, length accounting and JSON sizes. The root still adds `tokens` before
`doc_len`, preserving its normal object sorting behavior. No string deep copy,
normalization, rehash, token order/count change, new key encoding or new serializer
is introduced. `reserve` changes capacity only; it appends no nodes and modifies
neither parent pointers nor JSON size counters. Its pointer-size bound and the
node block's multiplication bounds precede allocation.

Only `ObExprTokenize` calls these two builders in the source tree (`rg` verified).
It supplies its per-evaluation temporary arena, and calls
`ObJsonExprHelper::pack_json_res` immediately afterward (expression cpp 53-73).
Packing uses `ObJsonWrapper::get_raw_binary` and then `pack_json_str_res`
(`ob_expr_json_func_helper.cpp:2076-2103`). Thus nodes and existing word bytes live
until serialization; the result datum already used the same arena-to-result copy
boundary. No member/static/global cache or new pointer escapes into later rows,
statements, plan specs, dictionaries or prepared-statement state.

`ObJsonObject`/`ObJsonArray` destructors at tree header 197/341 do not recursively
destroy/free child nodes; their member storage owns only pairs/pointers. This is
important: successful node blocks intentionally remain in the caller arena just
like existing successful nodes. `release()` disarms the local block cleanup only
after `json_root` is assigned successfully. A future consumer must not individually
free child addresses, since they may be interior record members. Such a consumer
does not exist in the inspected call graph; adding one requires revisiting this
contract. The ALL record declares its count before its object, so C++ destroys
the object container before the embedded count on failure, matching the old
explicit object-then-count cleanup order.

On failure, the original separately allocated root/count/array are still deleted
through their original base pointers. The block owner then destroys only the
slots actually constructed and calls `free` once on the block's allocation base.
For the actual `ObArenaAllocator`, `page_arena.h:1019-1020` explicitly makes that
call a no-op; the expression's `TempAllocGuard` reclaims the block with its other
temporary storage. A tracking allocator used in a native test must accept that
free contract and verify exact-base ownership. Slot destruction also releases
member arrays of earlier ALL records. No pooled child is passed to `OB_DELETEx`,
and no unconstructed slot is inspected or destroyed. Output root is assigned only
on success, as before. A zero-token batch has no block to free.

Allocation failure remains `OB_ALLOCATE_MEMORY_FAILED`; failures of existing
`add`/`append` calls retain their error. Impossible-size arithmetic is rejected
with `OB_SIZE_OVERFLOW` before allocation. Allocation order/count and the precise
point at which resource exhaustion occurs change, so equality of injected
allocation ordinals is not promised. Legal result semantics and existing input
validation/error ordering are preserved. The native failure tests in
`REGRESSION.md` are still required evidence, not a completed runtime proof.

## Regression handoff

`unittest/storage/fts/test_tokenize_json_nodes.py` stages a full-result SQL
differential: 1560 cases, 51 corpus documents, all five built-in parsers,
DEFAULT/ALL, unique-count and duplicate-count boundaries, escaping/NUL/Unicode,
collations/charset conversion, JSON consumers, multirow/persisted output,
prepared executions and property/parser errors. It compares ordered JSON bytes,
column metadata, warnings, SQL error code and message against the independent
original; it does not sort or canonicalize results. Unsupported syntax/errors in
required success cases are fatal. See `REGRESSION.md` for the complete matrix and
required allocator/lifetime/native checks, including their practical limits.

Original recording is explicit, refuses overwrites, requires official commit and
verified original binary SHA256, and never auto-records missing fixtures. Parent
example, after independently selecting an official-original instance on 2891:

```powershell
$test = 'C:\Users\11946\Documents\ChatGPT\OceanBase比赛\setup\fts\round14-tokenize-proposal\unittest\storage\fts\test_tokenize_json_nodes.py'
# Obtain $originalBinarySha256 from the independently verified running original.
& .venv/Scripts/python.exe $test --port 2891 `
  --record 'C:\Users\11946\Documents\ChatGPT\OceanBase比赛\setup\fts\round14-original-tokenize-json-nodes.json.gz' `
  --record-source-commit 5bce9e06d1281347ad61344e4b01fab9158c58a2 `
  --record-source-binary-sha256 $originalBinarySha256
```

On the candidate, use the same script with `--expected` pointing to that fixture;
never record a candidate. `SEEKDB_TEST_PASSWORD` supplies an optional password.
The script reads no connection-secret files, starts no server and records no
timings. When explicitly run, it creates/drops only its dedicated
`tokenize_json_nodes_r14` database on 2891. No fixture has been produced here.

## Static verification and remaining risk

`audit_stage.py` checks exact originals/candidates, context hashes, allowed file
inventory, patch/full-file agreement, unchanged parsing/segment/helper setup,
unchanged JSON class layout outside the additive method, Python AST and workload
enumeration. `static-audit.json` records these checks; the manifest hashes every
artifact except itself and rejects unexpected/older files. Git application and
whitespace checks are read-only and separately recorded in the tool transcript.

No native code, C++ compile/link, build, SQL/DB, performance measurement, fixture
recording or new platform validation was run. Concrete remaining risks are
larger contiguous allocations/arena page utilization, overhead on tiny outputs,
allocator/destructor edge paths requiring native testing, and modest total CPU
impact if parser work or JSON serialization dominates. The O(U) allocation-call
reduction is source-proven; its value on the unchanged workload remains for the
parent to measure independently.
