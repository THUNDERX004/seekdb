"""Offline round14 audit; --seal changes this package's metadata/patches only."""
import argparse
import ast
import difflib
import hashlib
import json
from pathlib import Path
import runpy

HERE = Path(__file__).resolve().parent
SOURCE_FILES = {"src/storage/fts/ob_fts_parser_helper.cpp",
                "src/oblib/common/json_type/ob_json_tree.h"}
REGRESSION = "unittest/storage/fts/test_tokenize_json_nodes.py"


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def blob(raw):
    return hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()


def lf(raw):
    return raw.replace(b"\r\n", b"\n")


def source_patch(path, old, new):
    return ("diff --git a/" + path + " b/" + path + "\n"
            + "index " + blob(old) + ".." + blob(new) + " 100644\n"
            + "".join(difflib.unified_diff(old.decode().splitlines(True), new.decode().splitlines(True),
                                           "a/" + path, "b/" + path)))


def audit(seal):
    manifest = json.loads((HERE / "manifest.json").read_bytes())
    source = Path(manifest["source_root"])
    expected = {"README.md", "REGRESSION.md", "prepare_stage.py", "audit_stage.py",
                "manifest.json", "source.patch", "regression.patch", "static-audit.json", REGRESSION}
    expected |= SOURCE_FILES | {"original/" + path for path in SOURCE_FILES}
    actual = {p.relative_to(HERE).as_posix() for p in HERE.rglob("*") if p.is_file()}
    missing = expected - actual
    if actual - expected or (missing - {"regression.patch", "static-audit.json"} if seal else missing):
        raise ValueError(("Unexpected/missing artifacts", sorted(actual - expected), sorted(missing)))
    assert len(expected) == 13
    assert set(manifest["source_write_set"]) == SOURCE_FILES
    assert len(manifest["source_files"]) == 2
    assert manifest["new_regression_files"] == [REGRESSION]
    assert not any("stop_word" in p or "/sort/" in p for p in SOURCE_FILES)
    generated = runpy.run_path(str(HERE / "prepare_stage.py"), run_name="offline_definition_only")
    patches, source_checks = [], []
    for entry in manifest["source_files"]:
        path = entry["path"]
        original = (HERE / entry["snapshot"]).read_bytes()
        changed = (HERE / path).read_bytes()
        assert sha(original) == entry["original_raw_sha256"]
        assert blob(original) == entry["original_raw_git_blob"]
        assert blob(lf(original)) == entry["original_lf_git_blob"] == entry["head_git_blob"]
        assert (source / path).read_bytes() == original
        assert changed.count(b"\r\n") == changed.count(b"\n")
        if seal:
            entry.update(changed_raw_sha256=sha(changed), changed_raw_git_blob=blob(changed),
                         changed_lf_git_blob=blob(lf(changed)), changed_bytes=len(changed))
        else:
            assert sha(changed) == entry["changed_raw_sha256"]
            assert blob(changed) == entry["changed_raw_git_blob"]
            assert blob(lf(changed)) == entry["changed_lf_git_blob"]
        old, new = lf(original).decode(), lf(changed).decode()
        if path.endswith(".h"):
            addition = ("\n  // Reserve pointer storage only; does not append nodes or change JSON metadata.\n"
                        "  int reserve(const int64_t count)\n"
                        "  {\n"
                        "    return count < 0 || count > INT64_MAX / static_cast<int64_t>(sizeof(ObJsonNode *))\n"
                        "           ? OB_SIZE_OVERFLOW : node_vector_.reserve(count);\n"
                        "  }\n")
            assert new.count(addition) == 1
            assert new.replace(addition, "") == old
        else:
            before = old[:old.index("int ObFTParseHelper::make_detail_json(")]
            after = old[old.index("int ObFTParseHelper::set_add_word_flag("):]
            expected_cpp = (before.replace('#include "common/json_type/ob_json_tree.h"\n',
                                          '#include "common/json_type/ob_json_tree.h"\n#include <utility>\n')
                            + generated["BATCH"] + generated["DETAIL"] + generated["DEFAULT"] + after)
            assert new == expected_cpp
            # These verify write scope/packaging, not runtime comparator/JSON behavior.
            assert "OB_NEWx(ObJsonString" not in new[new.index("namespace\n{\n// Only TOKENIZE"):]
            assert "OB_DELETEx(ObJsonInt, allocator_, token_cnt_node)" not in new
        patches.append(source_patch(path, lf(original), lf(changed)))
        source_checks.append({"path": path, "original_identity_verified": True,
                              "live_D_target_matches_original": True})
    source_raw = "".join(patches).encode()
    content = (HERE / REGRESSION).read_text(encoding="utf-8")
    regression_raw = ("diff --git a/" + REGRESSION + " b/" + REGRESSION + "\nnew file mode 100644\n"
                      + "".join(difflib.unified_diff([], content.splitlines(True),
                                                    "/dev/null", "b/" + REGRESSION))).encode()
    if seal:
        (HERE / "source.patch").write_bytes(source_raw)
        (HERE / "regression.patch").write_bytes(regression_raw)
    else:
        assert (HERE / "source.patch").read_bytes() == source_raw
        assert (HERE / "regression.patch").read_bytes() == regression_raw
    for entry in manifest["context_only_files"]:
        raw = (source / entry["path"]).read_bytes()
        assert sha(raw) == entry["raw_sha256"] and blob(raw) == entry["raw_git_blob"]
    for path in HERE.rglob("*.py"):
        ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    sql = runpy.run_path(str(HERE / REGRESSION), run_name="offline_workload_only")
    cases = list(sql["cases"]())
    assert len(cases) == len({case["id"] for case in cases}) == 1560
    assert len(sql["texts"]()) == 51 and len(sql["input_rows"]()) == 257
    assert all(set(case) == {"id", "sql", "params", "allow_error", "before"} for case in cases)
    # Existing frozen round12/13 manifests are consulted read-only for disjointness.
    other_write_sets = {}
    for directory in ("round12-stopword-proposal", "round13-sort-proposal"):
        other = json.loads((HERE.parent / directory / "manifest.json").read_bytes())
        paths = {entry["path"] for entry in other["source_files"]}
        assert SOURCE_FILES.isdisjoint(paths)
        other_write_sets[directory] = sorted(paths)
    checks = {"schema_version": 1, "source_checks": source_checks,
              "source_and_regression_patches_match_full_files": True,
              "segment_init_and_other_helper_methods_unchanged": True,
              "json_class_layout_unchanged_only_reserve_method_added": True,
              "context_file_hashes_unchanged": True, "other_write_sets": other_write_sets,
              "python_ast_parsed": True, "sql_entrypoint_or_capture_executed": False,
              "sql_case_count": len(cases), "corpus_documents": 51, "varying_input_rows": 257,
              "workload_sha256": sql["workload_hash"](cases),
              "fixture_created": False, "native_build_sql_perf_executed": False,
              "git_apply_check": "read-only checks executed separately; see tool transcript",
              "runtime_proof_pending": ["C++ compile/link", "SQL original/candidate differential",
                                        "native exact-base/free and failure sweep",
                                        "independent unchanged-workload measurement"]}
    if seal:
        (HERE / "static-audit.json").write_text(json.dumps(checks, indent=2) + "\n", encoding="utf-8")
        manifest["artifact_inventory"] = [{"path": path, "bytes": (HERE / path).stat().st_size,
                                           "sha256": sha((HERE / path).read_bytes())}
                                          for path in sorted(expected - {"manifest.json"})]
        (HERE / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    else:
        assert json.loads((HERE / "static-audit.json").read_bytes()) == checks
        assert {e["path"] for e in manifest["artifact_inventory"]} == expected - {"manifest.json"}
        for entry in manifest["artifact_inventory"]:
            raw = (HERE / entry["path"]).read_bytes()
            assert len(raw) == entry["bytes"] and sha(raw) == entry["sha256"]
    print(json.dumps({"artifact_count": 13, "inventory_entries": 12,
                      "sql_case_count": len(cases), "workload_sha256": checks["workload_sha256"],
                      "sealed": seal, "checks": "PASS offline only"}, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seal", action="store_true")
    audit(parser.parse_args().seal)
