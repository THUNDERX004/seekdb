"""Diagnose staged inputs only; this does not generate a result fixture."""
import json
from pathlib import Path
import runpy
import pymysql

here = Path(__file__).resolve().parent
definition = runpy.run_path(str(here / 'unittest/storage/fts/test_tokenize_json_nodes.py'))
observations = []
with pymysql.connect(host='127.0.0.1', port=2891, user='root', charset='utf8mb4',
                     use_unicode=False, autocommit=True, read_timeout=60) as conn:
    with conn.cursor() as cur:
        cur.execute('SET ob_query_timeout=1000000000')
        cur.execute('DROP DATABASE IF EXISTS tokenize_json_probe_r14')
        cur.execute('CREATE DATABASE tokenize_json_probe_r14 CHARACTER SET utf8mb4')
        cur.execute('USE tokenize_json_probe_r14')
        cur.execute('CREATE TABLE inputs(id INT PRIMARY KEY,doc LONGTEXT,parser VARCHAR(16),config LONGTEXT NOT NULL)')
        cur.executemany('INSERT INTO inputs VALUES(%s,%s,%s,%s)', definition['input_rows']())
        try:
            for identifier, doc, parser, config in definition['input_rows']():
                for form, sql, params in (
                    ('parameter', 'SELECT TOKENIZE(%s,%s,%s) AS tokens', (doc, parser, config)),
                    ('column', 'SELECT TOKENIZE(doc,parser,config) AS tokens FROM inputs WHERE id=%s', (identifier,))):
                    try:
                        cur.execute(sql, params)
                        cur.fetchall()
                    except pymysql.MySQLError as error:
                        if 2000 <= error.args[0] < 3000:
                            raise
                        observations.append(dict(id=identifier, parser=parser,
                            document_length=None if doc is None else len(doc), form=form,
                            error=error.args[0], message=str(error.args[1])))
        finally:
            cur.execute('DROP DATABASE tokenize_json_probe_r14')
output = here / 'original-input-diagnostic.json'
output.write_text(json.dumps(observations, indent=2) + '\n', encoding='utf-8')
print(json.dumps(observations[:20], indent=2))
print('diagnostic_errors=', len(observations))
