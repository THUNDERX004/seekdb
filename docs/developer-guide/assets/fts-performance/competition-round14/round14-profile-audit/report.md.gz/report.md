# FTS Round 14 Profile Audit

Audit date: 2026-11-04. Scope was the seekdb checkout at `D:\Projects\OceanBase\seekdb` plus saved FTS profile, ETW and micro artifacts. No `.secrets` file was opened. No Git command, source/build/test/SQL/performance operation, or fixture generation was performed. Since Git operations were prohibited, the exact live HEAD and its ancestry were not independently queried; line references and hashes below describe the files read from disk. The latest staged round14 package identifies its snapshot as `a01e9cde9951b999073d6c1cf2407064d72897a4`, which is not asserted to be the live HEAD.

## Recommendation

Advance one gated experiment: **batch the per-token JSON result-node allocations in `TOKENIZE`**. Keep it a proposal until it wins the unchanged competition benchmark. This is the clearest isolated target with a calculable amount of repeated work and direct representation in the official benchmark's `tokenize` category. The saved profiles do not prove that JSON allocation is a material CPU hotspot, so no speedup estimate is justified.

Current code paths:

- `src/storage/fts/ob_fts_parser_helper.cpp:443-498`, `make_detail_json`: for `U = words.size()` unique tokens, constructs a per-token `ObJsonObject` and `ObJsonInt` with two `OB_NEWx` allocator calls each (lines 467-470), then adds/appends each result (471-472).
- `src/storage/fts/ob_fts_parser_helper.cpp:500-527`, `make_token_array_json`: constructs one `ObJsonString` with one `OB_NEWx` per unique token (line 512), then appends it (515).
- `src/oblib/lib/allocator/ob_malloc.h:650-655`: each `OB_NEWx` calls `pool->alloc(sizeof(T))` before placement construction.
- `src/oblib/common/json_type/ob_json_tree.cpp:988-1004`: each array append sets its parent and updates serialized sizes; its pointer insertion remains necessary.
- `src/oblib/lib/container/ob_vector.ipp:339-379`: when the JSON array's pointer vector fills, `push_back` allocates a larger buffer and copies existing pointers. The vector already exposes `reserve` at `src/oblib/lib/container/ob_vector.h:155`.
- `src/sql/engine/expr/ob_expr_tokenize.cpp:53-73, 78-117`: the per-evaluation temporary arena owns tokenization and JSON packing; DEFAULT and ALL both use the builders above.

The experiment would allocate one checked, arena-lifetime block for the `U` DEFAULT string nodes or the `2U` ALL object/count nodes, construct the same node types in map iteration order, and reserve the fresh result array for `U` pointers before appending. For `U > 0`, this changes the per-token node allocator-call count from `U` to one in DEFAULT (saving `U-1`) and from `2U` to one in ALL (saving `2U-1`). One pointer-buffer allocation after reserve replaces repeated capacity-growth allocations and pointer copies. These are source-level call-count reductions, not CPU-time reductions. Constructors, `U` appends, JSON serialization, and in ALL the separate one-member object storage for each token remain. Empty results must avoid a zero-size batch allocation.

The saved candidate-v22 parser micro record reports five measured samples after a warm-up: IK `26.534 µs/call` (range `26.394–26.722`) and BENG `6.241 µs/call` (`6.198–6.349`). This is end-to-end `TOKENIZE` SQL timing, not an allocator-only measurement; the JSON record has no binary/source identity, so it is scale evidence only. Saved local `fts_large_bench` runs for candidate-v22 show IK tokenize `0.1157–0.1232 ms` and BENG `0.0802–0.0823 ms` across three runs, but identify `git_head=7ba84fd78` with a dirty tree, not a verified current HEAD. The official benchmark source measures `TOKENIZE`, and its baseline contract assigns `build`, `tokenize`, and `query` equal category weight. Therefore this target can affect a scored category, while its expected score contribution remains unknown.

## Profile Assessment

The strongest symbol evidence is an archived IK-only diagnostic: 300,000 `TOKENIZE` rounds produced 152 instruction-pointer samples; 36 were outside the server image, 10 landed in `ObFTDATReader::match_with_hit`, and 10 in `ObArrayHashMap::find`. Those two lookup symbols account for 20/152 (13.2%) of sampled instruction pointers in that diagnostic. This is coarse sampling, not an exact CPU profile, and it points to dictionary lookup rather than the JSON node builder. It is useful evidence that tokenize has parser work beyond result construction, but it does not establish that the current competition HEAD has the same proportions.

The candidate-v22 build diagnostic has 141 samples, 77 outside the image, and only three in `ObAddWord::groupby_word`; the saved query diagnostic has 466 samples, 459 outside the image, and no sampled FTS posting/merge symbol. The repository's `profile/observer-x86_64.prof` (59 bytes) and `hotfuncs-x86_64.txt` (49 bytes) are placeholders, not usable profiles. The saved ETW attempt failed to enable the system performance profiling policy (`0xc5585011`), and no `.etl` trace was present in the inspected FTS archive. Consequently:

- **ObAddWord:** observed, but 3/141 build samples are too few to establish a hotspot.
- **Charset conversion / hash sort:** sparse samples only (for example, 2 charset-convert and 3 hash-sort samples in the small BENG parser diagnostic); insufficient for attribution or prioritization.
- **Posting merge:** not demonstrated by the saved query profile.
- **JSON node allocation:** source proves repeated allocations; no saved profile isolates or quantifies their CPU share.

The alternative of optimizing IK dictionary lookup has more direct sampled symbol hits, but the profile is coarse and not tied to the verified live HEAD. Current `src/storage/fts/dict/ob_ft_dat_dict.cpp:250-285` also has an optional UTF-8 BMP direct-code table and retains hash lookup for fallback inputs. Changing this path without a current, representative profile would be a broader semantic and memory tradeoff than the bounded result-builder experiment.

## Required Validation

Treat the already staged `setup/fts/round14-tokenize-proposal` package as a design reference, not a tested result. The audit there records no fixture, SQL, build, or performance run. Before accepting any implementation:

1. Build official-original and candidate binaries from the official `2026-competition` baseline ancestry on the evaluation platform. Keep benchmark, SQL, scoring and build files unchanged.
2. Run the seven existing FTS SQL regression suites recorded in `competition-migration.json`: `test_hot_path.py`, `test_tokenize_config.py`, `test_collation.py`, `test_match_batches.py`, `test_map_concurrency.py`, `test_stopword_concurrency.py`, and `test_dictionary_prefixes.py`.
3. Run the staged 1,560-statement complete-result differential for `TOKENIZE` against independently recorded official-original output. Cover DEFAULT/ALL, empty and large unique-token counts, every supported parser, ordering/spelling/counts, charset/collation, JSON consumers, multirow and prepared execution, metadata, warnings and error codes/messages. The fixture is not present and was not created during this audit.
4. Add/run native tests against the real JSON builders and serializer: allocation-call counts; node types, parent pointers, order and serialized bytes; exact-base ownership and destructor behavior; every allocation-failure point; overflow and empty-input handling; and repeated evaluation/temp-arena lifetime. SQL output equality alone cannot establish these allocator properties.
5. Compare paired original/candidate runs with the unchanged official parameters (`ROWS=20000`, `BATCH=500`, `ROUNDS=3000`, `QUERY_ROUNDS=200`, `SAMPLES=3`, `WARMUP=30`, `SKIP_LOAD=0`). Retain every run and all build/tokenize/query metrics, including regressions. Accept only a repeatable tokenize-category improvement with no correctness, memory, or other-category regression; otherwise reject the change.

Primary risks are earlier/larger contiguous allocation and peak-memory changes, low-`U` overhead, multiplication/alignment mistakes, freeing an interior node as if it were an allocation base, failure-path double destruction, and pointers outliving the evaluation arena. ALL still has per-token object-member storage, so its net allocation reduction is smaller than the `2U-1` node-call figure suggests. The implementation must preserve exact iteration order, result bytes, warnings and errors. Round 9 lowercase-copy work, round 12 ASCII stopword work, and round 13 sort-descriptor cache are explicitly out of scope; round 13's cache decision remains rejected.

If the goal is to select a proposal specifically for index-build or MATCH-query score, the saved evidence is not sufficient to choose one. That requires a new representative CPU profile tied to the verified current competition binary: a build profile separated by parser/index phase, a query profile with useful in-image samples and call stacks for retrieval/posting merge, plus a matching unprofiled benchmark. No such data was generated here.
