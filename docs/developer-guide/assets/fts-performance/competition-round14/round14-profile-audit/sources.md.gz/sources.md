# Round 14 Audit Sources

Read-only inventory for `report.md`. SHA256 values fingerprint the files as inspected on 2026-11-04. Paths under `setup/fts` are relative to `C:\Users\11946\Documents\ChatGPT\OceanBase比赛`; source paths are relative to `D:\Projects\OceanBase\seekdb`.

## Current Source and Benchmark Contract

| Source | Use | SHA256 |
| --- | --- | --- |
| `src/storage/fts/ob_fts_parser_helper.cpp` | DEFAULT/ALL per-token node construction and allocation sites, lines 443-527 | `191C8B361CFEF10BB7288EDAAD5FDD8AA2822108860C00CD6AE210E568396DF3` |
| `src/oblib/common/json_type/ob_json_tree.cpp` | `ObJsonArray::append`, parent/size updates and pointer push, lines 988-1004 | `CC0B8BF147F884A624526A7BAF65800E44F90B80E6F0E7F0660C341EB87C62AC` |
| `src/oblib/common/json_type/ob_json_tree.h` | JSON array pointer-vector declaration and API | `F7FD75187CF022901B9A9E4366778E7FB002231E003CB52974584583451E1ED0` |
| `src/oblib/lib/container/ob_vector.ipp` | Growth allocation and pointer-copy behavior, lines 339-379 | `B0E10816A63F13740AC8B779CE51C19EE6107B6E2DF53ADAAA83D6BE9883C754` |
| `src/oblib/lib/allocator/ob_malloc.h` | `OB_NEWx` allocator call, lines 650-655 | `6F0900E2C1F5964DBC6BF91D6BA6031D825FAA2139B526C5343E70EA4FA79203` |
| `src/sql/engine/expr/ob_expr_tokenize.cpp` | Evaluation arena, JSON pack boundary and builder dispatch | `C44317814B7D83F4947F67554A999A7AE8A800313856D5A76E32332477B40851` |
| `tools/benchmark/fts_large_bench.sh` | Official benchmark includes index build, TOKENIZE and MATCH; fixed workload parameters | `7E5B4DEC9419DCEF85A5785DBE305D7F825F545F45538AF2084A5A2ACA090C0A` |
| `tools/benchmark/fts_large_bench_score.py` | Score calculation implementation | `BEC125DBF0F2AB7CB7938DE73C75A9062F1835CC99CBC62EC2E5901BE89CEB4E` |
| `tools/benchmark/fts_large_bench_baseline.json` | Equal `build`/`tokenize`/`query` category weighting and score rule | `05963BB9792E6BD81EED4F66D3C9BA2E8A7A67BE17BA91B23D2E373812A5E16C` |

## Saved Measurements

| Artifact | Evidence / limitation | SHA256 |
| --- | --- | --- |
| `setup/fts/candidate-v22-parser-micro.json` | Five timed samples per parser; IK mean 0.026534002 ms, BENG mean 0.006241416 ms. No source/binary identity in the JSON. | `30652621C85507785104175DD5F4F99E1AC97728882400D98D4B0BE81EC5E729` |
| `setup/fts/candidate-v20-ik-profile.json` | 300,000 rounds, 152 samples; 36 outside image, 10 DAT-reader, 10 hash-map-find. Coarse IP sampler. | `E014BB2B35F514C2FDFE006DB79FDFAD11580F367C8953B904F33DABA1EF8A99` |
| `setup/fts/candidate-v19-beng-profile.json` | 500,000 rounds, 73 samples; sparse charset/hash-sort hits, not stable percentages. | `F70B9715C86028E0D308A9E13D5D8D6553EDF2CC9B87DBEF7F8617CDB242C87D` |
| `setup/fts/candidate-v22-build-profile.json` | 141 samples; 77 outside image, `groupby_word` 3 samples. | `BA785FEAE98D762A8AA82E8B8CE67DF8E266A95D99A01E3600C2CEAFA78B8C56` |
| `setup/fts/query-profile.json` | 466 samples; 459 outside image, no useful posting-merge attribution. | `64BC548BC9936C100386B31A084685C7D1910EF5BC552613F3DEAB06FA9D41AB` |
| `setup/fts/candidate-v22-native-{1,2,3}-report.txt` | Saved local full-workload runs identify `git_head=7ba84fd78`, dirty; TOKENIZE metrics only, not proof for the live HEAD. | Checksums not captured |
| `setup/fts/round2-etw-first-etw.log` | ETW could not enable system performance profiling policy (`0xc5585011`); no ETL trace. | `401C063759FCC6D8CAED6EC08270AAF758A8FBD86ACEDCB52EC724EB86D66113` |
| `profile/observer-x86_64.prof` | 59-byte placeholder, not a usable CPU profile. | `D6EA8B7EA7B1B768387BA13483E7FA83C7C4B87C29138F53CCA169BE37BA608D` |
| `profile/hotfuncs-x86_64.txt` | 49-byte placeholder, not a symbol ranking. | `0458C4A8794116EE4C83B58A68FEDC2A9A1BF93B8927CCAD7AB4E85F489D069E` |

## Baseline and Prior Decisions

| Artifact | Relevance | SHA256 |
| --- | --- | --- |
| `docs/developer-guide/assets/fts-performance/competition-migration.json` | Records official baseline `5bce9e06d1281347ad61344e4b01fab9158c58a2`, corrected competition submission evidence, and local validation limits. | `F62EA0BC40A559781EFB1D9ABF6CE6843E69F116AEAF51121B85174C5E4F8FF1` |
| `docs/developer-guide/assets/fts-performance/competition-round13/manifest.json` | Round13 sort-cache experiment was rejected: 0.4536% overall local reduction with query category regression; cache reverted. | `4B3487372D594DA050CCFE21D71DA2885FE2A4F2B1EE6E8722C243C56412DBAA` |
| `setup/fts/round13-sort-three-pair-comparison.json` | Preserved three-pair measurements behind the rejection. | `3D7E9F794150B73FFFEC2C55A44D77CD65F607FD2F3D07F630434838BF31F290` |
| `setup/fts/round14-tokenize-proposal/manifest.json` | Existing staged proposal snapshot; identifies source head `a01e9cde9951b999073d6c1cf2407064d72897a4`; records no fixture/build/SQL/performance execution. Not treated as live HEAD proof. | `F481BA1EE0C440005376F323141446D643D89C867BF4A36579DB6BD9CAA96EE7` |
| `setup/fts/round14-tokenize-proposal/static-audit.json` | Archived static audit and pending runtime-proof list; not rerun for this task. | `D9E05947182DD4BE37E4904E5FE2B41C550DBC0E60D26E17146190100B42E01B` |
| `setup/fts/round14-tokenize-proposal/README.md` | Candidate design, allocation-count argument, lifetime considerations and limits. | `52A813E00E6F9542EDEB0B60EB56602D1FCF373F4EF19D75AA818F36F06FC6AC` |
| `setup/fts/round14-tokenize-proposal/REGRESSION.md` | Staged SQL and native allocator/lifetime regression design; not run and creates no fixture by itself. | `3317C3CF4F0D7166844230AD657E85FAE18934454036EA75B2A01C6B322DD6D0` |

The two current source files targeted by the staged result-node proposal were byte-for-byte equal to its archived `original/` copies when checked. This establishes applicability to those files only; it does not establish the live checkout's commit identity, clean state, or branch ancestry.
