# Round17 BMW sidecar: frozen rejection record

Status: FROZEN. V1 is rejected for a demonstrated correctness regression. V2 is rejected for target performance. New regression preparation is NOTEXECUTED; no expansion or execution proceeds in this cycle. All results below are parent-executed evidence, read from existing artifacts or explicitly identified as parent-reported. The sidecar executes no database or native workload.

## First matched pair retained in full

The sidecar read both complete reports, including their auxiliary timings, sample deviations and hit counts. Original files remain unchanged at ../r17-bmw-v2-candidate-a1-report.txt and ../r17-bmw-v2-control-a1-report.txt. No metric or unfavorable run is discarded.

| Metric | Control a1 | Candidate v2 a1 | Unit |
| --- | ---: | ---: | --- |
| build_ik_all_sec | 7.886 | 6.424 | s |
| build_ik_content_sec | 6.024 | 4.807 | s |
| build_beng_en_sec | 2.992 | 2.686 | s |
| tokenize_ik_avg_ms | 0.1365 | 0.1305 | ms |
| tokenize_beng_avg_ms | 0.0957 | 0.0971 | ms |
| query_cn_avg_ms | 1.0507 | 1.0195 | ms |
| query_beng_avg_ms | 1.3671 | 1.5087 | ms |
| query_mixed_avg_ms | 1.2252 | 1.1114 | ms |
| query_limit_avg_ms | 2.2823 | 3.2295 | ms |

query_limit rises by approximately 41.5% elapsed time. The parent rejects v2 promptly on this first matched pair. Positive-looking build or other unrelated means do not overturn the rejection. No weighted-score increase, performance gain, statistical significance or quantified prepass/traversal cost is claimed. Looser pivots causing more traversal remains a hypothesis for current-cycle sampling, not a measured hotspot conclusion.

Both reports use ROWS=20000, BATCH=500, ROUNDS=3000, QUERY_ROUNDS=200, SAMPLES=3, WARMUP=30 and SKIP_LOAD=0. Candidate report timestamp is 2026-11-04 20:00:21; control is 2026-11-04 20:01:28. Both report git_head aeb0331e7 and git_dirty=1. Experiment metadata gives source commit aeb0331e7e1e4a41005481654bf63aabdf9b9ca7; executable/payload hashes distinguish the dirty-tree builds.

- V2 candidate executable SHA256: df0547dbdf5d79d971be202f5cfc50480ad66f637ebbdf00e8d15218024f6159, from ../r17-bmw-v2-candidate-a1-experiment.json.
- Control executable SHA256: 58a14c4b3cfb44464882de1d87b0f8018c76595a563e039ff3cbd8be2351f07d, from ../r17-bmw-v2-control-a1-experiment.json.

## Correctness basis already captured

V1 executable 44c16395e1fab585b725cdf93ef6708701bec09346f9880bb7397799bae01856 changes exactly two of the complete 432 ranked cases: 49 and 265, Boolean +database -audit, ORDER BY score DESC,id LIMIT 1. Expected ID 1585 becomes 2170 at identical score 0.5001172075859774. The complete candidate diagnosis and actual-output gzip remain at ../r17-bmw-ranked-diagnostic-candidate-1/.

The parent reports the full 432-case control diagnostic has zero fixture differences. This confirms a real candidate-dependent selected-ID regression. The original fixture stays unchanged; ties are neither excused nor re-recorded.

The parent reports exact v2 passed all 432 ranked cases, 192 key-type cases and seven standard suites, then completed the full benchmark. This supports those observed checks only, not arbitrary-input equivalence. The mode guard and static code trace, count-domain caveat, normalization consumers and path questions remain in ../round17-query-proposal-v2/report.md. Passing suites do not establish a speedup.

## Regression preparation and freeze

NOTEXECUTED: authoring stopped before any runnable test source or expected fixture was written. Preparation only read existing helpers and considered one bounded finite corpus covering natural dense ties, Boolean controls, mutation and rebuild. No generated case count or new coverage is asserted. No additional SQL, correctness/native test, benchmark, build or Git operation was executed by this sidecar.

Existing candidate sources, original snapshots, patches, manifests and parent runtime artifacts remain preserved. Only auxiliary documentation is written. The parent reports restoration of all four production files from exact v2 originals and owns the round18 control-profile PDB build and current-cycle sampling; the sidecar neither performs nor independently claims completion of that restore/build. No guessed-hotspot candidate is proposed. This record is final for this sidecar cycle.
