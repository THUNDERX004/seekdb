# Round17 BMW regression preparation - NOTEXECUTED

Frozen at the parent's request after the first matched pair: query_limit is 2.2823 ms for control and 3.2295 ms for v2, a 41.5% elapsed-time regression. V2 is rejected.

Preparation stopped before any runnable regression source or expected fixture was written. Only the existing ranked/JSON helpers were read and a bounded finite-corpus outline considered. No generated case count or new runtime coverage is claimed. No new harness, SQL, build, native test, benchmark or Git operation was run by this sidecar.

See report.md for the frozen parent-evidence record, complete first-pair metric table, and v1/v2 correctness basis. Further regression authoring and execution are canceled for this cycle.
