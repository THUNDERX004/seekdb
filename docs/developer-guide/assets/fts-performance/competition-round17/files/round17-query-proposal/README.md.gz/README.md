# Frozen round17 saturation-bound proposal (v1)

Historical candidate; not accepted. Parent executable SHA256 44c16395e1fab585b725cdf93ef6708701bec09346f9880bb7397799bae01856 failed the first unchanged ranked suite before a benchmark. Complete 432-case diagnosis found exactly two Boolean LIMIT 1 ID differences (49/265), with equal scores; natural-language cases passed. No candidate fixture was recorded.

The three candidate source files, three originals, source.patch and manifest.json remain byte-for-byte frozen. The manifest's uncompiled status describes initial packaging time. Only this README and report.md are newly added here.

The proposal removes the complete per-term block-stat prepass and substitutes BM25 query-token weight as a saturation upper bound. It removes sum(B_i+1) iterator next calls, B_i score/max calculations and an extra init/reset per eligible term, retaining local bounds and exact scoring. It targets BMW top-k/query_limit, not the already score-free query_cn/query_beng COUNT union paths. Looser global bounds may increase later work; no speedup is established.

See report.md for the observed tie failure, the nonnegative signed-count assumptions (stored UInt64 above INT64_MAX is not covered), floating-point/tie sensitivity, MIN_MAX normalization consumers, and mandatory current-path diagnostics. Not all consumers use the value solely as an upper bound. A historical profile does not prove current branch execution or benefit.

The minimal natural-language-only repair is staged separately in ../round17-query-proposal-v2/. V1 must not be submitted with the demonstrated failure. No production or expected-fixture changes, build, SQL, test, benchmark or Git operations were performed by this sidecar.
