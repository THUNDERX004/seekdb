/*
 * Copyright (c) 2025 OceanBase.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#define USING_LOG_PREFIX STORAGE

#include "ob_text_retrieval_token_iter.h"
#include "query/das/ob_das_iter_access.h"
#include "share/rc/ob_server_runtime.h"
#include "query/engine/expr/ob_expr_bm25.h"

namespace oceanbase
{
namespace storage
{
ObTextRetrievalTokenIter::ObTextRetrievalTokenIter()
  : ObISparseRetrievalDimIter(),
    mem_context_(nullptr),
    allocator_(nullptr),
    inv_idx_scan_param_(nullptr),
    inv_idx_agg_param_(nullptr),
    inv_idx_scan_iter_(nullptr),
    inv_idx_agg_iter_(nullptr),
    inv_idx_agg_expr_(nullptr),
    eval_ctx_(nullptr),
    relevance_expr_(nullptr),
    inv_scan_doc_length_col_(nullptr),
    inv_scan_domain_id_col_(nullptr),
    token_weight_expr_(nullptr),
    relevance_calc_exprs_(),
    skip_(nullptr),
    max_batch_size_(0),
    token_doc_cnt_(0),
    max_token_relevance_(-1.0),
    advance_doc_id_(),
    token_doc_cnt_calculated_(false),
    inv_idx_agg_cache_mode_(false),
    is_inited_(false)
{
}

int ObTextRetrievalTokenIter::init(const ObTextRetrievalScanIterParam &iter_param)
{
  int ret = OB_SUCCESS;
  allocator_ = iter_param.allocator_;
  mem_context_ = iter_param.mem_context_;
  inv_idx_scan_param_ = iter_param.inv_idx_scan_param_;
  inv_idx_agg_param_ = iter_param.inv_idx_agg_param_;
  inv_idx_scan_iter_ = iter_param.inv_idx_scan_iter_;
  inv_idx_agg_iter_ = iter_param.inv_idx_agg_iter_;
  inv_idx_agg_expr_ = iter_param.inv_idx_agg_expr_;
  eval_ctx_ = iter_param.eval_ctx_;
  relevance_expr_ = iter_param.relevance_expr_;
  inv_scan_doc_length_col_ = iter_param.inv_scan_doc_length_col_;
  inv_scan_domain_id_col_ = iter_param.inv_scan_domain_id_col_;
  max_batch_size_ = OB_MAX(iter_param.eval_ctx_->max_batch_size_, 1);
  inv_idx_agg_cache_mode_ = iter_param.inv_idx_agg_cache_mode_;

  if (OB_ISNULL(inv_idx_scan_iter_) || OB_ISNULL(eval_ctx_) || OB_ISNULL(inv_idx_scan_param_) ||
      OB_ISNULL(inv_scan_domain_id_col_) || OB_ISNULL(allocator_) || OB_ISNULL(mem_context_.ref_context())) {
    ret = OB_ERR_UNEXPECTED;
    LOG_WARN("inv_idx_scan_iter or eval_ctx is NULL", K(ret), K_(inv_idx_scan_iter), KPC_(eval_ctx), KPC_(inv_idx_scan_param), KP(allocator_), KP(mem_context_.ref_context()));
  } else if (!need_calc_relevance()) {
  } else if (OB_ISNULL(relevance_expr_) || OB_ISNULL(inv_idx_agg_expr_) || OB_ISNULL(inv_idx_agg_iter_)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (OB_ISNULL(inv_scan_doc_length_col_)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (OB_FAIL(init_calc_exprs_in_relevance_expr())) {
  }
  // Document-id batches also use the skip vector when no score is requested.
  if (OB_SUCC(ret)) {
    if (OB_ISNULL(skip_ = sql::to_bit_vector(
                      allocator_->alloc(sql::ObBitVector::memory_size(max_batch_size_))))) {
      ret = OB_ALLOCATE_MEMORY_FAILED;
    } else {
      skip_->init(max_batch_size_);
    }
  }
  is_inited_ = OB_SUCC(ret);
  return ret;
}

void ObTextRetrievalTokenIter::reset()
{
  relevance_calc_exprs_.reset();
  token_doc_cnt_calculated_ = false;
}

void ObTextRetrievalTokenIter::reuse()
{
  if (need_calc_relevance() && inv_idx_agg_cache_mode_ && !inv_idx_agg_param_->need_switch_param_) {
    // do nothing
  } else {
    token_doc_cnt_calculated_ = false;
  }
}

int ObTextRetrievalTokenIter::init_calc_exprs_in_relevance_expr()
{
  int ret = OB_SUCCESS;
  if (need_calc_relevance()) {
    if (OB_ISNULL(relevance_expr_)) {
      ret = OB_ERR_UNEXPECTED;
    } else if (OB_FAIL(relevance_calc_exprs_.push_back(relevance_expr_))) {
    }
    for (int64_t i = 0; OB_SUCC(ret) && i < relevance_expr_->arg_cnt_; ++i) {
      sql::ObExpr *arg_expr = relevance_expr_->args_[i];
      if (OB_ISNULL(arg_expr)) {
        ret = OB_ERR_UNEXPECTED;
      } else if (T_FUN_SYS_CAST == arg_expr->type_) {
        // cast expr is evaluated with relevance expr
        if (OB_FAIL(relevance_calc_exprs_.push_back(arg_expr))) {
        }
      }
    }

    if (OB_SUCC(ret)) {
      sql::ObExpr *doc_length_param_expr = relevance_expr_->args_[sql::ObExprBM25::DOC_LENGTH_PARAM_IDX];
      if (OB_UNLIKELY(nullptr == doc_length_param_expr || doc_length_param_expr->type_ != T_REF_COLUMN ||
                      doc_length_param_expr != inv_scan_doc_length_col_ ||
                      doc_length_param_expr->datum_meta_.get_type() != ObUInt64Type)) {
        ret = OB_ERR_UNEXPECTED;
      }
    }
    if (OB_SUCC(ret)) {
      sql::ObExpr *token_weight_param_expr = relevance_expr_->args_[sql::ObExprBM25::TOKEN_WEIGHT_PARAM_IDX];
      if (OB_UNLIKELY(nullptr == token_weight_param_expr || token_weight_param_expr->type_ != T_PSEUDO_COLUMN)) {
        ret = OB_ERR_UNEXPECTED;
      } else {
        token_weight_expr_ = token_weight_param_expr;
      }
    }
  }
  return ret;
}

int ObTextRetrievalTokenIter::get_token_doc_cnt(int64_t &token_doc_cnt) const
{
  int ret = OB_SUCCESS;
  if (OB_UNLIKELY(!token_doc_cnt_calculated_)) {
    ret = OB_ERR_UNEXPECTED;
  } else {
    token_doc_cnt = token_doc_cnt_;
  }
  return ret;
}

void ObTextRetrievalTokenIter::clear_row_wise_evaluated_flag()
{
  for (int64_t i = 0; i < relevance_calc_exprs_.count(); ++i) {
    sql::ObExpr *expr = relevance_calc_exprs_.at(i);
    expr->clear_evaluated_flag(*eval_ctx_);
  }
}

int ObTextRetrievalTokenIter::fill_token_doc_cnt()
{
  int ret = OB_SUCCESS;
  if (OB_UNLIKELY(inv_idx_agg_expr_->datum_meta_.get_type() != ObIntType)) {
    ret = OB_ERR_UNEXPECTED;
  } else {
    ObEvalCtx::BatchInfoScopeGuard guard(*eval_ctx_);
    guard.set_batch_idx(0);
    ObDatum &doc_cnt_datum = inv_idx_agg_expr_->locate_datum_for_write(*eval_ctx_);
    doc_cnt_datum.set_int(token_doc_cnt_);
  }
  return ret;
}

int ObTextRetrievalTokenIter::fill_token_weight()
{
  int ret = OB_SUCCESS;
  if (OB_ISNULL(token_weight_expr_)) {
    ret = OB_ERR_UNEXPECTED;
  } else {
    ObEvalCtx::BatchInfoScopeGuard guard(*eval_ctx_);
    guard.set_batch_idx(0);
    ObDatum &token_weight_datum = token_weight_expr_->locate_datum_for_write(*eval_ctx_);
    token_weight_datum.set_double(max_token_relevance_);
  }
  return ret;
}

int ObTextRetrievalTokenIter::eval_relevance_expr()
{
  int ret = OB_SUCCESS;
  ObDatum *relevance_datum = nullptr;
  if (OB_FAIL(relevance_expr_->eval(*eval_ctx_, relevance_datum))) {
  }
  return ret;
}

int ObTextRetrievalTokenIter::get_next_row()
{
  int ret = OB_SUCCESS;
  if (IS_NOT_INIT) {
    ret = OB_NOT_INIT;
  } else if (need_calc_relevance() && !token_doc_cnt_calculated_ && OB_FAIL(estimate_token_doc_cnt())) {
  } else if (OB_FAIL(query::das_scan_next_row(inv_idx_scan_iter_))) {
    if (OB_UNLIKELY(OB_ITER_END != ret)) {
    }
  } else {
    if (need_calc_relevance()) {
      clear_row_wise_evaluated_flag();
      if (OB_FAIL(fill_token_doc_cnt())) {
      } else if (OB_FAIL(fill_token_weight())) {
      } else if (OB_FAIL(eval_relevance_expr())) {
      }
    }
  }
  return ret;
}

void ObTextRetrievalTokenIter::clear_batch_wise_evaluated_flag(const int64_t count)
{
  int64_t max_size = OB_MAX(max_batch_size_, count);
  for (int64_t i = 0; i < relevance_calc_exprs_.count(); ++i) {
    sql::ObExpr *expr = relevance_calc_exprs_.at(i);
    expr->get_evaluated_flags(*eval_ctx_).reset(count);
  }
}

int ObTextRetrievalTokenIter::batch_eval_relevance_expr(const int64_t count)
{
  int ret = OB_SUCCESS;
  if (OB_FAIL(relevance_expr_->eval_batch(*eval_ctx_, *skip_, count))) {
  }
  return ret;
}

int ObTextRetrievalTokenIter::get_next_batch(const int64_t capacity, int64_t &count)
{
  int ret = OB_SUCCESS;
  count = 0;
  if (IS_NOT_INIT) {
    ret = OB_NOT_INIT;
  } else if (need_calc_relevance() && !token_doc_cnt_calculated_ && OB_FAIL(estimate_token_doc_cnt())) {
  } else if (OB_FAIL(query::das_scan_next_rows(
                 inv_idx_scan_iter_, count, OB_MIN(max_batch_size_, capacity)))) {
    if (OB_UNLIKELY(OB_ITER_END != ret)) {
    } else if (count != 0) {
      ret = OB_SUCCESS;
    }
  }

  if (OB_FAIL(ret)) {
  } else if (need_calc_relevance()) {
    const sql::ObBitVector *skip = NULL;
    PRINT_VECTORIZED_ROWS(SQL, DEBUG, *eval_ctx_, *inv_idx_scan_param_->output_exprs_, count, skip);
    clear_batch_wise_evaluated_flag(count);
    if (OB_FAIL(fill_token_doc_cnt())) {
    } else if (OB_FAIL(fill_token_weight())) {
    } else if (OB_FAIL(batch_eval_relevance_expr(count))) {
    }
  }
  return ret;
}

int ObTextRetrievalTokenIter::advance_to(const ObDatum &id_datum)
{
  int ret = OB_SUCCESS;
  if (OB_FAIL(advance_doc_id_.from_datum(id_datum))) {
  } else if (OB_UNLIKELY(inv_idx_scan_param_->key_ranges_.count() != 1)) {
    ret = OB_ERR_UNEXPECTED;
  } else {
    ObRowkey start_rowkey = inv_idx_scan_param_->key_ranges_.at(0).start_key_;
    ObRowkey end_rowkey = inv_idx_scan_param_->key_ranges_.at(0).end_key_;
    if (&start_rowkey.get_obj_ptr()[2] != &end_rowkey.get_obj_ptr()[0]) {
      ret = OB_ERR_UNEXPECTED;
    }
    // obj_ptr[0] is token, obj_ptr[1] is docid
    ObObj *obj_ptr = start_rowkey.get_obj_ptr();
    ObNewRange scan_range;
    if (OB_FAIL(ret)) {
    } else if (OB_FAIL(advance_doc_id_.get_datum().to_obj(obj_ptr[1], inv_scan_domain_id_col_->obj_meta_))) {
    } else {
      scan_range.table_id_ = inv_idx_scan_param_->key_ranges_.at(0).table_id_;
      scan_range.start_key_.assign(obj_ptr, INV_IDX_ROWKEY_COL_CNT);
      scan_range.end_key_.assign(&obj_ptr[2], INV_IDX_ROWKEY_COL_CNT);
      scan_range.border_flag_.set_inclusive_start();
      scan_range.border_flag_.set_inclusive_end();
    }
    if (OB_FAIL(ret)) {
    } else if (FALSE_IT(inv_idx_scan_param_->key_ranges_.reuse())) {
    } else if (OB_UNLIKELY(!inv_idx_scan_param_->key_ranges_.empty())) {
      ret = OB_ERR_UNEXPECTED;
    } else if (OB_FAIL(inv_idx_scan_param_->key_ranges_.push_back(scan_range))) {
    } else if (OB_FAIL(query::das_scan_advance(inv_idx_scan_iter_))) {
    }
  }
  return ret;
}

int ObTextRetrievalTokenIter::update_scan_param(const ObString &token, common::ObArenaAllocator &allocator)
{
  int ret = OB_SUCCESS;
  ObTableScanParam *range_param = need_calc_relevance() ? inv_idx_agg_param_ : inv_idx_scan_param_;
  if (OB_ISNULL(range_param) || OB_UNLIKELY(range_param->key_ranges_.count() != 1)) {
    ret = OB_ERR_UNEXPECTED;
  } else {
    ObNewRange scan_range = range_param->key_ranges_.at(0);
    ObObj tmp_obj;
    tmp_obj.set_string(ObVarcharType, token);
    tmp_obj.set_meta_type(scan_range.start_key_.get_obj_ptr()->meta_);
    if (scan_range.start_key_.get_obj_ptr() + 2 != scan_range.end_key_.get_obj_ptr()) {
      ret = OB_ERR_UNEXPECTED;
    } else if (OB_FAIL(ob_write_obj(allocator, tmp_obj, *scan_range.start_key_.get_obj_ptr()))) {
    } else if (OB_FAIL(ob_write_obj(allocator, tmp_obj, *scan_range.end_key_.get_obj_ptr()))) {
    } else if (!need_inv_idx_agg()) {
      // skip inverted index aggregate iterator
    } else if (OB_FAIL(query::das_scan_reuse(inv_idx_agg_iter_))) {
    } else if (OB_UNLIKELY(!inv_idx_agg_param_->key_ranges_.empty())) {
      ret = OB_ERR_UNEXPECTED;
    } else if (OB_FAIL(inv_idx_agg_param_->key_ranges_.push_back(scan_range))) {
    } else if (OB_FAIL(query::das_scan_rescan(inv_idx_agg_iter_))) {
    }

    if (OB_FAIL(ret)) {
    } else if (OB_UNLIKELY(inv_idx_scan_param_->key_ranges_.empty())) {
      ret = OB_ERR_UNEXPECTED;
    } else if (inv_idx_scan_param_->key_ranges_.at(0).start_key_.get_obj_ptr()
        == inv_idx_scan_param_->key_ranges_.at(0).end_key_.get_obj_ptr()) {
      // function lookup mode
      ObSEArray<ObNewRange, 4> scan_ranges;
      scan_ranges.assign(inv_idx_scan_param_->key_ranges_);
      for (int64_t i = 0; OB_SUCC(ret) && i < scan_ranges.count(); ++i) {
        if (OB_FAIL(ob_write_obj(allocator, tmp_obj, *scan_ranges.at(i).start_key_.get_obj_ptr()))) {
        }
      }
      if (FAILEDx(query::das_scan_reuse(inv_idx_scan_iter_))) {
      } else if (OB_UNLIKELY(!inv_idx_scan_param_->key_ranges_.empty())) {
        ret = OB_ERR_UNEXPECTED;
      } else if (OB_FAIL(inv_idx_scan_param_->key_ranges_.assign(scan_ranges))) {
      } else if (OB_FAIL(query::das_scan_rescan(inv_idx_scan_iter_))) {
      }
    } else {
      // non-function lookup mode
      if (OB_FAIL(query::das_scan_reuse(inv_idx_scan_iter_))) {
      } else if (OB_UNLIKELY(!inv_idx_scan_param_->key_ranges_.empty())) {
        ret = OB_ERR_UNEXPECTED;
      } else if (OB_FAIL(inv_idx_scan_param_->key_ranges_.push_back(scan_range))) {
      } else if (OB_FAIL(query::das_scan_rescan(inv_idx_scan_iter_))) {
      }
    }
    if (OB_SUCC(ret)) {
      reuse();
    }
  }
  return ret;
}

int ObTextRetrievalTokenIter::estimate_token_doc_cnt()
{
  int ret = OB_SUCCESS;
  int64_t logical_row_cnt = 0;
  int64_t physical_row_cnt = 0;
  ObSEArray<ObEstRowCountRecord, 1> est_records;
  ObArenaAllocator allocator;
  const int64_t timeout_us = THIS_WORKER.get_timeout_remain();
  ObAccessService *access_service = NULL;
  storage::ObTableScanRange table_scan_range;
  ObSimpleBatch batch;
  batch.type_ = ObSimpleBatch::T_SCAN;
  batch.range_ = &inv_idx_agg_param_->key_ranges_.at(0);
  ObTableScanParam est_param;
  est_param.index_id_ = inv_idx_agg_param_->index_id_;
  est_param.scan_flag_ = inv_idx_agg_param_->scan_flag_;
  est_param.tablet_id_ = inv_idx_agg_param_->tablet_id_;
  est_param.tx_id_ = inv_idx_agg_param_->tx_id_;
  est_param.schema_version_ = inv_idx_agg_param_->schema_version_;
  est_param.frozen_version_ = GET_BATCH_ROWS_READ_SNAPSHOT_VERSION;
  if (OB_ISNULL(access_service = ::oceanbase::share::server_service<::oceanbase::storage::ObAccessService>())) {
    ret = OB_ERR_UNEXPECTED;
  } else if (OB_FAIL(table_scan_range.init(*inv_idx_agg_param_, batch, allocator))) {
  } else if (OB_FAIL(access_service->estimate_row_count(est_param,
                                                        table_scan_range,
                                                        timeout_us,
                                                        est_records,
                                                        logical_row_cnt,
                                                        physical_row_cnt))) {
  } else {
    token_doc_cnt_ = logical_row_cnt;
    token_doc_cnt_calculated_ = true;
    sql::ObExpr *total_doc_cnt_param_expr = relevance_expr_->args_[sql::ObExprBM25::TOTAL_DOC_CNT_PARAM_IDX];
    if (OB_ISNULL(total_doc_cnt_param_expr)) {
      ret = OB_ERR_UNEXPECTED;
    } else {
      int64_t total_doc_cnt = 0;
      total_doc_cnt = total_doc_cnt_param_expr->locate_expr_datum(*eval_ctx_, 0).get_int();
      max_token_relevance_ = sql::ObExprBM25::query_token_weight(token_doc_cnt_, total_doc_cnt);
    }
  }
  return ret;
}

ObTextRetrievalDaaTTokenIter::ObTextRetrievalDaaTTokenIter()
  : ObISRDaaTDimIter(),
    allocator_(nullptr),
    token_iter_(nullptr),
    eval_ctx_(nullptr),
    relevance_expr_(nullptr),
    inv_scan_domain_id_col_(nullptr),
    max_batch_size_(1),
    cur_idx_(-1),
    count_(0),
    relevance_(),
    doc_id_(),
    cmp_func_(nullptr),
    is_inited_(false)
{
}

int ObTextRetrievalDaaTTokenIter::init(const ObTextRetrievalScanIterParam &iter_param)
{
  int ret = OB_SUCCESS;
  void *buf = nullptr;
  allocator_ = iter_param.allocator_;
  if (OB_ISNULL(iter_param.eval_ctx_) || OB_ISNULL(iter_param.inv_scan_domain_id_col_) || OB_ISNULL(allocator_)) {
    ret = OB_INVALID_ARGUMENT;
  } else if (OB_ISNULL(buf = allocator_->alloc(sizeof(ObTextRetrievalTokenIter)))) {
    ret = OB_ALLOCATE_MEMORY_FAILED;
  } else {
    token_iter_ = new (buf) ObTextRetrievalTokenIter();
    if (OB_FAIL(token_iter_->init(iter_param))) {
    } else {
      eval_ctx_ = iter_param.eval_ctx_;
      relevance_expr_ = iter_param.relevance_expr_;
      inv_scan_domain_id_col_ = iter_param.inv_scan_domain_id_col_;
      max_batch_size_ = OB_MAX(iter_param.eval_ctx_->max_batch_size_, 1);
      common::ObDatumBasicFuncs *basic_funcs = ObDatumFuncs::get_basic_func(inv_scan_domain_id_col_->datum_meta_.type_, CS_TYPE_BINARY);
      cmp_func_ = basic_funcs->null_first_cmp_;
      if (OB_ISNULL(cmp_func_)) {
        ret = OB_ERR_UNEXPECTED;
      } else if (FALSE_IT(relevance_.set_allocator(allocator_))) {
      } else if (OB_FAIL(relevance_.init(max_batch_size_))) {
      } else if (OB_FAIL(relevance_.prepare_allocate(max_batch_size_))) {
      } else if (FALSE_IT(doc_id_.set_allocator(allocator_))) {
      } else if (OB_FAIL(doc_id_.init(max_batch_size_))) {
      } else if (OB_FAIL(doc_id_.prepare_allocate(max_batch_size_))) {
      } else {
        is_inited_ = true;
      }
    }
  }
  return ret;
}

void ObTextRetrievalDaaTTokenIter::reuse()
{
  cur_idx_ = -1;
  count_ = 0;
  token_iter_->reuse();
}

void ObTextRetrievalDaaTTokenIter::reset()
{
  relevance_.reset();
  doc_id_.reset();
  token_iter_->reset();
  cur_idx_ = -1;
  count_ = 0;
}

// Sparse Retrieval Dimension Iter Interfaces
int ObTextRetrievalDaaTTokenIter::get_next_row() {
  int ret = OB_SUCCESS;
  bool need_load = false;
  if (OB_LIKELY((++cur_idx_) < count_)) {
  } else if (!eval_ctx_->is_vectorized() && (OB_FAIL(token_iter_->get_next_row()))) {
    if (OB_UNLIKELY(OB_ITER_END != ret)) {
    }
  } else if (!eval_ctx_->is_vectorized() && FALSE_IT(count_ = 1)) {
  } else if (eval_ctx_->is_vectorized() && OB_FAIL(token_iter_->get_next_batch(max_batch_size_, count_))) {
    if (OB_UNLIKELY(OB_ITER_END != ret)) {
    } else if (count_ != 0) {
      ret = OB_SUCCESS;
      need_load = true;
    }
  } else {
    need_load = true;
  }
  if (OB_SUCC(ret) && need_load) {
    if (OB_NOT_NULL(relevance_expr_)) {
      if (OB_FAIL(save_relevances_and_docids())) {
      }
    } else if (OB_FAIL(save_docids())) {
    }
  }
  return ret;
}

int ObTextRetrievalDaaTTokenIter::save_relevances_and_docids()
{
  int ret = OB_SUCCESS;
  if (OB_ISNULL(relevance_expr_) || OB_ISNULL(inv_scan_domain_id_col_)) {
    ret = OB_INVALID_ARGUMENT;
  } else if (OB_FAIL(relevance_expr_->eval_batch(*eval_ctx_, *token_iter_->get_skip(), count_))) {
  } else {
    cur_idx_ = 0;
    const ObDatumVector &relevance_datum = relevance_expr_->locate_expr_datumvector(*eval_ctx_);
    const ObDatumVector &doc_id_datum = inv_scan_domain_id_col_->locate_expr_datumvector(*eval_ctx_);
    for (int64_t i = 0; OB_SUCC(ret) && i < count_; ++i) {
      if (OB_LIKELY(!token_iter_->get_skip()->at(i))) {
        relevance_[i] = relevance_datum.at(i)->get_double();
        if (OB_FAIL(doc_id_[i].from_datum(*doc_id_datum.at(i)))) {
        }
      }
    }
  }
  return ret;
}

int ObTextRetrievalDaaTTokenIter::save_docids()
{
  int ret = OB_SUCCESS;
  if (OB_ISNULL(inv_scan_domain_id_col_)) {
    ret = OB_INVALID_ARGUMENT;
  } else {
    cur_idx_ = 0;
    const ObDatumVector &doc_id_datum = inv_scan_domain_id_col_->locate_expr_datumvector(*eval_ctx_);
    for (int64_t i = 0; OB_SUCC(ret) && i < count_; ++i) {
      if (OB_LIKELY(!token_iter_->get_skip()->at(i))) {
        if (OB_FAIL(doc_id_[i].from_datum(*doc_id_datum.at(i)))) {
        };
      }
    }
  }
  return ret;
}

int ObTextRetrievalDaaTTokenIter::get_next_batch(const int64_t capacity, int64_t &count)
{
  return OB_NOT_IMPLEMENT;
}

int ObTextRetrievalDaaTTokenIter::advance_to(const ObDatum &id_datum)
{
  int ret = OB_SUCCESS;
  int result = 0;
  bool find = false;

  if (cur_idx_ < 0) {
    ret = OB_ERR_UNEXPECTED;
  }
  while (OB_SUCC(ret) && !find) {
    if (cur_idx_ < count_) {
      if (OB_FAIL(cmp_func_(
              id_datum, doc_id_[cur_idx_].get_datum(), result, nullptr))) {
      } else if (result <= 0) {
        find = true;
      } else {
        ++cur_idx_;
      }
    } else if (OB_FAIL(token_iter_->advance_to(id_datum))) {
    } else if (OB_FAIL(get_next_row())) {
      if (OB_UNLIKELY(OB_ITER_END != ret)) {
      } else {
        find = true;
      }
    } else if (cur_idx_ != 0) {
      ret = OB_ERR_UNEXPECTED;
    } else if (OB_FAIL(cmp_func_(
                   id_datum, doc_id_[cur_idx_].get_datum(), result, nullptr))) {
    } else if (result <= 0) {
      find = true;
    } else {
      ret = OB_ERR_UNEXPECTED;
    }
  }
  return ret;
}

int ObTextRetrievalDaaTTokenIter::get_curr_score(double &score) const
{
  int ret = OB_SUCCESS;
  if (OB_UNLIKELY(cur_idx_ >= count_)) {
    ret = OB_ARRAY_OUT_OF_RANGE;
  } else {
    score = nullptr != relevance_expr_ ? relevance_[cur_idx_] : 1.0;
  }
  return ret;
}

int ObTextRetrievalDaaTTokenIter::get_curr_id(const ObDatum *&id_datum) const
{
  int ret = OB_SUCCESS;
  if (OB_UNLIKELY(cur_idx_ >= count_)) {
    ret = OB_ARRAY_OUT_OF_RANGE;
  } else {
    id_datum = &doc_id_[cur_idx_].get_datum();
  }
  return ret;
}

ObTextRetrievalBlockMaxIter::ObTextRetrievalBlockMaxIter()
  : ObISRDimBlockMaxIter(),
    token_iter_(),
    block_max_iter_(),
    block_max_iter_param_(nullptr),
    block_max_scan_param_(nullptr),
    ranking_param_(),
    curr_id_(nullptr),
    max_score_tuple_(nullptr),
    dim_max_score_(0),
    block_max_inited_(false),
    in_shallow_status_(false),
    is_inited_(false)
{
}

int ObTextRetrievalBlockMaxIter::init(
    const ObTextRetrievalScanIterParam &iter_param,
    const ObBlockMaxScoreIterParam &block_max_iter_param,
    ObTableScanParam &scan_param)
{
  int ret = OB_SUCCESS;
  if (IS_INIT) {
    ret = OB_INIT_TWICE;
  } else if (OB_UNLIKELY(!block_max_iter_param.is_valid() || !scan_param.is_valid())) {
    ret = OB_INVALID_ARGUMENT;
  } else if (OB_FAIL(token_iter_.init(iter_param))) {
  } else {
    curr_id_ = nullptr;
    block_max_iter_param_ = &block_max_iter_param;
    block_max_scan_param_ = &scan_param;
    max_score_tuple_ = nullptr;
    dim_max_score_ = 0;
    in_shallow_status_ = false;
    ranking_param_.token_freq_col_idx_ = block_max_iter_param.token_freq_col_idx_;
    ranking_param_.doc_length_col_idx_ = block_max_iter_param.doc_length_col_idx_;
    is_inited_ = true;
  }
  return ret;
}

void ObTextRetrievalBlockMaxIter::reset()
{
  token_iter_.reset();
  block_max_iter_.reset();
  curr_id_ = nullptr;
  block_max_iter_param_ = nullptr;
  block_max_scan_param_ = nullptr;
  max_score_tuple_ = nullptr;
  dim_max_score_ = 0;
  in_shallow_status_ = false;
  block_max_inited_ = false;
  is_inited_ = false;
}

void ObTextRetrievalBlockMaxIter::reuse()
{
  token_iter_.reuse();
  block_max_iter_.reset();
  curr_id_ = nullptr;
  max_score_tuple_ = nullptr;
  in_shallow_status_ = false;
  block_max_inited_ = false;
  dim_max_score_ = 0;
}

int ObTextRetrievalBlockMaxIter::get_next_row()
{
  int ret = OB_SUCCESS;
  if (IS_NOT_INIT) {
    ret = OB_NOT_INIT;
  } else if (OB_UNLIKELY(in_shallow_status_)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (OB_FAIL(token_iter_.get_next_row())) {
    if (OB_UNLIKELY(OB_ITER_END != ret)) {
    }
  } else if (OB_FAIL(token_iter_.get_curr_id(curr_id_))) {
  }
  return ret;
}

int ObTextRetrievalBlockMaxIter::get_next_batch(const int64_t capacity, int64_t &count)
{
  return OB_NOT_IMPLEMENT;
}

int ObTextRetrievalBlockMaxIter::advance_to(const ObDatum &id_datum)
{
  int ret = OB_SUCCESS;
  if (IS_NOT_INIT) {
    ret = OB_NOT_INIT;
  } else if (OB_FAIL(token_iter_.advance_to(id_datum))) {
    if (OB_UNLIKELY(OB_ITER_END != ret)) {
    }
  } else if (OB_FAIL(token_iter_.get_curr_id(curr_id_))) {
  } else {
    in_shallow_status_ = false;
  }
  return ret;
}

int ObTextRetrievalBlockMaxIter::advance_shallow(const ObDatum &id_datum, const bool inclusive)
{
  int ret = OB_SUCCESS;
  if (IS_NOT_INIT) {
    ret = OB_NOT_INIT;
  } else if (OB_UNLIKELY(!block_max_inited_)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (OB_FAIL(block_max_iter_.advance_to(id_datum, inclusive))) {
    if (OB_UNLIKELY(OB_ITER_END != ret)) {
    }
  } else if (OB_FAIL(block_max_iter_.get_curr_max_score_tuple(max_score_tuple_))) {
  } else {
    // max_score_tuple_->min_domain_id_ should not be smaller than $id_datum
    curr_id_ = max_score_tuple_->min_domain_id_;
    in_shallow_status_ = true;
  }
  return ret;
}

int ObTextRetrievalBlockMaxIter::get_curr_score(double &score) const
{
  int ret = OB_SUCCESS;
  if (IS_NOT_INIT) {
    ret = OB_NOT_INIT;
  } else if (OB_UNLIKELY(in_shallow_status_)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (OB_FAIL(token_iter_.get_curr_score(score))) {
  }
  return ret;
}

int ObTextRetrievalBlockMaxIter::get_curr_id(const ObDatum *&id_datum) const
{
  int ret = OB_SUCCESS;
  if (IS_NOT_INIT) {
    ret = OB_NOT_INIT;
  } else if (OB_ISNULL(curr_id_)) {
    ret = OB_ERR_UNEXPECTED;
  } else {
    id_datum = curr_id_;
  }
  return ret;
}

int ObTextRetrievalBlockMaxIter::get_dim_max_score(double &score)
{
  int ret = OB_SUCCESS;
  if (IS_NOT_INIT) {
    ret = OB_NOT_INIT;
  } else if (OB_UNLIKELY(!block_max_inited_)) {
    ret = OB_ERR_UNEXPECTED;
  } else {
    score = dim_max_score_;
  }
  return ret;
}

int ObTextRetrievalBlockMaxIter::get_curr_block_max_info(const ObMaxScoreTuple *&max_score_tuple)
{
  int ret = OB_SUCCESS;
  if (IS_NOT_INIT) {
    ret = OB_NOT_INIT;
  } else if (OB_UNLIKELY(!block_max_inited_)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (OB_ISNULL(max_score_tuple_)) {
    ret = OB_ERR_UNEXPECTED;
  } else {
    max_score_tuple = max_score_tuple_;
  }
  return ret;
}

bool ObTextRetrievalBlockMaxIter::in_shallow_status() const
{
  return in_shallow_status_;
}

int ObTextRetrievalBlockMaxIter::calc_dim_max_score(
    const ObBlockMaxScoreIterParam &block_max_iter_param,
    const ObBlockMaxBM25RankingParam &ranking_param,
    ObTableScanParam &scan_param)
{
  int ret = OB_SUCCESS;
  // Maybe a specialized interface to calculate dimension max score based on statistics is more efficient
  if (OB_FAIL(block_max_iter_.init(ranking_param, block_max_iter_param, scan_param))) {
  }

  while (OB_SUCC(ret)) {
    const ObMaxScoreTuple *max_score_tuple = nullptr;
    if (OB_FAIL(block_max_iter_.get_next(max_score_tuple))) {
      if (OB_UNLIKELY(OB_ITER_END != ret)) {
      }
    } else if (OB_ISNULL(max_score_tuple)) {
      ret = OB_ERR_UNEXPECTED;
    } else {
      dim_max_score_ = std::max(dim_max_score_, max_score_tuple->max_score_);
    }
  }

  if (OB_LIKELY(OB_ITER_END == ret)) {
    ret = OB_SUCCESS;
    block_max_iter_.reset(); // TODO: reuse or rewind iter
  } else {
  }
  return ret;
}

int ObTextRetrievalBlockMaxIter::init_block_max_iter(const int64_t total_doc_cnt, const double avg_doc_token_cnt)
{
  int ret = OB_SUCCESS;
  if (IS_NOT_INIT) {
    ret = OB_NOT_INIT;
  } else if (OB_UNLIKELY(block_max_inited_)) {
    ret = OB_INIT_TWICE;
  } else if (FALSE_IT(ranking_param_.total_doc_cnt_ = total_doc_cnt)) {
  } else if (FALSE_IT(ranking_param_.avg_doc_token_cnt_ = avg_doc_token_cnt)) {
  } else if (OB_FAIL(token_iter_.get_token_doc_cnt(ranking_param_.doc_freq_))) {
  } else if (OB_FAIL(calc_dim_max_score(*block_max_iter_param_, ranking_param_, *block_max_scan_param_))) {
  } else if (OB_FAIL(block_max_iter_.init(ranking_param_, *block_max_iter_param_, *block_max_scan_param_))) {
  } else {
    block_max_inited_ = true;
  }
  return ret;
}

} // namespace storage
} // namespace oceanbase
