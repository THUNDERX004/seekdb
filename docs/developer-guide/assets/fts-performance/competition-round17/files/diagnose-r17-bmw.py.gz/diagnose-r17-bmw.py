"""Unscored complete ranked-output diagnosis, never creates expected fixtures."""
import argparse
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import socket
import subprocess
import time
import pymysql

ROOT = Path(r"D:/Projects/OceanBase/seekdb")
HERE = Path(__file__).resolve().parent
p = argparse.ArgumentParser()
p.add_argument("--binary", required=True, type=Path)
p.add_argument("--label", required=True)
a = p.parse_args()
assert all(c.isalnum() or c in "-_" for c in a.label)
OUT = HERE / a.label
assert not OUT.exists()
with socket.socket() as probe:
    assert probe.connect_ex(("127.0.0.1", 2891)) != 0
OUT.mkdir()
binary = a.binary.resolve()
base = Path(r"C:/Users/11946/AppData/Local/Temp") / ("seekdb-fts-" + a.label)
assert not base.exists()
cmd = [str(binary), "--nodaemon", "--base-dir=" + str(base), "--port=2891",
       "--parameter", "rpc_port=2892", "--parameter", "cpu_count=4",
       "--parameter", "memory_budget=2G", "--parameter", "log_disk_size=2G", "--log-level=WARN"]
result = dict(purpose="Unscored failed-regression diagnosis, actual outputs only", binary=str(binary),
              binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(), base_dir=str(base))
with (OUT / "server.log").open("wb") as log:
    proc = subprocess.Popen(cmd, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW)
    try:
        for _ in range(120):
            assert proc.poll() is None, "Server exited"
            try:
                conn = pymysql.connect(host="127.0.0.1", port=2891, user="root", connect_timeout=1)
                conn.close()
                break
            except (OSError, pymysql.MySQLError):
                time.sleep(1)
        else:
            raise RuntimeError("Startup timeout")
        spec = importlib.util.spec_from_file_location("ranked", ROOT / "unittest/storage/fts/test_ranked_batches.py")
        ranked = importlib.util.module_from_spec(spec); spec.loader.exec_module(ranked)
        actual = ranked.capture(dict(host="127.0.0.1", port=2891, user="root", charset="utf8mb4", autocommit=True, read_timeout=180))
        fixture = ROOT / "unittest/storage/fts/ranked_batches_expected.json.gz"
        expected = json.loads(gzip.decompress(fixture.read_bytes()))
        result["fixture_sha256"] = hashlib.sha256(fixture.read_bytes()).hexdigest()
        raw = (json.dumps(actual, ensure_ascii=True, separators=(",", ":")) + chr(10)).encode()
        (OUT / "actual-ranked-output.json.gz").write_bytes(gzip.compress(raw, mtime=0))
        differences = []
        for index, (left, right) in enumerate(zip(expected, actual)):
            try:
                ranked.compare(left, right)
            except AssertionError as error:
                differences.append(dict(case=index, header=right[:4], first_difference=str(error),
                                        expected=left[4] if len(left[4]) < 25 else left[4][:5],
                                        actual=right[4] if len(right[4]) < 25 else right[4][:5],
                                        expected_rows=len(left[4]), actual_rows=len(right[4])))
        result.update(cases=len(actual), expected_cases=len(expected), differences=differences)
    finally:
        if proc.poll() is None:
            proc.terminate()
            try:
                proc.wait(timeout=20)
            except subprocess.TimeoutExpired:
                proc.kill(); proc.wait()
        (OUT / "diagnosis.json").write_text(json.dumps(result, indent=2) + chr(10), encoding="utf-8")
print(json.dumps(dict(cases=result["cases"], differing_cases=len(result["differences"]),
                      first=result["differences"][:1]), indent=2))
