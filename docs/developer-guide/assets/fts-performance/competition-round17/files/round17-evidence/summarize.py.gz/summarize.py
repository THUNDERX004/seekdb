"""Offline single complete pair; retain all metrics and reject target regression."""
import hashlib
import json
from pathlib import Path
import re
import sys
from statistics import mean

HERE = Path(__file__).resolve().parent
FTS = HERE.parent
CLASSES = {"build": ["build_ik_all_sec", "build_ik_content_sec", "build_beng_en_sec"],
           "tokenize": ["tokenize_ik_avg_ms", "tokenize_beng_avg_ms"],
           "query": ["query_cn_avg_ms", "query_beng_avg_ms", "query_mixed_avg_ms", "query_limit_avg_ms"]}
PINS = {"control": "58a14c4b3cfb44464882de1d87b0f8018c76595a563e039ff3cbd8be2351f07d",
        "candidate": "df0547dbdf5d79d971be202f5cfc50480ad66f637ebbdf00e8d15218024f6159"}
PARAMS = dict(rows=20000, batch=500, rounds=3000, query_rounds=200, samples=3, warmup=30, skip_load=0)
HITS = dict(query_cn_hits=8001, query_beng_hits=11000, query_mixed_hits=7332, query_limit_hits=20)
inputs, reports, records = {}, {}, {}
def read(path):
    raw = path.read_bytes()
    inputs[path.relative_to(FTS).as_posix()] = dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
    return raw

for variant, pin in PINS.items():
    label = f"r17-bmw-v2-{variant}-a1"
    record = json.loads(read(FTS / f"{label}-experiment.json"))
    assert record["label"] == label and record["binary_sha256"] == pin and record["log_level"] == "WARN"
    assert all(x["exit_code"] == 0 for x in record["actions"])
    for action in ("benchmark", "input-validation"):
        assert sum(x["action"] == action for x in record["actions"]) == 1
    report_path = FTS / f"{label}-report.txt"
    assert Path(record["report"]).resolve() == report_path.resolve()
    raw = read(report_path).decode("utf-8-sig")
    assert raw.count("FTS Large Benchmark Report") == 1
    fields = dict(re.findall(r"^([A-Za-z0-9_]+):\s*(.*?)\s*$", raw, re.M))
    assert fields["label"] == label
    assert all(float(fields[k]) == v for k, v in {**PARAMS, **HITS}.items())
    affinity = json.loads(read(FTS / f"{label}-affinity.json"))
    assert affinity["mask"] == 15 and affinity["logical_cpu_ids"] == [0, 1, 2, 3]
    reports[variant], records[variant] = fields, record

metrics, classes = [], {}
for category, names in CLASSES.items():
    reductions = []
    for name in names:
        control, candidate = (float(reports[x][name]) for x in ("control", "candidate"))
        reduction = (control - candidate) / control
        metrics.append(dict(metric=name, control=control, candidate=candidate, reduction=reduction))
        reductions.append(reduction)
    classes[category] = mean(reductions)
result = dict(schema_version=1, experiment="round17-bmw-v2", completed_pairs=1, decision="REJECT",
              reason="Target LIMIT query regressed about41.5%; looser upper bound can increase subsequent traversal. Untouched build/tokenize fluctuations do not prove candidate benefit. Stop rather than spend further full pairs on this rejected proposal. No statistical stability claim.",
              method="Single complete adjacent pair; arithmetic mean within categories then equal category mean. All nine metrics and negatives retained; no SELECT1 subtraction or selected samples.",
              official_baseline="5bce9e06d1281347ad61344e4b01fab9158c58a2",
              parameters=PARAMS, hits=HITS, binary_pins=PINS, metrics=metrics, class_reductions=classes,
              overall_reduction=mean(classes.values()), metadata=records, input_hashes=inputs,
              correctness="V1 fails two Boolean ordered LIMIT tie cases, control full432 exact pass. V2 passed unchanged432 ranked,192keytypes andseven suites. Prepared extra SQL/native helpers not executed; no additional pass claimed.",
              restoration="Allfour production files copied from exact v2 originals and hashes verified. Initial restore build no-op due inherited old timestamps, then touched verified originals and explicitly rebuilt. Neither build is a performance sample.",
              formal_score="No new formal evaluation; 50/50 unproven")
raw = (json.dumps(result, indent=2) + chr(10)).encode()
target = HERE / "comparison.json"
if target.exists():
    assert target.read_bytes() == raw or "--refresh" in sys.argv
if not target.exists() or "--refresh" in sys.argv:
    target.write_bytes(raw)
print(json.dumps(dict(classes=classes, overall=result["overall_reduction"], decision="REJECT"), indent=2))
