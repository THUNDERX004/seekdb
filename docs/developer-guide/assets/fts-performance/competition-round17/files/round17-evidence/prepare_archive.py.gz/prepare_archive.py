"""Read existing round17 evidence and stage documentation; no workloads or Git."""
from __future__ import annotations
import ast
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
FTS = HERE.parent
ROOT = Path(r"D:\Projects\OceanBase\seekdb")

def require(ok, message):
    if not ok:
        raise RuntimeError(message)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read(path):
    return json.loads(path.read_bytes().decode("utf-8-sig"))

def write(name, value):
    path = HERE / name
    require(not path.exists(), f"Refuse overwrite: {path}")
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")

def main():
    for name in ("source.json", "disposition.json", "preflight.json", "reference", "docs-staging"):
        require(not (HERE / name).exists(), f"Preparation already present: {name}")
    frozen = {}
    def pin(path):
        relative = path.relative_to(FTS).as_posix()
        frozen[relative] = {"source": relative, "bytes": path.stat().st_size, "sha256": sha(path)}
        return frozen[relative]
    comparison = read(HERE / "comparison.json")
    comparison_pin = pin(HERE / "comparison.json")
    require(comparison["completed_pairs"] == 1 and comparison["decision"] == "REJECT", "Expected one rejected complete pair")
    payloads = {}
    for name, key in (("round17-query-proposal", "candidate_sha256"), ("round17-query-proposal-v2", "v2_sha256")):
        directory = FTS / name
        manifest = read(directory / "manifest.json"); pin(directory / "manifest.json")
        payloads[name] = []
        for item in manifest["files"]:
            for sub, expected in ((item["path"], item[key]), ("original/" + item["path"], item["original_sha256"])):
                path = directory / sub
                require(sha(path) == expected, f"Proposal source pin failed: {path}")
                payloads[name].append(pin(path))
        patches = manifest.get("patches", {"source.patch": manifest.get("source_patch")})
        for name_patch, identity in patches.items():
            path = directory / name_patch
            require(sha(path) == identity["sha256"], f"Patch pin failed: {path}")
            pin(path)
    v2_dir = FTS / "round17-query-proposal-v2"
    v2 = read(v2_dir / "manifest.json")
    for rel, expected in v2["v1_frozen_files"].items():
        path = FTS / "round17-query-proposal" / rel
        require(sha(path) == expected, "V1 frozen identity changed")
        pin(path)
    for item in v2["files"]:
        if item["changed_from_v1"]:
            path = v2_dir / "v1-preimage" / item["path"]
            require(sha(path) == item["v1_sha256"], "V2 incremental preimage changed"); pin(path)
    live = []
    for item in v2["files"]:
        original = v2_dir / "original" / item["path"]
        observed = sha(ROOT / item["path"])
        require(observed == sha(original) == item["original_sha256"], "Live restoration mismatch; do not change production")
        live.append({"path": item["path"], "live_sha256": observed, "original_sha256": item["original_sha256"],
                     "matches_original": True})
    diagnoses = {}
    actuals = {}
    for variant in ("candidate", "control"):
        directory = FTS / f"r17-bmw-ranked-diagnostic-{variant}-1"
        diagnosis = read(directory / "diagnosis.json"); pin(directory / "diagnosis.json")
        raw = gzip.decompress((directory / "actual-ranked-output.json.gz").read_bytes())
        actual = json.loads(raw)
        require(len(actual) == diagnosis["cases"] == diagnosis["expected_cases"] == 432, "Incomplete full diagnosis")
        diagnoses[variant] = diagnosis; actuals[variant] = actual
        diagnoses[variant]["archival_payload_identity"] = {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest(),
                                                        "source": pin(directory / "actual-ranked-output.json.gz")}
    require([x["case"] for x in diagnoses["candidate"]["differences"]] == [49, 265], "Unexpected V1 failure cases")
    require(diagnoses["control"]["differences"] == [], "Control diagnosis differs")
    for index in (49, 265):
        require(actuals["candidate"][index][4] == [[2170, 0.5001172075859774]]
                and actuals["control"][index][4] == [[1585, 0.5001172075859774]], "Exact ID/score evidence mismatch")
    fixture = ROOT / "unittest/storage/fts/ranked_batches_expected.json.gz"
    require(sha(fixture) == diagnoses["candidate"]["fixture_sha256"] == diagnoses["control"]["fixture_sha256"],
            "Independent original fixture identity mismatch")
    reference = HERE / "reference"; reference.mkdir()
    fixture_target = reference / "ranked_batches_expected.original.json.gz"
    fixture_target.write_bytes(fixture.read_bytes()); pin(fixture_target)
    comparator = ROOT / "unittest/storage/fts/test_ranked_batches.py"
    (reference / comparator.name).write_bytes(comparator.read_bytes()); pin(reference / comparator.name)
    native_dir = FTS / "round17-bmw-native"
    native = read(native_dir / "preparation.json"); pin(native_dir / "preparation.json")
    require(all(native[k] == "NOT RUN" for k in ("compile", "link", "native", "sql", "performance")), "Native status changed")
    for item in native["files"]:
        path = native_dir / item["path"]
        require(path.stat().st_size == item["bytes"] and sha(path) == item["sha256"], "Frozen native preparation changed"); pin(path)
    no_op = FTS / "round18-profile-control-build.log"
    rebuild = FTS / "round18-profile-control-rebuild-build.log"
    require(b"ninja: no work to do" in no_op.read_bytes(), "Missing initial no-op evidence")
    require(b"[1/7]" in rebuild.read_bytes() and b"[6/7] Linking CXX executable" in rebuild.read_bytes(),
            "Missing actual seven-task-chain evidence")
    source = {"schema_version": 1, "checked_utc": datetime.now(timezone.utc).isoformat(),
              "official_baseline": comparison["official_baseline"], "remote_git_verification": "Not performed; prohibited archival scope",
              "comparison": comparison_pin, "source_payloads": payloads, "restored_live_files": live,
              "binary_identities": {"v1": diagnoses["candidate"]["binary_sha256"], **comparison["binary_pins"]},
              "v1_parent_source_commit": read(FTS / "r17-bmw-candidate-a1-experiment.json")["source_commit"],
              "v2_parent_source_commit": comparison["metadata"]["candidate"]["source_commit"],
              "original_fixture": {"copied_from": str(fixture), **pin(fixture_target)},
              "complete_actual_diagnoses": diagnoses,
              "restore_builds": {"initial_no_op": pin(no_op), "actual_seven_task_chain": pin(rebuild),
                                 "timestamp_cause": "Inherited old timestamps and subsequent touch reported by parent; not independently inferred from log"},
              "limits": "Read-only source hash observation, no archive/binary rehash or rebuild; no round18 profiles imported"}
    write("source.json", source)
    write("disposition.json", {"schema_version": 1, "v1": "REJECT: exact Boolean ordered-LIMIT IDs differ at cases49/265",
          "v2": "REJECT: target LIMIT slower in one full matched pair", "completed_pairs": 1,
          "comparison_statistics": "Original comparison.json preserved, including favorable values; no significance or causal claim",
          "v2_existing_correctness": "432 ranked,192 key-type,seven suites passed in parent logs; no expanded coverage",
          "extra_sql_regression": "Preparation stopped before runnable source/fixture; NOT RUN",
          "native": "616096 planned only; compile/link/runtime NOT RUN",
          "restoration": "Four production files independently match saved original hashes at archival check; no-op then actual seven-task chain logged",
          "new_formal_score": "NONE; 50/50 unproven",
          "sidecar_actions": "Offline reads, documentation and evidence bytes only; no build/run/profile/SQL/production edits/Git"})
    staging = HERE / "docs-staging"; staging.mkdir()
    documentation = {}
    for language in ("zh-CN", "en"):
        rel = f"docs/developer-guide/{language}/fts-performance.md"
        path = ROOT / rel; before = path.read_bytes()
        fragment = (HERE / f"report.{language}.md").read_bytes()
        newline = b"\r\n" if b"\r\n" in before else b"\n"
        first, separator, rest = before.partition(newline)
        require(separator and b"competition-round17/manifest.json" not in before, "Existing round17 section or invalid report")
        addition = fragment.replace(b"\r\n", b"\n").replace(b"\n", newline)
        after = first + newline + newline + addition + rest
        staged = staging / f"{language}.md"; staged.write_bytes(after)
        documentation[rel] = {"before_sha256": hashlib.sha256(before).hexdigest(), "after_sha256": sha(staged),
                              "staged_path": staged.relative_to(HERE).as_posix(), "fragment_sha256": sha(HERE / f"report.{language}.md"),
                              "existing_remainder_preserved": after.endswith(rest)}
    for path in HERE.glob("*.py"):
        ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    write("preflight.json", {"schema_version": 1, "checks": "PASS offline pins, complete diagnostic sizes/selected IDs, original fixture, native NOT RUN, live restoration, historical logs, Python AST",
                             "documentation": documentation, "frozen_inputs": list(frozen.values())})
    print("Prepared archival identities and bilingual reports; production untouched; no workloads/Git.")

if __name__ == "__main__":
    main()
