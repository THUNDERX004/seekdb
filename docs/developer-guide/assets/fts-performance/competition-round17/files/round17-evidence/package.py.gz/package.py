"""Offline round17 documentation evidence packager. No workloads or Git."""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
FTS = HERE.parent
CHUNK = 1024 * 1024
ALLOWED = {".py", ".ps1", ".cpp", ".h", ".md", ".json", ".patch",
           ".diff", ".log", ".txt", ".rsp", ".gz"}
BLOCKED = {"tmp", "temp", "data", "logs", "log", "__pycache__", ".git",
           ".secrets", "link-intermediate"}

def require(ok, message):
    if not ok:
        raise RuntimeError(message)

def sha(path):
    result = hashlib.sha256()
    with path.open("rb") as stream:
        for data in iter(lambda: stream.read(CHUNK), b""):
            result.update(data)
    return result.hexdigest()

def json_raw(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")

def read(path):
    return json.loads(path.read_bytes().decode("utf-8-sig"))

def collect():
    files = {}
    def add(path):
        resolved = path.resolve()
        require(resolved.is_relative_to(FTS) and resolved.is_file(), f"Not auxiliary file: {path}")
        rel = resolved.relative_to(FTS)
        require(not any(p.lower() in BLOCKED for p in rel.parts), f"Blocked directory: {rel}")
        require(resolved.suffix.lower() in ALLOWED, f"Blocked extension: {rel}")
        require(resolved.stat().st_size <= 64 * CHUNK, f"Oversized artifact: {rel}")
        files[rel.as_posix()] = resolved
    for path in sorted(FTS.glob("r17-bmw-*")):
        if path.is_file():
            add(path)
    for name in ("round17-query-proposal", "round17-query-proposal-v2", "round17-ddl-proposal",
                 "round17-bmw-regression", "round17-bmw-native",
                 "r17-bmw-ranked-diagnostic-candidate-1", "r17-bmw-ranked-diagnostic-control-1"):
        for path in sorted((FTS / name).rglob("*")):
            if path.is_file():
                add(path)
    for name in ("diagnose-r17-bmw.py", "round17-bmw-bound-build.log",
                 "round17-bmw-bound-v2-build.log", "round18-profile-control-build.log",
                 "round18-profile-control-rebuild-build.log"):
        add(FTS / name)
    # Root-only selection prevents recursive inclusion of archive/staged docs.
    for path in sorted(HERE.iterdir()):
        if path.is_file() and path.suffix in ALLOWED and path.name not in ("manifest.json", "verification.json", "publication.json"):
            add(path)
    for path in sorted((HERE / "reference").iterdir()):
        if path.is_file():
            add(path)
    required = [HERE / name for name in ("comparison.json", "source.json", "disposition.json",
                "report.en.md", "report.zh-CN.md", "preflight.json")]
    for path in required:
        add(path)
    comparison = read(HERE / "comparison.json")
    require(comparison["completed_pairs"] == 1 and comparison["decision"] == "REJECT", "Must retain one-pair rejection")
    for rel, pin in comparison["input_hashes"].items():
        path = FTS / rel
        add(path)
        require(sha(path) == pin["sha256"] and path.stat().st_size == pin["bytes"], f"Comparison input changed: {rel}")
    preflight = read(HERE / "preflight.json")
    for pin in preflight["frozen_inputs"]:
        path = FTS / pin["source"]
        add(path)
        require(sha(path) == pin["sha256"] and path.stat().st_size == pin["bytes"], f"Frozen identity changed: {pin['source']}")
    native = read(FTS / "round17-bmw-native/preparation.json")
    require(all(native[key] == "NOT RUN" for key in ("compile", "link", "native", "sql", "performance")),
            "Native preparation no longer NOT RUN")
    require(not list((FTS / "round17-bmw-native").glob("parent-build-*"))
            and not list((FTS / "round17-bmw-native").glob("parent-run-*")), "Unexpected native execution artifacts")
    require(sum(path.stat().st_size for path in files.values()) <= 256 * CHUNK, "Total evidence bound exceeded")
    return files

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", required=True, type=Path)
    args = parser.parse_args()
    destination = args.output_dir.resolve()
    require(destination.parent == HERE and not destination.exists(), "Use a NEW direct auxiliary child")
    files = collect()
    pins = {rel: {"raw_bytes": path.stat().st_size, "raw_sha256": sha(path)} for rel, path in files.items()}
    destination.mkdir()
    entries = []
    for rel, source in sorted(files.items()):
        packed_rel = "files/" + rel + ".gz"
        target = destination / packed_rel
        target.parent.mkdir(parents=True, exist_ok=True)
        with source.open("rb") as raw, target.open("xb") as out:
            with gzip.GzipFile(filename="", mode="wb", fileobj=out, compresslevel=9, mtime=0) as stream:
                for block in iter(lambda: raw.read(CHUNK), b""):
                    stream.write(block)
        entries.append({"source": rel, "path": packed_rel, **pins[rel],
                        "packed_bytes": target.stat().st_size, "packed_sha256": sha(target),
                        "source_encoding": "gzip preserved inside outer gzip" if source.suffix == ".gz" else "raw bytes"})
    for rel, path in files.items():
        require(sha(path) == pins[rel]["raw_sha256"] and path.stat().st_size == pins[rel]["raw_bytes"],
                f"Source changed during packaging: {rel}")
    manifest = {"schema_version": 1, "created_utc": datetime.now(timezone.utc).isoformat(),
                "experiment": "round17 rejected BMW V1/V2", "source_root": str(FTS),
                "encoding": "Exact binary streams; no newline conversion; deterministic gzip header; nested gzip retains compressed originals",
                "decision": read(HERE / "disposition.json"), "completed_pairs": 1,
                "comparison": {"source": "round17-evidence/comparison.json", "raw_sha256": sha(HERE / "comparison.json"),
                               "treatment": "Archived verbatim, not recomputed"},
                "native": "PREPARATION ONLY; compile/link/execution NOT RUN; no native pass",
                "files": entries}
    (destination / "manifest.json").write_bytes(json_raw(manifest))
    (destination / "COMPLETE.json").write_bytes(json_raw({"status": "COMPLETE", "file_count": len(entries),
                                                         "manifest_sha256": sha(destination / "manifest.json")}))
    print(f"Archived {len(entries)} exact inputs; verify before publication: {destination}")

if __name__ == "__main__":
    try:
        main()
    except (RuntimeError, OSError, ValueError, KeyError) as error:
        print("ERROR:", error, file=sys.stderr)
        sys.exit(1)
