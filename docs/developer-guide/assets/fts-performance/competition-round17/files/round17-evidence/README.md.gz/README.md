# Round17 rejected BMW experiments: archival scope

V1 and v2 are rejected. This archival sidecar writes documentation and bounded
evidence only. It does not build, run SQL/native/benchmark workloads, profile,
modify production source, invoke Git, commit or push. Parent round18 work is
outside this archive except the two already-completed restoration build logs.

V1's complete 432-case candidate/control diagnoses are preserved, including
both actual-output gzip streams. Cases 49 and 265 return ID 2170 instead of
1585 at the same score 0.5001172075859774; the control has zero differences.
The failed original ranked test traceback is retained. Equal score does not
excuse a changed ordered-LIMIT result ID.

V2 passed the existing 432 ranked cases, 192 key-type cases and seven suites.
Only ONE complete matched full benchmark pair exists. Target query_limit is
3.2295 ms versus 2.2823 ms control, approximately 41.5% slower. All nine metrics
and the existing single-pair summary remain intact, including the positive
overall value; this does not establish benefit, stability or causality in
untouched build/tokenize paths. No new formal score is claimed.

Native helper compile/link/execution remain NOT RUN; its 616,096 cases are only
planned. The extra SQL regression was stopped before a runnable test or new
fixture existed. Both preparations are archived as such. Source formula
reasoning or native readiness is not integration proof.

Restoration evidence distinguishes the initial no-op build from the subsequent
actual seven-task rebuild. Neither is a benchmark sample. Exact staged original
and candidate source/patch bytes are retained without newline normalization.
Packaging uses binary gzip streams and records raw and packed SHA-256 values.
Already-gzipped diagnoses receive an outer gzip layer to preserve their exact
original compressed bytes. Binaries, PDB/OBJ/LIB/DLL, tmp, runtime data/log trees
and unrelated round18 profiles are excluded.
