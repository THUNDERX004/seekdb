"""Read-only gzip/hash verification, optionally writing an auxiliary report."""
from __future__ import annotations
import argparse
import gzip
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
FTS = HERE.parent
CHUNK = 1024 * 1024

def require(ok, message):
    if not ok:
        raise RuntimeError(message)

def sha(path):
    result = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(CHUNK), b""):
            result.update(block)
    return result.hexdigest()

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--package-dir", required=True, type=Path)
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    directory = args.package_dir.resolve()
    manifest_path = directory / "manifest.json"
    manifest = json.loads(manifest_path.read_bytes())
    complete = json.loads((directory / "COMPLETE.json").read_bytes())
    require(complete["status"] == "COMPLETE" and complete["manifest_sha256"] == sha(manifest_path), "Completion pin mismatch")
    paths = set()
    for item in manifest["files"]:
        target = (directory / item["path"]).resolve()
        source = (FTS / item["source"]).resolve()
        require(target.is_relative_to(directory) and source.is_relative_to(FTS), "Unsafe manifest path")
        require(item["path"] not in paths, "Duplicate archive path")
        paths.add(item["path"])
        require(sha(target) == item["packed_sha256"] and target.stat().st_size == item["packed_bytes"], "Packed bytes changed")
        digest = hashlib.sha256(); size = 0
        with gzip.open(target, "rb") as stream:
            for block in iter(lambda: stream.read(CHUNK), b""):
                size += len(block); digest.update(block)
        require(size == item["raw_bytes"] and digest.hexdigest() == item["raw_sha256"], "Gzip raw identity failed")
        require(source.stat().st_size == size and sha(source) == item["raw_sha256"], "Original input changed")
    actual = {p.relative_to(directory).as_posix() for p in directory.rglob("*") if p.is_file()}
    require(actual == paths | {"manifest.json", "COMPLETE.json"}, "Missing/unlisted package files")
    require(len(paths) == complete["file_count"] and manifest["completed_pairs"] == 1, "Count mismatch")
    result = {"status": "PASS", "kind": "offline evidence byte verification only",
              "package_dir": str(directory), "file_count": len(paths), "manifest_sha256": sha(manifest_path),
              "packed_raw_roundtrip_and_source_hashes": "all match",
              "native": "NOT RUN", "build_sql_profile_benchmark_git": "NOT RUN by archival sidecar"}
    if args.report:
        path = args.report.resolve()
        require(path.parent == HERE, "Verification report must be auxiliary")
        path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps(result, ensure_ascii=True))

if __name__ == "__main__":
    main()
