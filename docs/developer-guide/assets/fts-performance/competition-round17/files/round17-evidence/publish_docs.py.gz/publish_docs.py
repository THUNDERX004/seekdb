"""Publish prepared round17 docs/assets only; no production/build/Git operations."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import shutil

HERE = Path(__file__).resolve().parent
ROOT = Path(r"D:\Projects\OceanBase\seekdb")
ASSET = ROOT / "docs/developer-guide/assets/fts-performance/competition-round17"
REPORTS = ("docs/developer-guide/zh-CN/fts-performance.md", "docs/developer-guide/en/fts-performance.md")

def require(ok, message):
    if not ok:
        raise RuntimeError(message)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args()
    require(args.execute, "Explicit --execute required")
    archive = HERE / "archive"
    preflight = json.loads((HERE / "preflight.json").read_bytes())
    completion = json.loads((archive / "COMPLETE.json").read_bytes())
    require(completion["status"] == "COMPLETE" and completion["manifest_sha256"] == sha(archive / "manifest.json"),
            "Auxiliary archive incomplete")
    verified = json.loads((HERE / "verification.json").read_bytes())
    require(verified["status"] == "PASS" and verified["manifest_sha256"] == completion["manifest_sha256"],
            "Missing verified archive")
    require(not ASSET.exists(), "Round17 asset directory already exists; refusing overwrite")
    require(set(preflight["documentation"]) == set(REPORTS), "Unexpected documentation scope")
    changes = []
    for rel in REPORTS:
        item = preflight["documentation"][rel]
        target = ROOT / rel
        staged = (HERE / item["staged_path"]).resolve()
        require(staged.is_relative_to(HERE), "Invalid staged path")
        require(sha(target) == item["before_sha256"], f"Concurrent report change: {rel}")
        require(sha(staged) == item["after_sha256"], "Staged report changed")
        changes.append((target, staged, item))
    # All mutations are explicitly confined to the new asset directory and two reports.
    shutil.copytree(archive, ASSET)
    for target, staged, item in changes:
        target.write_bytes(staged.read_bytes())
        require(sha(target) == item["after_sha256"], "Published report mismatch")
    record = {"status": "PUBLISHED DOCS ONLY", "asset_dir": str(ASSET),
              "manifest_sha256": sha(ASSET / "manifest.json"),
              "reports": [{"path": str(p), "sha256": sha(p)} for p, _, _ in changes],
              "production_build_runtime_profile_sql_git": "NOT RUN"}
    (HERE / "publication.json").write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps(record, ensure_ascii=True))

if __name__ == "__main__":
    main()
