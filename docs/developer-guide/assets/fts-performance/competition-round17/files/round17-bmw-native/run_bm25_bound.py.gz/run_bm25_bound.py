"""Parent-only bounded native execution; never builds or runs SQL/performance work."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

HERE = Path(__file__).resolve().parent


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def sha(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--build-output", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--execute", action="store_true")
    parser.add_argument("--timeout", type=int, default=180)
    args = parser.parse_args()
    require(args.execute and 1 <= args.timeout <= 600, "Parent must explicitly pass --execute; timeout 1..600 seconds")
    build, output = args.build_output.resolve(), args.output_dir.resolve()
    require(build.is_relative_to(HERE) and build != HERE, "Build must belong to this helper")
    require(output.is_relative_to(HERE) and output != HERE and not output.exists(), "Use a NEW helper run directory")
    require(not output.is_relative_to(build) and not build.is_relative_to(output), "Separate build and run directories")
    receipt_path = build / "receipt.json"
    receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
    require(receipt.get("build_succeeded") and all(receipt["bm25_source_matches"].values()), "Missing successful production-linked helper build receipt")
    require(sha(HERE / "build-settings.json") == receipt["settings_sha256"], "Capture changed")
    require(sha(HERE / "test_bm25_bound.cpp") == receipt["test_sha256"], "Frozen test changed")
    map_path = build / "test_bm25_bound.map"
    require(sha(map_path) == receipt["production_function_map"]["sha256"], "Production symbol link map changed")
    executable = build / "test_bm25_bound.exe"
    require(sha(executable) == receipt["executable_sha256"], "Executable changed")
    for dll in receipt["runtime_dlls"]:
        require(sha(build / dll["name"]) == dll["sha256"], "Runtime DLL changed")
    output.mkdir()
    (output / "build-receipt.json").write_bytes(receipt_path.read_bytes())
    result = {"native": "PENDING", "output_validation": "PENDING", "sql": "NOT RUN", "performance": "NOT RUN",
              "executable_sha256": sha(executable), "settings_sha256": receipt["settings_sha256"],
              "oracle": "actual production query/doc weight symbols and public eval wrapper; numeric bound only, no integration oracle"}
    def save():
        (output / "run.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    save()
    environment = os.environ.copy()
    temp = output / "tmp"; temp.mkdir()
    environment["TEMP"] = environment["TMP"] = str(temp)
    environment["PATH"] = str(build) + os.pathsep + environment.get("PATH", "")
    with (output / "stdout.log").open("wb") as stdout, (output / "stderr.log").open("wb") as stderr:
        try:
            completed = subprocess.run([str(executable)], cwd=output, env=environment,
                                       stdout=stdout, stderr=stderr, timeout=args.timeout)
        except subprocess.TimeoutExpired:
            result["native"] = "TIMEOUT"; save()
            raise RuntimeError("Native timeout; output preserved")
    result["exit_code"] = completed.returncode
    result["native"] = "PASS" if completed.returncode == 0 else "FAIL"
    result["logs_sha256"] = {name: sha(output / name) for name in ("stdout.log", "stderr.log")}
    save()
    require(completed.returncode == 0, "Native checks failed; inspect stderr/stdout")
    require((output / "stdout.log").stat().st_size <= 64 * 1024 * 1024, "Native log exceeded 64 MiB parsing bound")
    lines = (output / "stdout.log").read_bytes().splitlines()
    summaries = [line for line in lines if line.startswith(b"PASS\t")]
    require(len(summaries) == 1, "Missing/duplicate native PASS summary")
    values = {}
    for token in summaries[0].decode("ascii").split("\t")[1:]:
        key, sep, value = token.partition("=")
        require(sep and key not in values and re.fullmatch(r"\d+", value), "Malformed native count")
        values[key] = int(value)
    require(values["cases"] == receipt["planned_cases"] == 616096 and values["cases"] <= receipt["case_limit"] <= 1000000,
            "Incomplete/oversized numeric corpus")
    require(values["grid"] == 516096 and values["random"] == 100000 and values["checks"] == values["cases"] * 8
            and values["failures"] == 0, "Incomplete exact-bound checks")
    require(all(values[name] > 0 for name in ("df_gt_total", "coherent_tf", "infinite_norm", "subnormal_avg",
                                             "subnormal_norm", "zero_weight", "unit_weight", "score_equals_bound")),
            "Missing declared numeric edge coverage")
    result["output_validation"] = "PASS"; result["summary"] = values; save()
    print("PASS production-linked numeric BM25 bound only:", output / "run.json")


if __name__ == "__main__":
    try:
        main()
    except (RuntimeError, OSError, ValueError, KeyError) as error:
        print("ERROR:", error, file=sys.stderr)
        sys.exit(1)
