param(
    [Parameter(Mandatory = $true)][string]$OutputDir,
    [string]$Python = 'python.exe',
    [switch]$Capture,
    [switch]$Build
)
$ErrorActionPreference = 'Stop'
if ($Capture -and $Build) { throw '-Capture and -Build are mutually exclusive; capture never compiles.' }
$env:PYTHONUTF8 = '1'
if ($Build) {
    $bmwNativeVs = 'C:\Program Files\Microsoft Visual Studio\2022\BuildTools'
    Import-Module (Join-Path $bmwNativeVs 'Common7\Tools\Microsoft.VisualStudio.DevShell.dll')
    Enter-VsDevShell -VsInstallPath $bmwNativeVs -SkipAutomaticLocation `
        -DevCmdArguments '-arch=amd64 -host_arch=amd64 -vcvars_ver=14.44 -winsdk=10.0.26100.0'
}
$bmwNativeArgs = @((Join-Path $PSScriptRoot 'prepare_bm25_bound.py'), '--output-dir', $OutputDir)
if ($Capture) { $bmwNativeArgs += '--capture' }
if ($Build) { $bmwNativeArgs += '--build' }
& $Python @bmwNativeArgs
exit $LASTEXITCODE
