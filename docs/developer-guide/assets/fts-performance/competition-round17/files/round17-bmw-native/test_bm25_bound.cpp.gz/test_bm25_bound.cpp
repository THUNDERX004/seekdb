/* Copyright (c) 2026 OceanBase. Licensed under the Apache License, Version 2.0. */
// Numeric property test only. Both weight functions are external production
// symbols; the score wrapper below is the real public production inline API.
#include <array>
#include <cfenv>
#include <cmath>
#include <cinttypes>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <limits>
#include <xmmintrin.h>

#include "query/engine/expr/ob_expr_bm25.h"

namespace {
using oceanbase::sql::ObExprBM25;
constexpr uint64_t CASE_LIMIT = 1000000;
constexpr uint64_t RANDOM_CASES = 100000;
constexpr int64_t I64_MAX = (std::numeric_limits<int64_t>::max)();
constexpr int64_t P31 = INT64_C(1) << 31;
constexpr int64_t P32 = INT64_C(1) << 32;
constexpr int64_t P53 = INT64_C(1) << 53;
constexpr int64_t P62 = INT64_C(1) << 62;

// Address-taking keeps the external production function dependencies explicit.
double (*volatile production_query)(int64_t, int64_t) = &ObExprBM25::query_token_weight;
double (*volatile production_doc)(int64_t, double) = &ObExprBM25::doc_token_weight;

struct Stats { int64_t df; int64_t total; };
struct Counters {
  uint64_t cases = 0, failures = 0, checks = 0;
  uint64_t df_gt_total = 0, tf_gt_doclen = 0, coherent_tf = 0;
  uint64_t infinite_norm = 0, subnormal_avg = 0, subnormal_norm = 0;
  uint64_t zero_weight = 0, unit_weight = 0, score_equals_bound = 0;
} counters;

uint64_t bits(double value)
{
  uint64_t result;
  static_assert(sizeof(result) == sizeof(value));
  std::memcpy(&result, &value, sizeof(result));
  return result;
}

void expect(bool ok, const char *check, const char *group, int64_t tf,
            int64_t doclen, double avg, Stats stat, double norm,
            double bound, double weight, double score, double wrapper)
{
  ++counters.checks;
  if (!ok) {
    if (counters.failures < 32) {
      std::fprintf(stderr,
          "FAIL case=%" PRIu64 " group=%s check=%s tf=%" PRId64
          " doclen=%" PRId64 " avg=%a avg_bits=%016" PRIx64
          " df=%" PRId64 " total=%" PRId64 " norm=%a bound=%a"
          " weight=%a score=%a wrapper=%a score_bits=%016" PRIx64
          " bound_bits=%016" PRIx64 "\n",
          counters.cases, group, check, tf, doclen, avg, bits(avg),
          stat.df, stat.total, norm, bound, weight, score, wrapper, bits(score), bits(bound));
    }
    ++counters.failures;
  }
}

bool test(const char *group, int64_t tf, int64_t doclen, double avg, Stats stat)
{
  if (counters.cases >= CASE_LIMIT || tf < 0 || doclen < 0 || stat.df < 0
      || stat.total < 0 || !std::isfinite(avg) || !(avg > 0.0)) {
    std::fprintf(stderr, "FAIL test corpus precondition/case ceiling\n");
    return false;
  }
  ++counters.cases;
  const double norm = static_cast<double>(doclen) / avg;
  const double bound = production_query(stat.df, stat.total);
  const double weight = production_doc(tf, norm);
  const double score = bound * weight;
  const double wrapper = ObExprBM25::eval(tf, doclen, stat.df, stat.total, avg);
  counters.df_gt_total += stat.df > stat.total;
  counters.tf_gt_doclen += tf > doclen;
  counters.coherent_tf += tf <= doclen;
  counters.infinite_norm += std::isinf(norm);
  counters.subnormal_avg += std::fpclassify(avg) == FP_SUBNORMAL;
  counters.subnormal_norm += std::fpclassify(norm) == FP_SUBNORMAL;
  counters.zero_weight += weight == 0.0;
  counters.unit_weight += weight == 1.0;
  counters.score_equals_bound += score == bound;
  const auto check = [&](bool ok, const char *name) {
    expect(ok, name, group, tf, doclen, avg, stat, norm, bound, weight, score, wrapper);
  };
  check(!std::isnan(norm) && norm >= 0.0, "nonnegative norm (positive infinity permitted)");
  check(std::isfinite(bound) && bound > 0.0, "finite positive production query bound");
  check(std::isfinite(weight) && weight >= 0.0 && weight <= 1.0, "production doc weight in [0,1]");
  check(std::isfinite(score) && score >= 0.0, "finite nonnegative product score");
  check(score <= bound, "EXACT product <= bound; no epsilon or bound widening");
  check(std::isfinite(wrapper) && wrapper >= 0.0, "finite nonnegative production wrapper score");
  check(wrapper <= bound, "EXACT production eval <= bound");
  check(bits(wrapper) == bits(score), "production wrapper matches external-weight composition bits");
  return counters.failures == 0;
}

// Fixed-seed data generation only; no scoring implementation is reproduced.
uint64_t random_state = UINT64_C(0x524f554e44313742);
uint64_t random_u64()
{
  random_state ^= random_state >> 12;
  random_state ^= random_state << 25;
  random_state ^= random_state >> 27;
  return random_state * UINT64_C(2685821657736338717);
}
int64_t random_nonnegative()
{
  return static_cast<int64_t>(random_u64() & static_cast<uint64_t>(I64_MAX));
}
} // namespace

int main()
{
  static_assert(std::numeric_limits<double>::is_iec559
                && std::numeric_limits<double>::digits == 53);
  const unsigned mxcsr = _mm_getcsr();
  const int rounding = std::fegetround();
  std::printf("ENV rounding=%d mxcsr=0x%08x case_limit=%" PRIu64 "\n", rounding, mxcsr, CASE_LIMIT);
  // Full subnormal corpus requires ordinary IEEE round-to-nearest with DAZ/FTZ off.
  // Fail explicitly instead of silently changing the caller's floating environment.
  if (rounding != FE_TONEAREST || (mxcsr & ((1U << 6) | (1U << 15))) != 0) {
    std::fprintf(stderr, "BLOCKED unsupported rounding or DAZ/FTZ; no numeric PASS\n");
    return 2;
  }
  constexpr std::array<int64_t, 24> counts = {
      0, 1, 2, 3, 4, 7, 15, 31, 127, 255, 65535, 65536,
      P31 - 1, P31, P32 - 1, P32, P53 - 1, P53, P53 + 1,
      P62 - 1, P62, I64_MAX - 2, I64_MAX - 1, I64_MAX};
  constexpr std::array<Stats, 32> statistics = {{
      {0, 0}, {0, 1}, {1, 0}, {1, 1}, {1, 2}, {2, 1}, {2, 2}, {2, 3},
      {3, 2}, {1, 31}, {31, 1}, {15, 31}, {16, 31}, {17, 31}, {31, 31}, {32, 31},
      {65535, 65536}, {65536, 65535}, {P31 - 1, P31}, {P31, P31 - 1},
      {P32 - 1, P32}, {P32, P32 - 1}, {P53 - 1, P53}, {P53, P53 - 1},
      {P53 + 1, P53}, {P53, P53 + 1}, {I64_MAX, 0}, {0, I64_MAX},
      {I64_MAX, I64_MAX}, {I64_MAX - 1, I64_MAX}, {I64_MAX, I64_MAX - 1}, {I64_MAX / 2, I64_MAX}}};
  const double infinity = std::numeric_limits<double>::infinity();
  const double tiny = (std::numeric_limits<double>::denorm_min)();
  const double normal = (std::numeric_limits<double>::min)();
  const double huge = (std::numeric_limits<double>::max)();
  const std::array<double, 28> averages = {
      tiny, std::nextafter(tiny, infinity), normal / 2.0, normal,
      std::nextafter(normal, 0.0), std::nextafter(normal, infinity),
      1e-300, 1e-200, 1e-100, 1e-16, 1e-6, 0.1, 0.25, 0.5,
      std::nextafter(1.0, 0.0), 1.0, std::nextafter(1.0, infinity), 2.0, 10.0, 1e6,
      std::ldexp(1.0, 53), std::ldexp(1.0, 63), 1e100, 1e200, 1e300,
      huge / 2.0, std::nextafter(huge, 0.0), huge};
  const uint64_t grid = counts.size() * counts.size() * averages.size() * statistics.size();
  const uint64_t planned = grid + RANDOM_CASES;
  if (planned > CASE_LIMIT) {
    std::fprintf(stderr, "FAIL planned corpus exceeds ceiling\n");
    return 2;
  }
  std::printf("PLAN grid=%" PRIu64 " deterministic_random=%" PRIu64 " total=%" PRIu64 "\n",
              grid, RANDOM_CASES, planned);
  for (int64_t tf : counts) {
    for (int64_t doclen : counts) {
      for (double avg : averages) {
        for (Stats stat : statistics) {
          if (!test("boundary-grid", tf, doclen, avg, stat)) { return 1; }
        }
      }
    }
  }
  for (uint64_t i = 0; i < RANDOM_CASES; ++i) {
    const int64_t tf = i % 3 == 0 ? counts[random_u64() % counts.size()] : random_nonnegative();
    const int64_t doclen = i % 5 == 0 ? counts[random_u64() % counts.size()] : random_nonnegative();
    // Every nonzero positive finite binary64 bit pattern is eligible. No NaN/Inf/zero divisor.
    const uint64_t average_bits = 1 + random_u64() % UINT64_C(0x7fefffffffffffff);
    double avg;
    std::memcpy(&avg, &average_bits, sizeof(avg));
    const Stats stat{random_nonnegative(), random_nonnegative()};
    if (!test("deterministic-random", tf, doclen, avg, stat)) { return 1; }
  }
  if (counters.cases != planned || counters.checks != planned * 8
      || !counters.df_gt_total || !counters.infinite_norm || !counters.subnormal_avg
      || !counters.subnormal_norm || !counters.unit_weight || !counters.coherent_tf) {
    std::fprintf(stderr, "FAIL incomplete corpus/counters\n");
    return 1;
  }
  std::printf("PASS\tcases=%" PRIu64 "\tchecks=%" PRIu64 "\tgrid=%" PRIu64
              "\trandom=%" PRIu64 "\tdf_gt_total=%" PRIu64 "\ttf_gt_doclen=%" PRIu64
              "\tcoherent_tf=%" PRIu64 "\tinfinite_norm=%" PRIu64
              "\tsubnormal_avg=%" PRIu64 "\tsubnormal_norm=%" PRIu64
              "\tzero_weight=%" PRIu64 "\tunit_weight=%" PRIu64
              "\tscore_equals_bound=%" PRIu64 "\tfailures=%" PRIu64 "\n",
              counters.cases, counters.checks, grid, RANDOM_CASES, counters.df_gt_total, counters.tf_gt_doclen,
              counters.coherent_tf, counters.infinite_norm, counters.subnormal_avg, counters.subnormal_norm,
              counters.zero_weight, counters.unit_weight, counters.score_equals_bound, counters.failures);
  return 0;
}
