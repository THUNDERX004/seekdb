# Round17 BMW v2: natural-language-only saturation shortcut

Final parent outcome (2026-11-04): REJECTED_TARGET_PERFORMANCE. Matched query_limit is 2.2823 ms control versus 3.2295 ms v2 (+41.5% elapsed time). Parent reports the existing correctness suites passed; no performance gain is claimed. New regression preparation is frozen NOTEXECUTED. Complete first-pair metrics and correctness basis are retained in ../round17-bmw-regression/report.md. Source payloads, patches and manifest remain unchanged. The earlier preparation notes below are historical.

Staged only. The new regression authoring task is paused at the parent's request. No expected fixture is created.

V1 failed unchanged ranked regression cases 49/265: Boolean +database -audit, ORDER BY score DESC,id LIMIT 1. Expected ID 1585 becomes 2170 with exactly the same score. See report.md and the parent's ../r17-bmw-ranked-diagnostic-candidate-1/diagnosis.json. This is a real compatibility failure; v1 is not acceptable.

## Payload and preconditions

- v1-to-v2.patch: minimal incremental delta against exact frozen v1; changes only ob_text_daat_iter.h and ob_text_daat_iter.cpp. Header preimage was unchanged by v1. Do not also apply the full patch.
- source.patch: complete four-file round17 change against the exact pre-round17 originals under original/.
- src/storage/retrieval/: final four-file v2 payload, with raw original line endings preserved. The two token-iterator files are byte-identical to v1.
- v1-preimage/: two exact incremental preimages.
- manifest.json: hashes for every preimage/output and both patches; verify before replacing files. Source differences outside these preconditions require parent reconciliation.

The new boolean requires exactly NATURAL_LANGUAGE_MODE and !function_lookup_mode_, in addition to v1's no-weights/unit-boost and numeric guards. It is assigned only after successful init, cleared at reset, and preserved for same-plan reuse. Boolean queries execute the original bound scan and pivot path. No scoring expression or heap comparator is changed.

## Parent-owned validation required

1. Run the unchanged complete ranked-batches/key-types fixtures, with exact original IDs (including 1585 at 49/265) and the existing 1e-12 float tolerance. Candidate must never record expected results.
2. Establish the actual measured query_limit BMW branch and guard eligibility on the v2 executable; verify prepass removal and local bounds retained outside scored timing.
3. Add original-recorded natural-language dense ties/high-frequency terms, rare/absent/repeated terms, LIMIT/OFFSET boundaries, INSERT/UPDATE/DELETE and rebuilt-index cases. The 432-case v1 diagnostic is not full natural-language tie proof. Independent original binary pin: bae4a3b9e1b4662d4021b28d5adc085764beb6cf02122eacd57b8e16b6fe1762; official baseline 5bce9e06d1281347ad61344e4b01fab9158c58a2.
4. Resolve MIN_MAX normalized-score consumer reachability, UInt64-to-signed count invariants and initialization/reuse/error behavior described in report.md.
5. Only after correctness passes, run the unchanged full benchmark. The original three categories remain equally weighted. No improvement or score is asserted here.

All frozen v1 files remain byte-for-byte unchanged. The added v1 README/report only document the later failed experiment; its original manifest describes its earlier packaging-time state. No build/runtime/SQL/performance/Git operation was performed by the sidecar.
