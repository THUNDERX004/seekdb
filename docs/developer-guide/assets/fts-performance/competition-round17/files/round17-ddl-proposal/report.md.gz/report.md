# Round 17: static FTS DDL scheduling and duplicate-segmentation audit

Date: 2026-11-04. Source checkout: D:/Projects/OceanBase/seekdb. This is a source-only sidecar report. No production files, tests, CI, benchmarks, build files, Git state, runtime configuration, services or running processes were changed. No build, test, SQL, performance, Git or remote command was run. Only auxiliary Markdown reports were written.

## Conclusions and evidence limits

1. **Yes: FTS_INDEX and FTS_DOC_WORD are separate complement children that independently read the original base table and segment its indexed text.** This is not an inference from elapsed times: the parent passes the same base-table ID, each child generates its own base-table INSERT SELECT, and both destination types enable the FTS segmentation scan. They are not guaranteed to read the same document version: each term-producing child acquires and persists its own snapshot.
2. A four-column tuple can be permuted from one layout to the other only under additional equivalence conditions. **Changing the second child's source table ID, or sharing the current operator-local cache, is not a justified bounded change under the existing snapshot, DML, ownership and recovery contracts.** A fused producer or durable intermediate is a larger design project, not a safe two-line reuse.
3. Source establishes 10ms scheduler retry waits, 100ms client completion polling, 10ms schema-visibility polling and conditional recovery/backoff intervals. **None establishes an unconditional seconds-long floor or explains the parent's approximately 7/5/3-second results.** Polling overlaps useful construction work, condition waits can wake early, and phase changes request immediate rescheduling.
4. One concrete bounded task-flow experiment is justified: **look past a delayed queue head for already-due work before taking the existing 10ms idle.** It preserves deadlines, phase checks, task ownership and durable recovery. The example below proves an avoidable scheduling opportunity; it does not prove measurable benchmark benefit. No source patch is staged because the shared-scheduler lock/fairness and performance checks have not been executed.

This uses the repository code-review guidance at [SKILL.md](D:/Projects/OceanBase/seekdb/.agents/skills/code-review/SKILL.md), specifically caller, lifetime, concurrency and focused-evidence analysis. It is not a PR approval or a performance finding against an evaluated implementation.

## Source identity and round16 provenance

No Git/remote/ancestry checks were allowed in this sidecar. The user-recorded official baseline remains upstream/2026-competition at 5bce9e06d1281347ad61344e4b01fab9158c58a2; this report does not independently reverify it.

Raw SHA-256 values captured during this followup:

| File under the D: checkout | SHA-256 |
| --- | --- |
| src/rootserver/ddl_task/ob_ddl_scheduler.cpp | 40925cba9b5b85126cb55a2e3ba65c87d99bb50a9006f96e3367207af5532b14 |
| src/rootserver/ddl_task/ob_ddl_task.cpp | e61feeba1c0bce60c4741c5cca5821aeeea0bc54b57bb39429f7a02bdfd7c454 |
| src/rootserver/ddl_task/ob_fts_index_build_task.cpp | f47c45c22a516a9b05c4712a6af9dcdee129759bb46aee5c5da2004acde2d592 |
| src/rootserver/ob_ddl_service.cpp | 13b4823058aa642d4015e41baeb8727662408129778fda0b85fb86ad82fcfcb6 |
| src/sql/das/ob_das_domain_utils.cpp | 6adeadca2e80c7ecf6ecce6beb456082ddfe0155a34705a63d54f21bb7265bd3 |

The last value matches the eager original in the frozen round16 package; the live followup read contains rows_ and the eager generate_fulltext_word_rows call. Earlier round16 audit reads matched its lazy-row candidate instead. This is a shared-checkout observation, not a claim about which binary the parent is currently building or running. The dispatch and duplicate-work conclusions hold for either cache implementation. Candidate-specific line references in the [round16 path report](C:/Users/11946/Documents/ChatGPT/OceanBase比赛/setup/fts/round16-path-audit/report.md) describe its earlier captured state. The frozen round16 package was not changed.

Parent-reported runtime evidence remains distinct from this static audit: DEBUG official full-dataset ALTER reached round16 segment at ob_das_domain_utils.cpp:122, ret=0, maps 40/39, in seekdb-fts-r16-lazy-path-diagnostic-2/log/seekdb.log lines 402045 and 402091; all three diagnostic indexes finished. This sidecar did not read those logs or run that diagnostic. It was unscored and proves candidate entry, not speedup. Parent-reported first candidate times were 7.033/5.002/2.791 seconds, with no clear win.

## Exact independent-parse chain

| Step | Source-level proof |
| --- | --- |
| Parent knows the original base table | [ObFtsIndexBuildTask::init:140](D:/Projects/OceanBase/seekdb/src/rootserver/ddl_task/ob_fts_index_build_task.cpp:140) sets object_id_ to data_table_schema->get_table_id(). |
| Two different term-producing children | [prepare_aux_index_tables:610](D:/Projects/OceanBase/seekdb/src/rootserver/ddl_task/ob_fts_index_build_task.cpp:610) submits the domain/inverted child; line 626 submits INDEX_TYPE_FTS_DOC_WORD_LOCAL. Both are submitted in the same parent phase without waiting for inverted completion first. |
| Same original source ID | [prepare_aux_table:449](D:/Projects/OceanBase/seekdb/src/rootserver/ddl_task/ob_fts_index_build_task.cpp:449) takes data_table_id from object_id_; line 463 puts it into arg.data_table_id_. It does not substitute the first auxiliary's ID. |
| Same parent parser specification, separate child arguments | [construct_domain_index_aux_arg:694](D:/Projects/OceanBase/seekdb/src/rootserver/ddl_task/ob_fts_index_build_task.cpp:694) and [construct_fts_doc_word_arg:705](D:/Projects/OceanBase/seekdb/src/rootserver/ddl_task/ob_fts_index_build_task.cpp:705) deep-copy create_index_arg_; doc-word changes the index type and generated auxiliary name. |
| Child owns its own DDL job | [ObDDLService::create_aux_index:4805](D:/Projects/OceanBase/seekdb/src/rootserver/ob_ddl_service.cpp:4805) uses arg.data_table_id_, obtains that source schema at 4829 and passes it into create_aux_index_task_. [4755](D:/Projects/OceanBase/seekdb/src/rootserver/ob_ddl_service.cpp:4755) constructs an ordinary CREATE_INDEX or partitioned local-index task with source and destination schemas. |
| Child executes an independent source scan | [ObIndexSSTableBuildTask::process:114](D:/Projects/OceanBase/seekdb/src/rootserver/ddl_task/ob_index_build_task.cpp:114) generates SQL, sets the session DDL flag at 134 and executes at 148. [generate_build_replica_sql:334](D:/Projects/OceanBase/seekdb/src/rootserver/ddl_task/ob_ddl_common_rs_impl.cpp:334) resolves data_table_id as the source; [537](D:/Projects/OceanBase/seekdb/src/rootserver/ddl_task/ob_ddl_common_rs_impl.cpp:537) emits a primary-index source hint and AS OF SNAPSHOT for that child. |
| Both target types segment | [ObStaticEngineCG scan generation:3722](D:/Projects/OceanBase/seekdb/src/sql/code_generator/ob_static_engine_cg.cpp:3722) enables is_fts_ddl_ for inverted OR doc-word destinations, selecting only the layout with is_fts_index_aux_. It also forces scalar scanning and copies parser name/properties. |
| Original text is read in each operator | [ObTableScanOp::fetch_next_fts_index_rows:3656](D:/Projects/OceanBase/seekdb/src/sql/engine/table/ob_table_scan_op.cpp:3656) pulls a source row, evaluates text and doc ID, resolves real LOB data at 3670 and calls its own fts_index_.segment at 3676. Neither this function nor the parent passes another child's token stream. |

The [current cache:60](D:/Projects/OceanBase/seekdb/src/sql/das/ob_das_domain_utils.cpp:60) owns its helper/context per scan instance and invokes the eager helper at line 91. The frozen lazy version retains the same per-scan segmentation contract. Therefore two independently built auxiliaries imply two parsing passes over surviving nonempty source texts, subject to their respective snapshots, retries, sampling phase and plan partitions. Empty strings short-circuit; all-filtered nonempty text can parse and emit no rows. Do not turn this into an unconditional exact 40,000 parser-call claim without runtime accounting.

Auxiliary tuple definitions are explicit in [generate_fulltext_word_rows:319](D:/Projects/OceanBase/seekdb/src/sql/das/ob_das_domain_utils.cpp:319):

- FTS_INDEX: word, doc_id, word_count, doc_length.
- FTS_DOC_WORD: doc_id, word, word_count, doc_length.

The same term map/frequencies/document length are computed independently, then the first two fields are swapped by layout. Counts and length are not computed from an already-built inverted index.

### Why same table does not mean same snapshot

The parent assigns arg.snapshot_version_ at FTS-task line 470. But [create_aux_index:4876](D:/Projects/OceanBase/seekdb/src/rootserver/ob_ddl_service.cpp:4876) forwards it only for rowkey-doc or vector rowkey-VID when an existing schema needs a task. Inverted and doc-word pass zero. The new-schema call at 4907 omits it, and [the declaration:1682](D:/Projects/OceanBase/seekdb/src/rootserver/ob_ddl_service.h:1682) defaults it to zero. Thus forwarding the parent field does not establish snapshot equality for these two children.

[ObIndexBuildTask::wait_trans_end:535](D:/Projects/OceanBase/seekdb/src/rootserver/ddl_task/ob_index_build_task.cpp:535) obtains the child's schema-transaction barrier and fetched snapshot. Lines 555–575 persist and hold it transactionally; an existing persisted snapshot wins on retry. The internal SQL uses that child's snapshot. Equal values can occur, but are not an invariant.

[ObDDLWaitTransEndCtx::check_schema_trans_end:1277](D:/Projects/OceanBase/seekdb/src/rootserver/ddl_task/ob_ddl_task.cpp:1277) performs write-defensive binding before checking transactions. [do_write_defensive:1322](D:/Projects/OceanBase/seekdb/src/rootserver/ddl_task/ob_ddl_task.cpp:1322) locks/checks the durable task phase and modifies tablet bindings transactionally. [try_wait:1391](D:/Projects/OceanBase/seekdb/src/rootserver/ddl_task/ob_ddl_task.cpp:1391) and lines 1424–1452 require successful positive snapshots for checked tablets. These are correctness barriers; they are not dispensable timer overhead.

### Derive or share: safe scope assessment

**Algebraic possibility:** given exactly the same source row versions, generated text expression, parser configuration, dictionary view, charset/collation grouping, doc-ID bytes/flags, term representative bytes, frequencies and document length, a complete four-field stream can feed both destinations with only the first two fields permuted and each destination's required sorting/storage handling. This observation alone supplies no task protocol.

**Why a source-ID-only derivation is unsafe:**

- The second child's snapshot and source schema currently refer to the base-table build contract. Reading a newly built index at a different snapshot does not prove equivalence, especially with INSERT/UPDATE/DELETE or rollback during DDL. Both source and destination snapshot holds, visibility and DML coverage must be redesigned together.
- Code generation enables segmentation according to the destination type, not a token-source marker. Feeding an auxiliary source through the current FTS scan would still require generated source expressions and segmentation handling. Re-segmenting a stored word is not a correct reconstruction of the original document's frequencies and length.
- The parent submits both term children without an inverted-first dependency. A derive-from-first design adds a new prerequisite and potentially serializes work that the local builder can currently overlap. [ObDDLLocalBuilder::get_thread_cnt_:351](D:/Projects/OceanBase/seekdb/src/share/ob_ddl_task_executor.cpp:351) selects one worker in mini mode or sixteen otherwise; which applies to the parent's binary was not inspected.
- A readable first index is not a durable shared-intermediate contract for both children. Cleanup, cancellation, missing/dropped schema, partial write, index status and execution/snapshot retry require explicit validation. [cleanup_impl:1487](D:/Projects/OceanBase/seekdb/src/rootserver/ddl_task/ob_index_build_task.cpp:1487) releases its snapshot, reports completion, deletes its task record and only then notifies the parent at 1503. The parent's recovery fallback at [wait_aux_table_complement:839](D:/Projects/OceanBase/seekdb/src/rootserver/ddl_task/ob_fts_index_build_task.cpp:839) looks up durable child results, not an intermediate row stream.
- Final parent [wait_schema_refresh_and_trans_end:1806](D:/Projects/OceanBase/seekdb/src/rootserver/ddl_task/ob_fts_index_build_task.cpp:1806) independently checks both auxiliary schemas and transactions. Preserving those waits is necessary even if generation is fused.

**Why operator-cache sharing is not bounded:** helpers, terms and returned rows belong to one operator's allocator/lifetime; PX and child jobs are independent. Cross-child reuse needs an owner, a versioned key (table/schema/snapshot/execution/parser/dictionary/charset), synchronization, resource limits, duplicate handling and a restart fallback. Holding two children's doc IDs or one borrowed row pointer does not meet these requirements. An in-memory optimization can remain non-durable only if a miss/restart safely recomputes under the exact equivalent child contract; the current independent snapshots still prevent a general hit.

**Assessment:** duplicate parsing is a concrete larger opportunity to investigate, but neither derivation nor sharing is approved here as a narrow semantics-preserving implementation candidate. No gain estimate is made. A separate design would need a common persisted snapshot/barrier, explicit fused-or-derived mode, durable dependency/result ownership, unchanged dual DML maintenance and restart/failure tests before performance experimentation. The official benchmark being quiescent would not justify a quiescent-only shortcut without an enforced supported SQL contract.

## Static wait accounting

Times below describe source controls, not measurements. Durations are not summed as a build-time floor.

| Control | Exact source and trigger | What can and cannot be quantified statically |
| --- | --- | --- |
| Normal task retry deadline | [ObDDLTask::calc_next_schedule_ts:979](D:/Projects/OceanBase/seekdb/src/rootserver/ddl_task/ob_ddl_task.cpp:979); [constants:698](D:/Projects/OceanBase/seekdb/src/rootserver/ddl_task/ob_ddl_task.h:698) | Non-timeout processing uses now + delay_schedule_time_ with a 10ms default and preserves a later old deadline. A successful phase change sets delay to zero at [switch_status:658](D:/Projects/OceanBase/seekdb/src/rootserver/ddl_task/ob_ddl_task.cpp:658). There is no mandatory 10ms per phase. |
| Queued but not due, or first retry marker reached | [ObDDLScheduler::do_work:950](D:/Projects/OceanBase/seekdb/src/rootserver/ddl_task/ob_ddl_scheduler.cpp:950) requeues and requests 10ms idle at 960 | The decision happens immediately on this task, without first looking for ready work behind it. The actual wait may be shortened by a wake; OS scheduling adds uncertainty. This is the bounded proposal's target. |
| Empty queue | [do_work:936](D:/Projects/OceanBase/seekdb/src/rootserver/ddl_task/ob_ddl_scheduler.cpp:936) requests up to 30s | New submissions [inner_schedule_ddl_task:3051](D:/Projects/OceanBase/seekdb/src/rootserver/ddl_task/ob_ddl_scheduler.cpp:3051) enable the task and wake the idler. It is not 30s imposed on a submitted build. |
| Actual idler mechanics | [ObThreadIdling::wakeup:34](D:/Projects/OceanBase/seekdb/src/rootserver/ob_thread_idling.cpp:34), [idle:53](D:/Projects/OceanBase/seekdb/src/rootserver/ob_thread_idling.cpp:53) | Condition broadcast plus wakeup count; millisecond deadline calculation, internal waits capped at 1s, bounded by requested/default interval. Do not equate requested idle with actual slept time. |
| Task timeout backoff | [calc_next_schedule_ts:983](D:/Projects/OceanBase/seekdb/src/rootserver/ddl_task/ob_ddl_task.cpp:983) | Only OB_TIMEOUT: delay grows by 6/5 plus 100ms, capped by min(task_count * ddl_rpc_timeout * 10, 600s), then randomly selects half-to-full delay. It is not a normal-build fixed wait. |
| Client waits for durable completion | [ObDDLExecutorUtil::wait_ddl_finish:61](D:/Projects/OceanBase/seekdb/src/sql/engine/cmd/ob_ddl_executor_util.cpp:61), query at 79 and sleep at 119 | Each miss that reaches the sleep requests 100ms. Requests total 100ms * number of such iterations, but overlap ongoing DDL. In an ideal healthy/quiescent poll, post-publication detection residual is below one 100ms interval plus lookup/scheduling cost; this is not a universal time bound or a minimum. The first successful lookup sleeps zero times. |
| Client local-schema visibility | [wait_local_schema_visible:336](D:/Projects/OceanBase/seekdb/src/sql/engine/cmd/ob_ddl_executor_util.cpp:336) | Only when refreshed version is behind: 10ms sleep at 346 per retry. The 1s constant at 343 rate-limits warnings; it is not a 1s sleep. |
| Durable recovery scan | [DDL_TASK_SCAN_PERIOD:248](D:/Projects/OceanBase/seekdb/src/rootserver/ddl_task/ob_ddl_scheduler.h:248); [DDLScanTask::schedule:662](D:/Projects/OceanBase/seekdb/src/rootserver/ddl_task/ob_ddl_scheduler.cpp:662) | 60s normal, 1s ERRSIM. runTimerTask recovers tasks and tries dictionary loading. Fresh auxiliary tasks are scheduled immediately after transaction commit and schema publication at [create_aux_index:4921](D:/Projects/OceanBase/seekdb/src/rootserver/ob_ddl_service.cpp:4921); they do not normally await this timer. |
| Heartbeat maintenance | [DDL_TASK_CHECK_PERIOD:379](D:/Projects/OceanBase/seekdb/src/rootserver/ddl_task/ob_ddl_scheduler.h:379) | 30s normal, 1s ERRSIM. Maintenance cadence, not a per-index sleep. |
| Snapshot offset | [get_snapshot:1485](D:/Projects/OceanBase/seekdb/src/rootserver/ddl_task/ob_ddl_task.cpp:1485), [calc_snapshot_with_gts:714](D:/Projects/OceanBase/seekdb/src/rootserver/ddl_task/ob_ddl_common_rs_impl.cpp:714) | INDEX_SNAPSHOT_VERSION_DIFF is subtracted from GTS and clamped against transaction/frozen snapshots. It is a timestamp offset, not an instruction to sleep 100ms. GTS acquisition/transaction/storage latency was not measured. |
| Checksums | [wait_data_complement:904](D:/Projects/OceanBase/seekdb/src/rootserver/ddl_task/ob_index_build_task.cpp:904) | Inverted/doc-word skip that base-vs-index checksum comparison. Mapping children may still need checksums. The 1s messages at 936/1020 are logging gates. The 10s checksum-wait context at 1143 is a conditional timeout, not a mandatory term-index delay. |
| Local builder queue | [ObDDLLocalBuilder::push_task:339](D:/Projects/OceanBase/seekdb/src/share/ob_ddl_task_executor.cpp:339); [ObAsyncTaskQueue::run2:121](D:/Projects/OceanBase/seekdb/src/oblib/lib/thread/ob_async_task_queue.cpp:121) | Queue capacity/concurrency can affect latency; retry sleep requires an already-executed task with a later retry deadline. Source does not establish an initial mandatory worker delay. |

Therefore the source-only lower bound on explicit polling sleeps in an already-ready path is zero. Required schema, transaction, snapshot, durable record and storage work remains, with unknown elapsed cost. When tasks are not ready, timing depends on outstanding work, timeouts, ready-task contention and wakeups; the normal 10/100ms constants cannot alone attribute seconds of measured build time.

### Completion notifications are not immediate runnable transitions

[ObIndexSSTableBuildTask::process:171](D:/Projects/OceanBase/seekdb/src/rootserver/ddl_task/ob_index_build_task.cpp:171) reports local complement completion. [ObDDLScheduler::on_sstable_complement_job_reply:3101](D:/Projects/OceanBase/seekdb/src/rootserver/ddl_task/ob_ddl_scheduler.cpp:3101) updates the task via modify_task; [update_complete_sstable_job_status:1205](D:/Projects/OceanBase/seekdb/src/rootserver/ddl_task/ob_index_build_task.cpp:1205) takes the task lock, checks phase/snapshot/execution and stores the result. [check_local_build:799](D:/Projects/OceanBase/seekdb/src/rootserver/ddl_task/ob_index_build_task.cpp:799) later consumes it and preserves retry rules.

Likewise [ObDDLScheduler::on_ddl_task_finish:3168](D:/Projects/OceanBase/seekdb/src/rootserver/ddl_task/ob_ddl_scheduler.cpp:3168) invokes the parent's [on_child_task_finish:915](D:/Projects/OceanBase/seekdb/src/rootserver/ddl_task/ob_fts_index_build_task.cpp:915), which locks and writes the child-result map. [ObDDLTaskQueue::modify_task:181](D:/Projects/OceanBase/seekdb/src/rootserver/ddl_task/ob_ddl_scheduler.cpp:181) and its task-ID overload at 200 only lock, find and invoke; they do not wake the idler or reset schedule timestamps.

This is evidence of periodic result consumption, not evidence that all build delay comes from missing wakeups. A wake-only patch can still encounter a future deadline and immediately request another 10ms idle. Calling enable_schedule from callbacks also introduces writes racing with the worker's plain next_schedule_ts_/delay calculations, can interfere with initial disable_schedule, and requires timeout/obsolete-callback policy. It is not the proposed patch. A complete event-driven design needs synchronized ready notifications consumed by the scheduler and careful post-process rearm behavior; it is larger than adding one broadcast.

## Bounded task-flow candidate: ready lookahead before idle

### Concrete current execution

Assume one available scheduler worker, no pending idler wake, queue [A, B], A not due until later, B already due.

1. [get_next_task:129](D:/Projects/OceanBase/seekdb/src/rootserver/ddl_task/ob_ddl_scheduler.cpp:129) removes A without consulting its deadline.
2. do_work finds !A.need_schedule(), appends A, sets idle_time to 10ms and calls idler.idle before fetching B.
3. B was already runnable but this worker enters a timer wait first. If no wake intervenes, this adds a nominal 10ms scheduling wait. With k delayed heads encountered before a ready task, the current single-worker ordering can request k such waits. Other workers/wakes may hide or reduce this cost.

This example can occur with a waiting FTS parent/mapping child ahead of a ready term child, but the report does not assert that it occurred in the parent's measurements. It concerns ready dispatch, not shortening a schema/transaction/storage barrier.

### Exact implementation scope for a later worker

Only src/rootserver/ddl_task/ob_ddl_scheduler.h and .cpp would change. Extend the FIFO pop with an optional output for the queue size observed **under its existing spinlock before that pop**, retaining the exact current behavior when the output is unused. Use that count only in ObDDLScheduler::do_work to bound a local selection sweep. [destroy_all_tasks:3226](D:/Projects/OceanBase/seekdb/src/rootserver/ddl_task/ob_ddl_scheduler.cpp:3226) must still use the ordinary FIFO behavior and remove every queued task, including disabled/future tasks during teardown. Do not use the existing unlocked get_task_cnt() accessor as the new scan-budget synchronization contract.

Algorithm, with every queue mutation retaining its existing lock scope:

1. On the first FIFO pop in a selection attempt, capture N = queue size before removal while holding the existing queue lock. Retain all current not-initialized, empty-queue, null-node and stop/draining behavior. No task is added to or removed from either map by a pop.
2. After releasing the lock, inspect the popped task exactly as the existing worker does. If it is the existing first_retry_task marker, retain the original requeue-and-idle branch. If it is due, run the existing process/calc-next/requeue-or-remove block, then end this selection attempt. A due head stays O(1).
3. If it is not due, requeue it through add_task_to_last exactly as today. Instead of immediately idling, pop the next task while fewer than N nodes have been examined in this attempt. Each examined task consumes one budget unit, regardless of concurrent queue size changes. Check stop conditions between pops and preserve every original requeue/removal error branch.
4. After N non-due nodes, take the existing 10ms idle and reset the selection budget/marker as the original idle path does. If the queue becomes empty, retain the existing empty-queue idle path. New enqueues still issue the existing wake, so arrivals after the captured budget are not dependent solely on the polling deadline. Never spin until a raw pointer marker happens to reappear: another worker can remove that task.
5. Keep all existing first_retry_task process/requeue bookkeeping, task health/phase checks, calc_next_schedule_ts, ownership transfer and stop handling. No schedule deadline, delay, result map, phase, execution ID, snapshot, durable record, callback or idler interval changes. The candidate deliberately does not eliminate all marker-induced waits.

This chooses a bounded sequence of existing FIFO ownership transfers rather than traversing queued task objects and reading their readiness under a long-held queue lock. need_schedule is read only after popping that task, at the same ownership point as today. The optional count is an integer, not a retained list iterator or unowned task pointer. Queue membership and task callbacks retain their existing synchronization. Initial disable/enable publication behavior must be preserved and tested; this proposal does not claim to repair or redesign that existing contract.

This is at most N queue-pop/requeue attempts before the selection idles or processes a due task, instead of taking a 10ms idle after each non-due head. It uses no new allocation, list traversal under the lock, SQL call or callback. Other workers can change which nodes this worker encounters, but cannot make its captured budget unbounded. A long all-delayed queue increases lock acquisitions/readiness checks per idle and can increase contention; that is a real acceptance risk. If material, abandon this candidate or explicitly design/test a capped sweep separately. Do not silently introduce an untested magic cap or a new priority policy.

### Invariants and limits

- Never process a not-yet-due task earlier than its existing need_schedule predicate; all-delayed work retains the existing retry deadline and 10ms idle after a bounded sweep.
- Preserve list/map membership, exactly one worker ownership, removal/destruction, all error returns and management-stop draining.
- Retain FIFO pops/tail requeues and due-task ordering for an uncontended sweep; delayed tasks regain eligibility normally as time advances. Existing first-retry throttling remains. No global ordering across parallel workers is newly promised.
- Run the full existing process/health/phase/barrier path on selection. Do not mark children complete or skip retryable failures. Recovery and durable snapshot semantics are unchanged.
- No term/document/charset/parser/dictionary/row/storage code changes. The shared scheduler affects non-FTS DDL too, requiring focused general queue coverage.
- No measured gain, score estimate, CPU attribution or claim that this resolves the 7/5/3-second control times. Maximum benefit is contingent on queue ordering/wakes and can be zero.

### Necessary focused checks before any acceptance

These are proposed checks, **not tests run by this sidecar**. Use a controllable clock/task stub and scheduler/idler observer in a focused native queue/scheduler test target; there is no existing unittest/rootserver directory in this checkout, so do not cite an invented existing target.

1. Queue [future A, due B], no first-retry marker collision: the worker requeues A, then processes B without an intervening idle; A retains its timestamp and map membership. The corresponding old path requests idle before B.
2. Due head / multiple due nodes: process the first popped due task without extra work. An all-future/disabled queue requeues at most the captured N tasks and idles, with no unbounded selection loop. Empty/not-initialized/null-node cases preserve errors. Test zero/one/many nodes and count capture before the first removal.
3. Requeue, first-retry marker and clock advance: bounded selection; no phase skipping, future task not executed early, no starvation when its deadline becomes due, and current per-pass throttle remains.
4. Two workers plus push/modify/requeue/remove: no duplicate execution, dangling node, map/list mismatch or lost ownership. Test enqueue between selection and idle, stop/deactivate, disabled initialization and teardown draining. A source-only review cannot substitute for this concurrency coverage.
5. Timeout/retry/cancel/failure and restart: unchanged persisted statuses, snapshots, execution IDs and child error propagation; missing callbacks still recover via durable result lookup. Include ordinary/partitioned index and FTS parent/children because the queue is shared.
6. Parent-run correctness gates: existing FTS SQL suites including complete tuple/count/doc-ID/token/ranking comparisons and concurrent DML/rollback; actual CREATE/ALTER index completion under failure/restart. See [current FTS suites](D:/Projects/OceanBase/seekdb/unittest/storage/fts/README.md). Query hit counts alone are insufficient. Do not change official benchmark/scoring/SQL fixtures.
7. Parent-only performance gate: isolated paired release builds, unchanged official full dataset/settings, all three build metrics plus tokenize/query regressions; record ready-task queue residence and idle count separately from SQL/storage duration if instrumentation is used. Also stress a long all-delayed queue to check increased lock acquisitions/readiness checks. Diagnostic timing is not the scored result.

## Handoff status

The round16 path audit is finalized with parent runtime evidence separated from static evidence and its optimizer attribution corrected. This round17 report supplies source-proven duplicate parsing, the independent-snapshot limitation, conditional wait accounting and one bounded ready-dispatch proposal. No production/staged source patch, test, CI, benchmark, runtime or Git operation was performed for round17. The parent can assess priority without interrupting its native build or applying an unvalidated shared-parser rewrite.
