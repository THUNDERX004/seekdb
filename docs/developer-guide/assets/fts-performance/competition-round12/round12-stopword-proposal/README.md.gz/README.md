# Round12 built-in stopword proposal

Staged only. Apply `src/storage/fts/ob_fts_stop_word.cpp` and `.h` after verifying
the original hashes in `manifest.json`. No other production file changes.
The existing stopword initializer is byte-for-byte unchanged. No new global
hash implementation, dictionary entry, workload-specific literal or allocation
is introduced by the shortcut. The original generic set is still populated.

The target is BENG's `ObAddWord::process_word -> check_stopword ->
ObStopWordChecker::check_stopword -> charset_convert -> exist_refactored ->
ObFTWord::hash -> default_hash_/ob_hash_sort_utf8mb4`. BENG sets min/max,
stopword and grouping flags, but does not set casedown, so mixed-case input
must be handled inside the checker. An eligible lookup avoids construction of
the local arena and all charset conversion/generic-set/hash work.

## Data and ownership

`init_ascii_stopwords()` reads the actual target GENERAL_CI descriptor's
`caseinfo->page[0]` and `state`. It verifies all 26 upper/lower pairs have
equal, mutually distinct weights, with no zero or space-equivalent letter.
The projection is exactly `ob_tosort_unicode`'s `LOWER_SORT ? tolower : sort`.
It then derives and insertion-sorts keys from **every original list entry**.
Only after all checks pass is the nonzero count published. Any unsupported
table or future nonletter/too-long built-in disables this optional path and
retains the original generic set. The duplicate `the` entry remains unchanged.

The member payload is fixed: 128 one-byte codes, 36 eight-byte keys and an
eight-byte count, 424 bytes before enclosing-class padding. A temporary
26-element weight array uses stack space during initialization only. The path
adds no heap allocation at init or lookup. Existing set allocations remain.

The existing lifecycle still requires initialization before workers and
destruction after workers stop. Neither the generic set nor the derived table
is mutated by lookups. Repeated successful init still returns INIT_TWICE and
leaves the working checker intact. Failed initialization releases any created
or partially populated set; destroy also clears the shortcut count, supports
repeated destruction and allows re-init. Optional derivation failure is not a
checker initialization failure. Allocation-failure injection has not been run.

## Correctness argument

1. Only the three fixed UTF8 collations GENERAL_CI, BIN and UNICODE_CI are
   eligible. The original `charset_convert` validates them, identifies all as
   CHARSET_UTF8MB4 and returns the same bytes when converting to GENERAL_CI.
   The **target** GENERAL_CI weights govern membership even for BIN input.
2. Actual `utf8_plane00` has sort('A'+i) = sort('a'+i) = 0x41+i, for all 26
   letters; its lower-sort alternative is 0x61+i. Static inspection checked
   all 52 source-table rows. The descriptor uses `ob_unicase_default`; the
   attached source receipt pins that table, descriptor, conversion and compare
   implementations. Initialization verifies the conditions again against the
   actual descriptor rather than assuming ASCII bit-folding is equivalent.
3. The general-ci comparator decodes each ASCII letter to that codepoint and
   maps one weight per character, without expansions or contractions. Thus
   two equal-length all-letter sequences compare equal exactly when each
   validated letter code is equal. Different lengths cannot compare equal:
   no eligible remaining byte is a PAD SPACE. No locale-specific raw `tolower`
   or hash equality assumption is needed.
4. Codes 1..26 packed as base-32 digits are injective for lengths 1..9; there
   is no leading zero and the maximum fits 45 bits. Key=0 is reserved for
   longer all-letter strings, after inspecting **every byte**; every built-in
   key is positive and shorter than ten bytes. Integer key order need not be
   collation order: only exact membership is used in the sorted fixed table.
5. Any nonletter, non-ASCII byte, embedded NUL, trailing space, unsupported
   collation, disabled table or empty/uninitialized checker keeps the original
   behavior. On a declined shortcut the output bool is untouched before the
   complete original conversion and set path executes. Accented equivalents,
   malformed bytes, source conversions and PAD SPACE rules remain there.

All `ObAddWord` methods are unchanged, including min/max filtering before the
check, casing flags, latest-spelling retention, frequencies and document length.
No iteration order or output generation code changes.

## Parent regression commands, deferred

Copy the Python and direct checker regression from `unittest/storage/fts/` to
the same relative directory when integrating. The Python entry point requires
PyMySQL and an already-running dedicated instance; it sends SELECT only. From
the staging directory, supply `--source-root` explicitly. When installed in
the repository, its default root is `Path(__file__).resolve().parents[3]`.

Record **only on the verified unmodified official competition binary**:

```powershell
python ./unittest/storage/fts/test_stopword_ascii.py --source-root D:/Projects/OceanBase/seekdb --port 2891 --record ./stopword_ascii_expected.json --baseline-revision 5bce9e06d1281347ad61344e4b01fab9158c58a2 --baseline-binary-sha256 <verified-original-executable-sha256>
```

Then check the applied candidate against that unchanged fixture:

```powershell
python ./unittest/storage/fts/test_stopword_ascii.py --source-root D:/Projects/OceanBase/seekdb --port 2891 --fixture ./stopword_ascii_expected.json
```

Use `SEEKDB_TEST_PASSWORD` for credentials. Supplied binary provenance is a
parent assertion; SQL cannot independently verify an executable's SHA. No
expected fixture is included or manufactured. The script derives all built-in
case combinations, misses and repeated groups from the source initializer.
It compares complete ordered JSON arrays, spellings, frequencies, lengths,
every output field and errors across both parsers, all three UTF8 collations,
min/max/output configurations, accents, digits, controls and conversion paths.
Some unsupported source charsets may produce original errors; those exact codes
are recorded and compared rather than asserted to succeed.

`test_stopword_ascii_checker.cpp` has a standalone `main` to link with the
normal production storage/charset/runtime test dependencies. It is not a
self-contained leaf and is not registered in build files by this proposal.
The parent must link it with the real candidate `ObStopWordChecker`, `ObFTWord`,
`ObCharset` and allocator dependencies. It tests the actual GENERAL_CI comparator
on all 52x52 letter pairs and compares the real checker with the original
conversion + real generic set on all built-in case combinations, misses,
all two-letter strings, all 256 bytes at three positions, long inputs and
uninitialized/destroy/re-init behavior. These direct cases cover trailing
spaces and invalid byte strings which SQL tokenizers might split or transform.
Both initial bool values are checked to retain error-output behavior.

No compilation, native regression, SQL, database startup, build or performance
measurement has been performed for this proposal. Static Python parsing,
original/proposal hashes, actual source-table inspection and unchanged-list/
fallback/ObAddWord comparisons are the only validation claimed. Future
performance benefit remains unmeasured.
