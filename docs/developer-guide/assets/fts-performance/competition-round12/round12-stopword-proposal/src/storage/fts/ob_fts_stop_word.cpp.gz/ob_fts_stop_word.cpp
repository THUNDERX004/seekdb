/*
 * Copyright (c) 2025 OceanBase.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "object/ob_object.h"
#define USING_LOG_PREFIX STORAGE_FTS

#include "share/rc/ob_server_runtime.h"
#include "storage/fts/ob_fts_stop_word.h"
#include "lib/charset/ob_ctype.h"
#include "storage/fts/ob_fts_parser_helper.h"
#include "storage/fts/ob_fts_parser_property.h"

namespace oceanbase
{
namespace storage
{

////////////////////////////////////////////////////////////////////////////////
// class ObStopWordChecker
ObStopWordChecker::~ObStopWordChecker()
{
  destroy();
}

int ObStopWordChecker::init()
{
  int ret = OB_SUCCESS;
  
  

  if (inited_) {
    ret = OB_INIT_TWICE;
  } else if (OB_FAIL(stopword_set_.create(DEFAULT_STOPWORD_BUCKET_NUM, "StopWordSet", "StopWordSet"))) {
  } else {
    ObObjMeta stop_meta;
    stop_meta.set_varchar();
    stop_meta.set_collation_type(ObCollationType::CS_TYPE_UTF8MB4_GENERAL_CI);

    stopword_type_.set_meta(stop_meta);
    const int64_t stopword_count = sizeof(ob_stop_word_list) / sizeof(ob_stop_word_list[0]);
    for (int64_t i = 0; OB_SUCC(ret) && i < stopword_count; ++i) {
      ObFTWord stopword(STRLEN(ob_stop_word_list[i]), ob_stop_word_list[i], stopword_type_);
      if (OB_FAIL(stopword_set_.set_refactored(stopword))) {
      }
    }

    if (OB_SUCC(ret)) {
      init_ascii_stopwords();
      inited_ = true;
    }
  }
  if (OB_SUCCESS != ret && !inited_) {
    // Also release a partially populated set before a failed init is retried.
    destroy();
  }
  return ret;
}

void ObStopWordChecker::destroy()
{
  ascii_stopword_count_ = 0;
  if (stopword_set_.created()) {
    stopword_set_.destroy();
  }
  inited_ = false;
}

void ObStopWordChecker::init_ascii_stopwords()
{
  ascii_stopword_count_ = 0;
  MEMSET(ascii_letter_codes_, 0, sizeof(ascii_letter_codes_));
  const ObCharsetInfo *cs = common::ObCharset::get_charset(
      ObCollationType::CS_TYPE_UTF8MB4_GENERAL_CI);
  if (OB_ISNULL(cs) || OB_ISNULL(cs->caseinfo) || cs->caseinfo->maxchar < 0x7f
      || OB_ISNULL(cs->caseinfo->page) || OB_ISNULL(cs->caseinfo->page[0])) {
    return;
  }
  const ObUnicaseInfoChar *page = cs->caseinfo->page[0];
  const bool lower_sort = 0 != (cs->state & OB_CS_LOWER_SORT);
  const auto weight = [page, lower_sort](const unsigned char ch) -> uint32_t {
    return lower_sort ? page[ch].tolower : page[ch].sort;
  };
  uint32_t letter_weights[26];
  for (int64_t i = 0; i < 26; ++i) {
    const unsigned char upper = static_cast<unsigned char>('A' + i);
    const unsigned char lower = static_cast<unsigned char>('a' + i);
    const uint32_t upper_weight = weight(upper);
    // These are checks against the same caseinfo/state used by
    // ob_tosort_unicode, not an unconditional ASCII case-fold assumption.
    if (upper_weight == 0 || upper_weight == weight(' ')
        || upper_weight != weight(lower)) {
      return;
    }
    for (int64_t j = 0; j < i; ++j) {
      if (upper_weight == letter_weights[j]) {
        return;
      }
    }
    letter_weights[i] = upper_weight;
    ascii_letter_codes_[upper] = static_cast<uint8_t>(i + 1);
    ascii_letter_codes_[lower] = static_cast<uint8_t>(i + 1);
  }

  for (int64_t i = 0; i < BUILTIN_STOPWORD_COUNT; ++i) {
    uint64_t key = 0;
    if (!make_ascii_stopword_key(ob_stop_word_list[i], STRLEN(ob_stop_word_list[i]), key)
        || key == 0) {
      // Future nonletter/long built-in entries disable the entire shortcut.
      return;
    }
    int64_t pos = i;
    while (pos > 0 && ascii_stopword_keys_[pos - 1] > key) {
      ascii_stopword_keys_[pos] = ascii_stopword_keys_[pos - 1];
      --pos;
    }
    ascii_stopword_keys_[pos] = key;
  }
  // Publish only after every weight and every original entry was checked.
  // The original list's duplicate entries are harmless membership duplicates.
  ascii_stopword_count_ = BUILTIN_STOPWORD_COUNT;
}

bool ObStopWordChecker::make_ascii_stopword_key(
    const char *str, const int64_t len, uint64_t &key) const
{
  key = 0;
  if (OB_ISNULL(str) || len <= 0) {
    return false;
  }
  const bool fits_key = len < FTS_STOP_WORD_MAX_LENGTH;
  for (int64_t i = 0; i < len; ++i) {
    const unsigned char ch = static_cast<unsigned char>(str[i]);
    if (ch >= sizeof(ascii_letter_codes_) || ascii_letter_codes_[ch] == 0) {
      return false;
    }
    if (fits_key) {
      key = (key << 5) | ascii_letter_codes_[ch];
    }
  }
  // Nonzero base-32 digits give an injective key for up to nine letters.
  // Longer all-letter inputs keep key=0, which no built-in entry can have.
  return true;
}

bool ObStopWordChecker::try_check_ascii_stopword(
    const ObFTWord &word, bool &is_stopword) const
{
  const ObCollationType coll = word.get_collation_type();
  if (ascii_stopword_count_ == 0
      || (coll != ObCollationType::CS_TYPE_UTF8MB4_GENERAL_CI
          && coll != ObCollationType::CS_TYPE_UTF8MB4_BIN
          && coll != ObCollationType::CS_TYPE_UTF8MB4_UNICODE_CI)) {
    return false;
  }
  const common::ObString str = word.get_word().get_string();
  uint64_t key = 0;
  if (!make_ascii_stopword_key(str.ptr(), str.length(), key)) {
    return false;
  }
  int64_t first = 0;
  int64_t last = ascii_stopword_count_;
  while (first < last) {
    const int64_t mid = first + (last - first) / 2;
    if (ascii_stopword_keys_[mid] < key) {
      first = mid + 1;
    } else {
      last = mid;
    }
  }
  is_stopword = first < ascii_stopword_count_ && ascii_stopword_keys_[first] == key;
  return true;
}

int ObStopWordChecker::check_stopword(const ObFTWord &word, bool &is_stopword)
{
  int ret = OB_SUCCESS;
  
  
  if (OB_UNLIKELY(!inited_)) {
    ret = OB_NOT_INIT;
  } else if (OB_UNLIKELY(word.empty())) {
    ret = OB_INVALID_ARGUMENT;
  } else if (try_check_ascii_stopword(word, is_stopword)) {
  } else {
    common::ObArenaAllocator allocator(lib::ObMemAttr("ChkStopWord"));
    common::ObString cmp_str;
    // do nothing set out with in if type is the same.
    if (OB_FAIL(common::ObCharset::charset_convert(
                                       allocator,
                                       word.get_word().get_string(),
                                       word.get_collation_type(),
                                       stopword_type_.get_collation_type(),
                                       cmp_str))) {
    } else {
      ObFTWord converted(cmp_str.length(), cmp_str.ptr(), stopword_type_);
      ret = stopword_set_.exist_refactored(converted);
      if (OB_HASH_NOT_EXIST == ret) {
        is_stopword = false;
        ret = OB_SUCCESS;
      } else if (OB_HASH_EXIST == ret) {
        is_stopword = true;
        ret = OB_SUCCESS;
      } else if (OB_SUCC(ret)) {
        ret = OB_ERR_UNEXPECTED;
      } else {
      }
    }
  }
  return ret;
}

////////////////////////////////////////////////////////////////////////////////
// class ObAddWord
ObAddWord::ObAddWord(
    const ObFTParserProperty &property,
    const ObObjMeta &meta,
    const ObAddWordFlag &flag,
    common::ObIAllocator &allocator,
    ObFTWordMap &word_map)
  : word_meta_(meta),
    allocator_(allocator),
    word_map_(word_map),
    min_max_word_cnt_(0),
    non_stopword_cnt_(0),
    stopword_cnt_(0),
    min_token_size_(property.min_token_size_),
    max_token_size_(property.max_token_size_),
    flag_(flag)
{
}

int ObAddWord::process_word(
    const char *word,
    const int64_t word_len,
    const int64_t char_cnt,
    const int64_t word_freq)
{
  int ret = OB_SUCCESS;
  bool is_stopword = false;
  ObFTWord src_word(word_len, word, word_meta_);
  ObFTWord dst_word;
  if (OB_ISNULL(word) || OB_UNLIKELY(0 >= word_len || 0 >= char_cnt || 0 >= word_freq)) {
    ret = OB_INVALID_ARGUMENT;
  } else if (is_min_max_word(char_cnt)) {
    ++min_max_word_cnt_;
  } else if (OB_FAIL(casedown_word(src_word, dst_word))) {
  } else if (OB_FAIL(check_stopword(dst_word, is_stopword))) {
  } else if (OB_UNLIKELY(is_stopword)) {
    ++stopword_cnt_;
  } else if (OB_FAIL(groupby_word(dst_word, word_freq))) {
  } else {
    non_stopword_cnt_ += word_freq;
  }
  return ret;
}

bool ObAddWord::is_min_max_word(const int64_t c_len) const
{
  return flag_.min_max_word() && (c_len < min_token_size_ || c_len > max_token_size_);
}

int ObAddWord::casedown_word(const ObFTWord &src, ObFTWord &dst)
{
  int ret = OB_SUCCESS;
  if (OB_UNLIKELY(src.empty())) {
    ret = OB_INVALID_ARGUMENT;
  } else if (flag_.casedown()) {
    ObString dst_str;
    if (OB_FAIL(ObCharset::tolower(
                    word_meta_.get_collation_type(),
                    src.get_word().get_string(),
                    dst_str,
                    allocator_))) {
    } else {
      ObFTWord tmp(dst_str.length(), dst_str.ptr(), word_meta_);
      dst = tmp;
    }
  } else {
    dst = src;
  }
  return ret;
}

int ObAddWord::check_stopword(const ObFTWord &ft_word, bool &is_stopword)
{
  int ret = OB_SUCCESS;
  if (OB_UNLIKELY(ft_word.empty())) {
    ret = OB_INVALID_ARGUMENT;
  } else if (flag_.stopword()) {
    ObStopWordChecker *stop_word_checker = ObFTParseData::instance().stop_word_checker();
    if (OB_ISNULL(stop_word_checker)) {
      ret = OB_ERR_UNEXPECTED;
    } else if (OB_FAIL(stop_word_checker->check_stopword(ft_word, is_stopword))) {
    }
  }
  return ret;
}

int ObAddWord::groupby_word(const ObFTWord &word, const int64_t word_freq)
{
  int ret = OB_SUCCESS;
  if (OB_UNLIKELY(word.empty() || word_freq <= 0)) {
    ret = OB_INVALID_ARGUMENT;
  } else if (!flag_.groupby_word()) {
    if (OB_FAIL(word_map_.set_refactored(word, 1/*word count*/))) {
    }
  } else {
    // Hash and locate the word once. The previous overwrite replaced the key
    // too, so retain the latest spelling of a collation-equivalent word.
    auto add_frequency = [&word, word_freq](hash::HashMapPair<ObFTWord, int64_t> &entry) {
      entry.first = word;
      entry.second += word_freq;
    };
    ret = word_map_.set_or_update(word, 1/*word count*/, add_frequency);
  }
  return ret;
}

} // end namespace storage
} // end namespace oceanbase
