"""Preserve round12 raw evidence in deterministic gzip files, outside timed work."""
import argparse, gzip, hashlib, json
from pathlib import Path

HERE=Path(__file__).resolve().parent
ROOT=Path(r'D:\Projects\OceanBase\seekdb')
def digest(raw): return hashlib.sha256(raw).hexdigest()
def write_json(path,value):
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--decision',choices=['retain','reject'],required=True)
    a=p.parse_args()
    out=ROOT/'docs/developer-guide/assets/fts-performance/competition-round12'
    assert not out.exists(),'Refuse to overwrite evidence'
    comparison=json.loads((HERE/'round12-three-pair-comparison.json').read_text())
    source=json.loads((HERE/'round12-source.json').read_text())
    binary=json.loads((HERE/'round12-binary.json').read_text())
    assert source['parent']=='a01e9cde9951b999073d6c1cf2407064d72897a4'
    assert digest((HERE/'round12-source.patch').read_bytes())==source['sha256']
    assert digest(Path(binary['binary']).read_bytes())==binary['sha256']
    paths=[(q,q.name) for q in sorted(HERE.glob('round12-*')) if q.is_file()]
    for dirname in ['round12-stopword-proposal','round12-native-helper']:
        for q in sorted((HERE/dirname).rglob('*')):
            if q.is_file() and q.suffix in ['.md','.json','.py','.ps1','.cpp','.h','.log','.rsp']:
                paths.append((q,q.relative_to(HERE).as_posix()))
    regressions=['test_stopword_ascii.py','test_stopword_ascii_checker.cpp',
                 'stopword_ascii_expected.json','stopword_ascii_initial_expected.json']
    for name in regressions:
        q=ROOT/'unittest/storage/fts'/name
        paths.append((q,'regression/'+name))
    paths.append((HERE/'experiment-competition.py','helpers/experiment-competition.py'))
    paths.append((Path(__file__),'helpers/package-round12.py'))
    assert len(paths)==len({name for _,name in paths})
    out.mkdir(parents=True)
    entries={}
    for q,name in paths:
        raw=q.read_bytes(); archived=name+'.gz'
        target=out/archived; target.parent.mkdir(parents=True,exist_ok=True)
        packed=gzip.compress(raw,mtime=0); target.write_bytes(packed)
        entries[archived]={'sha256':digest(packed),'raw_sha256':digest(raw),'raw_bytes':len(raw)}
    fixture=json.loads((ROOT/'unittest/storage/fts/stopword_ascii_expected.json').read_text())
    assert len(fixture['cases'])==2064
    manifest={'official_commit':'5bce9e06d1281347ad61344e4b01fab9158c58a2',
              'source':source,'binary':binary,'decision':a.decision,'comparison':comparison,
              'formal_score':None,'fixture_cases':2064,'fixture_sha256':digest((ROOT/'unittest/storage/fts/stopword_ascii_expected.json').read_bytes()),
              'direct_checker_checks':37948,'files':entries,
              'notes':['Local Windows comparison only; no new formal score or Linux CI claim.',
                       'All six scored reports and all negative metrics retained; no clipping or SELECT1 subtraction.',
                       'Original recording failures 1/2 retained; recording3 initial 1488-case fixture retained; recording4 expands valid min/max cases to2064.',
                       'Initial recording failure was client metadata/row UTF8 decoding, not server failure.',
                       'Direct checker compiles and links the actual production storage/charset/hash implementations, no stubs.',
                       'Raw evidence is gzip-compressed without newline conversion. Test helpers and proposal metadata retain historical scope.']}
    write_json(out/'manifest.json',manifest)
    for name,entry in entries.items():
        packed=(out/name).read_bytes()
        assert digest(packed)==entry['sha256']
        assert digest(gzip.decompress(packed))==entry['raw_sha256']
    per=comparison['per_category_reduction']; overall=comparison['overall_reduction']
    for language in ['en','zh-CN']:
        report=ROOT/f'docs/developer-guide/{language}/fts-performance.md'
        old=report.read_text(encoding='utf-8')
        assert 'Round-12 checkpoint' not in old and '第十二轮检查点' not in old
        if language=='en':
            section=f'## Round-12 checkpoint (2026-11-04)\n\nDecision: **{a.decision}** the derived ASCII stopword shortcut. Three full adjacent parent/candidate comparisons show **{100*overall:.4f}%** equal-category time reduction: build {100*per["build"]:.4f}%, tokenize {100*per["tokenize"]:.4f}%, query {100*per["query"]:.4f}%. These are local incremental results; there is no new formal score and no demonstrated full marks.\n\n'
            section+='The candidate derives fixed membership keys from the unchanged built-in list and actual GENERAL_CI weights. Only letter-only inputs in the three supported UTF8 collations use the shortcut. Nonletters, non-ASCII and all other charsets retain the original conversion and hash set. The generic set remains initialized. No input, parser rule or benchmark changes are made.\n\n'
            section+='The official-original SQL recording covers 2,064 complete ordered result/error cases (1,458 successes, 576 original invalid-option errors, 30 original unsupported-charset errors). The actual production checker also passes 37,948 direct comparisons, including case variants, byte boundaries, trailing spaces/NUL, conversions and init/destroy/reinit. Candidate-1 passes query-materialization, casecopy, BMP, ranked, key types and all seven established suites. All failed original-recording attempts and the initial fixture are retained.\n\n'
            section+='| Metric | Parent mean | Candidate mean | Reduction |\n| --- | ---: | ---: | ---: |\n'
        else:
            decision='保留' if a.decision=='retain' else '撤回'
            section=f'## 第十二轮检查点（2026-11-04）\n\n决定：**{decision}**从原词表派生的 ASCII 停用词快速路径。三组完整相邻对照的三类等权综合耗时下降 **{100*overall:.4f}%**；构建 {100*per["build"]:.4f}%、分词 {100*per["tokenize"]:.4f}%、查询 {100*per["query"]:.4f}%。这是本地增量对照，没有新的正式成绩，也未证明满分。\n\n'
            section+='候选从未修改的内置词表及真实 GENERAL_CI 权重派生成员键，仅三个已支持 UTF8 collation 的纯 ASCII 字母输入使用快路径；非字母、非 ASCII 及其他字符集保留原转换与哈希集合路径，通用集合仍完整初始化。不改数据、分词规则或官方基准。\n\n'
            section+='官方原版独立录制的 2,064 组回归逐字节比较完整有序输出及错误：1,458 组成功、576 组保留原无效选项错误、30 组保留原不支持字符集错误。直接链接生产 checker/字符集/哈希实现的 C++ 回归通过 37,948 次比较，覆盖大小写、边界字节、尾空格/NUL、转换和初始化生命周期。候选第一组同时通过完整查询、Unicode、BMP、排名、键类型及七套旧回归。原版录制失败及最初 fixture 均保留。\n\n'
            section+='| 指标 | 父版本均值 | 候选均值 | 耗时下降 |\n| --- | ---: | ---: | ---: |\n'
        for key,rate in comparison['per_metric_reduction'].items():
            section+=f'| `{key}` | {comparison["control_mean"][key]:.6f} | {comparison["candidate_mean"][key]:.6f} | {100*rate:.4f}% |\n'
        if language=='en':
            section+='\nAll runs, negative metrics, exact patches, build logs, production-link receipt, test drivers and fixtures are in the [round-12 manifest](../assets/fts-performance/competition-round12/manifest.json). Every gzip member preserves raw bytes and has both archive and raw SHA256. Performance is serialized and uses the unchanged full workload (20,000 rows, load enabled). The first candidate sample is noisy and retained. The direct check and correctness suites run outside timed samples. No Windows result establishes clean Linux CI.\n'
        else:
            section+='\n所有样本、负指标、精确补丁、构建日志、生产依赖链接凭证、回归驱动及 fixture 见[第十二轮清单](../assets/fts-performance/competition-round12/manifest.json)。gzip 保留原始字节，同时记录压缩前后 SHA256。性能实验串行执行，完整使用 20,000 行与重新导入。首轮候选波动较大，仍完整保留。直接回归与正确性测试在计时区间外运行；Windows 结果不代表干净 Linux CI 已通过。\n'
        title,rest=old.split('\n',1)
        report.write_text(title+'\n\n'+section+'\n'+rest.lstrip('\n'),encoding='utf-8',newline='\n')
    print('Packaged and verified',len(entries),'raw evidence members; decision',a.decision)

if __name__=='__main__': main()
