param(
    [Parameter(Mandatory = $true)][string]$SourceRoot,
    [Parameter(Mandatory = $true)][string]$OutputDir,
    [string]$BuildDir,
    [string]$Test,
    [string]$Python = 'python.exe',
    [switch]$Build
)
$ErrorActionPreference = 'Stop'
$env:PYTHONUTF8 = '1'
if ($Build) {
    # Match setup/fts/build-competition.ps1, pinning its actual installed toolset/SDK.
    $checkerVs = 'C:\Program Files\Microsoft Visual Studio\2022\BuildTools'
    Import-Module (Join-Path $checkerVs 'Common7\Tools\Microsoft.VisualStudio.DevShell.dll')
    Enter-VsDevShell -VsInstallPath $checkerVs -SkipAutomaticLocation `
        -DevCmdArguments '-arch=amd64 -host_arch=amd64 -vcvars_ver=14.44 -winsdk=10.0.26100.0'
}
$checkerArgs = @(
    (Join-Path $PSScriptRoot 'prepare_stopword_checker.py'),
    '--source-root', $SourceRoot, '--output-dir', $OutputDir
)
if ($BuildDir) { $checkerArgs += @('--build-dir', $BuildDir) }
if ($Test) { $checkerArgs += @('--test', $Test) }
if ($Build) { $checkerArgs += '--build' }
& $Python @checkerArgs
exit $LASTEXITCODE
