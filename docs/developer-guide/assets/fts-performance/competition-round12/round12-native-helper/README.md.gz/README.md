# Round12 production checker build helper

Auxiliary staging only. The helper compiles the integrated
`unittest/storage/fts/test_stopword_ascii_checker.cpp` as one translation unit
and links it against existing production artifacts from
`D:/Projects/OceanBase/seekdb/build_fts_competition`. It never builds seekdb,
changes source/build/CI files, or runs the resulting executable. Run `-Build`
only after round12 integration and the full production build have finished,
with the parent's regression/performance tasks stopped.

`build-settings.json` captures the relevant real `compile_commands.json`
record, Ninja seekdb link edge/rule, environment requirements, source hashes
and provenance. It uses the storage FTS unity's actual Clang 18.1.8/MSVC
frontend command, C++20, `/MD`, optimization/debug switches, defines, warnings
and include directories. Only the test source, `/Fo` and `/Fd` are replaced.
No test implementation or stub is generated.

Linking retains CMake's actual `vs_link_exe`, RC, llvm-mt, lld-link, library
paths, link flags and ordered dependency list, including
`ob_storage_static.lib`, `oblib.lib`, allocator, SQL/share/observer and Rust
libraries. The test object replaces only
`src/observer/CMakeFiles/ob_main.dir/main.cpp.obj`; the command-line-parser
and Windows-service objects remain. All relative production artifact paths
become absolute because the working directory is the dedicated output.
`PRE_LINK` must remain `cd .`; the seekdb post-build bundling command is not
executed. After a successful link, DLLs already bundled beside the production
seekdb executable are copied to the dedicated output and their hashes recorded.
The helper does not obtain DLLs from another installation.

From this workspace in PowerShell, generate a plan after integration:

```powershell
$helper = 'C:/Users/11946/Documents/ChatGPT/OceanBase比赛/setup/fts/round12-native-helper'
$python = 'C:/Users/11946/Documents/ChatGPT/OceanBase比赛/.venv/Scripts/python.exe'
& "$helper/build_stopword_checker.ps1" -SourceRoot D:/Projects/OceanBase/seekdb -OutputDir "$helper/parent-plan-1" -Python $python
```

When benchmarks and other work are idle, compile/link explicitly:

```powershell
& "$helper/build_stopword_checker.ps1" -SourceRoot D:/Projects/OceanBase/seekdb -OutputDir "$helper/parent-build-1" -Python $python -Build
```

The wrapper imports the same Visual Studio BuildTools DevShell used by the
existing competition build script, selecting x64, MSVC 14.44 and SDK
10.0.26100.0. Python checks `VCToolsVersion=14.44.35207`,
`WindowsSDKVersion=10.0.26100.0` and `VSCMD_ARG_TGT_ARCH=x64`. Its `--build`
mode may also be called directly from an already matching developer shell.
No environment initialization occurs in plan-only mode.

Optional Python arguments: `--source-root`, `--test`, `--output-dir`,
`--build-dir`, `--build`; PowerShell equivalents are `-SourceRoot`, `-Test`,
`-OutputDir`, `-BuildDir`, `-Build`. Source root and build directory must match
the captured configuration; the helper does not rewrite embedded absolute
include/library paths. Default test is read from the actual source root.
Each invocation requires a new empty output directory outside the checkout.
All object/PDB/EXE/import-lib/response files, logs, linker intermediates and
compiler temporary files stay there. No build files are generated in D:.

`commands.json`, `compile.rsp`, `link-inputs.rsp` and `receipt.json` make the
plan reviewable. Build mode checks the pinned round12 `.cpp`/`.h`, direct test
and four charset inputs, accepting only the documented raw/LF hash pairs.
It rejects relevant CMake/Ninja command drift or missing production artifacts,
and checks that the storage unity object is at least as new as the two round12
sources and its archive is at least as new as that object. Any compile/link
failure stops without retries, stubs, source recompilation or unresolved-symbol
suppression. Review `compile.log`/`link.log` in that output if it fails.

Manual test execution is a separate parent action, only after successful build
and with benchmarks idle:

```powershell
Push-Location -LiteralPath "$helper/parent-build-1"
try {
    & './test_stopword_ascii_checker.exe'
    if ($LASTEXITCODE -ne 0) { throw "direct checker failed: $LASTEXITCODE" }
} finally { Pop-Location }
```

Preparation performed Python AST parsing and plan-only command generation
against the actual build configuration, reading the staged test as `--test`.
`example-plan/` records that generation. Candidate production source hashes did
not yet match round12, so this is not candidate validation. No compiler,
linker, Ninja command, native executable, SQL, database, production build or
performance task was invoked. The round12 proposal manifest remains
`ad09a1ee4d7557d7d40cfced662a9edbfbb7828281abe3915e0e5af4d130be1b`.

Remaining limits: compile/link success and runtime initialization are untested;
the parent must resolve any genuine compiler/dependency error rather than
substitute an algorithm-only test. Timestamp checks and recorded artifact
hashes do not prove archive/source identity. The parent must use its completed
round12 build. This helper is specific to the captured Windows configuration;
any relevant toolchain/configuration drift needs a deliberate new capture.
