"""Plan, or explicitly compile/link, the real round12 production checker test.

Never invokes Ninja/CMake build, starts seekdb, or executes the resulting test.
Default operation only writes command/response/receipt files under --output-dir.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

HERE = Path(__file__).resolve().parent
TEST_REL = "unittest/storage/fts/test_stopword_ascii_checker.cpp"
MAIN_OBJ = "src/observer/CMakeFiles/ob_main.dir/main.cpp.obj"


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def json_write(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def windows_args(command):
    """Decode MS CRT quoting without starting a process or using shell parsing."""
    result, index = [], 0
    while index < len(command):
        while index < len(command) and command[index] in " \t\r\n":
            index += 1
        if index == len(command):
            break
        arg, quoted = [], False
        while index < len(command):
            if command[index] in " \t\r\n" and not quoted:
                break
            slashes = 0
            while index < len(command) and command[index] == "\\":
                slashes += 1
                index += 1
            if index < len(command) and command[index] == '"':
                arg.append("\\" * (slashes // 2))
                if slashes % 2:
                    arg.append('"')
                elif quoted and index + 1 < len(command) and command[index + 1] == '"':
                    arg.append('"')
                    index += 1
                else:
                    quoted = not quoted
                index += 1
            else:
                arg.append("\\" * slashes)
                if index < len(command) and command[index] in " \t\r\n" and not quoted:
                    break
                if index < len(command):
                    arg.append(command[index])
                    index += 1
        require(not quoted, "Unterminated Windows command quote")
        result.append("".join(arg))
    return result


def response_write(path, args):
    encoded = subprocess.list2cmdline(args)
    require(windows_args(encoded) == args, "Response-file quoting round trip failed")
    # clang-cl and lld-link both consume Windows-quoted UTF-8 response files.
    Path(path).write_text(encoded + "\n", encoding="utf-8")


def ninja_expand(value, variables):
    def replace(match):
        key = match.group(1)
        if key in ("$", " ", ":"):
            return key
        key = key[1:-1] if key.startswith("{") else key
        require(key in variables, "Unsupported Ninja variable: " + key)
        return variables[key]
    return re.sub(r"\$(\$| |:|\{[^}]+\}|[A-Za-z_][A-Za-z_0-9]*)", replace, value)


def ninja_blocks(path):
    lines = Path(path).read_text(encoding="utf-8").splitlines()
    require(not any(line.endswith("$") for line in lines),
            "Ninja continuation appeared; re-extract settings deliberately")
    blocks = []
    for index, line in enumerate(lines):
        if line.startswith(("build ", "rule ")):
            variables = {}
            for following in lines[index + 1:]:
                if not following.startswith("  "):
                    break
                key, sep, value = following.strip().partition(" = ")
                require(bool(sep), "Unsupported Ninja binding")
                variables[key] = value
            blocks.append((line, variables))
    return blocks


def extract_records(build_dir):
    commands = json.loads((build_dir / "compile_commands.json").read_text(encoding="utf-8"))
    units = [item for item in commands
             if "/ob_storage.dir/" in item.get("output", "").replace("\\", "/")
             and Path(item["file"]).name == "unity_ob_storage_ob_storage_fts_0_c___cxx.cxx"]
    require(len(units) == 1, "Expected exactly one existing production FTS unity compile record")
    edges = [(line, values) for line, values in ninja_blocks(build_dir / "build.ninja")
             if line.startswith("build ") and ": CXX_EXECUTABLE_LINKER__seekdb_" in line]
    require(len(edges) == 1, "Expected exactly one seekdb executable link edge")
    edge, variables = edges[0]
    rule_name, tail = edge.split(": ", 1)[1].split(" ", 1)
    inputs = ninja_expand(tail.split(" |", 1)[0], {}).split()
    require(inputs.count(MAIN_OBJ) == 1, "The original main object was not uniquely identified")
    require(all(path.endswith(".obj") for path in inputs), "Unexpected explicit link inputs")
    rules = [values for line, values in ninja_blocks(build_dir / "CMakeFiles/rules.ninja")
             if line == "rule " + rule_name]
    require(len(rules) == 1, "Executable link rule missing")
    # Exclude the seekdb POST_BUILD action: it writes beside the production EXE.
    require(variables.get("PRE_LINK") == "cd .", "Nontrivial PRE_LINK needs explicit adaptation")
    require(rules[0].get("rspfile_content") == "$in $LINK_PATH $LINK_LIBRARIES",
            "Unexpected executable response-file contract")
    selected = {key: variables[key] for key in (
        "LINK_FLAGS", "LINK_PATH", "LINK_LIBRARIES", "PRE_LINK", "POST_BUILD", "TARGET_FILE")}
    return {"compile_record": units[0], "link_rule_name": rule_name,
            "link_rule": rules[0], "link_variables": selected, "explicit_objects": inputs}


def full_build_path(value, build_dir):
    path = Path(value)
    return path if path.is_absolute() else build_dir / path


def input_status(root, settings, test):
    status = []
    for pin in settings["source_pins"]:
        path = root / pin["path"]
        actual = sha(path) if path.is_file() else None
        status.append({"path": str(path), "sha256": actual,
                       "matches": actual in pin["accepted_sha256"]})
    actual = sha(test) if test.is_file() else None
    status.append({"path": str(test), "sha256": actual,
                   "matches": actual in settings["test_pin"]["accepted_sha256"]})
    return status


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-root", type=Path, required=True)
    parser.add_argument("--build-dir", type=Path, help="Default: source-root/build_fts_competition")
    parser.add_argument("--test", type=Path, help="Default: source-root/" + TEST_REL)
    parser.add_argument("--output-dir", type=Path, required=True,
                        help="Dedicated helper-owned directory outside the production checkout")
    parser.add_argument("--build", action="store_true",
                        help="Compile exactly this test TU and link once; NEVER execute it. Idle host only.")
    args = parser.parse_args()
    settings_path = HERE / "build-settings.json"
    settings = json.loads(settings_path.read_text(encoding="utf-8"))
    root = args.source_root.resolve()
    build_dir = (args.build_dir or root / "build_fts_competition").resolve()
    test = (args.test or root / TEST_REL).resolve()
    output = args.output_dir.resolve()
    require(root == Path(settings["source_root"]).resolve(),
            "This captured CMake configuration embeds its source root; relocation needs a new capture")
    require(build_dir == Path(settings["build_dir"]).resolve(), "Build directory differs from capture")
    require(not output.is_relative_to(root) and not root.is_relative_to(output),
            "Output must be a dedicated directory outside the source/build checkout")
    require(output != HERE and not HERE.is_relative_to(output), "Output cannot replace the helper directory")
    if output.exists():
        require(not any(output.iterdir()), "Use a new empty output directory for each plan/build")
    actual = extract_records(build_dir)
    require(actual == settings["records"], "Relevant CMake/Ninja command records drifted; no silent fallback")
    unity = Path(actual["compile_record"]["file"])
    require(sha(unity) == settings["unity_sha256"], "Production unity membership changed")
    require('src/storage/fts/ob_fts_stop_word.cpp' in unity.read_text(encoding="utf-8").replace("\\", "/"),
            "Selected production unity does not contain the checker")
    status = input_status(root, settings, test)
    if args.build:
        require(os.name == "nt", "Captured ABI requires native Windows x64")
        require(all(item["matches"] for item in status), "Round12/test/proof hashes do not match; apply first")
        for key, expected in settings["environment_required"].items():
            value = os.environ.get(key, "").rstrip("\\/")
            require(value.lower() == expected.lower(), f"{key}={value!r}, expected {expected!r}; use the PS wrapper")
        require(bool(os.environ.get("INCLUDE")) and bool(os.environ.get("LIB")), "VS x64 INCLUDE/LIB missing")
    compile_tokens = windows_args(actual["compile_record"]["command"])
    compiler, original_args = compile_tokens[0], compile_tokens[1:]
    require(Path(compiler).name.lower() == "clang-cl.exe", "Expected captured clang-cl frontend")
    compile_args, replacements = [], {"object": 0, "pdb": 0, "source": 0}
    for arg in original_args:
        if arg.startswith("/Fo"):
            require(arg[3:].replace("\\", "/") == actual["compile_record"]["output"].replace("\\", "/"),
                    "Unexpected compile object argument")
            arg = "/Fo" + (output / "checker.obj").as_posix()
            replacements["object"] += 1
        elif arg.startswith("/Fd"):
            arg = "/Fd" + (output / "checker-compile.pdb").as_posix()
            replacements["pdb"] += 1
        elif arg == actual["compile_record"]["file"]:
            arg = test.as_posix()
            replacements["source"] += 1
        compile_args.append(arg)
    require(replacements == {"object": 1, "pdb": 1, "source": 1}, "Compile substitution was not exact")
    require("-c" in compile_args and "--" in compile_args, "Expected compile-only source contract")
    link_objects = [full_build_path(item, build_dir).as_posix()
                    for item in actual["explicit_objects"] if item != MAIN_OBJ]
    libraries = windows_args(ninja_expand(actual["link_variables"]["LINK_LIBRARIES"], {}))
    require(all(item.lower().endswith(".lib") for item in libraries), "Unexpected link library expression")
    libraries = [full_build_path(item, build_dir).as_posix()
                 if "/" in item or "\\" in item else item for item in libraries]
    link_args = [(output / "checker.obj").as_posix()] + link_objects
    link_args += windows_args(ninja_expand(actual["link_variables"]["LINK_PATH"], {})) + libraries
    require(not any(item.replace("\\", "/").endswith("/" + MAIN_OBJ) for item in link_args),
            "Original main object survived link replacement")
    # Reuse the actual CMake vs_link_exe wrapper, RC, MT, linker, and link flags.
    rule = actual["link_rule"]["command"]
    match = re.fullmatch(r'.+? /C "\$PRE_LINK && (.+) && \$POST_BUILD"', rule)
    require(match is not None, "Unexpected link shell wrapper; adapt deliberately")
    variables = {"OBJECT_DIR": subprocess.list2cmdline([(output / "link-intermediate").as_posix()]),
                 "RSP_FILE": subprocess.list2cmdline([(output / "link-inputs.rsp").as_posix()]),
                 "TARGET_FILE": subprocess.list2cmdline([(output / "test_stopword_ascii_checker.exe").as_posix()]),
                 "TARGET_IMPLIB": subprocess.list2cmdline([(output / "checker.lib").as_posix()]),
                 "TARGET_PDB": subprocess.list2cmdline([(output / "checker-link.pdb").as_posix()]),
                 "MANIFESTS": "", "LINK_FLAGS": actual["link_variables"]["LINK_FLAGS"]}
    link_command = windows_args(ninja_expand(match.group(1), variables))
    require("vs_link_exe" in link_command and "--manifests" in link_command,
            "Lost CMake manifest-link wrapper")
    require(any(Path(item).name.lower() == "lld-link.exe" for item in link_command), "Lost production linker")
    artifacts = []
    for item in link_objects + libraries:
        if "/" in item or "\\" in item:
            path = Path(item)
            artifacts.append({"path": str(path), "exists": path.is_file(),
                              "bytes": path.stat().st_size if path.is_file() else None})
    obj = full_build_path(actual["compile_record"]["output"], build_dir)
    archive = build_dir / "src/storage/ob_storage_static.lib"
    fresh = obj.is_file() and archive.is_file() and all(
        obj.stat().st_mtime_ns >= (root / pin["path"]).stat().st_mtime_ns
        for pin in settings["source_pins"] if pin["path"].startswith("src/storage/fts/"))
    fresh = bool(fresh and archive.stat().st_mtime_ns >= obj.stat().st_mtime_ns)
    runtime_dir = build_dir / "src/observer"
    dlls = sorted(runtime_dir.glob("*.dll"))
    require(bool(dlls), "No bundled production runtime DLLs found")
    if args.build:
        require(all(item["exists"] for item in artifacts), "Existing production link artifact missing; no rebuild attempted")
        require(fresh, "Production FTS unity/archive are older than round12 inputs; parent must rebuild first")
    output.mkdir(parents=True, exist_ok=False) if not output.exists() else None
    response_write(output / "compile.rsp", compile_args)
    response_write(output / "link-inputs.rsp", link_args)
    compile_command = [compiler, "@" + str(output / "compile.rsp")]
    commands = {"cwd": str(output), "compile": compile_command, "link": link_command,
                "removed_main_object": MAIN_OBJ, "retained_explicit_objects": link_objects,
                "compile_replacements_only": replacements,
                "response_sha256": {name: sha(output / name) for name in ("compile.rsp", "link-inputs.rsp")}}
    json_write(output / "commands.json", commands)
    receipt = {"mode": "build" if args.build else "plan-only", "settings_sha256": sha(settings_path),
               "source_root": str(root), "build_dir": str(build_dir), "test": str(test),
               "input_hashes": status, "candidate_source_hashes_match": all(item["matches"] for item in status),
               "production_fresh_by_mtime_only": fresh, "link_artifacts": artifacts,
               "runtime_dll_sources": [str(item) for item in dlls],
               "compile": "NOT RUN", "link": "NOT RUN", "native_test": "NOT RUN"}
    json_write(output / "receipt.json", receipt)
    if not args.build:
        print("PLAN ONLY:", output, "candidate_hashes_match=", receipt["candidate_source_hashes_match"])
        return
    environment = os.environ.copy()
    temporary = output / "tmp"
    temporary.mkdir()
    environment["TMP"] = environment["TEMP"] = str(temporary)
    for phase, command in (("compile", compile_command), ("link", link_command)):
        if phase == "link":
            (output / "link-intermediate").mkdir()
        with (output / (phase + ".log")).open("wb") as log:
            completed = subprocess.run(command, cwd=output, env=environment, stdout=log, stderr=subprocess.STDOUT)
        receipt[phase] = {"exit_code": completed.returncode, "log_sha256": sha(output / (phase + ".log"))}
        json_write(output / "receipt.json", receipt)
        require(completed.returncode == 0, f"{phase} failed; see {output / (phase + '.log')}; no retry/fallback")
    receipt["runtime_dlls"] = []
    for dll in dlls:
        target = output / dll.name
        shutil.copy2(dll, target)
        digest = sha(dll)
        require(sha(target) == digest, "Runtime DLL copy differs")
        receipt["runtime_dlls"].append({"path": str(dll), "sha256": digest})
    receipt["production_hashes"] = {str(path): sha(path) for path in (
        obj, archive, build_dir / "src/oblib/oblib.lib", build_dir / "src/oblib/lib/ob_malloc.lib")}
    receipt["executable_sha256"] = sha(output / "test_stopword_ascii_checker.exe")
    json_write(output / "receipt.json", receipt)
    print("COMPILED AND LINKED; NOT EXECUTED:", output / "test_stopword_ascii_checker.exe")


if __name__ == "__main__":
    try:
        main()
    except (RuntimeError, OSError, ValueError, KeyError) as error:
        print("ERROR:", error, file=sys.stderr)
        sys.exit(1)
