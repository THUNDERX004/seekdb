# Round 18: bounded count-only short-union proposal

STAGED / NOT BUILT / NOT EXECUTED. Two proposed source files only. Production and prior round artifacts remain untouched.

## Evidence and exact scope

Parent supplied a fresh control CN diagnostic: 50k, expected COUNT 8001; 1814 instruction-pointer samples, 432 in the target image and 1382 external. Reported target symbols: do_merge_batch 79, StringDiffDecoder::batch_decode 78, ObIArrayWrap<ObPxTabletRange*>::at 48, cache_result 24, BitVector::at 22, ObIArrayWrap<ObDocIdExt>::at 16, from_datum 10. These are selected instruction-pointer observations, not stacks or CPU percentages. COMDAT folding may explain the ObPxTabletRange symbol: those 48 samples cannot be attributed exactly to the dimension array from symbol name alone. This sidecar did not rerun or independently inspect that runtime collection.

The candidate removes repeated calls/accounting in the existing existence-only union; it does not claim a measured gain. The alternative IDF-cache investigation is set aside.

Original source locations (D:/Projects/OceanBase/seekdb):
- src/storage/retrieval/ob_text_daat_iter.cpp:81-130, ObTextDaaTIter::do_merge_batch: three-or-fewer natural-language dimensions, no projected relevance, residual filter, or function lookup. The existing outer gate stays intact. The threshold is 3 in src/storage/access/ob_simple_rows_merger.h:30.
- src/storage/retrieval/ob_sparse_daat_iter.cpp:392-415, cache_result: the exact side effects replaced only when materialize_results_ is false and limit_param_->is_valid() is false.
- src/storage/retrieval/ob_text_retrieval_token_iter.h:138-148, next_doc_id: use get_data for the existing within-saved-batch ID access, retaining its bounds assertion and refill/error path.

## Candidate behavior and counter invariant

Within the existing short-union branch, cache_result is bypassed only if outputs need no datum materialization, the pushed limit/offset parameter is invalid, initial count is nonnegative, and requested effective capacity fits BOTH output buffers. An insufficient-buffer case still calls cache_result, retaining its input-counter increment followed by OB_INVALID_ARGUMENT. Valid LIMIT/OFFSET and materialized output continue calling cache_result.

Under that gate, one successful unique champion originally changes exactly count += 1, input_row_cnt_ += 1, output_row_cnt_ += 1; it performs no datum writes and cannot stop on LIMIT/OFFSET. The candidate increments local count once for that same champion and, after the loop, adds count - initial_count to both counters. This accounting runs for success, OB_ITER_END, and every ordinary non-success return, not only successful batches. No row is credited for a failing advance/comparison. A later project_results error sees already-accounted rows in both versions.

get_next_rows at ob_sparse_daat_iter.cpp:218-245 resets count to zero and passes MIN(capacity, max_batch_size_); the loop still uses count < capacity. Buffer allocation at :107-127 is at least max_batch_size_. The additional capacity gate preserves the existing buffer-error fallback rather than silently dropping its check. There is no other reader of the parent merge counters in the traced token advance or ID comparison path; counters are accounted before do_merge_batch returns. ObTextDaaTIter is final and does not override cache_result. The method is declared virtual, but compilation may already devirtualize the call: this proposal removes the per-result call/body, without claiming a demonstrated indirect-dispatch cost.

## Array and ownership invariant

ObIArray inherits ObIArrayWrap (src/oblib/lib/container/ob_iarray.h:42). Both original one-argument at and get_data access the same data_ (ob_array_wrap.h:40-62); no reinterpret cast or assumption about a separate element representation is introduced.

Successful merge initialization prepares iter_domain_ids_ and next_round_iter_idxes_ to exactly dim_count and seeds pending indices 0..dim_count-1 (ob_sparse_daat_iter.cpp:117-137). Reuse reseeds them (:173-176). Every subsequent pending index is a scan index i satisfying 0 <= i < dim_count; equal champions are still advanced together, in the same order. The candidate validates matching array counts, pending-count bounds, and non-null positive-size storage once per call, and retains the generated-index assertion. Empty dimensions dereference no storage. Inconsistent internal layout now returns OB_ERR_UNEXPECTED; the original treated invalid raw-array indices/storage as an internal assertion/invariant violation. This is not claimed as original error compatibility for corrupted internal state.

The hoisted three pointers are local borrowed views, never stored or returned. The loop only overwrites existing slots; token refill does not resize these parent arrays. Original NULL token errors, end-of-token clearing, compare error propagation, next_round_cnt_ transitions, ordering, and duplicate suppression stay unchanged. Materialized results are copied before refill exactly as before.

## Current FTS caller audit: contiguous storage verified

No concrete Major/Blocker was found for get_data on current FTS callers. This conclusion is scoped to the checked production source, not a promise about arbitrary future ObIArray subclasses.

1. The only production constructor call sites for ObTextDaaTIter/ObTextBMWIter are ObDASLegacyTRMergeIter::init_sparse_retrieval_iter in src/observer/composition/retrieval/ob_das_legacy_tr_merge_iter.cpp:421-438. Both call its init_daat_iter_param at :423/:433. That function assigns iter_param.dim_iters_ = &dim_iters_ at :480; there is no cast, adapter, or alternative parameter source. ObTextDaaTIter::init passes that exact array to ObSRDaaTIterImpl::init at src/storage/retrieval/ob_text_daat_iter.cpp:31, which stores its address at ob_sparse_daat_iter.cpp:105.
2. The actual owning member is ObDASLegacyTRMergeIter::ObDASTokenRetrievalIterArray, declared as ObSEArray<ObISRDaaTDimIter *, 4> at ob_das_legacy_tr_merge_iter.h:124-126. create_dim_iters adds ObTextRetrievalDaaTTokenIter objects for the DaaT path at .cpp:316-324; the BMW branch adds its different block-max children at :303-313 and uses ObTextBMWIter instead. Thus the changed short union receives the expected token-iterator type.
3. ObSEArray is the final wrapper over ObSEArrayImpl (src/oblib/lib/container/ob_array.h:840-846), whose base is ObIArray at :270. Its data_ is set to the contiguous local buffer at :714; growth allocates a single new_data buffer and updates data_ at :381. ObIArrayWrap::at and get_data use the same base data_ at ob_array_wrap.h:40-62. Eligible 1-3 dimensions fit the declared inline capacity 4; retained heap storage would also be contiguous. The payload neither copies pointer objects by reinterpret_cast nor assumes derived-object stride.
4. All writes to this owner's dim_iters_ in the traced implementation are construction push_back calls at ob_das_legacy_tr_merge_iter.cpp:313/:324 and release reset at :859. Release resets the sparse retrieval iterator first at :855-857. inner_get_next_row/inner_get_next_rows simply forward to it at :879-902. No resize/reallocation occurs inside the merge loop or a token advance. The raw views remain local to one call.
5. A separate same-named alias in src/sql/das/iter/ob_das_text_retrieval_merge_iter.h:159-171 is ObSEArray<ObDASTextRetrievalIter *, 4>; its token_iters_ is also contiguous. That SQL iterator does not construct ObTextDaaTParam/ObTextDaaTIter and is not an additional caller of this optimized storage loop.
6. The current Ob2DArray declaration in src/oblib/lib/container/ob_2d_array.h:38 does not inherit ObIArray. No Ob2DArray, noncontiguous adapter, or forced container cast was found supplying an FTS ObTextDaaTParam. Searches covered current src plus unittest/tools; documentation's archived proposal copies were excluded from the set of production callers. A bounded stack copy through at is therefore unnecessary for the current chain; if a future noncontiguous adapter is introduced, it must establish this contract or use a safe bounded copy before enabling the raw-view path.

The once-per-call dimension/storage checks and generated-index assertions remain in the staged payload. They are defensive validation, not a substitute for this concrete owning-type trace.

## next_doc_id inspection

The current helper already has a nonvirtual saved-batch fast path, avoiding score retrieval. Its remaining element access uses ObFixedArray::operator[] -> at. The one-line payload uses doc_id_.get_data()[cur_idx_] and retains the same index-bound assertion. No raw pointer is retained across refill.

Token initialization preallocates doc_id_ to max_batch_size_ (ob_text_retrieval_token_iter.cpp:441-451); get_next_row loads at that capacity (:477-500). save_docids and save_relevances_and_docids retain the owned ObDocIdExt copies (:504-540). The fast path is entered only for the next index inside the saved count. get_next_row/get_curr_id, end-with-partial-batch conversion, scalar handling, reset/reuse, skip checks, from_datum, and all refill errors are unchanged. No prefix processing, galloping, decoder work, copy elimination, or broader batching is proposed. Refill still supplies the same owned bytes needed because child iterators share expression state.

This tiny header delta can be evaluated separately by the parent if attribution is needed; its standalone gain is unknown. Debug container-specific extra_access_check dispatch is bypassed by raw access, while index assertions remain. This does not justify suppressing unrelated decoder/skip/copy checks.

## Focused parent checks required, not performed

1. Compare original and candidate exact union/count batches and final counters with 0/1/2/3 dimensions; >3 fallback; empty/absent tokens; disjoint, identical, and overlapping posting lists; repeated query tokens; UINT64 and existing binary/composite key types. Exercise exhaustion of all children together and one-by-one, including ties at child refill boundaries.
2. Effective capacities 0, 1, 2, max_batch_size_-1, max_batch_size_, and larger caller requests (clamped by the existing wrapper); multiple full batches followed by a partial batch. Check count, ret, pending indices, active IDs, and both cumulative counters against the original after each return.
3. Inject a child advance failure, NULL child, or comparison failure before any output and after K successful unique champions. Expected delta is exactly K for count and both counters even on error, with the same original return code and merge state. Exercise original buffer-capacity failure fallback; input increment for the rejected champion must remain.
4. Verify fallback for materialize_results_=true, valid pushed LIMIT/OFFSET (including OFFSET skipping and boundary LIMIT), Boolean, score/filter/function-lookup, and larger-dimension plans; exact IDs/order/scores/errors must remain. Confirm scalar cardinality handling and reset/reuse/rescan do not retain local state.
5. next_doc_id: verify last saved ID, refill, empty/end, final partial batch, refill/copy errors, and reuse, including long owned key bytes after another child refills shared expressions. Run existing materialization/keytype/ranked controls; keep all fixtures immutable, including ranked cases 49/265.
6. Parent must confirm the actual CN COUNT selects this short, unmaterialized, unlimited union. Compare serial matched full benchmark reports, retaining negatives. The supplied profile motivates targeting the path but establishes neither the path's full dynamic contract nor any speedup.

## Static package identity

Original CPP SHA-256: dbc022030c8fa856a1e521d80c366207e290f13bb679b62b81d2293e44c3ce2d
Candidate CPP SHA-256: a8c0555150ffbe5d7e7b8d05ed66c670b86e46fb9b2440cbbab05941fd59ebbe
Original header SHA-256: b094bd2d5700ea9fe3ed36a36960c0874d3ee54744e68126d7a0dfe487e48ae9
Candidate header SHA-256: 8404bfdf5fe0d7ee461dc7f060c6aef019830a4fd93f78938501a71df0f82b01
Combined patch SHA-256: 96bd121756dd79dc3e9c67bd0cdc6ab8228feb59d091df931df71717609556f8

Only static source-anchor transformations, unchanged-function-boundary checks, SHA-256 and reversible textual reconstruction were performed. No C++ compilation, executable, SQL, correctness test, performance collection, or Git command was run. Syntax/ABI/runtime behavior and performance remain unvalidated.

## Parent coordination and freeze

Parent reports applying the two exact candidate snapshots and starting build session 11814 with control executable/PDB pinned. Independent static file hashes now confirm both live source files equal the staged candidates. The earlier end-of-packaging assertion requiring live sources still equal the originals detected that parent application; it was not a candidate runtime or patch-replay failure. Final static validation checks the explicitly applied candidate identity instead.

Singer owns the focused SQL accounting regression. This sidecar did not create a duplicate runtime harness or run any regression. All listed runtime checks remain requirements, not passing results. Source snapshots, candidate payloads, combined patch, and their manifest identities are frozen unchanged. Only this auxiliary report is finalized after the caller audit.
