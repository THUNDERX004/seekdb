# Round 18 count-union proposal

Status: STAGED ONLY / NOT BUILT / NOT EXECUTED. Production source was read, not changed. No seekdb native run, SQL, benchmark, build, service operation, or Git operation was performed by this sidecar.

- original/: exact current control snapshots, with original line endings. These are not the competition-original source tree.
- candidate/: matching two-file proposed payload.
- source.patch: exact unified two-file delta; the C++ source uses LF and header uses CRLF, preserved in snapshots and payload.
- manifest.json: original/payload SHA-256, byte lengths, and patch SHA-256.
- report.md: applicability, accounting/bounds/ownership argument, next_doc_id inspection, and focused parent validation.

Parent must compare every live preimage and candidate hash with manifest.json before applying, then own compilation, correctness checks, path confirmation, and serial matched performance evaluation. The patch is an optimization proposal, not correctness or performance validation. The prior IDF-cache idea is set aside. No BMW bound/traversal, tokenizer, benchmark, scoring, or fixture changes are included.

Parent subsequently reports applying the exact two payloads and starting build 11814. Caller-contiguity audit and static payload verification are complete in report.md; this sidecar has not run compilation/runtime/regression. Candidate and patch bytes stay frozen.
