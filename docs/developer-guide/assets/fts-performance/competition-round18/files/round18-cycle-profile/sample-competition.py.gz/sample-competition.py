#!/usr/bin/env python3
"""Intrusive, unscored, PID-bound AMD64 Windows cycle-selected RIP diagnostic.

Staged only: not executed or imported by its author. See README.md before use.
"""
import argparse
from collections import Counter
import ctypes as c
from ctypes import wintypes as w
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import socket
import struct
import sys
import threading
import time
import uuid

DWORD = c.c_uint32
QWORD = c.c_uint64
FAIL_DWORD = 0xFFFFFFFF
INVALID_HANDLE = c.c_void_p(-1).value
PORT = 2891
REFRESH_NS = 100_000_000
SELECT_CAP = 2


class THREADENTRY32(c.Structure):
    _fields_ = [("dwSize", DWORD), ("cntUsage", DWORD), ("tid", DWORD),
                ("pid", DWORD), ("basePriority", c.c_int32),
                ("deltaPriority", c.c_int32), ("flags", DWORD)]


class MODULEENTRY32W(c.Structure):
    _fields_ = [("dwSize", DWORD), ("moduleID", DWORD), ("pid", DWORD),
                ("globalUsage", DWORD), ("processUsage", DWORD),
                ("base", c.c_void_p), ("size", DWORD), ("module", w.HANDLE),
                ("name", c.c_wchar * 256), ("path", c.c_wchar * 260)]


class TCPROW(c.Structure):
    _fields_ = [(name, DWORD) for name in
                ("state", "localAddr", "localPort", "remoteAddr", "remotePort", "pid")]


class GUID(c.Structure):
    _fields_ = [("d1", DWORD), ("d2", c.c_uint16), ("d3", c.c_uint16),
                ("d4", c.c_ubyte * 8)]


class MODULEINFO(c.Structure):
    _fields_ = [("SizeOfStruct", DWORD), ("BaseOfImage", QWORD),
                ("ImageSize", DWORD), ("TimeDateStamp", DWORD),
                ("CheckSum", DWORD), ("NumSyms", DWORD), ("SymType", DWORD),
                ("ModuleName", c.c_wchar * 32), ("ImageName", c.c_wchar * 256),
                ("LoadedImageName", c.c_wchar * 256), ("LoadedPdbName", c.c_wchar * 256),
                ("CVSig", DWORD), ("CVData", c.c_wchar * 780), ("PdbSig", DWORD),
                ("PdbSig70", GUID), ("PdbAge", DWORD), ("PdbUnmatched", w.BOOL),
                ("DbgUnmatched", w.BOOL), ("LineNumbers", w.BOOL),
                ("GlobalSymbols", w.BOOL), ("TypeInfo", w.BOOL),
                ("SourceIndexed", w.BOOL), ("Publics", w.BOOL),
                ("MachineType", DWORD), ("Reserved", DWORD)]


class SYMBOLINFO(c.Structure):
    _fields_ = [("SizeOfStruct", DWORD), ("TypeIndex", DWORD), ("Reserved", QWORD * 2),
                ("Index", DWORD), ("Size", DWORD), ("ModBase", QWORD),
                ("Flags", DWORD), ("Value", QWORD), ("Address", QWORD),
                ("Register", DWORD), ("Scope", DWORD), ("Tag", DWORD),
                ("NameLen", DWORD), ("MaxNameLen", DWORD), ("Name", c.c_char * 1)]


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def absolute_file(value, suffix):
    p = Path(value)
    require(p.is_absolute(), "An absolute file path is required")
    p = p.resolve(strict=True)
    require(p.is_file() and p.suffix.lower() == suffix, "Unexpected file type")
    return p


def same_path(left, right):
    return os.path.normcase(str(Path(left).resolve())) == os.path.normcase(str(Path(right).resolve()))


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def identity(rsds):
    require(rsds[:4] == b"RSDS" and len(rsds) >= 24, "Missing modern RSDS debug identity")
    return {"guid": str(uuid.UUID(bytes_le=rsds[4:20])),
            "age": struct.unpack_from("<I", rsds, 20)[0]}


def pe_identity(read, loaded=False):
    """read(offset, length) reads disk file offsets or loaded-image RVAs."""
    dos = read(0, 64)
    require(dos[:2] == b"MZ", "Invalid executable DOS header")
    pe = struct.unpack_from("<I", dos, 60)[0]
    require(pe < 16 * 1024 * 1024, "Unreasonable PE header offset")
    header = read(pe, 24)
    require(header[:4] == b"PE\0\0", "Invalid PE signature")
    machine, sections, _, _, _, opt_size, _ = struct.unpack_from("<HHIIIHH", header, 4)
    require(machine == 0x8664 and 0 < sections <= 96 and 168 <= opt_size <= 4096,
            "Only native AMD64 PE images are supported")
    opt = read(pe + 24, opt_size)
    require(struct.unpack_from("<H", opt)[0] == 0x20B, "Expected PE32+ image")
    image_size = struct.unpack_from("<I", opt, 56)[0]
    require(struct.unpack_from("<I", opt, 108)[0] > 6, "Missing debug directory")
    debug_rva, debug_size = struct.unpack_from("<II", opt, 112 + 6 * 8)
    require(debug_rva > 0 and 0 < debug_size <= 65536 and debug_size % 28 == 0,
            "Invalid debug-directory size")
    section_data = read(pe + 24 + opt_size, 40 * sections)

    def offset(rva):
        if loaded:
            return rva
        for index in range(sections):
            virtual_size, virtual_addr, raw_size, raw_ptr = struct.unpack_from(
                "<IIII", section_data, index * 40 + 8)
            if virtual_addr <= rva < virtual_addr + max(virtual_size, raw_size):
                require(rva - virtual_addr < raw_size, "Debug RVA has no disk bytes")
                return raw_ptr + rva - virtual_addr
        raise RuntimeError("Debug RVA is outside PE sections")

    directory = read(offset(debug_rva), debug_size)
    for index in range(0, debug_size, 28):
        _, _, _, _, kind, length, rva, raw = struct.unpack_from("<IIHHIIII", directory, index)
        if kind == 2:
            require(24 <= length <= 65536, "Invalid CodeView record size")
            cv = read(rva if loaded else raw, length)
            if cv[:4] == b"RSDS":
                return {**identity(cv), "image_size": image_size, "machine": machine}
    raise RuntimeError("No RSDS record found")


class WinAPI:
    def __init__(self):
        require(sys.platform == "win32" and c.sizeof(c.c_void_p) == 8,
                "Requires 64-bit Windows Python")
        self.k = c.WinDLL("kernel32", use_last_error=True)
        self.handles = Counter()
        specs = {
            "OpenProcess": ([DWORD, w.BOOL, DWORD], w.HANDLE),
            "QueryFullProcessImageNameW": ([w.HANDLE, DWORD, w.LPWSTR, c.POINTER(DWORD)], w.BOOL),
            "IsWow64Process2": ([w.HANDLE, c.POINTER(c.c_uint16), c.POINTER(c.c_uint16)], w.BOOL),
            "GetCurrentProcess": ([], w.HANDLE),
            "GetProcessTimes": ([w.HANDLE] + [c.POINTER(w.FILETIME)] * 4, w.BOOL),
            "GetThreadTimes": ([w.HANDLE] + [c.POINTER(w.FILETIME)] * 4, w.BOOL),
            "ReadProcessMemory": ([w.HANDLE, c.c_void_p, c.c_void_p, c.c_size_t,
                                   c.POINTER(c.c_size_t)], w.BOOL),
            "WaitForSingleObject": ([w.HANDLE, DWORD], DWORD),
            "OpenThread": ([DWORD, w.BOOL, DWORD], w.HANDLE),
            "GetProcessIdOfThread": ([w.HANDLE], DWORD),
            "QueryThreadCycleTime": ([w.HANDLE, c.POINTER(QWORD)], w.BOOL),
            "SuspendThread": ([w.HANDLE], DWORD), "ResumeThread": ([w.HANDLE], DWORD),
            "GetThreadContext": ([w.HANDLE, c.c_void_p], w.BOOL),
            "CloseHandle": ([w.HANDLE], w.BOOL),
            "CreateToolhelp32Snapshot": ([DWORD, DWORD], w.HANDLE),
            "Thread32First": ([w.HANDLE, c.POINTER(THREADENTRY32)], w.BOOL),
            "Thread32Next": ([w.HANDLE, c.POINTER(THREADENTRY32)], w.BOOL),
            "Module32FirstW": ([w.HANDLE, c.POINTER(MODULEENTRY32W)], w.BOOL),
            "Module32NextW": ([w.HANDLE, c.POINTER(MODULEENTRY32W)], w.BOOL),
            "GetSystemDirectoryW": ([w.LPWSTR, DWORD], DWORD),
        }
        for name, (arguments, result) in specs.items():
            method = getattr(self.k, name)
            method.argtypes, method.restype = arguments, result

    def check(self, ok, name):
        if not ok:
            raise OSError(c.get_last_error(), name)

    def close(self, handle):
        if handle and handle != INVALID_HANDLE:
            self.handles["close_attempts"] += 1
            if not self.k.CloseHandle(handle):
                self.handles["close_failures"] += 1
                raise OSError(c.get_last_error(), "CloseHandle")
            self.handles["closed"] += 1

    def native_x64(self, handle):
        process_machine, native_machine = c.c_uint16(), c.c_uint16()
        self.check(self.k.IsWow64Process2(handle, c.byref(process_machine), c.byref(native_machine)),
                   "IsWow64Process2")
        require(process_machine.value == 0 and native_machine.value == 0x8664,
                "WOW64/ARM64/emulated targets or interpreters are unsupported")

    def creation_time(self, handle, thread=False):
        values = [w.FILETIME() for _ in range(4)]
        method = self.k.GetThreadTimes if thread else self.k.GetProcessTimes
        self.check(method(handle, *(c.byref(v) for v in values)), "GetCreationTime")
        return (values[0].dwHighDateTime << 32) | values[0].dwLowDateTime

    def snapshot(self, flags, pid, entry_class, first_name, next_name):
        handle = self.k.CreateToolhelp32Snapshot(flags, pid)
        self.check(handle and handle != INVALID_HANDLE, "CreateToolhelp32Snapshot")
        self.handles["snapshots_opened"] += 1
        try:
            entry = entry_class()
            entry.dwSize = c.sizeof(entry)
            first, following = getattr(self.k, first_name), getattr(self.k, next_name)
            if not first(handle, c.byref(entry)):
                require(c.get_last_error() == 18, "Snapshot first-entry failure")
                return []
            result = []
            while True:
                result.append(c.string_at(c.byref(entry), c.sizeof(entry)))
                entry.dwSize = c.sizeof(entry)
                if not following(handle, c.byref(entry)):
                    require(c.get_last_error() == 18, "Snapshot enumeration failure")
                    return [entry_class.from_buffer_copy(raw) for raw in result]
        finally:
            self.close(handle)

    def listeners(self):
        iphlp = c.WinDLL("iphlpapi", use_last_error=True)
        method = iphlp.GetExtendedTcpTable
        method.argtypes = [c.c_void_p, c.POINTER(DWORD), w.BOOL, DWORD, DWORD, DWORD]
        method.restype = DWORD
        size = DWORD()
        result = method(None, c.byref(size), False, 2, 3, 0)
        require(result in (0, 122), "GetExtendedTcpTable sizing failed")
        for _ in range(4):
            require(4 <= size.value <= 64 * 1024 * 1024, "Invalid TCP table size")
            buffer = c.create_string_buffer(size.value)
            result = method(buffer, c.byref(size), False, 2, 3, 0)
            if result == 122:
                continue
            require(result == 0, "GetExtendedTcpTable failed")
            count = DWORD.from_buffer(buffer).value
            require(4 + count * c.sizeof(TCPROW) <= len(buffer), "Truncated TCP table")
            return [TCPROW.from_buffer_copy(buffer, 4 + i * c.sizeof(TCPROW)) for i in range(count)]
        raise RuntimeError("TCP listener table changed repeatedly")


class Target:
    def __init__(self, api, pid, binary):
        self.api, self.pid, self.binary, self.handle = api, pid, binary, None
        require(pid > 4 and pid != os.getpid(), "Invalid or self target PID")
        require(binary.name.lower() == "seekdb.exe", "Expected explicit seekdb.exe target")
        try:
            self.handle = api.k.OpenProcess(0x100000 | 0x0400 | 0x0010, False, pid)
            api.check(self.handle, "OpenProcess")
            api.handles["process_opened"] += 1
            api.native_x64(api.k.GetCurrentProcess())
            api.native_x64(self.handle)
            name, length = c.create_unicode_buffer(32768), DWORD(32768)
            api.check(api.k.QueryFullProcessImageNameW(self.handle, 0, name, c.byref(length)),
                      "QueryFullProcessImageNameW")
            require(same_path(name.value, binary), "Supplied PID executable does not match --binary")
            self.creation = api.creation_time(self.handle)
            self.alive()
            self.check_listener()
            modules = api.snapshot(0x08 | 0x10, pid, MODULEENTRY32W,
                                   "Module32FirstW", "Module32NextW")
            matches = [m for m in modules if same_path(m.path, binary)]
            require(len(matches) == 1, "Cannot identify one exact target image mapping")
            self.base, self.size = int(matches[0].base), int(matches[0].size)
            self.modules = [{"base": int(m.base), "size": int(m.size), "path": m.path}
                            for m in modules]
            with binary.open("rb") as stream:
                def disk_read(offset, length):
                    stream.seek(offset)
                    data = stream.read(length)
                    require(len(data) == length, "Truncated PE file")
                    return data
                self.disk_identity = pe_identity(disk_read)
            self.loaded_identity = pe_identity(self.read, loaded=True)
            require(self.loaded_identity == self.disk_identity and
                    self.size == self.disk_identity["image_size"],
                    "Loaded image and supplied executable identity differ")
            self.binary_hash = sha256(binary)
        except BaseException:
            self.close()
            raise

    def alive(self):
        require(self.api.k.WaitForSingleObject(self.handle, 0) == 258,
                "Supplied process exited or could not be checked; no PID/name fallback")

    def check_listener(self):
        own = [row for row in self.api.listeners() if row.pid == self.pid]
        require(not any(socket.ntohs(row.localPort & 0xFFFF) == 2881 for row in own),
                "Refusing a process that owns protected port 2881")
        require(any(socket.ntohs(row.localPort & 0xFFFF) == PORT and
                    socket.inet_ntoa(struct.pack("<I", row.localAddr)) in ("127.0.0.1", "0.0.0.0")
                    for row in own), "Supplied PID does not own the local IPv4 2891 listener")

    def read(self, rva, length):
        require(0 <= rva and 0 < length <= 65536, "Invalid image read")
        buffer, copied = c.create_string_buffer(length), c.c_size_t()
        self.api.check(self.api.k.ReadProcessMemory(self.handle, self.base + rva, buffer,
                                                   length, c.byref(copied)), "ReadProcessMemory")
        require(copied.value == length, "Partial loaded-image read")
        return buffer.raw

    def close(self):
        if self.handle:
            handle, self.handle = self.handle, None
            self.api.close(handle)


class Symbols:
    def __init__(self, target, pdb, dll):
        self.target, self.pdb, self.initialized = target, pdb, False
        self.dll_path = dll
        self.d = c.WinDLL(str(dll), use_last_error=True)
        specs = {
            "SymSetOptions": ([DWORD], DWORD),
            "SymInitializeW": ([w.HANDLE, w.LPCWSTR, w.BOOL], w.BOOL),
            "SymLoadModuleExW": ([w.HANDLE, w.HANDLE, w.LPCWSTR, w.LPCWSTR,
                                   QWORD, DWORD, c.c_void_p, DWORD], QWORD),
            "SymGetModuleInfoW64": ([w.HANDLE, QWORD, c.POINTER(MODULEINFO)], w.BOOL),
            "SymFromAddr": ([w.HANDLE, QWORD, c.POINTER(QWORD), c.c_void_p], w.BOOL),
            "SymCleanup": ([w.HANDLE], w.BOOL),
        }
        for name, (arguments, result) in specs.items():
            method = getattr(self.d, name)
            method.argtypes, method.restype = arguments, result
        require(c.sizeof(MODULEINFO) == 3264 and c.sizeof(SYMBOLINFO) == 88 and
                SYMBOLINFO.Name.offset == 84, "Unexpected DbgHelp structure layout")
        # UNDNAME | NO_UNQUALIFIED_LOADS | FAIL_CRITICAL_ERRORS | EXACT_SYMBOLS |
        # IGNORE_NT_SYMPATH | NO_PROMPTS. No deferred/export-only/mismatch fallback.
        self.d.SymSetOptions(0x2 | 0x100 | 0x200 | 0x400 | 0x1000 | 0x80000)
        try:
            target.api.check(self.d.SymInitializeW(target.handle, str(pdb.parent), False),
                             "SymInitializeW")
            self.initialized = True
            target.api.check(self.d.SymLoadModuleExW(target.handle, None, str(target.binary), None,
                                                    target.base, target.size, None, 0),
                             "SymLoadModuleExW")
            info = MODULEINFO()
            info.SizeOfStruct = c.sizeof(info)
            target.api.check(self.d.SymGetModuleInfoW64(target.handle, target.base, c.byref(info)),
                             "SymGetModuleInfoW64 (compatible local DbgHelp required)")
            guid = str(uuid.UUID(bytes_le=c.string_at(c.byref(info.PdbSig70), 16)))
            require(info.SymType == 3 and not info.PdbUnmatched and not info.DbgUnmatched and
                    guid == target.disk_identity["guid"] and info.PdbAge == target.disk_identity["age"] and
                    same_path(info.LoadedPdbName, pdb) and info.BaseOfImage == target.base and
                    info.ImageSize == target.size, "Matching supplied PDB was not loaded; refusing diagnosis")
            self.metadata = {"loaded_pdb": str(pdb), "guid": guid, "age": int(info.PdbAge),
                             "sym_type": int(info.SymType), "exact_match": True,
                             "pdb_sha256": sha256(pdb), "dbghelp": str(dll),
                             "dbghelp_sha256": sha256(dll), "external_symbols_loaded": False}
        except BaseException:
            self.close()
            raise

    def resolve(self, ip):
        t = self.target
        result = {"ip": hex(ip), "module_at_start": None, "resolved": False, "symbol": None}
        for module in t.modules:
            if module["base"] <= ip < module["base"] + module["size"]:
                result["module_at_start"] = module["path"]
                break
        if not t.base <= ip < t.base + t.size:
            result["reason"] = "external_or_unmapped_no_matching_pdb_requested"
            return result
        result["rva"] = hex(ip - t.base)
        buffer = c.create_string_buffer(c.sizeof(SYMBOLINFO) + 4096)
        info = SYMBOLINFO.from_buffer(buffer)
        info.SizeOfStruct, info.MaxNameLen = c.sizeof(SYMBOLINFO), 4096
        displacement = QWORD()
        if self.d.SymFromAddr(t.handle, ip, c.byref(displacement), buffer) and info.ModBase == t.base:
            require(info.NameLen < 4096, "Oversized DbgHelp symbol name")
            result.update(resolved=True,
                          symbol=c.string_at(c.addressof(buffer) + SYMBOLINFO.Name.offset,
                                             info.NameLen).decode("utf-8", errors="replace"),
                          displacement=int(displacement.value))
        else:
            result.update(reason="target_pdb_symbol_unresolved", winerror=c.get_last_error())
        return result

    def close(self):
        if self.initialized:
            self.initialized = False
            self.target.api.check(self.d.SymCleanup(self.target.handle), "SymCleanup")


def error_record(error):
    # Do not serialize connection arguments, environment values or tracebacks.
    result = {"type": type(error).__name__}
    if isinstance(error, OSError):
        result["winerror_or_errno"] = error.errno
    elif isinstance(error, RuntimeError):
        result["message"] = str(error)
    elif error.args and isinstance(error.args[0], int):
        result["sql_error_code"] = error.args[0]
    return result


class CycleSampler:
    def __init__(self, target, interval_ms, maximum):
        self.target, self.api = target, target.api
        self.interval, self.maximum = interval_ms / 1000.0, maximum
        self.cache, self.records = {}, []
        self.counts, self.busy_histogram = Counter(), Counter()
        self.events, self.errors = [], []
        self.stop_event = threading.Event()
        self.worker = None
        self.started_ns = self.ended_ns = self.last_refresh_ns = 0
        self.gap_sum_ns = self.gap_count = self.gap_max_ns = 0
        self.refresh_gap_max_ns = 0
        self.context_storage = c.create_string_buffer(1232 + 15)
        self.context = (c.addressof(self.context_storage) + 15) & ~15
        # Native AMD64 CONTEXT_CONTROL: flags +48, RIP +248, size 1232, aligned 16.
        self.context_flags = DWORD.from_address(self.context + 48)
        self.context_ip = QWORD.from_address(self.context + 248)

    def _drop(self, tid):
        state = self.cache.pop(tid)
        try:
            if state["pending_resume"]:
                self._resume(state)
        finally:
            try:
                self.api.close(state["handle"])
                state["closed"] = True
                self.counts["thread_handles_closed"] += 1
            finally:
                state["handle"] = None

    def _refresh(self):
        now = time.perf_counter_ns()
        self.target.alive()
        entries = self.api.snapshot(0x04, 0, THREADENTRY32, "Thread32First", "Thread32Next")
        tids = {int(entry.tid) for entry in entries if entry.pid == self.target.pid}
        self.counts["handle_refreshes"] += 1
        self.counts["target_thread_ids_seen_across_refreshes"] += len(tids)
        if self.last_refresh_ns:
            self.refresh_gap_max_ns = max(self.refresh_gap_max_ns, now - self.last_refresh_ns)
        self.last_refresh_ns = now
        for tid in list(self.cache):
            state = self.cache[tid]
            waited = self.api.k.WaitForSingleObject(state["handle"], 0)
            require(waited in (0, 258), "Cached thread liveness check failed")
            if tid not in tids or waited == 0:
                state["exit_or_disappearance_seen"] = True
                self._drop(tid)
        for tid in sorted(tids - self.cache.keys()):
            handle = self.api.k.OpenThread(0x100000 | 0x0002 | 0x0008 | 0x0040, False, tid)
            if not handle:
                self.counts["open_thread_failed_winerror_" + str(c.get_last_error())] += 1
                continue
            self.api.handles["thread_opened"] += 1
            self.counts["thread_handles_opened"] += 1
            adopted = False
            try:
                # Snapshot/open races cannot make us sample another process's recycled TID.
                if self.api.k.GetProcessIdOfThread(handle) != self.target.pid:
                    self.counts["thread_owner_mismatch_or_exit"] += 1
                    continue
                created = self.api.creation_time(handle, thread=True)
                cycles = QWORD()
                if not self.api.k.QueryThreadCycleTime(handle, c.byref(cycles)):
                    self.counts["baseline_cycle_query_failures"] += 1
                    continue
                stamp = time.perf_counter_ns()
                state = {"tid": tid, "creation_filetime": created,
                         "generation": str(tid) + ":" + str(created), "handle": handle,
                         "pending_resume": False, "closed": False,
                         "first_cycles": int(cycles.value), "last_cycles": int(cycles.value),
                         "first_read_ns": stamp, "last_read_ns": stamp,
                         "observed_cycle_delta": 0, "cycle_reads": 1, "cycle_failures": 0,
                         "busy_loops": 0, "selected": 0, "skipped_by_cap": 0,
                         "ip_samples": 0, "suspend_failures": 0, "context_failures": 0,
                         "pre_suspended": 0, "resume_failures": 0,
                         "suspension_max_ns": 0, "counter_decreases": 0}
                self.cache[tid] = state
                self.records.append(state)
                adopted = True
                self.counts["cycle_baselines"] += 1
            except OSError:
                # Exiting threads can vanish after OpenThread; retain an explicit miss.
                self.counts["thread_initialization_os_errors"] += 1
            finally:
                if not adopted:
                    self.api.close(handle)
                    self.counts["thread_handles_closed"] += 1

    def _resume(self, state):
        # Never resume repeatedly after one success: preserve external suspend counts.
        for _ in range(3):
            result = self.api.k.ResumeThread(state["handle"])
            if result != FAIL_DWORD:
                state["pending_resume"] = False
                self.counts["resume_successes"] += 1
                require(result > 0, "Unexpected external resume interference")
                return
            state["resume_failures"] += 1
            self.counts["resume_failures"] += 1
        if self.api.k.WaitForSingleObject(state["handle"], 0) == 0:
            state["pending_resume"] = False
            self.counts["thread_exited_before_resume"] += 1
            return
        raise RuntimeError("Could not restore a live thread's suspend count; inspect target")

    def _capture(self, state, delta, window_ns, rank, loop):
        self.context_flags.value = 0x100001
        suspended, ip, context_error = False, None, None
        before = time.perf_counter_ns()
        try:
            prior = self.api.k.SuspendThread(state["handle"])
            if prior == FAIL_DWORD:
                state["suspend_failures"] += 1
                self.counts["suspend_failures"] += 1
                return
            suspended = state["pending_resume"] = True
            if prior == 0:
                if self.api.k.GetThreadContext(state["handle"], self.context):
                    ip = int(self.context_ip.value)
                else:
                    context_error = c.get_last_error()
            # A pre-suspended thread is immediately restored; no context is used.
        finally:
            if suspended:
                self._resume(state)
        after = time.perf_counter_ns()
        hold_ns = after - before  # Includes suspend/resume call overhead, not a hard bound.
        state["suspension_max_ns"] = max(state["suspension_max_ns"], hold_ns)
        self.counts["successful_suspend_pairs"] += 1
        if prior != 0:
            state["pre_suspended"] += 1
            self.counts["pre_suspended_skips"] += 1
        elif context_error is not None:
            state["context_failures"] += 1
            self.counts["context_failed_winerror_" + str(context_error)] += 1
        elif ip:
            state["ip_samples"] += 1
            self.counts["captured_ip_samples"] += 1
            self.events.append({"ip": hex(ip), "thread_generation": state["generation"],
                                "tid": state["tid"], "loop": loop, "rank": rank,
                                "offset_ns": before - self.started_ns,
                                "preceding_cycle_delta": delta, "cycle_window_ns": window_ns,
                                "suspend_call_to_resume_return_ns": hold_ns,
                                "previous_suspend_count": int(prior)})
        else:
            self.counts["zero_ip_contexts"] += 1

    def start(self):
        try:
            self._refresh()
            require(self.cache, "No owned thread handles with readable cycle counters")
            self.started_ns = time.perf_counter_ns()
            self.worker = threading.Thread(target=self._run, name="r18-cycle-sampler", daemon=False)
            self.worker.start()
        except BaseException:
            self._cleanup()
            raise

    def _run(self):
        previous_loop = 0
        try:
            while not self.stop_event.is_set():
                now = time.perf_counter_ns()
                if previous_loop:
                    gap = now - previous_loop
                    self.gap_count += 1
                    self.gap_sum_ns += gap
                    self.gap_max_ns = max(self.gap_max_ns, gap)
                previous_loop = now
                self.target.alive()
                if now - self.last_refresh_ns >= REFRESH_NS:
                    self._refresh()
                self.counts["loops"] += 1
                loop, busy = self.counts["loops"], []
                for state in list(self.cache.values()):
                    cycles = QWORD()
                    self.counts["cycle_queries"] += 1
                    if not self.api.k.QueryThreadCycleTime(state["handle"], c.byref(cycles)):
                        state["cycle_failures"] += 1
                        self.counts["cycle_query_failures"] += 1
                        continue
                    stamp = time.perf_counter_ns()
                    delta = int(cycles.value) - state["last_cycles"]
                    window_ns = stamp - state["last_read_ns"]
                    state["last_cycles"], state["last_read_ns"] = int(cycles.value), stamp
                    state["cycle_reads"] += 1
                    if delta < 0:
                        state["counter_decreases"] += 1
                        self.counts["cycle_counter_decreases"] += 1
                    elif delta > 0:
                        state["observed_cycle_delta"] += delta
                        state["busy_loops"] += 1
                        self.counts["busy_thread_deltas"] += 1
                        self.counts["observed_cycle_delta_all_threads"] += delta
                        busy.append((delta, state["tid"], state, window_ns))
                busy.sort(key=lambda item: (-item[0], item[1]))
                self.busy_histogram[len(busy)] += 1
                if not busy:
                    self.counts["zero_busy_loops"] += 1
                if len(busy) > SELECT_CAP:
                    self.counts["loops_over_selection_cap"] += 1
                for _, _, state, _ in busy[SELECT_CAP:]:
                    state["skipped_by_cap"] += 1
                    self.counts["busy_threads_skipped_by_cap"] += 1
                for rank, (delta, _, state, window_ns) in enumerate(busy[:SELECT_CAP], 1):
                    if len(self.events) >= self.maximum or self.stop_event.is_set():
                        break
                    state["selected"] += 1
                    self.counts["selected_threads"] += 1
                    self._capture(state, delta, window_ns, rank, loop)
                if len(self.events) >= self.maximum:
                    self.counts["sample_cap_reached"] = 1
                    break
                # Requested cadence only; no timeBeginPeriod or system timer changes.
                self.stop_event.wait(self.interval)
        except BaseException as error:
            self.errors.append(error_record(error))
            self.stop_event.set()
        finally:
            self._cleanup()
            self.ended_ns = time.perf_counter_ns()

    def _cleanup(self):
        for tid in list(self.cache):
            try:
                self._drop(tid)
            except BaseException as error:
                self.errors.append(error_record(error))
        self.counts["cached_handles_remaining"] = len(self.cache)

    def stop(self):
        self.stop_event.set()
        if self.worker is not None and self.worker.ident is not None:
            self.worker.join()  # Never close a handle while the capture thread owns it.
        else:
            self._cleanup()

    def check(self):
        require(not self.errors, "Sampler failed; partial evidence retained in report")

    def report(self, symbols):
        counts = Counter(int(event["ip"], 16) for event in self.events)
        total, resolved, target_count, target_unresolved = len(self.events), 0, 0, 0
        addresses, names = [], Counter()
        for ip, count in counts.most_common():
            item = symbols.resolve(ip)
            item.update(count=count, all_ip_sample_percent=100.0 * count / total)
            addresses.append(item)
            in_target = self.target.base <= ip < self.target.base + self.target.size
            target_count += count if in_target else 0
            if item["resolved"]:
                resolved += count
                names[item["symbol"]] += count
            elif in_target:
                target_unresolved += count
        pct = lambda n, d: None if not d else 100.0 * n / d
        return {"counters": dict(self.counts), "sample_count": total,
                "started_perf_ns": self.started_ns, "ended_perf_ns": self.ended_ns,
                "requested_interval_ms": self.interval * 1000,
                "handle_refresh_requested_ms": REFRESH_NS / 1_000_000,
                "selection_cap_per_loop": SELECT_CAP, "sample_cap": self.maximum,
                "loop_gap_mean_ns": self.gap_sum_ns / self.gap_count if self.gap_count else None,
                "loop_gap_max_ns": self.gap_max_ns, "refresh_gap_max_ns": self.refresh_gap_max_ns,
                "busy_thread_count_histogram": dict(self.busy_histogram),
                "threads": [{key: value for key, value in state.items() if key != "handle"}
                            for state in self.records],
                "pending_resume_generations": [s["generation"] for s in self.records if s["pending_resume"]],
                "raw_ip_events": self.events, "addresses": addresses,
                "symbols": [{"symbol": name, "count": count, "all_ip_sample_percent": pct(count, total)}
                            for name, count in names.most_common()],
                "resolved_samples": resolved, "unresolved_samples": total - resolved,
                "unresolved_all_ip_sample_percent": pct(total - resolved, total),
                "target_image_samples": target_count, "target_unresolved_samples": target_unresolved,
                "target_unresolved_percent_of_target_samples": pct(target_unresolved, target_count),
                "external_or_unmapped_samples": total - target_count,
                "external_or_unmapped_all_ip_sample_percent": pct(total - target_count, total),
                "errors": self.errors}


QUERY_CN = "SELECT COUNT(*) FROM fts_large_bench.docs WHERE MATCH(title,content) AGAINST('全文索引 分词器')"
QUERY_BENG = "SELECT COUNT(*) FROM fts_large_bench.docs WHERE MATCH(title_en,content_en) AGAINST('database performance audit')"


def identifier(name):
    require(re.fullmatch(r"[A-Za-z_][A-Za-z_0-9]{0,63}", name) is not None, "Invalid SQL identifier")
    return chr(96) + name + chr(96)


def one(cursor, sql, expected):
    cursor.execute(sql)
    value = cursor.fetchone()
    require(value == (expected,), "Expected diagnostic SQL result mismatch")
    return value[0]


def source_preflight(cursor):
    one(cursor, "SELECT COUNT(*) FROM fts_large_bench.docs", 20000)
    cursor.execute("SELECT COLUMN_NAME, COLLATION_NAME FROM information_schema.columns "
                   "WHERE TABLE_SCHEMA='fts_large_bench' AND TABLE_NAME='docs' ORDER BY ORDINAL_POSITION")
    columns = cursor.fetchall()
    require([row[0] for row in columns] == ["id", "category", "title", "content", "title_en", "content_en"],
            "Unexpected benchmark source columns")
    collations = {row[1] for row in columns[2:]}
    require(len(collations) == 1, "Source text columns must use one common collation")
    collation = next(iter(collations))
    require(isinstance(collation, str) and re.fullmatch(r"utf8mb4_[a-z0-9_]+", collation) is not None,
            "Expected a named utf8mb4 source collation")
    return {"rows": 20000, "text_collation": collation}


def prepare_build(cursor, name, source):
    require(re.fullmatch(r"fts_cycle_r18_[A-Za-z0-9_]+", name) is not None,
            "Build database must have the explicit fts_cycle_r18_ prefix")
    db = identifier(name)
    collation = identifier(source["text_collation"])
    cursor.execute("CREATE DATABASE " + db + " DEFAULT CHARACTER SET utf8mb4 COLLATE " + collation)
    table = db + ".docs"
    cursor.execute("CREATE TABLE " + table + " (id BIGINT AUTO_INCREMENT PRIMARY KEY, "
                   "category INT NOT NULL, title VARCHAR(256) NOT NULL, content TEXT NOT NULL, "
                   "title_en VARCHAR(256) NOT NULL, content_en TEXT NOT NULL) "
                   "DEFAULT CHARSET=utf8mb4 COLLATE " + collation)
    cursor.execute("INSERT INTO " + table + " (id,category,title,content,title_en,content_en) "
                   "SELECT id,category,title,content,title_en,content_en FROM fts_large_bench.docs ORDER BY id")
    one(cursor, "SELECT COUNT(*) FROM " + table, 20000)
    totals = "SELECT COUNT(*),SUM(OCTET_LENGTH(title)),SUM(OCTET_LENGTH(content))," \
             "SUM(OCTET_LENGTH(title_en)),SUM(OCTET_LENGTH(content_en)) FROM "
    cursor.execute(totals + "fts_large_bench.docs")
    original = cursor.fetchone()
    cursor.execute(totals + table)
    copied = cursor.fetchone()
    require(original == copied, "Copied source byte totals differ")
    comparisons = ["NOT(s.category <=> d.category)"]
    comparisons += ["NOT(CAST(s." + col + " AS BINARY) <=> CAST(d." + col + " AS BINARY))"
                    for col in ("title", "content", "title_en", "content_en")]
    one(cursor, "SELECT COUNT(*) FROM fts_large_bench.docs s LEFT JOIN " + table +
        " d ON s.id=d.id WHERE d.id IS NULL OR " + " OR ".join(comparisons), 0)
    return {"database": name, "retained_for_inspection": True,
            "source_and_copy_byte_totals": [int(value) if value is not None else None for value in original],
            "exact_mismatched_source_rows": 0}


def run_phase(name, function, target, symbols, args, report):
    target.alive()
    target.check_listener()
    sampler = CycleSampler(target, args.interval_ms, args.max_samples)
    phase = {"name": name, "status": "starting", "excluded_from_scoring": True}
    report["phases"].append(phase)
    begin = time.perf_counter_ns()
    try:
        sampler.start()
        phase["workload"] = function(sampler)
        sampler.check()
        phase["status"] = "complete"
    except BaseException as error:
        phase.update(status="failed", workload_error=error_record(error))
        raise
    finally:
        sampler.stop()
        phase["elapsed_with_sampling_sec"] = (time.perf_counter_ns() - begin) / 1_000_000_000
        phase["sampling"] = sampler.report(symbols)
        phase["minimum_requested_samples"] = args.min_samples
        phase["evidence_sample_target_met"] = len(sampler.events) >= args.min_samples
        if sampler.errors:
            phase["status"] = "failed"
    require(not sampler.errors and not phase["sampling"]["pending_resume_generations"],
            "Sampler cleanup/capture failure; diagnosis invalid")


def workloads(cursor, target, symbols, args, report):
    source = source_preflight(cursor)
    report["source"] = source
    if args.workload == "build":
        report["build_setup"] = prepare_build(cursor, args.diagnostic_database, source)
        table = identifier(args.diagnostic_database) + ".docs"
        builds = [("build_ik_all", "fti_all_ik(title,content) WITH PARSER ik"),
                  ("build_ik_content", "fti_content_ik(content) WITH PARSER ik"),
                  ("build_beng_en", "fti_en_beng(title_en,content_en) WITH PARSER beng")]
        for name, specification in builds:
            sql = "ALTER TABLE " + table + " ADD FULLTEXT INDEX " + specification
            def build(sampler, statement=sql):
                sampler.check()
                cursor.execute(statement)
                return {"sql": statement, "completed_alter_statements": 1}
            run_phase(name, build, target, symbols, args, report)
        cn = QUERY_CN.replace("fts_large_bench.docs", table)
        beng = QUERY_BENG.replace("fts_large_bench.docs", table)
        limit = "SELECT COUNT(*) FROM (SELECT id FROM " + table + \
                " WHERE MATCH(content) AGAINST('倒排索引 tokenizer') LIMIT 20) t"
        report["build_result_checks"] = {"query_cn": one(cursor, cn, 8001),
                                         "query_beng": one(cursor, beng, 11000),
                                         "query_limit": one(cursor, limit, 20)}
    else:
        sql, expected = (QUERY_CN, 8001) if args.workload == "query-cn" else (QUERY_BENG, 11000)
        for _ in range(args.warmup):
            one(cursor, sql, expected)
        progress = {"sql": sql, "expected_hits": expected, "last_observed_hits": None,
                    "warmups_completed": args.warmup, "rounds_requested": args.query_rounds,
                    "rounds_completed": 0}
        report["query_progress"] = progress
        def query(sampler):
            for _ in range(args.query_rounds):
                sampler.check()
                progress["last_observed_hits"] = one(cursor, sql, expected)
                progress["rounds_completed"] += 1
            return dict(progress)
        run_phase(args.workload, query, target, symbols, args, report)


def arguments():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("pid", type=int)
    parser.add_argument("workload", choices=("build", "query-cn", "query-beng"))
    parser.add_argument("--binary", required=True)
    parser.add_argument("--pdb", required=True)
    parser.add_argument("--dbghelp")
    parser.add_argument("--output", required=True)
    parser.add_argument("--user", default="root")
    parser.add_argument("--diagnostic-database")
    parser.add_argument("--query-rounds", type=int, default=8000)
    parser.add_argument("--warmup", type=int, default=30)
    parser.add_argument("--interval-ms", type=float, default=1.0)
    parser.add_argument("--max-samples", type=int, default=50000)
    parser.add_argument("--min-samples", type=int, default=1000)
    parser.add_argument("--sql-socket-timeout", type=int, default=120)
    args = parser.parse_args()
    require(0.25 <= args.interval_ms <= 100 and 1 <= args.query_rounds <= 1_000_000 and
            0 <= args.warmup <= 10000 and 1 <= args.min_samples <= args.max_samples <= 200000 and
            1 <= args.sql_socket_timeout <= 3600, "Invalid diagnostic bounds")
    require(args.workload != "build" or args.diagnostic_database is not None,
            "Build requires an explicit new --diagnostic-database")
    return args


def main():
    args = arguments()
    output = Path(args.output)
    require(output.is_absolute() and output.suffix.lower() == ".json" and output.parent.is_dir(),
            "Output must be an absolute new .json path with an existing parent")
    # Reserve exclusively before any target interaction; never overwrite previous evidence.
    with output.open("x", encoding="utf-8") as destination:
        report = {"created_utc": datetime.now(timezone.utc).isoformat(), "status": "preflight",
                  "purpose": "Intrusive cycle-selected RIP diagnosis; no performance/CPU attribution",
                  "excluded_from_scoring": True, "pid": args.pid, "workload": args.workload,
                  "endpoint": {"host": "127.0.0.1", "port": PORT}, "phases": [],
                  "cleanup_errors": []}
        api = target = symbols = None
        exit_code = 1
        try:
            binary, pdb = absolute_file(args.binary, ".exe"), absolute_file(args.pdb, ".pdb")
            api = WinAPI()
            target = Target(api, args.pid, binary)
            if args.dbghelp:
                dll = absolute_file(args.dbghelp, ".dll")
            else:
                buffer = c.create_unicode_buffer(32768)
                length = api.k.GetSystemDirectoryW(buffer, len(buffer))
                require(0 < length < len(buffer), "Cannot locate system DbgHelp")
                dll = absolute_file(str(Path(buffer.value) / "dbghelp.dll"), ".dll")
            symbols = Symbols(target, pdb, dll)
            report["identity"] = {"binary": str(binary), "binary_sha256": target.binary_hash,
                                  "process_creation_filetime": target.creation,
                                  "loaded_image_base": hex(target.base), "loaded_image_size": target.size,
                                  "disk_pe": target.disk_identity, "loaded_pe": target.loaded_identity,
                                  "symbols": symbols.metadata}
            import pymysql  # Existing environment only; no path injection or package installation.
            target.alive()
            target.check_listener()
            with pymysql.connect(host="127.0.0.1", port=PORT, user=args.user,
                                 password=os.environ.get("SEEKDB_TEST_PASSWORD", ""),
                                 charset="utf8mb4", autocommit=True, connect_timeout=5,
                                 read_timeout=args.sql_socket_timeout,
                                 write_timeout=args.sql_socket_timeout) as connection:
                target.alive()
                target.check_listener()
                with connection.cursor() as cursor:
                    cursor.execute("SET ob_query_timeout=100000000000")
                    cursor.execute("SET ob_trx_timeout=100000000000")
                    workloads(cursor, target, symbols, args, report)
            target.alive()
            require(sha256(binary) == target.binary_hash and sha256(pdb) == symbols.metadata["pdb_sha256"],
                    "Executable or PDB changed during collection")
            adequate = all(phase["evidence_sample_target_met"] for phase in report["phases"])
            report["status"] = "complete" if adequate else "insufficient_samples"
            exit_code = 0 if adequate else 2
        except BaseException as error:
            report.update(status="interrupted" if isinstance(error, KeyboardInterrupt) else "failed",
                          error=error_record(error))
            exit_code = 130 if isinstance(error, KeyboardInterrupt) else 1
        finally:
            for resource in (symbols, target):
                if resource is not None:
                    try:
                        resource.close()
                    except BaseException as error:
                        report["cleanup_errors"].append(error_record(error))
            if api is not None:
                report["handle_accounting"] = dict(api.handles)
                opened = sum(api.handles[name] for name in
                             ("process_opened", "thread_opened", "snapshots_opened"))
                report["handle_accounting"]["opened_total"] = opened
                report["handle_accounting"]["unclosed_total"] = opened - api.handles["closed"]
                if opened != api.handles["closed"] or api.handles["close_failures"]:
                    report["cleanup_errors"].append({"type": "HandleAccountingFailure"})
            if report["cleanup_errors"]:
                report["status"], exit_code = "failed_cleanup", 1
            report["finished_utc"] = datetime.now(timezone.utc).isoformat()
            json.dump(report, destination, ensure_ascii=False, indent=2)
            destination.write("\n")
            destination.flush()
        print(json.dumps({"report": str(output.resolve()), "status": report["status"],
                          "sample_counts": {p["name"]: p.get("sampling", {}).get("sample_count", 0)
                                            for p in report["phases"]}}, ensure_ascii=False))
        return exit_code


if __name__ == "__main__":
    sys.exit(main())
