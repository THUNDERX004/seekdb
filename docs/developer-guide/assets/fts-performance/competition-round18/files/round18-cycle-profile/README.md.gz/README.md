# Round 18: cycle-selected Windows IP diagnostic

Frozen sidecar proposal, 2026-11-04. Files: README.md and sample-competition.py only. The author has not executed, imported, compiled or run the script, connected to SQL, built seekdb, changed system settings or used Git. Parent review and serial execution are required. No scheduler or production source change is included.

## Scope

The script targets one explicitly supplied PID and absolute seekdb.exe path. It verifies the held process handle, executable path, native AMD64 architecture, loaded image identity, file SHA-256 and ownership of the local IPv4 SQL listener on 127.0.0.1:2891. It refuses a target that owns a listener on 2881. It connects only to 127.0.0.1:2891, never starts/stops servers, issues KILL, changes privileges or enables ETW/debug sessions/system timer settings. A thread snapshot enumerates IDs globally, but handles are opened only after filtering the supplied PID and ownership is checked again on every newly opened handle.

Thread handles are cached and discovery refreshed every requested 100ms. Every sampling loop queries QueryThreadCycleTime on cached handles, computes each thread's delta since its preceding successful read, and selects at most the two largest positive deltas. Every thread baseline advances even when that thread loses selection. This avoids the old sampler's coarse user_time/system_time selection. New threads get a baseline, not a fabricated positive delta. TID reuse is distinguished by thread creation FILETIME and held-handle lifetime.

Only a selected thread is suspended, one at a time. Its aligned AMD64 CONTEXT is preallocated. The suspended region reads the context/RIP and always calls ResumeThread in finally; symbol lookup, SQL, hashing, output and sleeps occur outside that region. One successful resume reverses this sampler's increment only; it never drains another owner's suspend count. Pre-suspended threads are immediately restored and excluded. Failures, resume retries, hold durations and incomplete cleanup are explicit. This is best-effort intrusive diagnosis: OS API failure or externally terminating Python can defeat cleanup; a requested sampling interval is not a hard suspension-time guarantee. Do not force-terminate the sampler.

The exact executable RSDS GUID/age must match its loaded image and the PDB actually accepted by DbgHelp. The required absolute --pdb path is checked against LoadedPdbName, GUID, age and mismatch flags with exact-symbol options. Symbols are loaded before SQL and resolved after sampling, on the main thread only. No symbol server or ambient symbol path is used. A local compatible --dbghelp DLL may be supplied; an incompatible system DbgHelp fails preflight rather than accepting exports or mismatched symbols. Only the target EXE is symbolized; external/unmapped IPs stay unresolved and remain in all-sample percentages.

## Parent invocation

Use the existing 64-bit Windows Python environment containing PyMySQL; no psutil or package installation is required. Parent starts and owns the dedicated experiment server and loads the unchanged official 20,000-document data beforehand. Run serially after all scored/native work has stopped. Supply the real experiment PID and matching Release or RelWithDebInfo EXE/PDB; placeholders below are not values to copy unchanged. The output path must be absolute, end in .json, have an existing parent and not already exist. Password is read only from SEEKDB_TEST_PASSWORD (empty by default), never from the workspace secret file or command line.

    .\.venv\Scripts\python.exe .\setup\fts\round18-cycle-profile\sample-competition.py <PID> query-cn --binary D:\...\seekdb.exe --pdb D:\...\seekdb.pdb --output C:\...\r18-cn.json
    .\.venv\Scripts\python.exe .\setup\fts\round18-cycle-profile\sample-competition.py <PID> query-beng --binary D:\...\seekdb.exe --pdb D:\...\seekdb.pdb --output C:\...\r18-beng.json
    .\.venv\Scripts\python.exe .\setup\fts\round18-cycle-profile\sample-competition.py <PID> build --binary D:\...\seekdb.exe --pdb D:\...\seekdb.pdb --diagnostic-database fts_cycle_r18_control_a --output C:\...\r18-build.json

Optional --dbghelp takes an absolute installed DLL path. Query defaults: 8,000 measured diagnostic repetitions and 30 warmups. Sampler defaults: requested 1ms loop interval, fixed 100ms handle refresh, two selected threads per loop, maximum 50,000 captured IPs per phase, minimum useful evidence flag at 1,000 IPs per phase. The exact evidence threshold option is --min-samples. Caps/shortfalls are reported, never filled or extrapolated. Parent may increase --query-rounds or --max-samples; no sample target guarantees enough evidence. The minimum is an evidence-quality exit condition, not a performance score.

Parent reports the rebuilt restored control SHA-256 as ddd423ff4e7b7da6b80ac9cb034dbed8e7c76be24eb41f7b2764c7741a72896a. This is supplied provenance, not independently inspected here. The script computes the absolute target file's actual SHA-256 for every collection; parent must compare it with the intended experiment identity.

## SQL effects and result checks

Query modes read fts_large_bench.docs with the official query text, require exactly 20,000 source rows, assert every full COUNT result (Chinese 8,001; BENG 11,000), and record the actual number completed. This preserves the old Python-client diagnostic shape, not official benchmark timing equivalence.

Build mode requires an explicitly named, nonexisting database matching fts_cycle_r18_ followed by letters/digits/underscores. It creates only that database and a raw six-column docs table, copies all 20,000 rows including IDs from the existing official table, then separately samples the three ordinary ALTER ADD FULLTEXT operations in official order: IK title/content, IK content, BENG title_en/content_en. Source text collations are required to agree and are copied to the diagnostic table. It verifies copied row count, per-column byte totals and an exact binary/null-safe source-versus-copy comparison before sampling. After builds it asserts the CN/BENG/limited-content expected hits. Setup/copy/checks/warmups are outside sampling; each build phase has its own thread baselines. The database is deliberately left for parent inspection even on failure. No automatic DROP or change to fts_large_bench is performed.

The script also changes ob_query_timeout and ob_trx_timeout on its own connection only. It does not cancel an in-flight server DDL after a sampler failure; it reports failure once the SQL call returns or its socket timeout expires. Parent must inspect the retained diagnostic database after interruption. Closing the client is not a claim that server-side DDL was cancelled.

## Report and interpretation

JSON includes absolute binary/PDB/DLL paths and SHA-256 hashes; PE/loaded/PDB identities; process creation identity; exact workload and expected/observed results; actual raw RIP events (thread generation, loop, prior cycle delta, rank, context suspension duration); per-thread first/last cycles and observed delta totals; busy/zero-busy/selection/cap/error/refresh/handle-close counters; timing gaps; all captured IP/symbol counts with all-sample percentages; separate target-image and external/unmapped unresolved counts and percentages; and partial failure status.

RIP samples are instantaneous user-context locations after a positive preceding cycle delta. They are neither stacks nor proof that those cycles were spent at that RIP. QueryThreadCycleTime includes kernel and user cycles; the script does not convert cycles to seconds, CPU utilization or per-symbol CPU shares. Top-two selection, omitted short-lived threads between refreshes, query client pacing, background tasks, unresolved symbols and suspension perturbation bias the sample. A blocked-thread context can still be captured after recent activity. All diagnostic elapsed times include perturbation and are excluded from official scores. No optimization gain or better sample count than the historical 141 is claimed before parent execution.

## API grounding and review gates

Official reference pages used for this staged design:

- https://learn.microsoft.com/en-us/windows/win32/api/realtimeapiset/nf-realtimeapiset-querythreadcycletime
- https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-getthreadcontext
- https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-resumethread
- https://learn.microsoft.com/en-us/windows/win32/api/winnt/ns-winnt-context
- https://learn.microsoft.com/en-us/windows/win32/api/dbghelp/nf-dbghelp-symgetmoduleinfow64
- https://learn.microsoft.com/en-us/windows/win32/api/dbghelp/ns-dbghelp-imagehlp_modulew64

Parent should inspect ctypes layouts/calling signatures, exact PDB preflight, PID/listener ownership, TID reuse, all success/error/interrupt handle paths, suspend/resume pairing, sample cap and unresolved denominators before execution. Then check one short serial query diagnostic before a longer collection. This package supplies code for that review, not runtime validation or a measured profile.
