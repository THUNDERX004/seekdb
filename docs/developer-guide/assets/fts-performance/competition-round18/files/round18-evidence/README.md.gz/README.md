# Round18 offline archive

Parent decision: RETAIN bounded count-union incremental checkpoint. Three full
pairs and both focused SQL outcomes are complete. This tool only reads selected
local evidence and writes an exact-byte package; no workload helper is executed.

    python package.py --output-dir archive
    python package.py --output-dir archive --execute
    python -B verify_package.py --package-dir archive --report verification.json
    python -B publish_docs.py --package-dir archive --execute

Default is inventory only. Packing requires final disposition, three complete
pairs, all regression receipts and frozen source pins. Use a NEW auxiliary output
directory; missing COMPLETE.json means incomplete and is never overwritten.
Publication is limited to new round18 assets, two bilingual main report sections
and one FTS README entry, after exact package and document-preimage verification.

Raw/log/source files are deterministic-header gzip byte streams: no decoding,
newline conversion or metadata repair. Raw and packed counts/SHA256 plus full
roundtrip/source verification are required. Build1 invalid JSON and its Decimal
traceback remain failed raw evidence. Build2 success is separate. Current helper
snapshots do not establish the exact failed historical source revision.

Six full reports, all a1 regressions, two accounting runs, proposal originals/
candidates/patch/static report, candidate build log, reviewed SQL test, actual
auxiliary harness snapshots and all five profile attempts are retained. Earlier
restoration build logs are referenced in round17 rather than duplicated.
Unfinished stringdiff, binaries/PDB/DLL/LIB/OBJ, runtime/data, caches and secrets
are excluded. Bounds fail rather than truncate. No cumulative/formal score is
computed; every negative and SQL/sampling limitation remains explicit.
