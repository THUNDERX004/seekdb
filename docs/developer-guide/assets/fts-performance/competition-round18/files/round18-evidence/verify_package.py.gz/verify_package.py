"""Read-only round18 gzip/raw/source hash verifier; no workloads or Git."""
import argparse
import gzip
import hashlib
import json
from pathlib import Path
from package import HERE, FTS, REPO, TEST, CHUNK, MAX_FILE, require, sha, read


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--package-dir", required=True, type=Path)
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    directory = args.package_dir.resolve()
    manifest = read(directory / "manifest.json")
    complete = read(directory / "COMPLETE.json")
    require(complete["status"] == "COMPLETE" and complete["manifest_sha256"] == sha(directory / "manifest.json"),
            "Completion identity mismatch")
    require(manifest["completed_pairs"] == 3 and manifest["decision"] == "RETAIN (parent)", "Wrong decision/pair count")
    paths = set()
    sources = set()
    for item in manifest["files"]:
        relative = item["path"]
        require(relative not in paths and item["source"] not in sources, "Duplicate manifest entry")
        paths.add(relative)
        sources.add(item["source"])
        target = (directory / relative).resolve()
        require(target.is_relative_to(directory), "Unsafe packed path")
        if item["source"].startswith("checkout/"):
            require(item["source"] == "checkout/" + TEST, "Unauthorized checkout source")
            source = REPO / TEST
        else:
            source = (FTS / item["source"]).resolve()
            require(source.is_relative_to(FTS), "Unsafe auxiliary source")
        require(sha(target) == item["packed_sha256"] and target.stat().st_size == item["packed_bytes"], "Packed identity failed")
        digest = hashlib.sha256()
        size = 0
        with gzip.open(target, "rb") as stream:
            for block in iter(lambda: stream.read(CHUNK), b""):
                size += len(block)
                require(size <= MAX_FILE, "Unpacked evidence exceeds bound")
                digest.update(block)
        require(size == item["raw_bytes"] and digest.hexdigest() == item["raw_sha256"], "Raw round-trip failed")
        require(sha(source) == item["raw_sha256"] and source.stat().st_size == size, "Original input changed")
    actual = {p.relative_to(directory).as_posix() for p in directory.rglob("*") if p.is_file()}
    require(actual == paths | {"manifest.json", "COMPLETE.json"}, "Missing/unlisted archive files")
    require(len(paths) == complete["file_count"], "File count mismatch")
    result = {"status": "PASS", "kind": "offline exact-byte archival verification only", "file_count": len(paths),
              "manifest_sha256": sha(directory / "manifest.json"), "packed_raw_and_source_hashes": "ALL MATCH",
              "build_sql_native_performance_git": "NOT RUN by archival sidecar"}
    if args.report:
        report = args.report.resolve()
        require(report.parent == HERE and not report.exists(), "Use a NEW auxiliary verification report")
        report.write_bytes((json.dumps(result, indent=2) + "\n").encode())
    print(json.dumps(result))


if __name__ == "__main__":
    main()
