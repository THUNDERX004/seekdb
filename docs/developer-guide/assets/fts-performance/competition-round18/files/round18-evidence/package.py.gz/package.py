"""Offline exact-byte round18 archive; default inventory only, --execute packs.

Never imports/executes workload helpers or runs seekdb, SQL, builds or Git.
Only writes a NEW direct child of this auxiliary directory.
"""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
FTS = HERE.parent
REPO = Path(r"D:\Projects\OceanBase\seekdb")
CHUNK = 1024 * 1024
MAX_FILE = 64 * CHUNK
MAX_TOTAL = 256 * CHUNK
ALLOWED = {".py", ".ps1", ".md", ".json", ".txt", ".log", ".patch", ".h", ".cpp"}
FORBIDDEN = {".secrets", ".git", "__pycache__", "tmp", "temp", "runtime", "data", "logs", "log"}
TEST = "unittest/storage/fts/test_count_union_accounting.py"
VARIANTS = ("control", "candidate")
RUNS = tuple(f"r18-count-{v}-a{n}" for n in range(1, 4) for v in VARIANTS)
ACCOUNTING = tuple(f"r18-count-accounting-{v}-1" for v in VARIANTS)
PROFILES = ("r18-cycle-preflight-cn1", "r18-cycle-control-cn1", "r18-cycle-control-beng1",
            "r18-cycle-control-build1", "r18-cycle-control-build2")
REGRESSIONS = ("query-materialization", "ranked", "keytypes", "test_hot_path.py",
               "test_tokenize_config.py", "test_collation.py", "test_match_batches.py",
               "test_map_concurrency.py", "test_stopword_concurrency.py", "test_dictionary_prefixes.py")


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def sha(path):
    result = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(CHUNK), b""):
            result.update(block)
    return result.hexdigest()


def read(path):
    require(path.stat().st_size <= MAX_FILE, f"Oversized metadata: {path}")
    return json.loads(path.read_bytes().decode("utf-8-sig"))


def encoded(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def collect():
    selected = {}
    def add(path, key=None):
        path = path.resolve()
        is_aux = path.is_relative_to(FTS)
        require(is_aux or path == (REPO / TEST).resolve(), f"Not an authorized input: {path}")
        require(path.is_file() and path.suffix.lower() in ALLOWED, f"Missing/disallowed artifact: {path}")
        rel = path.relative_to(FTS).as_posix() if is_aux else "checkout/" + TEST
        require(not any(p.lower() in FORBIDDEN for p in Path(rel).parts), f"Excluded directory: {rel}")
        require("round18-stringdiff" not in rel, "Unfinished stringdiff is excluded")
        require(path.stat().st_size <= MAX_FILE, f"Oversized artifact; no truncation: {rel}")
        selected[key or rel] = path
        return path

    comparison = read(add(HERE / "count-comparison-3pair.json"))
    disposition = read(add(HERE / "disposition.json"))
    source = read(add(HERE / "source.json"))
    require(comparison["completed_pairs"] == disposition["completed_pairs"] == 3,
            "Exactly three complete pairs required; never package partial runs")
    require(disposition["decision"] == "RETAIN" and disposition["parent_serial_gate_complete"] is True,
            "Final parent decision and serial completion gate required")
    require(comparison["parameters"] == dict(rows=20000, batch=500, rounds=3000, query_rounds=200,
            samples=3, warmup=30, skip_load=0), "Fixed official parameters changed")
    require(comparison["hits"] == dict(query_cn_hits=8001, query_beng_hits=11000,
            query_mixed_hits=7332, query_limit_hits=20), "Reported hit cross-check differs")
    previous = REPO / "docs/developer-guide/assets/fts-performance/competition-round17"
    for reference in source["round17_build_references"]:
        require(sha(previous / "manifest.json") == reference["previous_manifest_sha256"], "Round17 manifest changed")
        require(sha(previous / reference["previous_round17_archive"]) == reference["packed_sha256"],
                "Referenced round17 packed build log changed")
        require(sha(FTS / reference["source"]) == reference["raw_sha256"], "Referenced raw build log changed")
    require(sha(HERE / "count-comparison-3pair.json") == disposition["comparison_sha256"],
            "Final comparison changed")
    for relative, pin in comparison["input_hashes"].items():
        path = add(FTS / relative)
        require(sha(path) == pin["sha256"] and path.stat().st_size == pin["bytes"],
                f"Comparison input changed: {relative}")
    for label in RUNS:
        record = read(add(FTS / (label + "-experiment.json")))
        variant = "candidate" if "-candidate-" in label else "control"
        require(record["label"] == label and record["binary_sha256"] == comparison["pins"][variant],
                f"Wrong run identity: {label}")
        require(record["log_level"] == "WARN" and record["affinity_mask"] == record["affinity_mask_verified"] == 15,
                f"Wrong log level/affinity: {label}")
        require(all(action["exit_code"] == 0 for action in record["actions"]), f"Incomplete/failed run: {label}")
        for action in ("benchmark", "input-validation"):
            require(sum(a["action"] == action for a in record["actions"]) == 1, f"Missing action: {label}/{action}")
        for suffix in ("experiment.json", "report.txt", "benchmark.log", "input-validation.log", "server.log"):
            add(FTS / f"{label}-{suffix}")
        for path in sorted(FTS.glob(label + "-*")):
            if path.is_file():
                add(path)
    candidate = read(FTS / "r18-count-candidate-a1-experiment.json")
    for name in REGRESSIONS:
        require(sum(a["action"] == name and a["exit_code"] == 0 for a in candidate["actions"]) == 1,
                f"Missing candidate-a1 regression: {name}")
        add(FTS / f"r18-count-candidate-a1-{name}.log")
    for label in ACCOUNTING:
        record = read(add(FTS / (label + "-experiment.json")))
        variant = "candidate" if "-candidate-" in label else "control"
        require(record["label"] == label and record["binary_sha256"] == comparison["pins"][variant],
                f"Wrong accounting identity: {label}")
        require(len(record["actions"]) == 1 and record["actions"][0]["action"] == "count-union-accounting"
                and record["actions"][0]["exit_code"] == 0, f"Accounting not complete: {label}")
        output = add(FTS / (label + "-count-union-accounting.log"))
        require(b"96 query/batch groups; 36 prepared count executions; 709 exact result comparisons" in output.read_bytes(),
                f"Accounting result summary missing: {label}")
        for path in sorted(FTS.glob(label + "-*")):
            if path.is_file():
                add(path)

    proposal = FTS / "round18-count-union-proposal"
    pins = read(add(proposal / "manifest.json"))
    require(sha(add(proposal / "source.patch")) == pins["patch_sha256"], "Proposal patch changed")
    for pin in pins["files"]:
        for side in ("original", "candidate"):
            path = add(proposal / side / pin["path"])
            require(sha(path) == pin[side + "_sha256"] and path.stat().st_size == pin[side + "_bytes"],
                    f"Proposal identity changed: {side}/{pin['path']}")
        live = REPO / pin["path"]
        require(sha(live) == pin["candidate_sha256"], f"Retained live candidate changed: {pin['path']}")
    for path in sorted(proposal.rglob("*")):
        if path.is_file():
            add(path)
    test = add(REPO / TEST)
    require(sha(test) == source["focused_test"]["sha256"], "Focused SQL test changed")
    add(FTS / "round18-count-candidate-build.log")
    for name in ("experiment-competition.py", "mysql_client.py", "validate-competition.py", "build-competition.ps1"):
        add(FTS / name)
    for name in ("README.md", "sample-competition.py"):
        add(FTS / "round18-cycle-profile" / name)

    # build1 is intentionally invalid/truncated JSON. Preserve raw bytes and its
    # traceback; never repair it, treat it as a successful profile, or JSON-load it.
    for label in PROFILES:
        for path in sorted(FTS.glob(label + "-*")):
            if path.is_file():
                add(path)
        action = "cycle-build" if "build" in label else "cycle-query-beng" if "beng" in label else "cycle-query-cn"
        record = read(add(FTS / (label + "-experiment.json")))
        require(record["label"] == label, f"Profile label mismatch: {label}")
        expected_exit = 1 if label.endswith("build1") else 0
        require(len(record["actions"]) == 1 and record["actions"][0]["action"] == action
                and record["actions"][0]["exit_code"] == expected_exit, f"Wrong profile receipt: {label}")
        raw = add(FTS / f"{label}-{action}.json")
        log = add(FTS / f"{label}-{action}.log")
        add(FTS / f"{label}-server.log")
        if expected_exit:
            try:
                read(raw)
            except json.JSONDecodeError:
                pass
            else:
                raise RuntimeError("build1 partial JSON was unexpectedly replaced/repaired")
            require(b"TypeError: Object of type Decimal is not JSON serializable" in log.read_bytes(),
                    "Original build1 serialization failure traceback missing")
        else:
            report = read(raw)
            require(report["status"] == "complete" and report["excluded_from_scoring"] is True,
                    f"Profile not complete/unscored: {label}")
    for name in ("package.py", "verify_package.py", "publish_docs.py", "README.md", "profile-notes.json",
                 "report.en.md", "report.zh-CN.md", "test-readme-entry.md", "publication-plan.json",
                 "summarize-count.py", "count-comparison-1pair.json", "count-comparison-2pair.json"):
        add(HERE / name)
    for operation in read(HERE / "publication-plan.json")["operations"]:
        staged = add(HERE / operation["staged_file"])
        require(sha(staged) == operation["staged_sha256"], "Staged documentation changed")
    for pin in source["frozen_auxiliary_inputs"]:
        path = add(FTS / pin["source"])
        require(sha(path) == pin["sha256"] and path.stat().st_size == pin["bytes"], f"Frozen source changed: {path}")
    require(sum(p.stat().st_size for p in selected.values()) <= MAX_TOTAL, "Evidence exceeds 256 MiB")
    return selected


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", required=True, type=Path, help="NEW direct auxiliary child")
    parser.add_argument("--execute", action="store_true", help="Pack completed evidence; otherwise inventory only")
    args = parser.parse_args()
    destination = args.output_dir.resolve()
    require(destination.parent == HERE and not destination.exists(), "Use a NEW direct child of round18-evidence")
    selected = collect()
    pins = {name: {"raw_bytes": path.stat().st_size, "raw_sha256": sha(path)} for name, path in selected.items()}
    if not args.execute:
        print(json.dumps({"mode": "PLAN ONLY; no package written", "file_count": len(selected),
                          "raw_bytes": sum(p["raw_bytes"] for p in pins.values()), "destination": str(destination)}))
        return
    destination.mkdir()
    entries = []
    # Absence of COMPLETE.json means a failed/incomplete package; never overwrite it.
    for name, source in sorted(selected.items()):
        relative = "files/" + name + ".gz"
        target = destination / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        digest = hashlib.sha256()
        size = 0
        with source.open("rb") as raw, target.open("xb") as packed:
            with gzip.GzipFile(filename="", mode="wb", fileobj=packed, compresslevel=9, mtime=0) as out:
                for block in iter(lambda: raw.read(CHUNK), b""):
                    digest.update(block)
                    size += len(block)
                    require(size <= MAX_FILE, f"Source grew beyond bound: {name}")
                    out.write(block)
        require(size == pins[name]["raw_bytes"] and digest.hexdigest() == pins[name]["raw_sha256"],
                f"Source changed during packing: {name}")
        entries.append({"source": name, "path": relative, **pins[name],
                        "packed_bytes": target.stat().st_size, "packed_sha256": sha(target)})
    for name, path in selected.items():
        require(sha(path) == pins[name]["raw_sha256"] and path.stat().st_size == pins[name]["raw_bytes"],
                f"Input changed before completion: {name}")
    manifest = {"schema_version": 1, "created_utc": datetime.now(timezone.utc).isoformat(),
                "experiment": "round18 bounded count-union incremental checkpoint", "completed_pairs": 3,
                "decision": "RETAIN (parent)", "source_root": str(FTS), "checkout_root": str(REPO),
                "encoding": "Exact raw byte streams in deterministic-header gzip; no newline conversion or JSON rewriting",
                "comparison": "Archived verbatim, not recomputed by packager",
                "formal_result": "No new platform result; prior user-supplied result only; no cumulative/full-marks claim",
                "limits": "SQL does not establish internal capacities/counters/error injection; diagnostic IP samples are not CPU shares",
                "references_not_duplicated": read(HERE / "source.json")["round17_build_references"],
                "files": entries}
    (destination / "manifest.json").write_bytes(encoded(manifest))
    (destination / "COMPLETE.json").write_bytes(encoded({"status": "COMPLETE", "file_count": len(entries),
                                                        "manifest_sha256": sha(destination / "manifest.json")}))
    print(json.dumps({"status": "PACKED; run offline verifier", "file_count": len(entries), "destination": str(destination)}))


if __name__ == "__main__":
    try:
        main()
    except (RuntimeError, OSError, ValueError, KeyError) as error:
        print("ERROR:", error, file=sys.stderr)
        sys.exit(1)
