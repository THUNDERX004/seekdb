"""Offline matched complete pairs. Output is not a formal performance score."""
import argparse
import hashlib
import json
from pathlib import Path
from statistics import mean

CLASSES = dict(build=['build_ik_all_sec', 'build_ik_content_sec', 'build_beng_en_sec'],
               tokenize=['tokenize_ik_avg_ms', 'tokenize_beng_avg_ms'],
               query=['query_cn_avg_ms', 'query_beng_avg_ms', 'query_mixed_avg_ms', 'query_limit_avg_ms'])
PARAMS = dict(rows=20000, batch=500, rounds=3000, query_rounds=200, samples=3, warmup=30, skip_load=0)
HITS = dict(query_cn_hits=8001, query_beng_hits=11000, query_mixed_hits=7332, query_limit_hits=20)
HERE = Path(__file__).resolve().parent
FTS = HERE.parent

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--pairs', type=int, required=True)
    args = parser.parse_args()
    assert 1 <= args.pairs <= 3
    inputs, pins, records = {}, {}, {}
    reports = dict(control=[], candidate=[])
    def read(path):
        raw = path.read_bytes()
        inputs[path.relative_to(FTS).as_posix()] = dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
        return raw
    for number in range(1, args.pairs + 1):
        for variant in ('control', 'candidate'):
            label = f'r18-count-{variant}-a{number}'
            record = json.loads(read(FTS / (label + '-experiment.json')))
            assert record['label'] == label and record['log_level'] == 'WARN'
            assert record['affinity_mask'] == record['affinity_mask_verified'] == 15
            pins.setdefault(variant, record['binary_sha256'])
            assert pins[variant] == record['binary_sha256']
            assert all(a['exit_code'] == 0 for a in record['actions'])
            assert all(sum(a['action'] == name for a in record['actions']) == 1
                       for name in ('benchmark', 'input-validation'))
            path = FTS / (label + '-report.txt')
            assert Path(record['report']).resolve() == path.resolve()
            raw = read(path).decode('utf-8-sig')
            assert raw.count('FTS Large Benchmark Report') == 1
            fields = dict(line.split(':', 1) for line in raw.splitlines() if ':' in line)
            assert fields['label'].strip() == label
            values = {k: float(fields[k]) for k in [*PARAMS, *HITS, *sum(CLASSES.values(), [])]}
            assert all(values[k] == expected for k, expected in {**PARAMS, **HITS}.items())
            assert all(values[k] > 0 for k in sum(CLASSES.values(), []))
            reports[variant].append(values)
            records[label] = record
    assert pins['control'] == 'ddd423ff4e7b7da6b80ac9cb034dbed8e7c76be24eb41f7b2764c7741a72896a'
    metrics, reductions = [], {}
    for category, names in CLASSES.items():
        rates = []
        for name in names:
            c, n = [mean(x[name] for x in reports[v]) for v in ('control', 'candidate')]
            rate = (c - n) / c
            metrics.append(dict(metric=name, control_mean=c, candidate_mean=n, reduction=rate))
            rates.append(rate)
        reductions[category] = mean(rates)
    pairs = []
    for i in range(args.pairs):
        categories = {category: mean((reports['control'][i][k] - reports['candidate'][i][k]) /
                                    reports['control'][i][k] for k in names)
                      for category, names in CLASSES.items()}
        pairs.append(dict(pair=i + 1, class_reductions=categories, overall_reduction=mean(categories.values())))
    result = dict(experiment='round18-count-union', completed_pairs=args.pairs,
                  method='Ratio of all per-metric run means, category arithmetic means, equal category mean; all negatives retained; no SELECT1 subtraction or sample selection.',
                  official_baseline='5bce9e06d1281347ad61344e4b01fab9158c58a2',
                  parameters=PARAMS, hits=HITS, pins=pins, metrics=metrics,
                  class_reductions=reductions, overall_reduction=mean(reductions.values()),
                  pairs=pairs, metadata=records, input_hashes=inputs,
                  formal_score='No new formal platform result; 50/50 not established')
    output = HERE / f'count-comparison-{args.pairs}pair.json'
    encoded = (json.dumps(result, indent=2) + chr(10)).encode()
    if output.exists():
        assert output.read_bytes() == encoded, 'Refusing to overwrite different derived evidence'
    else:
        output.write_bytes(encoded)
    print(json.dumps({k: result[k] for k in ('completed_pairs', 'pins', 'class_reductions', 'overall_reduction', 'pairs')}, indent=2))

if __name__ == '__main__':
    main()
