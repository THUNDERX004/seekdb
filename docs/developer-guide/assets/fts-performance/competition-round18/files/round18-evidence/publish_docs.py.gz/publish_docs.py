"""Publish only verified round18 assets and three preimage-pinned docs. No Git."""
import argparse
import gzip
import hashlib
import json
from pathlib import Path
from package import HERE, FTS, REPO, CHUNK, MAX_FILE, require, sha, read, encoded

DOCS = {"docs/developer-guide/en/fts-performance.md", "docs/developer-guide/zh-CN/fts-performance.md",
        "unittest/storage/fts/README.md"}
ASSET = "docs/developer-guide/assets/fts-performance/competition-round18"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--package-dir", required=True, type=Path)
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args()
    package = args.package_dir.resolve()
    require(package.parent == HERE, "Only a local round18 package may be published")
    plan = read(HERE / "publication-plan.json")
    require(plan["repository"] == str(REPO) and plan["asset_directory"] == ASSET, "Wrong repository/asset scope")
    require({x["path"] for x in plan["operations"]} == DOCS and len(plan["operations"]) == 3,
            "Exactly the approved three document edits are allowed")
    manifest = read(package / "manifest.json")
    complete = read(package / "COMPLETE.json")
    verification = read(HERE / "verification.json")
    manifest_sha = sha(package / "manifest.json")
    require(complete["status"] == "COMPLETE" and verification["status"] == "PASS"
            and complete["manifest_sha256"] == verification["manifest_sha256"] == manifest_sha,
            "Offline verification receipt does not match complete package")
    expected = {"manifest.json", "COMPLETE.json"}
    for item in manifest["files"]:
        require(item["path"] not in expected, "Duplicate archive entry")
        expected.add(item["path"])
        packed = (package / item["path"]).resolve()
        require(packed.is_relative_to(package), "Unsafe archive path")
        require(sha(packed) == item["packed_sha256"] and packed.stat().st_size == item["packed_bytes"],
                "Packed input changed after verification")
        digest = hashlib.sha256()
        size = 0
        with gzip.open(packed, "rb") as stream:
            for block in iter(lambda: stream.read(CHUNK), b""):
                size += len(block)
                require(size <= MAX_FILE, "Raw bound exceeded")
                digest.update(block)
        require(size == item["raw_bytes"] and digest.hexdigest() == item["raw_sha256"], "Raw gzip identity mismatch")
    actual = {p.relative_to(package).as_posix() for p in package.rglob("*") if p.is_file()}
    require(actual == expected and len(manifest["files"]) == complete["file_count"], "Archive file set mismatch")
    for operation in plan["operations"]:
        target = REPO / operation["path"]
        staged = (HERE / operation["staged_file"]).resolve()
        require(staged.is_relative_to(HERE / "repository-stage"), "Unsafe staged document path")
        require(sha(target) == operation["preimage_sha256"], "Repository document changed; stop for review")
        require(sha(staged) == operation["staged_sha256"], "Staged document changed")
    for pin in read(HERE / "source.json")["live_candidate_files"]:
        require(sha(REPO / pin["path"]) == pin["sha256"], "Live production differs; no restoration attempted")
    destination = REPO / ASSET
    require(not destination.exists(), "Round18 asset destination already exists; refusing overwrite")
    require(not (HERE / "publication.json").exists(), "Publication receipt already exists")
    if not args.execute:
        print(json.dumps({"mode": "PLAN ONLY", "asset_files": len(expected), "documents": sorted(DOCS)}))
        return
    destination.mkdir()
    for relative in sorted(expected):
        source = package / relative
        target = destination / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open("xb") as out:
            out.write(source.read_bytes())
        require(sha(target) == sha(source), "Published asset copy differs")
    for operation in plan["operations"]:
        target = REPO / operation["path"]
        require(sha(target) == operation["preimage_sha256"], "Document changed during publication")
        target.write_bytes((HERE / operation["staged_file"]).read_bytes())
        require(sha(target) == operation["staged_sha256"], "Published document differs")
    actual_published = {p.relative_to(destination).as_posix() for p in destination.rglob("*") if p.is_file()}
    require(actual_published == expected, "Published asset inventory differs")
    receipt = {"status": "PASS", "kind": "Exact-byte documentation publication only", "asset_directory": ASSET,
               "artifact_count": len(manifest["files"]), "copied_asset_files": len(expected),
               "manifest_sha256": manifest_sha,
               "documents": [{"path": x["path"], "sha256": sha(REPO / x["path"])} for x in plan["operations"]],
               "production": "Read-only SHA verification; two live candidates still match staged snapshots",
               "build_sql_native_profile_benchmark_git": "NOT RUN by archival sidecar"}
    (HERE / "publication.json").write_bytes(encoded(receipt))
    print(json.dumps(receipt))


if __name__ == "__main__":
    main()
