import argparse
import hashlib
import json
import os
from pathlib import Path
import socket
import subprocess
import tempfile
import time

root = Path(r'D:\Projects\OceanBase\seekdb')
logs = Path(__file__).resolve().parent
python = Path(r'C:\Users\11946\Documents\ChatGPT\OceanBase比赛\.venv\Scripts\python.exe')
validation = root / 'build_fts_competition' / 'validation'
fixture_cases = {
    'test_hot_path.py': 'hot_path_expected.json',
    'test_collation.py': 'collation_expected.json',
    'test_tokenize_config.py': 'tokenize_config_expected.json',
    'test_dictionary_prefixes.py': 'dictionary_prefixes_expected.json',
}


def git(*args):
    return subprocess.check_output(['git', *args], cwd=root)


def prepare():
    validation.mkdir(parents=True, exist_ok=True)
    files = git('ls-tree', '-r', '--name-only', 'codex/fts-performance-competition',
                '--', 'unittest/storage/fts').decode().splitlines()
    for name in files:
        if name.endswith(('.py', '.json')):
            target = validation / Path(name).name
            if not target.exists():
                target.write_bytes(git('show', f'codex/fts-performance-competition:{name}'))


def run(options):
    binary = Path(options.binary).resolve()
    if options.kind == 'baseline':
        baseline = '5bce9e06d1281347ad61344e4b01fab9158c58a2'
        assert git('rev-parse', 'HEAD').decode().strip() == baseline
        assert not git('diff', '--name-only', baseline).strip(), 'Original source has changes'
    prepare()
    with socket.socket() as check:
        if check.connect_ex(('127.0.0.1', 2891)) == 0:
            raise RuntimeError('Dedicated SQL port 2891 already occupied')
    label = 'competition-' + options.kind
    source = git('rev-parse', 'HEAD').decode().strip()
    digest = hashlib.sha256(binary.read_bytes()).hexdigest()
    base_dir = Path(tempfile.gettempdir()) / ('seekdb-fts-competition-' + options.kind)
    command = [str(binary), '--nodaemon', '--base-dir=' + str(base_dir),
               '--port=2891', '--parameter', 'rpc_port=2892', '--parameter',
               'cpu_count=4', '--parameter', 'memory_budget=2G', '--parameter',
               'log_disk_size=2G', '--log-level=WARN']
    environment = os.environ.copy()
    environment['PYTHONUTF8'] = '1'
    environment['PYTHONIOENCODING'] = 'utf-8'
    environment.pop('SEEKDB_TEST_PASSWORD', None)
    results = []
    benchmark = None
    with (logs / (label + '-server.stdout.log')).open('w') as out, \
         (logs / (label + '-server.stderr.log')).open('w') as err:
        process = subprocess.Popen(command, cwd=root, stdout=out, stderr=err,
                                   creationflags=subprocess.CREATE_NO_WINDOW)
        try:
            for _ in range(120):
                if process.poll() is not None:
                    raise RuntimeError(f'Test server exited: {process.returncode}')
                try:
                    import pymysql
                    with pymysql.connect(host='127.0.0.1', port=2891, user='root',
                                         connect_timeout=1, charset='utf8mb4') as connection:
                        with connection.cursor() as cursor:
                            cursor.execute('SELECT 1')
                            assert cursor.fetchone() == (1,)
                    break
                except (OSError, pymysql.MySQLError):
                    time.sleep(1)
            else:
                raise RuntimeError('Dedicated database did not become ready')
            if options.kind == 'baseline':
                for test, fixture in fixture_cases.items():
                    args = [str(python), '-X', 'utf8', str(validation / test),
                            '--record', str(validation / fixture)]
                    result = subprocess.run(args, cwd=root, env=environment,
                                            text=True, encoding='utf-8', capture_output=True)
                    (logs / (label + '-record-' + test + '.log')).write_text(
                        result.stdout + result.stderr, encoding='utf-8')
                    print(result.stdout, end='', flush=True)
                    if result.returncode:
                        print(result.stderr, flush=True)
                        raise RuntimeError('Official fixture recording failed: ' + test)
            for test in ['test_hot_path.py', 'test_tokenize_config.py', 'test_collation.py',
                         'test_match_batches.py', 'test_map_concurrency.py',
                         'test_stopword_concurrency.py', 'test_dictionary_prefixes.py']:
                args = [str(python), '-X', 'utf8', str(validation / test)]
                if options.kind == 'candidate' and test == 'test_hot_path.py':
                    args.append('--check-plans')
                started = time.monotonic()
                result = subprocess.run(args, cwd=root, env=environment,
                                        text=True, encoding='utf-8', capture_output=True)
                contents = result.stdout + result.stderr
                (logs / (label + '-' + test + '.log')).write_text(contents, encoding='utf-8')
                print(contents, end='', flush=True)
                results.append({'test': test, 'exit_code': result.returncode,
                                'elapsed_sec': time.monotonic() - started})
                if result.returncode:
                    raise RuntimeError('Regression failed: ' + test)
            if options.benchmark:
                report = logs / (label + '-report.txt')
                if report.exists():
                    raise RuntimeError('Benchmark report already exists: ' + str(report))
                client = root / 'build/fts-native-client/mysql-native.exe'
                environment.update({
                    'MYSQL': client.as_posix() + ' -h127.0.0.1 -P2891 -uroot -N -s -A --default-character-set=utf8mb4',
                    'MYSQL_VERBOSE': client.as_posix() + ' -h127.0.0.1 -P2891 -uroot -A --default-character-set=utf8mb4',
                    'LABEL': label, 'ROWS': '20000', 'BATCH': '500', 'ROUNDS': '3000',
                    'QUERY_ROUNDS': '200', 'SAMPLES': '3', 'WARMUP': '30',
                    'SKIP_LOAD': '0', 'OUTPUT': report.as_posix(),
                })
                result = subprocess.run([r'C:\Program Files\Git\bin\bash.exe',
                        'tools/benchmark/fts_large_bench.sh'], cwd=root, env=environment,
                        text=True, encoding='utf-8', capture_output=True)
                (logs / (label + '-bench.log')).write_text(
                    result.stdout + result.stderr, encoding='utf-8')
                if result.returncode:
                    print(result.stdout + result.stderr, flush=True)
                    raise RuntimeError('Official full benchmark failed')
                score = subprocess.run([str(python), '-X', 'utf8',
                    'tools/benchmark/fts_large_bench_score.py', str(report)],
                    cwd=root, env=environment, text=True, encoding='utf-8', capture_output=True)
                (logs / (label + '-ci-reference-score.txt')).write_text(
                    score.stdout + score.stderr, encoding='utf-8')
                if score.returncode:
                    print(score.stdout + score.stderr, flush=True)
                    raise RuntimeError('Official benchmark parameter/metric validation failed')
                benchmark = {'report_file': report.name,
                    'report_sha256': hashlib.sha256(report.read_bytes()).hexdigest(),
                    'benchmark_exit_code': result.returncode, 'score_script_exit_code': score.returncode,
                    'ROWS': 20000, 'BATCH': 500, 'ROUNDS': 3000, 'QUERY_ROUNDS': 200,
                    'SAMPLES': 3, 'WARMUP': 30, 'SKIP_LOAD': 0,
                    'comparison_or_formal_ci_score': False}
                print('PASS: unchanged official full benchmark and scoring input validation', flush=True)
        finally:
            if process.poll() is None:
                process.terminate()
                try:
                    process.wait(timeout=20)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait()
    metadata = {'kind': options.kind, 'source_commit': source,
                'binary': str(binary), 'binary_sha256': digest,
                'tests': results, 'benchmark': benchmark, 'fixtures': {
                    fixture: hashlib.sha256((validation / fixture).read_bytes()).hexdigest()
                    for fixture in fixture_cases.values()}}
    (logs / (label + '-validation.json')).write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print('PASS: official competition ' + options.kind + ' validation', flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--kind', choices=['baseline', 'candidate'], required=True)
    parser.add_argument('--binary', required=True)
    parser.add_argument('--benchmark', action='store_true')
    run(parser.parse_args())
