"""Minimal batch MySQL client for the unchanged FTS benchmark script."""
import argparse
import sys
import pymysql


def statements(text):
    start = 0
    quote = None
    escaped = False
    line_comment = False
    block_comment = False
    i = 0
    while i < len(text):
        c = text[i]
        if line_comment:
            line_comment = c != '\n'
        elif block_comment:
            if text[i:i+2] == '*/':
                block_comment = False
                i += 1
        elif quote:
            if escaped:
                escaped = False
            elif c == '\\':
                escaped = True
            elif c == quote:
                if i+1 < len(text) and text[i+1] == quote:
                    i += 1
                else:
                    quote = None
        elif c in "'\"\x60":
            quote = c
        elif c == '#' or (text[i:i+2] == '--' and (i+2 == len(text) or text[i+2].isspace())):
            line_comment = True
        elif text[i:i+2] == '/*':
            block_comment = True
            i += 1
        elif c == ';':
            sql = text[start:i+1].strip()
            if sql:
                yield sql
            start = i+1
        i += 1
    if text[start:].strip():
        yield text[start:]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('-e', '--execute')
    parser.add_argument('-N', action='store_true')
    parser.add_argument('-s', action='store_true')
    parser.add_argument('-A', action='store_true')
    parser.add_argument('--default-character-set', default='utf8mb4')
    args = parser.parse_args()
    sql = args.execute if args.execute is not None else sys.stdin.read()
    with pymysql.connect(host='127.0.0.1', port=2891, user='root', password='', charset='utf8mb4', autocommit=True, read_timeout=3600, write_timeout=3600) as connection:
        with connection.cursor() as cursor:
            for query in statements(sql):
                cursor.execute(query)
                if cursor.description:
                    for row in cursor.fetchall():
                        print('\t'.join('NULL' if value is None else str(value) for value in row))


if __name__ == '__main__':
    main()

