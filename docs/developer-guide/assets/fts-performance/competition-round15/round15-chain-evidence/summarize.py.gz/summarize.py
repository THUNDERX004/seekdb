"""Offline three-pair summary; no workloads, subprocesses, Git or networking.

Default: r15-chain, ../round15-chain-array/source.json, comparison.json here.
Reuse with --prefix NAME --source PATH (relative to setup/fts or absolute).
Exit 2 means completion metadata is missing/incomplete; no reports were read
and no output was created. Retry after completion, not in a tight poll loop.
--check recomputes without writes. Default refuses to overwrite a differing
comparison; --refresh updates only comparison.json. Output has fewer than 150
lines, retaining compact per-pair micro means instead of raw sample arrays.
"""
import argparse
import hashlib
import json
import math
import re
from pathlib import Path
from statistics import mean

OUT = Path(__file__).resolve().parent
FTS = OUT.parent
CLASSES = {
    "build": ["build_ik_all_sec", "build_ik_content_sec", "build_beng_en_sec"],
    "tokenize": ["tokenize_ik_avg_ms", "tokenize_beng_avg_ms"],
    "query": ["query_cn_avg_ms", "query_beng_avg_ms", "query_mixed_avg_ms", "query_limit_avg_ms"],
}
PARAMETERS = dict(rows=20000, batch=500, rounds=3000, query_rounds=200, samples=3, warmup=30, skip_load=0)
HITS = dict(query_cn_hits=8001, query_beng_hits=11000, query_mixed_hits=7332, query_limit_hits=20)
PACKED_ROWS = {"metrics", "runs", "pairs", "microsets", "input_hashes"}


def compact(value):
    return json.dumps(value, ensure_ascii=False, allow_nan=False, separators=(",", ":"))


def render(data):
    lines = ["{"]
    for key, value in data.items():
        if key in PACKED_ROWS:
            lines.append("  " + compact(key) + ": [")
            lines.extend("    " + compact(row) + ("," if n < len(value) - 1 else "") for n, row in enumerate(value))
            lines.append("  ],")
        else:
            lines.append("  " + compact(key) + ": " + compact(value) + ",")
    lines[-1] = lines[-1].removesuffix(",")
    lines.append("}")
    assert len(lines) < 150
    result = ("\n".join(lines) + "\n").encode("utf-8")
    assert json.loads(result) == data
    return result


def reduction(control, candidate):
    assert control > 0 and candidate > 0 and math.isfinite(control + candidate)
    return (control - candidate) / control


def direction(value):
    return "improved" if value > 0 else "regressed" if value < 0 else "unchanged"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--prefix", default="r15-chain")
    parser.add_argument("--source", default="round15-chain-array/source.json")
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--check", action="store_true")
    mode.add_argument("--refresh", action="store_true")
    args = parser.parse_args()
    assert OUT.name == "round15-chain-evidence" and FTS.name == "fts"
    assert re.fullmatch(r"[A-Za-z0-9_-]+", args.prefix)
    inputs = {}

    def read(path):
        path = path.resolve()
        assert path.is_relative_to(FTS.resolve()), "Only auxiliary FTS inputs may be read"
        if path not in inputs:
            inputs[path] = path.read_bytes()
        return inputs[path]

    source_path = Path(args.source)
    if not source_path.is_absolute():
        source_path = FTS / source_path
    source = json.loads(read(source_path))
    patch = source_path.parent / "source.patch"
    assert hashlib.sha256(read(patch)).hexdigest() == source["patch_sha256"]
    records, pending = {}, []
    # All six completion records are validated before ANY report is opened.
    for n in range(1, 4):
        for variant in ("control", "candidate"):
            label = f"{args.prefix}-{variant}-b{n}"
            path = FTS / (label + "-experiment.json")
            if not path.is_file():
                pending.append(path.name)
                continue
            try:
                record = json.loads(read(path))
            except json.JSONDecodeError:
                pending.append(path.name + " (incomplete JSON)")
                continue
            actions = record.get("actions", [])
            for action in ("benchmark", "input-validation"):
                matches = [item for item in actions if item.get("action") == action]
                if len(matches) != 1 or "exit_code" not in matches[0]:
                    pending.append(label + " (" + action + " incomplete)")
                elif matches[0]["exit_code"] != 0:
                    raise SystemExit("Unsuccessful completion: " + label + " " + action)
            assert all(item.get("exit_code") == 0 for item in actions), label + " has an unsuccessful action"
            assert record["label"] == label and record["source_commit"] == source["parent_commit"]
            pin = "control_binary_sha256" if variant == "control" else "binary_sha256"
            assert record["binary_sha256"] == source[pin], label + " binary differs from source.json"
            records[variant, n] = record
    if pending:
        print(compact(dict(status="waiting_for_completion_metadata", pending=pending, reports_read=False, output_written=False)))
        return 2
    assert len(records) == 6

    reports, runs = {}, []
    for (variant, n), record in records.items():
        path = FTS / (record["label"] + "-report.txt")
        assert Path(record["report"]).resolve() == path.resolve()
        report = read(path).decode("utf-8-sig")
        assert report.count("FTS Large Benchmark Report") == 1
        fields = dict(re.findall(r"^([a-zA-Z0-9_]+):\s*(.*?)\s*$", report, re.M))
        assert fields["label"] == record["label"]
        assert all(float(fields[key]) == value for key, value in {**PARAMETERS, **HITS}.items())
        reports[variant, n] = fields
        runs.append([record["label"], fields["timestamp"], record["source_commit"], record["binary_sha256"],
                     fields["git_head"], int(fields["git_dirty"])])
    metric_rows, aggregate_classes = [], {}
    pair_classes = {n: {} for n in range(1, 4)}
    for category, metrics in CLASSES.items():
        rates = []
        for metric in metrics:
            control = [float(reports["control", n][metric]) for n in range(1, 4)]
            candidate = [float(reports["candidate", n][metric]) for n in range(1, 4)]
            rate = reduction(mean(control), mean(candidate))
            metric_rows.append([metric, "sec" if metric.endswith("_sec") else "ms", mean(control), mean(candidate), rate])
            rates.append(rate)
        aggregate_classes[category] = mean(rates)
        for n in range(1, 4):
            pair_classes[n][category] = mean(reduction(float(reports["control", n][metric]), float(reports["candidate", n][metric])) for metric in metrics)
    pairs = []
    for n in range(1, 4):
        rates = pair_classes[n]
        pairs.append([f"b{n}", rates, {key: direction(value) for key, value in rates.items()}, mean(rates.values())])

    microsets, missing_micro = [], []
    for n in range(1, 4):
        samples = {}
        for variant in ("control", "candidate"):
            record = records[variant, n]
            path = FTS / (record["label"] + "-micro.json")
            complete = [item for item in record["actions"] if item["action"] == "micro" and item["exit_code"] == 0]
            if not path.is_file() or len(complete) != 1:
                missing_micro.append(record["label"])
                continue
            sample = json.loads(read(path))
            for name in ("ik_us", "beng_us"):
                assert len(sample[name]) == 3 and all(math.isfinite(x) and x > 0 for x in sample[name])
            samples[variant] = sample
        if len(samples) == 2:
            microsets.append({"pair": f"b{n}", **{name: [mean(samples["control"][name]), mean(samples["candidate"][name]),
                              reduction(mean(samples["control"][name]), mean(samples["candidate"][name]))] for name in ("ik_us", "beng_us")}})
    micro_aggregate = {name: reduction(mean(row[name][0] for row in microsets),
                                     mean(row[name][1] for row in microsets))
                       for name in ("ik_us", "beng_us")} if microsets else {}
    provenance = {key: source[key] for key in ("parent_commit", "official_baseline", "patch_sha256", "binary", "binary_sha256",
                  "source_sha256", "control_binary", "control_binary_sha256", "build_configuration_sha256", "notes") if key in source}
    decision = "rejected" if args.prefix == "r15-chain" else "parent_pending"
    parent_confirmation = dict(
        decision_basis="No stable scored improvement: overall -1.291247%, tokenize -0.195313%; unscored IK engine micro +6.740611% does not override the full-workload result.",
        correctness={"existing_1560_JSON_fixture": "passed per parent", "seven_existing_suites": "passed per parent", "new_972_case_official_original_exact_fixture": "passed per parent"},
        production_restoration="Parent announced restoration of both production files; completion is not confirmed by this auxiliary task. Tests/evidence retained.",
        production_files=list(source.get("source_sha256", {})),
        causal_limit="Recorded query regression (~4.36%) and unchanged BENG-path regressions are observations; no causal attribution to the IK change is established.",
    ) if args.prefix == "r15-chain" else None
    result = dict(schema_version=1, experiment=args.prefix, decision=decision, parent_confirmation=parent_confirmation, completion_gate="All six metadata records successful before reading reports",
                  provenance=provenance,
                  provenance_notes=["Control f602 source code equals parent 620; intervening changes are tests/evidence only, as reported by parent/source.json.",
                                    "Metadata source_commit is a label; reports git_head/git_dirty refer to the checkout, not executable identity. No current source, binary or Git verification performed here."],
                  parameters=PARAMETERS, query_hits_all_runs=HITS,
                  method="For each metric: (mean(control b1..b3)-mean(candidate b1..b3))/mean(control b1..b3); mean within each class, then equal mean of three classes; retain every negative; no intermediate rounding.",
                  metric_columns=["metric", "unit", "control_mean", "candidate_mean", "reduction"], metrics=metric_rows,
                  class_reductions=aggregate_classes, overall_reduction=mean(aggregate_classes.values()),
                  pair_columns=["pair", "class_reductions", "class_directions", "overall_reduction"], pairs=pairs,
                  run_columns=["label", "timestamp_local", "source_commit_label", "binary_sha256", "report_git_head", "report_git_dirty"], runs=runs,
                  micro_note="Unscored diagnostic; each parser value is [control mean us, candidate mean us, pair reduction]; each mean covers 3 samples. Aggregate uses only complete paired sets. Raw samples remain in hashed input files.",
                  microsets=microsets, micro_missing_or_not_successful=missing_micro, micro_aggregate_reductions=micro_aggregate,
                  limits="Descriptive local evidence only; no official score or statistical significance claimed. Final disposition and additional correctness/restoration information are parent-reported, not independently rerun. No workloads or Git operations were run.",
                  input_hash_columns=["path_relative_to_setup_fts", "sha256", "bytes"],
                  input_hashes=[[path.relative_to(FTS.resolve()).as_posix(), hashlib.sha256(data).hexdigest(), len(data)] for path, data in sorted(inputs.items())])
    output = render(result)
    for path, data in inputs.items():
        assert path.read_bytes() == data, "Input changed during summary: " + path.name
    destination = OUT / "comparison.json"
    if args.check:
        assert destination.is_file() and destination.read_bytes() == output, "Output missing/different"
    elif destination.exists():
        if destination.read_bytes() != output:
            assert args.refresh, "Output differs; use --refresh for an authorized summary update"
            destination.write_bytes(output)
    else:
        with destination.open("xb") as handle:
            handle.write(output)
    print(compact(dict(status="verified" if args.check else "summarized", lines=len(output.splitlines()), class_reductions=aggregate_classes,
                       overall_reduction=result["overall_reduction"], per_pair_overall=[row[3] for row in pairs], microsets=len(microsets), decision=decision)))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
