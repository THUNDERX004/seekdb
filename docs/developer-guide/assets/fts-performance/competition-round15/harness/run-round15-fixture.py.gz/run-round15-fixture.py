"""Serial original/candidate SQL differential on the dedicated test endpoint."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import socket
import subprocess
import time

ROOT = Path(r"D:\Projects\OceanBase\seekdb")
HERE = Path(__file__).resolve().parent
PYTHON = HERE.parents[1] / ".venv/Scripts/python.exe"
ORIGINAL = "bae4a3b9e1b4662d4021b28d5adc085764beb6cf02122eacd57b8e16b6fe1762"

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--binary", required=True, type=Path)
    parser.add_argument("--label", required=True)
    parser.add_argument("--suite", choices=("json", "chain"), required=True)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--record", type=Path)
    mode.add_argument("--expected", type=Path)
    args = parser.parse_args()
    if not all(c.isalnum() or c in "-_" for c in args.label):
        raise ValueError("Invalid experiment label")
    binary = args.binary.resolve()
    digest = hashlib.sha256(binary.read_bytes()).hexdigest()
    metadata_path = HERE / (args.label + "-fixture.json")
    if metadata_path.exists():
        raise FileExistsError(metadata_path)
    if args.record and (args.record.exists() or digest != ORIGINAL):
        raise ValueError("Recording requires a new fixture and the verified original executable")
    test = ROOT / ("unittest/storage/fts/test_tokenize_json_nodes.py" if args.suite == "json"
                   else "unittest/storage/fts/test_ik_chain_directory.py")
    if not test.is_file():
        raise FileNotFoundError(test)
    for port in (2891, 2892):
        with socket.socket() as check:
            if check.connect_ex(("127.0.0.1", port)) == 0:
                raise RuntimeError("Dedicated endpoint occupied: " + str(port))
    base = Path(r"C:\Users\11946\AppData\Local\Temp") / ("fts_" + args.label.replace("-", "_"))
    if base.exists():
        raise FileExistsError(base)
    meta = {"binary": str(binary), "binary_sha256": digest, "suite": args.suite,
            "test_sha256": hashlib.sha256(test.read_bytes()).hexdigest(), "base_dir": str(base),
            "sql_port": 2891, "rpc_port": 2892, "cpu_count": 4, "memory_budget": "2G", "log_disk_size": "2G"}
    command = [str(binary), "--nodaemon", "--base-dir=" + str(base), "--port=2891",
               "--parameter", "rpc_port=2892", "--parameter", "cpu_count=4", "--parameter",
               "memory_budget=2G", "--parameter", "log_disk_size=2G", "--log-level=WARN"]
    env = os.environ.copy()
    env.update(PYTHONUTF8="1", PYTHONIOENCODING="utf-8")
    env.pop("SEEKDB_TEST_PASSWORD", None)
    with (HERE / (args.label + "-server.log")).open("x", encoding="utf-8") as log:
        process = subprocess.Popen(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT,
                                   creationflags=subprocess.CREATE_NO_WINDOW)
        try:
            import pymysql
            for _ in range(120):
                if process.poll() is not None:
                    raise RuntimeError("Isolated server exited: " + str(process.returncode))
                try:
                    with pymysql.connect(host="127.0.0.1", port=2891, user="root", connect_timeout=1) as connection:
                        with connection.cursor() as cursor:
                            cursor.execute("SELECT 1")
                            assert cursor.fetchone() == (1,)
                    break
                except (OSError, pymysql.MySQLError):
                    time.sleep(1)
            else:
                raise TimeoutError("Readiness timeout")
            command = [str(PYTHON), "-X", "utf8", str(test), "--port", "2891"]
            if args.record:
                command += ["--record", str(args.record), "--record-source-commit",
                            "5bce9e06d1281347ad61344e4b01fab9158c58a2",
                            "--record-source-binary-sha256", digest]
            else:
                command += ["--expected", str(args.expected)]
                meta["fixture_sha256_before"] = hashlib.sha256(args.expected.read_bytes()).hexdigest()
            with (HERE / (args.label + "-test.log")).open("x", encoding="utf-8") as out:
                result = subprocess.run(command, cwd=ROOT, env=env, stdout=out, stderr=subprocess.STDOUT)
            meta["exit_code"] = result.returncode
            if result.returncode:
                raise RuntimeError("Fixture test failed; see saved test log")
            if args.expected:
                meta["fixture_sha256_after"] = hashlib.sha256(args.expected.read_bytes()).hexdigest()
                assert meta["fixture_sha256_before"] == meta["fixture_sha256_after"]
            else:
                meta["recorded_fixture_sha256"] = hashlib.sha256(args.record.read_bytes()).hexdigest()
        finally:
            if process.poll() is None:
                process.terminate()
                try:
                    process.wait(timeout=20)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait()
            metadata_path.write_text(json.dumps(meta, indent=2)+"\n", encoding="utf-8")
    print("PASS isolated", args.suite, "fixture:", args.label)

if __name__ == "__main__":
    main()
