"""Apply one guarded experimental chain-directory change in the selected checkout."""
from pathlib import Path
import hashlib

ROOT = Path(r"D:\Projects\OceanBase\seekdb")
OUT = Path(__file__).resolve().parent / "round15-chain-array"
OUT.mkdir(exist_ok=True)

def change(rel, replacements):
    path = ROOT / rel
    raw = path.read_bytes()
    text = raw.decode("utf-8").replace("\r\n", "\n")
    for old, new in replacements:
        if text.count(old) != 1:
            raise RuntimeError(f"Guard failed: {rel}: {old[:80]!r}")
        text = text.replace(old, new, 1)
    before = OUT / "original" / rel
    before.parent.mkdir(parents=True, exist_ok=True)
    if before.exists():
        raise FileExistsError(before)
    before.write_bytes(raw)
    updated = text.replace("\n", "\r\n").encode("utf-8") if b"\r\n" in raw else text.encode("utf-8")
    path.write_bytes(updated)
    snapshot = OUT / rel
    snapshot.parent.mkdir(parents=True, exist_ok=True)
    snapshot.write_bytes(updated)
    print(rel, hashlib.sha256(raw).hexdigest(), hashlib.sha256(updated).hexdigest())

change("src/storage/fts/ik/ob_ik_arbitrator.h", [
    ('#include "lib/hash/ob_hashmap.h"', '#include "lib/container/ob_se_array.h"'),
    ('  int prepare(TokenizeContext &ctx);', '  int prepare();\n\n  int find_chain(const int64_t offset, ObIKTokenChain *&chain) const;'),
    ('  // Arbitration state is owned by one synchronous parser invocation.\n  hash::ObHashMap<int64_t, ObIKTokenChain *, hash::NoPthreadDefendMode> chains_;',
     '  // Keep the offset directory contiguous; chain objects retain arena ownership.\n  ObSEArray<ObIKTokenChain *, 16> chains_;\n  bool is_prepared_;'),
])
change("src/storage/fts/ik/ob_ik_arbitrator.cpp", [
    ('if (OB_FAIL(prepare(ctx)))', 'if (OB_FAIL(prepare()))'),
    ('chains_.get_refactored(current, chain)', 'find_chain(current, chain)'),
    ('''int ObIKArbitrator::prepare(TokenizeContext &ctx)
{
  int ret = OB_SUCCESS;

  int cal_bucket_num = MAX(ctx.fulltext_len() / 100, 10);
  cal_bucket_num = MIN(cal_bucket_num, 100);
  if (OB_FAIL(chains_.create(cal_bucket_num, ObMemAttr("IK ARBITRATE")))) {
  }
  return ret;
}

ObIKArbitrator::ObIKArbitrator() : alloc_(lib::ObMemAttr("IK Arbitrator")) {}''',
     '''int ObIKArbitrator::prepare()
{
  int ret = OB_SUCCESS;
  if (is_prepared_) {
    ret = OB_INIT_TWICE;
  } else {
    is_prepared_ = true;
  }
  return ret;
}

int ObIKArbitrator::find_chain(const int64_t offset, ObIKTokenChain *&chain) const
{
  int ret = OB_HASH_NOT_EXIST;
  int64_t begin = 0;
  int64_t end = chains_.count();
  while (begin < end) {
    const int64_t middle = begin + (end - begin) / 2;
    const int64_t key = chains_.at(middle)->min_offset();
    if (key < offset) {
      begin = middle + 1;
    } else {
      end = middle;
    }
  }
  if (begin < chains_.count() && chains_.at(begin)->min_offset() == offset) {
    chain = chains_.at(begin);
    ret = OB_SUCCESS;
  }
  return ret;
}

ObIKArbitrator::ObIKArbitrator()
    : alloc_(lib::ObMemAttr("IK Arbitrator")),
      chains_(lib::ObLabel("IK ARBITRATE"), OB_MALLOC_NORMAL_BLOCK_SIZE),
      is_prepared_(false)
{}'''),
    ('''  } else if (OB_FAIL(chains_.set_refactored(chain->min_offset(), chain))) {
  }
  return ret;
}

ObIKArbitrator::~ObIKArbitrator()
{
  chains_.destroy();''',
     '''  } else {
    // Process normally appends nonoverlapping chains. Keep ordered insertion
    // and the original duplicate-key error for all other insertion orders.
    int64_t position = chains_.count();
    while (position > 0 && chains_.at(position - 1)->min_offset() > chain->min_offset()) {
      --position;
    }
    if (position > 0 && chains_.at(position - 1)->min_offset() == chain->min_offset()) {
      ret = OB_HASH_EXIST;
    } else if (position < chains_.count()
               && chains_.at(position)->min_offset() == chain->min_offset()) {
      ret = OB_HASH_EXIST;
    } else if (OB_FAIL(chains_.push_back(chain))) {
    } else {
      for (int64_t index = chains_.count() - 1; index > position; --index) {
        chains_.at(index) = chains_.at(index - 1);
      }
      chains_.at(position) = chain;
    }
  }
  return ret;
}

ObIKArbitrator::~ObIKArbitrator()
{
  chains_.reset();'''),
])
