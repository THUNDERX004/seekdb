from pathlib import Path
import gzip
import hashlib
import json
import shutil

HERE = Path(__file__).resolve().parent
ROOT = Path(r"D:\Projects\OceanBase\seekdb")
DEST = ROOT / "docs/developer-guide/assets/fts-performance/competition-round15"
assert not DEST.exists()
DEST.mkdir()
files = []

def archive(path, relative):
    raw = path.read_bytes()
    packed = gzip.compress(raw, mtime=0)
    relative = str(relative).replace("\\", "/") + ".gz"
    target = DEST / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(packed)
    files.append({"path": relative, "source": str(path), "source_bytes": len(raw),
                  "source_sha256": hashlib.sha256(raw).hexdigest(),
                  "bytes": len(packed), "sha256": hashlib.sha256(packed).hexdigest()})

for pattern in ("r15-*.json", "r15-*.log", "r15-*-report.txt", "round15-*-build.log"):
    for path in sorted(HERE.glob(pattern)):
        archive(path, Path("raw") / path.name)
for dirname in ("round15-chain-array", "round15-chain-evidence", "round15-chain-audit", "round15-chain-regression"):
    for path in sorted((HERE / dirname).rglob("*")):
        if path.is_file() and "__pycache__" not in path.parts:
            archive(path, Path(dirname) / path.relative_to(HERE / dirname))
for name in ("apply-round15-chain-array.py", "refine-round15-init.py", "pin-round15-source.py",
             "run-round15-fixture.py", "experiment-competition.py", "micro-competition.py", "package-round15.py"):
    archive(HERE/name, Path("harness")/name)

fixture = HERE / "r15-original-ik-chain-directory.json.gz"
payload = json.loads(gzip.decompress(fixture.read_bytes()))
assert payload["case_count"] == 972
assert payload["workload_sha256"] == "88503130a31c4da39c8d7579691b32547f5fd297b8adee4f3f7a1a3f9cf94f68"
assert payload["original"] == {
    "commit": "5bce9e06d1281347ad61344e4b01fab9158c58a2",
    "binary_sha256": "bae4a3b9e1b4662d4021b28d5adc085764beb6cf02122eacd57b8e16b6fe1762"}
target = ROOT / "unittest/storage/fts/ik_chain_directory_expected.json.gz"
assert not target.exists()
shutil.copyfile(fixture, target)
assert target.read_bytes() == fixture.read_bytes()

decision = {
    "date": "2026-11-04", "decision": "rejected; both IK production files restored exactly",
    "overall_reduction": -0.012912473386346567,
    "class_reductions": {"build": 0.006843973146741635, "tokenize": -0.001953125000000056,
                         "query": -0.04362826830578128},
    "ik_micro_reduction_unscored": 0.06740610559311967,
    "reason": "No repeatable scored overall benefit, despite an engine-only IK diagnostic improvement",
    "causality_limit": "Unchanged BENG timing changes are retained; this comparison does not establish their cause",
    "correctness": {"existing_complete_tokenize_cases": 1560, "standard_suites": 7,
                    "focused_complete_ik_cases": 972, "status": "all passed on pinned candidate"},
    "fixture": {"path": str(target.relative_to(ROOT)), "sha256": hashlib.sha256(fixture.read_bytes()).hexdigest(),
                "workload_sha256": payload["workload_sha256"]},
    "fixture_provenance": payload["original"],
    "native_limit": "No direct private-directory allocation-failure/lifecycle test executed; SQL does not prove those paths",
    "formal_result": "No new formal score; only the user's earlier raw21.099/100, weighted10.55/50",
    "protection": "Official workload, SQL, timing, scoring and build/CI files unchanged"
}
(DEST / "decision.json").write_text(json.dumps(decision, indent=2)+"\n", encoding="utf-8")
manifest = {"schema_version": 1, "files": files,
            "decision_sha256": hashlib.sha256((DEST / "decision.json").read_bytes()).hexdigest()}
(DEST / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
for item in files:
    packed = (DEST / item["path"]).read_bytes()
    assert hashlib.sha256(packed).hexdigest() == item["sha256"]
    assert hashlib.sha256(gzip.decompress(packed)).hexdigest() == item["source_sha256"]
print("Archived", len(files), "artifacts; fixture", decision["fixture"]["sha256"])

sections = {
    "docs/developer-guide/zh-CN/fts-performance.md": '''## 第十五轮 IK 仲裁目录实验（2026-11-04）

决定：**撤回**链目录的小数组替换。三组完整对照，构建下降 0.6844%、分词退化 0.1953%、查询退化 4.3628%，三类等权综合 **退化 1.2912%**。逐配对综合为 -4.0185%、0.7303%、-1.0909%。IK 引擎诊断微基准下降约 6.74%，但计分 TOKENIZE IK 均值相同，不能把诊断收益当作计分收益。未修改的 BENG 波动同样完整保留，不据此断言因果。

候选通过已有 1,560 组完整 TOKENIZE 对照、七套旧 suite，以及新增 **972 组** IK smart/max_word、DEFAULT/ALL、三种 UTF8 collation、容量边界、重叠词、NUL 和 1000 字符分段边界回归。后者 fixture 独立录制自官方原版；完整有序 JSON 字节、元数据、警告及 12 个原有错误全部核对。SQL 不能证明私有目录分配失败路径，本轮未运行对应 native 注入。

[第十五轮证据](../assets/fts-performance/competition-round15/manifest.json)保存全部六次完整运行、诊断、精确补丁、源码和二进制身份、审查及新 fixture 来源。两处生产文件已恢复；不以未保留方案宣称优化。没有新正式成绩，50/50 目标尚未达成。
''',
    "docs/developer-guide/en/fts-performance.md": '''## Round 15 IK chain-directory experiment (2026-11-04)

Decision: **reject** the small-array chain directory. Three full pairs show build +0.6844%, tokenize -0.1953%, query -4.3628%, and equal-category overall **-1.2912%** time reduction. Pair totals are -4.0185%, +0.7303%, -1.0909%. The unscored engine-only IK diagnostic improves about 6.74%; scored IK TOKENIZE means are equal. Retain unchanged BENG fluctuations without assigning a cause.

The pinned candidate passed 1,560 complete TOKENIZE cases, seven established suites, and **972 new cases** spanning IK modes, both output modes, three UTF8 collations, capacity inputs, overlapping words, NUL and the 1000-character segmentation boundary. The new fixture was independently recorded from the official original and compares complete ordered JSON bytes, metadata, warnings and 12 original errors. No direct private-directory allocation-failure test ran; SQL equality does not prove that path.

[Round 15 evidence](../assets/fts-performance/competition-round15/manifest.json) preserves all six full runs, diagnostics, exact patch/source/binary identities, review and original-fixture provenance. Both production files were restored. No new formal score or full marks is claimed.
'''
}
for rel, addition in sections.items():
    path = ROOT / rel
    raw = path.read_bytes()
    text = raw.decode("utf-8").replace("\r\n", "\n")
    title, rest = text.split("\n", 1)
    text = title + "\n\n" + addition + rest
    path.write_bytes(text.replace("\n", "\r\n").encode() if b"\r\n" in raw else text.encode())
path = ROOT / "unittest/storage/fts/README.md"
with path.open("a", encoding="utf-8", newline="") as out:
    out.write('''
## IK chain-directory boundary regression (round 15)

```sh
python3 unittest/storage/fts/test_ik_chain_directory.py --port 2891 --expected unittest/storage/fts/ik_chain_directory_expected.json.gz
```

The 972-case independent-original fixture covers smart/max_word, DEFAULT/ALL,
three UTF8 collations, disjoint phrases, overlaps, NUL and segment boundaries.
Compare complete ordered JSON bytes, column metadata, warnings and exact errors.
Recording requires the verified official-original binary, never candidate output.
This suite issues parameterized SELECTs on dedicated port 2891 and creates no
tables. Input phrase counts do not assert a particular internal directory size.
See round-15 decision.json for fixture SHA256 and provenance. The small-array
production experiment was rejected after a 1.2912% full-benchmark regression.
''')
