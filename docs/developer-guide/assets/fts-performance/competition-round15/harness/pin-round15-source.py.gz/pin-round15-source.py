from pathlib import Path
import hashlib
import json
import shutil
import subprocess

ROOT = Path(r"D:\Projects\OceanBase\seekdb")
HERE = Path(__file__).resolve().parent
OUT = HERE / "round15-chain-array"
REL = ["src/storage/fts/ik/ob_ik_arbitrator.cpp", "src/storage/fts/ik/ob_ik_arbitrator.h"]
patch = subprocess.run(["git", "diff", "--binary", "--", *REL], cwd=ROOT, capture_output=True, check=True).stdout
assert patch
(OUT / "source.patch").write_bytes(patch)
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
binary = ROOT / "build_fts_competition/src/observer/seekdb.exe"
snapshot = ROOT / "build/fts-round15-chain-array"
if snapshot.exists():
    raise FileExistsError(snapshot)
snapshot.mkdir()
for item in [binary, *sorted(binary.parent.glob("*.dll"))]:
    shutil.copy2(item, snapshot / item.name)
    assert sha(item) == sha(snapshot / item.name)
meta = {"parent_commit": subprocess.run(["git", "rev-parse", "HEAD"], cwd=ROOT, capture_output=True, text=True, check=True).stdout.strip(),
        "official_baseline": "5bce9e06d1281347ad61344e4b01fab9158c58a2",
        "patch_sha256": sha(OUT / "source.patch"), "binary": str(snapshot / binary.name),
        "binary_sha256": sha(binary), "source_sha256": {p: sha(ROOT/p) for p in REL},
        "control_binary": str(ROOT / "build_fts_r14_control_observer/seekdb.exe"),
        "control_binary_sha256": sha(ROOT / "build_fts_r14_control_observer/seekdb.exe"),
        "build_configuration_sha256": sha(ROOT / "build_fts_competition/CMakeCache.txt"),
        "build_logs": ["round15-chain-array-build.log", "round15-chain-array-final-build.log"],
        "notes": ["Control f602 and current parent 620 differ only in regression/evidence files", "No JSON batching or stopword production patch remains", "Final lookup preserves OB_NOT_INIT before process"]}
(OUT / "source.json").write_text(json.dumps(meta, indent=2)+"\n", encoding="utf-8")
print(json.dumps({"binary_sha256": meta["binary_sha256"], "patch_sha256": meta["patch_sha256"]}))
