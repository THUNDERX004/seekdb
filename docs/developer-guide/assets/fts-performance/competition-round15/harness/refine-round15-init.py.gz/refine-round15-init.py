from pathlib import Path
import hashlib

path = Path(r"D:\Projects\OceanBase\seekdb\src\storage\fts\ik\ob_ik_arbitrator.cpp")
raw = path.read_bytes()
text = raw.decode().replace("\r\n", "\n")
old = '''int ObIKArbitrator::find_chain(const int64_t offset, ObIKTokenChain *&chain) const
{
  int ret = OB_HASH_NOT_EXIST;
'''
new = '''int ObIKArbitrator::find_chain(const int64_t offset, ObIKTokenChain *&chain) const
{
  if (!is_prepared_) {
    return OB_NOT_INIT;
  }
  int ret = OB_HASH_NOT_EXIST;
'''
assert text.count(old) == 1
text = text.replace(old, new)
updated = text.replace("\n", "\r\n").encode() if b"\r\n" in raw else text.encode()
path.write_bytes(updated)
snapshot = Path(__file__).resolve().parent / "round15-chain-array/src/storage/fts/ik/ob_ik_arbitrator.cpp"
snapshot.write_bytes(updated)
print("Preserved the pre-process lookup error; source SHA256", hashlib.sha256(updated).hexdigest())
