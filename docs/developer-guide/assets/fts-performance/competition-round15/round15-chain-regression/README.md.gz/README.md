The staged `test_ik_chain_directory.py` is ready to copy into `D:/Projects/OceanBase/seekdb/unittest/storage/fts/` beside the existing `test_tokenize_json_nodes.py`. It imports that file's exact `cell`, `query`, and recursive `compare` helpers. When run from this auxiliary directory, it falls back only to the explicitly selected `D:/Projects/OceanBase/seekdb/unittest/storage/fts/test_tokenize_json_nodes.py`; it does not search for another checkout or copy the comparison implementation.

This preparation performs static AST inspection only. No baseline fixture is supplied or recorded, and no script, helper, SQL, database, build, benchmark, or Git operation is run by the static checker. The regression itself is intended for a caller-managed isolated instance on localhost port 2891. It never starts or stops seekdb and needs no database: workload statements are parameterized `SELECT TOKENIZE(...) AS r15_result`, with no tables, DDL, `USE`, prepared statements, or persistent state. Connection setup sets the strict SQL mode and query timeout; the shared helper issues `SHOW WARNINGS` immediately after every workload statement.

There are **972 cases**: 80 documents crossed with IK `smart` / `max_word`, DEFAULT / ALL output, and `utf8mb4_bin` / `utf8mb4_general_ci` / `utf8mb4_unicode_ci`, followed by 12 narrowly designated original-error cases. All 960 valid cases must succeed. The exact workload SHA-256 is **`88503130a31c4da39c8d7579691b32547f5fd297b8adee4f3f7a1a3f9cf94f68`**; the script checks this pin and case identities before opening a SQL connection.

| Family | Documents / cases | Purpose |
| --- | --- | --- |
| Capacity inputs | 40 / 480 | Requested disjoint phrase counts 0, 1, 15, 16, 17, 31, 32, 33, 257, 1025, each as English words separated by `\|`, CJK phrases separated by `\|`, English words separated by Hiragana `あ`, and CJK phrases separated by English `q`. |
| Segment boundaries | 15 / 180 | Exact Unicode-character lengths 999, 1000, 1001, 1999, 2001, each with periodic ASCII delimiters, periodic CJK delimiters, and useful mixed text with delimiters at positions around the strict 1000-character threshold. |
| Special/repeated | 25 / 300 | Empty/punctuation-only/one-token inputs; overlapping Chinese ambiguities; Arabic and Chinese numbers, quantifiers and connectors; mixed English/CJK; internal/edge NUL; supplementary characters, emoji/ZWJ, Japanese/Korean, accents/combining marks, width variants, quotes/backslashes, identical repeated documents, reversed groups and repeated ambiguity. |
| Exact errors | — / 12 | Invalid IK mode, invalid output, and unknown IK option under the three collations; three untyped-NULL option forms. Exact positive server error number and message are required, based on observations already present in the independent official-original round14 fixture. |

Capacity labels denote input phrase counts, not asserted final unique-token counts or measured directory sizes. Punctuation may trigger segmentation after `handle_size > 1000`. The `あ` and `q` separators are useful CJK/English characters, so those variants avoid that punctuation-triggered early split and exercise a larger accumulated directory. Actual dictionary matches and smart arbitration can add or merge chains; this SQL suite cannot directly prove a particular internal chain count or allocation boundary. The shorter segment cases intentionally cover the sides of the threshold; longer periodic-delimiter cases exercise multiple parser batches. The exact lengths count Unicode characters, matching the parser's step counter, rather than UTF-8 bytes. The longest document is 7,174 characters, and the largest encoded input is 10,249 UTF-8 bytes. Inputs are capped at 16,384 bytes and are never truncated.

Supplementary Unicode characters are sent as valid UTF-8, including characters that use surrogate pairs in UTF-16. This does not exercise the internal UTF-16 surrogate branch, malformed-surrogate transport, private directory operations, injected allocation failures, arbitrary post-publication key mutation, or repeated `process` on one arbitrator. Those require separate native coverage. SQL repetition here means repeated texts across independent parameterized statements and multiple parser batches inside long texts.

The fixture preserves the shared helper's complete JSON bytes (hex-tagged binary cells), ordered result rows, column metadata, warnings, error numbers and messages. It does not parse or normalize returned TOKENIZE JSON, sort tokens, remove duplicates, replace spelling, or compare only hit counts. Unexpected errors in valid cases abort through the shared helper. Designated errors are additionally checked against an exact number and message, so a different unsupported/error outcome or unexpected success also aborts. Comparison uses the same immutable fixture with the shared exact recursive comparator.

With `use_unicode=False`, result cells retain their binary representation, while PyMySQL error messages remain Python `str`, as observed in the existing independent-original fixture. `shared.cell(required["message"])` preserves that string, so required-error comparison uses the same type without encoding or normalization.

Compressed fixture size is capped at **32 MiB**; complete uncompressed fixture JSON has a separate **256 MiB** cap. Recording aborts without writing if either cap is exceeded; it never samples or trims output. Actual fixture size remains unmeasured until the parent records the independent original. Gzip uses a fixed timestamp. Recording uses exclusive creation and rejects existing paths, including symlinks; it requires an existing parent directory. Comparison never creates or replaces a fixture, and mode selection is mandatory. All 972 cases and the workload hash are unchanged by this limit split.

Only the official original commit **`5bce9e06d1281347ad61344e4b01fab9158c58a2`** and the exact independently supplied original binary SHA-256 **`bae4a3b9e1b4662d4021b28d5adc085764beb6cf02122eacd57b8e16b6fe1762`** are accepted for recording or fixture provenance. The caller must independently establish that this is the binary actually serving port 2891. Supplying the hash, SQL version text, or a filename alone does not verify the running process. Source/binary provenance arguments are rejected in comparison mode. No candidate results may be recorded as the original.

After independently starting and verifying the official original, record to a NEW path (this example is documentation only):

```powershell
.venv/Scripts/python.exe -X utf8 setup/fts/round15-chain-regression/test_ik_chain_directory.py --record setup/fts/r15-original-ik-chain-directory.json.gz --record-source-commit 5bce9e06d1281347ad61344e4b01fab9158c58a2 --record-source-binary-sha256 bae4a3b9e1b4662d4021b28d5adc085764beb6cf02122eacd57b8e16b6fe1762
```

Then use that unchanged fixture for an original determinism check and the candidate:

```powershell
.venv/Scripts/python.exe -X utf8 setup/fts/round15-chain-regression/test_ik_chain_directory.py --expected setup/fts/r15-original-ik-chain-directory.json.gz
```

The examples run from `C:/Users/11946/Documents/ChatGPT/OceanBase比赛`. Install the script in the selected checkout when integrating it into the established FTS regression suite. `SEEKDB_TEST_PASSWORD` is optional environment input; the script does not open the workspace credential file or print connection secrets.

The initial draft passed the static AST check below. `static-ast-check.json` retains that historical draft's source hash and limits. The frozen draft splits the fixture limits and documents error-message types; it has not been rerun, as requested. The checker itself now reports the two separate limits. Use a NEW output path if rerunning it later:

```powershell
.venv/Scripts/python.exe -X utf8 setup/fts/round15-chain-regression/static_ast_check.py --output setup/fts/round15-chain-regression/static-ast-check-frozen.json
```

This checker parses the source and literal corpus, independently reconstructs the declared workload, and verifies the count, matrix, byte/character limits, exact SELECT aliases, helper reuse and pinned hash. It never imports or executes the regression module, shared helper, or database driver. Its result is static evidence only, not an original-output fixture or a runtime correctness result.
