#!/usr/bin/env python3
"""Inspect literal regression data/AST only; never import or execute the test."""
import argparse
import ast
from collections import Counter
import hashlib
import json
from pathlib import Path


def inspect_script(path):
    source = path.read_bytes()
    tree = ast.parse(source, filename=str(path))
    constants = {}
    for node in tree.body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
            try:
                constants[node.targets[0].id] = ast.literal_eval(node.value)
            except (TypeError, ValueError):
                pass
    assert constants["OFFICIAL"] == "5bce9e06d1281347ad61344e4b01fab9158c58a2"
    assert constants["ORIGINAL_BINARY_SHA256"] == "bae4a3b9e1b4662d4021b28d5adc085764beb6cf02122eacd57b8e16b6fe1762"
    assert constants["CAPACITIES"] == (0, 1, 15, 16, 17, 31, 32, 33, 257, 1025)
    assert constants["SEGMENT_LENGTHS"] == (999, 1000, 1001, 1999, 2001)
    assert constants["MODES"] == ("smart", "max_word")
    assert constants["OUTPUTS"] == ("default", "all")
    assert constants["COLLATIONS"] == ("utf8mb4_bin", "utf8mb4_general_ci", "utf8mb4_unicode_ci")
    assert constants["MAX_COMPRESSED_FIXTURE_BYTES"] == 33554432
    assert constants["MAX_RAW_FIXTURE_BYTES"] == 268435456
    documents = constants["DOCUMENTS"]
    assert len(documents) == 80 and len({label for label, _ in documents}) == 80
    document_map = dict(documents)
    for family in ("english_punctuation", "cjk_punctuation", "english_cjk_separator", "cjk_english_separator"):
        for count in constants["CAPACITIES"]:
            assert "capacity/" + family + "/" + str(count) in document_map
    for family in ("ascii", "cjk", "threshold_delimiters"):
        for count in constants["SEGMENT_LENGTHS"]:
            assert len(document_map["segment/" + family + "/" + str(count)]) == count
    assert document_map["special/repeat_a"] == document_map["special/repeat_b"]
    assert "\0" in document_map["special/nul_internal"]
    assert any(ord(character) > 0xFFFF for character in document_map["special/supplementary"])
    assert max(len(document.encode("utf-8")) for _, document in documents) <= constants["MAX_INPUT_UTF8_BYTES"]
    functions = {node.name: node for node in tree.body if isinstance(node, ast.FunctionDef)}
    assert {"load_shared", "case", "cases", "workload_hash", "check_result", "capture", "read_fixture", "main"} <= functions.keys()
    assert not {"cell", "query", "compare"} & functions.keys()
    shared_calls = {node.func.attr for node in ast.walk(tree) if isinstance(node, ast.Call)
                    and isinstance(node.func, ast.Attribute) and isinstance(node.func.value, ast.Name)
                    and node.func.value.id == "shared"}
    assert {"cell", "query", "compare"} <= shared_calls
    assert not any(isinstance(node, ast.Try) for node in ast.walk(functions["capture"]))
    assert not any(isinstance(node, ast.Call) and isinstance(node.func, ast.Name)
                   and node.func.id in ("exec", "eval") for node in ast.walk(tree))
    assert not any(isinstance(node, (ast.Import, ast.ImportFrom)) and any(
        name.name.split(".")[0] in ("subprocess", "socket", "shutil") for name in node.names)
                   for node in ast.walk(tree))

    # Independently reconstruct the workload from AST literals. No function
    # from the regression module or helper is evaluated during this check.
    workload = []
    def item(name, sql, params, error=None):
        return {"id": name, "sql": sql, "params": list(params), "before": [],
                "allow_error": error is not None, "required_error": error}
    for label, document in documents:
        for mode in constants["MODES"]:
            for output in constants["OUTPUTS"]:
                config = json.dumps([{"output": output}, {"additional_args": [{"ik_mode": mode}]}],
                                    ensure_ascii=True, allow_nan=False, separators=(",", ":"))
                for collation in constants["COLLATIONS"]:
                    workload.append(item(label + "/" + mode + "/" + output + "/" + collation,
                                         constants["SELECT_SQL"].format(collation=collation),
                                         (document, "ik", config)))
    for label, config, number, message in constants["INVALID_OPTIONS"]:
        for collation in constants["COLLATIONS"]:
            workload.append(item("errors/" + label + "/" + collation,
                                 constants["SELECT_SQL"].format(collation=collation),
                                 ("南京市长江大桥 123个 zxqv", "ik", config),
                                 {"number": number, "message": message}))
    for index, config in enumerate(constants["NULL_OPTIONS"]):
        workload.append(item("errors/untyped_null/" + str(index), constants["UNTYPED_SQL"],
                             (None, "ik", config),
                             {"number": constants["NULL_ERROR"][0], "message": constants["NULL_ERROR"][1]}))
    assert len(workload) == constants["EXPECTED_CASE_COUNT"] == 972
    assert len({case["id"] for case in workload}) == len(workload)
    for case in workload:
        assert case["sql"].startswith("SELECT TOKENIZE(") and case["sql"].endswith(" AS r15_result")
        assert case["sql"].count("%s") == 3 and " FROM " not in case["sql"]
        assert not case["before"] and case["params"][1] == "ik"
        assert case["allow_error"] == (case["required_error"] is not None)
    definition = {"suite": constants["SUITE"], "cases": workload, "strict_mode": constants["STRICT_MODE"]}
    signature = hashlib.sha256(json.dumps(definition, ensure_ascii=True, allow_nan=False,
                                         separators=(",", ":")).encode("utf-8")).hexdigest()
    assert signature == constants["PINNED_WORKLOAD_SHA256"]
    return {"validation": "static AST/literal inspection only; regression/helper not imported or executed",
            "script_sha256": hashlib.sha256(source).hexdigest(), "workload_sha256": signature,
            "documents": len(documents), "cases": len(workload),
            "required_success_cases": sum(not case["allow_error"] for case in workload),
            "required_error_cases": sum(case["allow_error"] for case in workload),
            "case_families": dict(Counter(case["id"].split("/")[0] for case in workload)),
            "maximum_document_characters": max(len(document) for _, document in documents),
            "maximum_document_utf8_bytes": max(len(document.encode("utf-8")) for _, document in documents),
            "compressed_fixture_limit_bytes": constants["MAX_COMPRESSED_FIXTURE_BYTES"],
            "complete_json_fixture_limit_bytes": constants["MAX_RAW_FIXTURE_BYTES"],
            "official_commit": constants["OFFICIAL"], "original_binary_sha256": constants["ORIGINAL_BINARY_SHA256"],
            "runtime_or_database_validation_performed": False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, metavar="NEW_AUDIT_JSON")
    args = parser.parse_args()
    result = inspect_script(Path(__file__).with_name("test_ik_chain_directory.py"))
    raw = json.dumps(result, ensure_ascii=True, indent=2) + "\n"
    if args.output is not None:
        with args.output.open("x", encoding="utf-8", newline="\n") as output:
            output.write(raw)
    print(raw, end="")


if __name__ == "__main__":
    main()
