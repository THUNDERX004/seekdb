# Round 16: staged DDL lazy-row candidate

Prepared 2026-11-04 from the exact current DAS files in `D:/Projects/OceanBase/seekdb`. This is an **unapplied, uncompiled candidate** for the parent to consider only after gating the separate IK round 15 experiment. No builds, project tests, SQL, performance runs, Git commands, service operations, or remote operations were performed. No D: file was modified. Only this staging directory was written.

The implementation replaces eager per-document row materialization inside `ObFTIndexRowCache` with an exclusive per-document word map and one reusable four-column row. It preserves the existing eager DML helper and all source following the cache implementation byte for byte. It changes no parser, tokenizer, IK arbitrator, charset, stopword, sorting, storage writer, benchmark, scoring, CI, or build code. The unrelated data-plane FTS header comment is intentionally untouched, as requested.

## Package and exact source identity

The package has exactly these six files:

```text
README.md
source.patch
src/sql/das/ob_das_domain_utils.h
src/sql/das/ob_das_domain_utils.cpp
original/src/sql/das/ob_das_domain_utils.h
original/src/sql/das/ob_das_domain_utils.cpp
```

`original` contains byte-exact copies of the live DAS files at capture. Both originals still matched the corresponding live files during packaging verification. Full original/candidate copies preserve their original CRLF endings. `source.patch` is a conventional UTF-8, LF-normalized unified diff with repository-relative `a/` and `b/` paths, generated only for the two DAS files. No Git command was used to generate or check it. A static regeneration of the unified diff matched the patch bytes exactly; an actual parent-side Git application has not been attempted here.

| File | Original raw SHA-256 | Staged raw SHA-256 |
| --- | --- | --- |
| `ob_das_domain_utils.h` | `1430f9997bea2ce557ae2d9f6ce6aa513a88a11bd7a91e51a366d02e23356cdb` | `6fcb5b5a660d361ff024393f1938b4ef7d13184d32a400c03ee665925b78aad3` |
| `ob_das_domain_utils.cpp` | `6adeadca2e80c7ecf6ecce6beb456082ddfe0155a34705a63d54f21bb7265bd3` | `5f2327db753293026bd9dadf0176c57a3b18399f44f211f56dff61060af55ba5` |

The patch is 6,090 bytes; SHA-256: `3ae2a4aeb6b3e24c112017379dcbb9d65d34b8e3f3209f3d15001b2cdbffbe94`. Diff size: header `+8/-2`, implementation `+66/-20`.

The unchanged implementation suffix starting at `ObDASDomainUtils::generate_spatial_index_rows` is 52,514 bytes, SHA-256 `4cad4ef023b56521e7b2cddbe80a59a5d5361c39e6d6b0d6428df17ca6f313bf`. The unchanged range containing `generate_fulltext_word_rows` and `segment_and_calc_word_count`, ending immediately before `get_pure_mutivalue_data`, has SHA-256 `07339d2dd38c2c83e804025796604d46e674b2ae9e78b62b5c5a8b52e21f7e9f`. Header declarations after `ObFTIndexRowCache` are also byte-identical.

These are local raw-byte identities, not Git object IDs or a claim about live HEAD. Existing project guidance records the official baseline as `upstream/2026-competition` at `5bce9e06d1281347ad61344e4b01fab9158c58a2`; this sidecar did not query ancestry or reverify the remote because Git/remote work was excluded. The parent must recheck exact original identities and the intended competition ancestry before applying, then re-review if the DAS files or their dependent contracts changed.

## Concrete implementation

The changed class is in [the staged header](C:/Users/11946/Documents/ChatGPT/OceanBase比赛/setup/fts/round16-lazy-rows/src/sql/das/ob_das_domain_utils.h:36); its implementation starts in [the staged source](C:/Users/11946/Documents/ChatGPT/OceanBase比赛/setup/fts/round16-lazy-rows/src/sql/das/ob_das_domain_utils.cpp:46).

- The cache replaces `rows_` with `word_map_`, `word_iter_`, `row_`, `doc_id_`, `doc_length_`, and `has_document_`. `row_idx_` remains the number of emitted entries for tracing. No shared or thread-local mutable state is introduced. The complete `ObDatumRow` header is included because the row is now a by-value member.
- `init` initializes `row_` once via `row_.init(4)`. That overload uses the row's own local allocator, which outlives document-arena resets. The document map is still created lazily, once per nonempty input; there is no cross-document bucket/node cache.
- `segment` discards the previous document, validates the same meta/empty-input preconditions, creates the map with exactly `MIN(MAX(fulltext.length()/10,2),997)` requested buckets and the same `FTWordMap` memory attribute, and calls the unchanged public `helper_.segment` with the original meta/input and the existing document allocator selected during helper initialization. All segmentation, filtering, grouping, normalization, document-length calculation, and parser destruction finish before rows can be emitted.
- After successful nonempty segmentation, `src_doc_id.shallow_copy_from_datum` followed by `doc_id_.deep_copy` copies the incoming datum's packed flags and exact payload bytes into cache-owned document storage. There is no conversion, parsing, regenerated ID, or hard-coded format. The temporary storage datum dies at the end of the block; the owned copy survives. Only after that copy succeeds are the iterator and `has_document_` published.
- `get_next_row` writes the next complete tuple into `row_`, advances the iterator once, and returns that row. It preserves `[word,doc_id,word_count,doc_length]` versus `[doc_id,word,word_count,doc_length]`, the same `set_datum`/`shallow_copy_from_datum` operations, and unsigned count/length setters. No successful drain operation allocates, parses, hashes, regroups, or reads a new source document.
- `reuse` invalidates the iterator and ready flag, clears row/ID views and counters, destroys the map, then resets the document context. `reset` applies the same ordering before destroying the context and additionally resets the row/helper. The final successful row keeps both map and document storage alive; even a subsequent `OB_ITER_END` does not prematurely free its bytes. Reuse/reset/destruction or the next document performs cleanup.
- All failed or empty segmentation paths leave the cache not ready and perform the same ordered cleanup. The original return code is retained. Error/end returns from `get_next_row` set its output pointer to null, so a stale pointer cannot look like a successful result.

The eager `ObDASDomainUtils::generate_fulltext_word_rows` and `segment_and_calc_word_count` functions, their DML callers, contiguous row-array assumptions, and all other DAS utilities are unchanged.

## Static self-review

The repository's [code-review skill](D:/Projects/OceanBase/seekdb/.agents/skills/code-review/SKILL.md) was read and used to trace the affected caller, ownership, state, and error contracts. The statements below are source reasoning and packaging-integrity checks, not execution of the implementation.

**Validation/error order.** The old eager path first validates meta, then empty length, then creates the map, then validates/calls the parser. The candidate keeps that order. The omitted private `segment_and_calc_word_count` wrapper checked a non-null helper, a created map, and the collation boundary before calling `helper->segment`. In the cache, `&helper_` cannot be null, successful `word_map_.create` establishes the map, and initialized cache state follows successful helper initialization. The public helper itself applies the same invalid/upper-bound collation checks before parsing; see [the live helper](D:/Projects/OceanBase/seekdb/src/storage/fts/ob_fts_parser_helper.cpp:383). No private function is called illegally and no friendship/API expansion is added.

Before initialization, `segment`/`get_next_row` still return `OB_NOT_INIT`. Invalid meta returns `OB_INVALID_ARGUMENT`; valid-meta zero-length input and zero-term parser output return `OB_ITER_END`. Map/parser failures propagate their existing code. An ID-copy allocation failure is a new failure point of this representation and returns the allocator's error without publishing a partial document. Removed row-array allocation failure sites are not artificially retained. Exact allocator failure positions cannot remain identical after removing allocations; the required contract is correct error family, no partial success, and complete cleanup.

**Iteration and semantic data.** The map implementation, per-document creation, requested bucket count/prime selection, input sequence, key equality/hash, parser properties, and grouping updates are unchanged. No map mutation occurs while draining. Starting at `begin()` after segmentation and advancing once for each success gives the same entry sequence as the eager loop. Counts come directly from the existing map, and `doc_length_` comes directly from the helper rather than distinct-term count. Existing latest-spelling behavior for collation-equivalent words is preserved by leaving grouping untouched.

**Row/input ownership.** Current [ObTableScanOp::inner_get_next_fts_index_row](D:/Projects/OceanBase/seekdb/src/sql/engine/table/ob_table_scan_op.cpp:3627) immediately consumes the cache pointer through [fill_generated_fts_cols](D:/Projects/OceanBase/seekdb/src/sql/engine/table/ob_table_scan_op.cpp:3688). The pointer does not escape that call. A reusable row is therefore valid for this current caller; it is not a promise that two saved `ObDatumRow*` results remain independent. Strings remain in the document arena until the existing next-document boundary. The sort's [deep-copy ingestion](D:/Projects/OceanBase/seekdb/src/sql/engine/basic/ob_chunk_datum_store.cpp:251) remains necessary and untouched.

The row's own datum buffer is independent of `merge_memctx_`. `row_.reuse()` resets its four cell views while retaining capacity. Neither its initialization nor reset frees document-owned strings. The copied ID is a separate member and arena payload, so replacing the row does not overwrite the source for later ID copies. `ObStorageDatum::deep_copy` copies `pack_` and payload bytes; a null/zero-length value retains flags without needing payload allocation. `reserved_` is initialized/reset to zero, matching the old `shallow_copy_from_datum` row construction. The input API supplies `ObDatum`, which has no storage-only `reserved_` field to preserve.

**Parser term lifetime.** No token borrowing is added. IK/space/ngram/ngram2 retain their existing caller-allocator lowercase path. Current BENG [explicitly stores normalized tokens in the caller allocator](D:/Projects/OceanBase/seekdb/src/storage/fts/ob_beng_ft_parser.cpp:50). Retaining the word map does not extend parser scratch or input/LOB buffer ownership. Parser allocation/copy behavior is untouched. This reasoning depends on the current parser contracts and must be proved by the parent's ownership differential.

**Cleanup and initialization.** Default map iterator state is never dereferenced: `has_document_` short-circuits iteration until successful publication, and `is_inited_` guards use of the four-cell row. Reset/reuse replace the iterator before destroying map nodes and before resetting arena-backed keys/IDs. Partial context/helper/row initialization uses `reset`, whose operations are safe on their default members. The [MemoryContext default constructor](D:/Projects/OceanBase/seekdb/src/oblib/lib/rc/context.h:285) initializes its handle to null. Repeated reset and destruction do not leave a created map for implicit member destructors to free twice. An `init` call on an already initialized cache still returns `OB_INIT_TWICE` without resetting the active cache, as before.

**Costs retained or introduced.** One bulk row-array request, complete per-term row construction/init, and per-term pointer pushes are removed from the cache. Four tuple assignments per output term, all parsing/grouping, map node allocation/destruction, and downstream deep copies remain. A four-cell row already fit its embedded datum buffer; this does not remove one heap allocation per term. The map now remains live during draining, and an external doc ID adds one per-document payload allocation/copy. These costs and the extra reusable-row assignments need actual measurement.

The by-value map/row members also enlarge `ObFTIndexRowCache`, which is embedded in `ObTableScanOp` even for ordinary non-FTS scans. Construction now initializes one row's embedded datum slots for each such operator. No byte/RSS/timing claim is made without compiling on the target platform; the parent should include a non-FTS scan sanity/performance check when assessing overall impact. The proposal does not silently treat those costs as free.

## Assumptions and parent gates

1. A cache is used serially by its owning scalar table-scan operator. No overlapping `segment`, `get_next_row`, `reuse`, or `reset` calls occur on the same instance. Parallel workers each own an independent cache.
2. The current immediate-consumption row-pointer contract remains true. A new caller retaining multiple row pointers or mutating row attributes would need a separate ownership review; the unchanged DML helper still supplies its existing array contract.
3. Parser output bytes remain valid in the caller's document allocator after parser teardown. No parser allocator policy from the separate IK candidate may invalidate that contract.
4. Successful cache initialization implies a live context/helper and a four-cell row. Doc-ID input remains readable for the synchronous `segment` call; the deep copy owns it before row emission begins.
5. Parent-side runtime gates remain pending: a real tuple-stream differential against the unchanged eager helper and independently recorded official-original results, both auxiliary layouts, all supported parsers/configs/charsets, equivalent spellings and exact counts/length/ID flags/bytes, input/parser scratch clobbering, real sort copy followed by document reset, empty/failed/partly drained transitions, allocation-failure cleanup, repeated reset/rescan, multiple workers, forced sort spill, complete MATCH IDs/scores, and DML insert/update/delete regressions.
6. Only after the separate IK experiment is accepted/rejected should this isolated patch be applied to matching DAS originals and built. Run the unchanged official fixed-parameter benchmark in serial matched pairs and retain all build/tokenize/query metrics and negative runs. No performance result or score exists for this staged candidate. If the isolated change has no repeatable overall benefit, discard it.

No source change outside the two staged DAS files is part of `source.patch`; originals are historical input copies. No runnable test or build artifact is included or generated.
