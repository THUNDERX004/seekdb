/*
 * Copyright (c) 2025 OceanBase.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef OCEANBASE_DAS_DOMAIN_UTILS_H
#define OCEANBASE_DAS_DOMAIN_UTILS_H

#include "lib/allocator/page_arena.h"
#include "lib/hash/ob_hashset.h"
#include "common/datum/ob_datum.h"
#include "sql/das/ob_das_dml_ctx_define.h"
#include "data_plane/fts/ob_fts_parser_helper.h"
#include "data_plane/fts/ob_fts_doc_word_scan.h"
#include "data_plane/fts/ob_fts_parser_helper.h"
#include "share/geo/ob_srs_provider.h"

namespace oceanbase
{
namespace sql
{


class ObFTIndexRowCache final
{
public:
  static ObObjDatumMapType FTS_INDEX_TYPES[4];
  static ObObjDatumMapType FTS_DOC_WORD_TYPES[4];
  static ObExprOperatorType FTS_INDEX_EXPR_TYPE[4];
  static ObExprOperatorType FTS_DOC_WORD_EXPR_TYPE[4];

  ObFTIndexRowCache();
  ~ObFTIndexRowCache();
  int init(
      const bool is_fts_index_aux,
      const common::ObString &parser_name,
      const common::ObString &parser_properties);
  int segment(const common::ObObjMeta &ft_obj_meta, const ObDatum &doc_id, const common::ObString &fulltext);
  int get_next_row(blocksstable::ObDatumRow *&row);
  void reset();
  void reuse();
  TO_STRING_KV(K_(row_idx), K_(is_fts_index_aux), K_(helper), K_(is_inited),
               "row_count", rows_.count());
private:
  lib::MemoryContext merge_memctx_;
  ObDomainIndexRow rows_;
  uint64_t row_idx_;
  bool is_fts_index_aux_;
  storage::ObFTParseHelper helper_;
  bool is_inited_;

  DISALLOW_COPY_AND_ASSIGN(ObFTIndexRowCache);
};

enum class ObDomainDMLMode : uint8
{
  DOMAIN_DML_MODE_DEFAULT  = 0,
  DOMAIN_DML_MODE_FT_SCAN  = 1,
  DOMAIN_DML_MODE_MAX      = 2,
};

class ObFTDocWordInfo final
{
public:
  ObFTDocWordInfo()
    : table_id_(OB_INVALID_ID),
      doc_word_table_id_(OB_INVALID_ID),
      doc_word_tablet_id_(),
      snapshot_(),
      doc_word_schema_version_(),
      doc_word_found_(false)
  {}
  ~ObFTDocWordInfo() = default;

  int assign(const ObFTDocWordInfo &src)
  {
    int ret = OB_SUCCESS;
    table_id_ = src.table_id_;
    doc_word_table_id_ = src.doc_word_table_id_;
    doc_word_tablet_id_ = src.doc_word_tablet_id_;
    doc_word_schema_version_ = src.doc_word_schema_version_;
    doc_word_found_ = src.doc_word_found_;

    if (OB_FAIL(snapshot_.assign(src.snapshot_))) {
    }
    return ret;
  }

  TO_STRING_KV(K_(table_id),
               K_(doc_word_table_id),
               K_(doc_word_tablet_id),
               K_(snapshot),
               K_(doc_word_schema_version),
               K_(doc_word_found));
public:
  uint64_t table_id_;
  uint64_t doc_word_table_id_;
  common::ObTabletID doc_word_tablet_id_;
  transaction::ObTxReadSnapshot snapshot_;
  int64_t doc_word_schema_version_;
  bool doc_word_found_;

private:
  DISALLOW_COPY_AND_ASSIGN(ObFTDocWordInfo);
};

class ObDomainDMLParam final
{
public:
  ObDomainDMLParam(
    common::ObIAllocator &allocator,
    const IntFixedArray *row_projector,
    ObDASWriteBuffer::Iterator &write_iter,
    const ObDASDMLBaseCtDef *das_ctdef,
    const ObDASDMLBaseCtDef *main_ctdef,
    common::ObISrsProvider *srs_provider,
    const common::ObLobReadOptions *lob_read_options)
  : mode_(ObDomainDMLMode::DOMAIN_DML_MODE_DEFAULT),
    allocator_(allocator),
    row_projector_(row_projector),
    write_iter_(write_iter),
    das_ctdef_(das_ctdef),
    main_ctdef_(main_ctdef),
    srs_provider_(srs_provider),
    lob_read_options_(lob_read_options),
    ft_doc_word_info_(nullptr)
  {}
  ~ObDomainDMLParam() = default;

  TO_STRING_KV(K_(mode), KPC_(row_projector), KPC_(das_ctdef), KPC_(main_ctdef), KPC_(ft_doc_word_info));

public:
  ObDomainDMLMode mode_;
  common::ObIAllocator &allocator_;
  const IntFixedArray *row_projector_;
  ObDASWriteBuffer::Iterator &write_iter_;
  const ObDASDMLBaseCtDef *das_ctdef_;
  const ObDASDMLBaseCtDef *main_ctdef_;
  common::ObISrsProvider *srs_provider_;
  const common::ObLobReadOptions *lob_read_options_;
  const ObFTDocWordInfo *ft_doc_word_info_;

private:
  DISALLOW_COPY_AND_ASSIGN(ObDomainDMLParam);
};

class ObDASDomainUtils final
{
public:

  static const uint64_t MVI_FULL_ROWKEY_THRESHOLD = 6;
  static const uint64_t MVI_ROWKEY_SIZE_THRESHOLD = 48;

  ObDASDomainUtils() = default;
  ~ObDASDomainUtils() = default;

  static int build_ft_doc_word_infos(
      const transaction::ObTxDesc *trans_desc,
      const transaction::ObTxReadSnapshot *snapshot,
      const common::ObIArray<const ObDASBaseCtDef *> &related_ctdef,
      const common::ObIArray<common::ObTabletID> &related_tablet_ids,
      const bool is_main_table_in_fts_ddl,
      common::ObIArray<ObFTDocWordInfo> &doc_word_infos);
  static int generate_spatial_index_rows(
      ObIAllocator &allocator,
      common::ObISrsProvider &srs_provider,
      const ObDASDMLBaseCtDef &das_ctdef,
      const ObString &wkb_str,
      const IntFixedArray &row_projector,
      const ObDASWriteBuffer::DmlRow &dml_row,
      ObDomainIndexRow &spat_rows);
  static int generate_fulltext_word_rows(common::ObIAllocator &allocator,
                                         storage::ObFTParseHelper *helper,
                                         const common::ObObjMeta &ft_obj_meta,
                                         const ObDatum &doc_id_datum,
                                         const ObString &fulltext,
                                         const bool is_fts_index_aux,
                                         ObDomainIndexRow &word_rows);
  static int generate_multivalue_index_rows(
      ObIAllocator &allocator,
      const ObDASDMLBaseCtDef &das_ctdef,
      int64_t mvi_idx,
      int64_t mvi_arr_idx,
      const ObString &json_data,
      const IntFixedArray &row_projector,
      const ObDASWriteBuffer::DmlRow &dml_row,
      ObDomainIndexRow &domain_rows);
private:
  static int segment_and_calc_word_count(
      common::ObIAllocator &allocator,
      storage::ObFTParseHelper *helper,
      const common::ObObjMeta &meta,
      const ObString &fulltext,
      int64_t &doc_length,
      storage::ObFTWordMap &words_count);
  static int calc_save_rowkey_policy(
    ObIAllocator &allocator,
    const ObDASDMLBaseCtDef &das_ctdef,
    const IntFixedArray &row_projector,
    const ObDASWriteBuffer::DmlRow &dml_row,
    const int64_t record_cnt,
    bool& is_save_rowkey);

  static int get_pure_mutivalue_data(
    const ObString &json_str,
    const char*& data, 
    int64_t& data_len,
    uint32_t& record_num); 
};

class ObDomainDMLIterator
{
public:
  static const int64_t DEFAULT_DOMAIN_ROW_COUNT = 32;
  typedef common::ObSEArray<blocksstable::ObDatumRow*, DEFAULT_DOMAIN_ROW_COUNT> ObDomainIndexRow;

  static int create_domain_dml_iterator(
      const ObDomainDMLParam &param,
      ObDomainDMLIterator *&domain_iter);

public:
  virtual ~ObDomainDMLIterator();
  virtual void reset();
  virtual int change_domain_dml_mode(const ObDomainDMLMode &mode);
  virtual int rewind()
  {
    row_idx_ = 0;
    return common::OB_SUCCESS;
  }
  void set_ctdef(
      const ObDASDMLBaseCtDef *das_ctdef,
      const IntFixedArray *row_projector,
      const ObDomainDMLMode &mode);
  void set_row_projector(const IntFixedArray *row_projector) { row_projector_ = row_projector; }
  int get_next_domain_row(blocksstable::ObDatumRow *&row);
  int get_next_domain_rows(blocksstable::ObDatumRow *&row, int64_t &row_count);
  bool is_same_domain_type(const ObDASDMLBaseCtDef *das_ctdef) const;

  TO_STRING_KV(K_(row_idx), "row_count", rows_.count(), KPC_(row_projector),
               KPC_(das_ctdef), K_(main_ctdef));
protected:
  ObDomainDMLIterator(
      common::ObIAllocator &allocator,
      const IntFixedArray *row_projector,
      ObDASWriteBuffer::Iterator &write_iter,
      const ObDASDMLBaseCtDef *das_ctdef,
      const ObDASDMLBaseCtDef *main_ctdef,
      const common::ObLobReadOptions *lob_read_options);
  virtual int generate_domain_rows(const ObChunkDatumStore::StoredRow *store_row) = 0;

  virtual int check_sync_interval(bool &is_sync_interval) const { UNUSED(is_sync_interval); return OB_SUCCESS; }

protected:
  ObDomainDMLMode mode_;
  uint32_t row_idx_;
  // every element holds a pointer to in a sequential array
  ObDomainIndexRow rows_;
  const IntFixedArray *row_projector_;
  ObDASWriteBuffer::Iterator &write_iter_;
  const ObDASDMLBaseCtDef *das_ctdef_;
  const ObDASDMLBaseCtDef *main_ctdef_;
  common::ObArenaAllocator allocator_;
  bool is_update_;
  const common::ObLobReadOptions *lob_read_options_;
private:
  DISALLOW_COPY_AND_ASSIGN(ObDomainDMLIterator);
};

class ObSpatialDMLIterator final : public ObDomainDMLIterator
{
public:
  ObSpatialDMLIterator(
      common::ObIAllocator &allocator,
      const IntFixedArray *row_projector,
      ObDASWriteBuffer::Iterator &write_iter,
      const ObDASDMLBaseCtDef *das_ctdef,
      const ObDASDMLBaseCtDef *main_ctdef,
      common::ObISrsProvider *srs_provider,
      const common::ObLobReadOptions *lob_read_options)
    : ObDomainDMLIterator(
          allocator, row_projector, write_iter, das_ctdef, main_ctdef,
          lob_read_options),
      srs_provider_(srs_provider)
  {}
  virtual ~ObSpatialDMLIterator() = default;

private:
  virtual int generate_domain_rows(const ObChunkDatumStore::StoredRow *store_row) override;
  int get_geo_wkb(
      const ObChunkDatumStore::StoredRow *store_row,
      int64_t &geo_idx,
      ObString &geo_wkb,
      ObObjMeta &geo_meta) const;
  int get_geo_wkb_for_update(
      const ObChunkDatumStore::StoredRow *store_row,
      int64_t &geo_idx,
      ObString &geo_wkb,
      ObObjMeta &geo_meta) const;
  common::ObISrsProvider *srs_provider_;
};

class ObMultivalueDMLIterator final : public ObDomainDMLIterator
{
public:
  ObMultivalueDMLIterator(
      common::ObIAllocator &allocator,
      const IntFixedArray *row_projector,
      ObDASWriteBuffer::Iterator &write_iter,
      const ObDASDMLBaseCtDef *das_ctdef,
      const ObDASDMLBaseCtDef *main_ctdef,
      const common::ObLobReadOptions *lob_read_options)
    : ObDomainDMLIterator(
          allocator, row_projector, write_iter, das_ctdef, main_ctdef,
          lob_read_options)
  {}
  virtual ~ObMultivalueDMLIterator() = default;

private:
  virtual int generate_domain_rows(const ObChunkDatumStore::StoredRow *store_row) override;
  int get_multivlaue_json_data(
    const ObChunkDatumStore::StoredRow *store_row,
    int64_t& multivalue_idx,
    int64_t& multivalue_arr_idx,
    ObString &multivalue_data);
  
  int get_multivlaue_json_data_for_update(
    const ObChunkDatumStore::StoredRow *store_row,
    int64_t& multivalue_idx,
    int64_t& multivalue_arr_idx,
    ObString &multivalue_data);
};

class ObFTDMLIterator final : public ObDomainDMLIterator
{
public:
  ObFTDMLIterator(
    const ObDomainDMLMode &mode,
    const ObFTDocWordInfo *ft_doc_word_info,
    common::ObIAllocator &allocator,
    const IntFixedArray *row_projector,
    ObDASWriteBuffer::Iterator &write_iter,
    const ObDASDMLBaseCtDef *das_ctdef,
    const ObDASDMLBaseCtDef *main_ctdef,
    const common::ObLobReadOptions *lob_read_options)
  : ObDomainDMLIterator(
        allocator, row_projector, write_iter, das_ctdef, main_ctdef,
        lob_read_options),
    doc_word_info_(ft_doc_word_info),
    ft_doc_word_iter_(nullptr),
    ft_doc_word_allocator_(allocator),
    ft_parse_helper_(),
    is_inited_(false)
  {
    ObDomainDMLIterator::mode_ = mode;
  }
  virtual ~ObFTDMLIterator();

  virtual void reset() override;
  void set_ft_doc_word_info(const ObFTDocWordInfo *ft_doc_word_info) { doc_word_info_ = ft_doc_word_info; }
  virtual int rewind() override;
  virtual int change_domain_dml_mode(const ObDomainDMLMode &mode) override;
  int init(const common::ObString &parser_name,
           const common::ObString &parser_property);

  INHERIT_TO_STRING_KV("ObDomainDMLIterator", ObDomainDMLIterator, K_(ft_parse_helper), K_(is_inited));
protected:
  virtual int generate_domain_rows(const ObChunkDatumStore::StoredRow *store_row) override;
  int get_ft_and_doc_id(const ObChunkDatumStore::StoredRow *store_row,
                        ObDatum &doc_id_datum,
                        ObString &ft,
                        common::ObObjMeta &ft_meta);
  int get_ft_and_doc_id_for_update(const ObChunkDatumStore::StoredRow *store_row,
                                   ObDatum &doc_id_datum,
                                   ObString &ft,
                                   common::ObObjMeta &ft_meta);
  int generate_ft_word_rows(const ObChunkDatumStore::StoredRow *store_row);
  int scan_ft_word_rows(const ObChunkDatumStore::StoredRow *store_row);
  int build_ft_word_row(blocksstable::ObDatumRow *src_row, blocksstable::ObDatumRow *&dest_row);

private:
  const ObFTDocWordInfo *doc_word_info_;
  data_plane::ObFTDocWordIterator *ft_doc_word_iter_;
  common::ObArenaAllocator ft_doc_word_allocator_;
  storage::ObFTParseHelper ft_parse_helper_;
  bool is_inited_;
};

} // end namespace sql
} // end namespace oceanbase

#endif // OCEANBASE_DAS_DOMAIN_UTILS_H
