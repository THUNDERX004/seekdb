param(
    [Parameter(Mandatory = $true)][string]$OutputDir,
    [string]$Python = 'python.exe',
    [switch]$Capture,
    [switch]$Build
)
$ErrorActionPreference = 'Stop'
if ($Capture -and $Build) { throw '-Capture and -Build are mutually exclusive; capture never compiles.' }
$env:PYTHONUTF8 = '1'
if ($Build) {
    $rowNativeVs = 'C:\Program Files\Microsoft Visual Studio\2022\BuildTools'
    Import-Module (Join-Path $rowNativeVs 'Common7\Tools\Microsoft.VisualStudio.DevShell.dll')
    Enter-VsDevShell -VsInstallPath $rowNativeVs -SkipAutomaticLocation `
        -DevCmdArguments '-arch=amd64 -host_arch=amd64 -vcvars_ver=14.44 -winsdk=10.0.26100.0'
}
$rowNativeArgs = @((Join-Path $PSScriptRoot 'prepare_fts_lazy_rows.py'), '--output-dir', $OutputDir)
if ($Capture) { $rowNativeArgs += '--capture' }
if ($Build) { $rowNativeArgs += '--build' }
& $Python @rowNativeArgs
exit $LASTEXITCODE
