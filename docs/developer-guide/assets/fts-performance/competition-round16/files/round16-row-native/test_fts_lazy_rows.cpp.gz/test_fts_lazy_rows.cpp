/* Copyright (c) 2025 OceanBase. Licensed under the Apache License, Version 2.0. */
// Calls production cache, eager generator, parser/map, datum conversions and
// chunk-store APIs. No production algorithm or private state is reproduced.
#include <algorithm>
#include <array>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <memory>
#include <optional>
#include <stdexcept>
#include <string>
#include <vector>

#include "lib/allocator/ob_allocator.h"
#include "lib/rc/context.h"
#include "share/datum/ob_datum_funcs.h"
#include "data_plane/blocksstable/ob_datum_row.h"
#include "data_plane/transaction/ob_tx_desc_access.h"
#include "sql/das/ob_das_domain_utils.h"
#include "sql/engine/basic/ob_chunk_datum_store.h"

using namespace oceanbase;
using namespace oceanbase::common;
using namespace oceanbase::sql;
using namespace oceanbase::storage;
using namespace oceanbase::blocksstable;

namespace {
std::string phase = "startup";
int64_t checks = 0, cases = 0, compared_rows = 0, stored_rows = 0;
int64_t lifecycle_checks = 0, ext_rejections = 0, repeated_counts = 0;
constexpr size_t MAX_ROWS = 8192;

void require(bool ok, const char *message)
{
  ++checks;
  if (!ok) { throw std::runtime_error(phase + ": " + message); }
}
void success(int ret, const char *message) { require(ret == OB_SUCCESS, message); }
ObString view(const std::string &s) { return ObString(static_cast<int32_t>(s.size()), s.data()); }

// Root/current context initialization is the production public API. Each cache
// creates its actual child context below this scope. No server/tenant is mocked.
class ContextScope final
{
public:
  ContextScope()
  {
    lib::ContextParam param;
    param.set_mem_attr("R16RowNative", ObCtxIds::DEFAULT_CTX_ID)
         .set_properties(lib::USE_TL_PAGE_OPTIONAL);
    success(CURRENT_CONTEXT->CREATE_CONTEXT(context_, param), "CREATE_CONTEXT failed");
    require(context_ != nullptr, "CREATE_CONTEXT returned a null handle");
    flow_.emplace(context_);
    const int ret = flow_->init();
    if (ret != OB_SUCCESS) {
      flow_.reset();
      DESTROY_CONTEXT(context_);
      context_ = nullptr;
      success(ret, "Flow::init failed");
    }
  }
  ~ContextScope()
  {
    if (flow_) { flow_->deinit(); flow_.reset(); }
    if (context_ != nullptr) { DESTROY_CONTEXT(context_); context_ = nullptr; }
  }
private:
  lib::MemoryContext context_;
  std::optional<lib::Flow> flow_;
};

struct Cell
{
  uint32_t pack;
  int32_t reserved;
  std::string payload;
  bool operator==(const Cell &other) const
  { return pack == other.pack && reserved == other.reserved && payload == other.payload; }
};
Cell snapshot(const ObDatum &datum, int32_t reserved = 0)
{
  require(datum.is_null() || datum.len_ == 0 || datum.ptr_ != nullptr, "null payload pointer");
  require(datum.len_ <= 65536, "datum exceeded input bound");
  return {datum.pack_, reserved, datum.is_null() || datum.len_ == 0 ? std::string()
                  : std::string(datum.ptr_, datum.len_)};
}
struct Tuple
{
  std::array<Cell, 4> cells;
  uint32_t read_flags;
  uint8_t dml_flags, mvcc_flags;
  int64_t tx_id, scan, group, version;
  bool null_trans_info;
  bool operator==(const Tuple &other) const
  {
    return cells == other.cells && read_flags == other.read_flags
        && dml_flags == other.dml_flags && mvcc_flags == other.mvcc_flags
        && tx_id == other.tx_id && scan == other.scan && group == other.group
        && version == other.version && null_trans_info == other.null_trans_info;
  }
};
Tuple snapshot(const ObDatumRow &row)
{
  require(row.is_valid() && row.count_ == 4, "row validity/column count");
  Tuple result;
  for (int i = 0; i < 4; ++i) {
    result.cells[i] = snapshot(row.storage_datums_[i], row.storage_datums_[i].reserved_);
  }
  result.read_flags = row.read_flag_;
  result.dml_flags = row.row_flag_.get_serialize_flag();
  result.mvcc_flags = row.mvcc_row_flag_.flag_;
  result.tx_id = row.trans_id_.get_id();
  result.scan = row.scan_index_;
  result.group = row.group_idx_;
  result.version = row.snapshot_version_;
  result.null_trans_info = row.trans_info_ == nullptr;
  require(result.null_trans_info, "unexpected transaction-info payload");
  return result;
}
void hex(const std::string &s)
{
  static const char digits[] = "0123456789abcdef";
  for (unsigned char c : s) { std::putchar(digits[c >> 4]); std::putchar(digits[c & 15]); }
}
void emit_tuple(const Tuple &tuple, size_t ordinal)
{
  std::printf("TUPLE\t%s\t%zu\tread=%u\tdml=%u\tmvcc=%u\ttx=%lld\tscan=%lld"
              "\tgroup=%lld\tversion=%lld\tnull_trans_info=%d", phase.c_str(), ordinal,
              tuple.read_flags, static_cast<unsigned>(tuple.dml_flags),
              static_cast<unsigned>(tuple.mvcc_flags), static_cast<long long>(tuple.tx_id),
              static_cast<long long>(tuple.scan), static_cast<long long>(tuple.group),
              static_cast<long long>(tuple.version), tuple.null_trans_info ? 1 : 0);
  for (const auto &cell : tuple.cells) {
    std::printf("\t%u:%d:", cell.pack, cell.reserved); hex(cell.payload);
  }
  std::putchar('\n');
}

enum class Id { binary, long_binary, tiny, number, empty, null_value, min, max, nop, outrow, lob };
struct Sample { const char *name; std::string text; Id id; };
std::vector<Sample> samples()
{
  std::string large;
  for (int i = 0; i < 257; ++i) { large += "term" + std::to_string(i) + " "; }
  return {
    {"empty", "", Id::empty}, {"separators", " \t\n ,.;!? \r ", Id::null_value},
    {"short", "a", Id::null_value}, {"repeat", "aaaaaa aaaa AAAAAA aaaa", Id::long_binary},
    {"case", "Alpha ALPHA alpha beta BETA gamma", Id::number},
    {"unicode", "\xe6\x95\xb0\xe6\x8d\xae\xe5\xba\x93\xe5\x85\xa8\xe6\x96\x87 "
                "\xe6\x95\xb0\xe6\x8d\xae\xe5\xba\x93 caf\xc3\xa9 CAFE e\xcc\x81 "
                "\xf0\x9f\x98\x80\xf0\xa0\x80\x80", Id::binary},
    {"embedded_nul", std::string("aa\0BB\0cc", 8), Id::outrow},
    {"many", large, Id::lob}, {"min_id", "alpha beta alpha", Id::min},
    {"max_id", "alpha beta alpha", Id::max}, {"nop_id", "alpha beta alpha", Id::nop},
    {"empty_id", "alpha beta alpha", Id::empty},
    {"null_id", "alpha beta alpha", Id::null_value},
    {"tiny_id", "alpha beta alpha", Id::tiny},
  };
}

struct Range
{
  uintptr_t begin;
  size_t size;
  bool contains(const void *ptr) const
  { const auto p = reinterpret_cast<uintptr_t>(ptr); return p >= begin && p - begin < size; }
};
struct Expected
{
  int ret;
  std::vector<Tuple> rows;
  Cell id;
  std::array<Range, 3> destroyed_inputs;
};

// Source inputs and eager helper/rows are destroyed on RETURN from this frame.
// Only owned value snapshots and address ranges survive; no row pointer escapes.
__declspec(noinline) Expected prepare(ObFTIndexRowCache &cache, bool aux,
                                    const std::string &properties, const ObObjMeta &meta,
                                    const Sample &sample)
{
  auto text = std::make_unique<char[]>(sample.text.size() + 1);
  std::memcpy(text.get(), sample.text.data(), sample.text.size());
  text[sample.text.size()] = '\0';
  const size_t id_size = sample.id == Id::long_binary ? 4097 : sample.id == Id::tiny ? 1 : 32;
  auto id_bytes = std::make_unique<char[]>(id_size);
  for (size_t i = 0; i < id_size; ++i) { id_bytes[i] = static_cast<char>((i * 73 + 19) & 255); }
  id_bytes[0] = '\0';
  ObStorageDatum id;
  // Initialize padding in the public input buffer, then use only real setters.
  std::memset(id.buf_, 0, sizeof(id.buf_));
  switch (sample.id) {
    case Id::number: id.set_uint(0xfedcba9876543210ULL); break;
    case Id::empty: id.set_string(id_bytes.get(), 0); break;
    case Id::null_value: id.set_null(); break;
    case Id::min: id.set_min(); break;
    case Id::max: id.set_max(); break;
    case Id::nop: id.set_nop(); break;
    default:
      id.set_string(id_bytes.get(), static_cast<uint32_t>(id_size));
      if (sample.id == Id::outrow) { id.set_outrow(); }
      if (sample.id == Id::lob) { id.set_has_lob_header(); }
      break;
  }
  Expected result;
  result.id = snapshot(id);
  result.destroyed_inputs = {{{reinterpret_cast<uintptr_t>(text.get()), sample.text.size() + 1},
                              {reinterpret_cast<uintptr_t>(id_bytes.get()), id_size},
                              {reinterpret_cast<uintptr_t>(id.buf_), sizeof(id.buf_)}}};
  {
    ObArenaAllocator arena("R16EagerRows");
    ObFTParseHelper eager_helper;
    success(eager_helper.init(&arena, ObString::make_string("ngram.1"), view(properties)),
            "real eager helper init failed");
    ObDomainIndexRow eager_rows;
    result.ret = ObDASDomainUtils::generate_fulltext_word_rows(
        arena, &eager_helper, meta, id, ObString(static_cast<int32_t>(sample.text.size()), text.get()),
        aux, eager_rows);
    require(result.ret == OB_SUCCESS || result.ret == OB_ITER_END
            || result.ret == OB_INVALID_ARGUMENT, "unexpected eager segmentation error");
    require(eager_rows.count() <= static_cast<int64_t>(MAX_ROWS), "eager row bound exceeded");
    uint64_t total_count = 0, doc_length = 0;
    for (int64_t i = 0; i < eager_rows.count(); ++i) {
      require(eager_rows[i] != nullptr, "eager returned null row");
      require(eager_rows[i]->storage_datums_[2].pack_ == sizeof(uint64_t)
              && eager_rows[i]->storage_datums_[3].pack_ == sizeof(uint64_t), "eager numeric flags/width");
      const uint64_t count = eager_rows[i]->storage_datums_[2].get_uint();
      const uint64_t length = eager_rows[i]->storage_datums_[3].get_uint();
      require(count > 0 && count <= UINT64_MAX - total_count, "eager count/overflow");
      total_count += count;
      if (i == 0) { doc_length = length; }
      require(length == doc_length, "inconsistent eager doc length");
      result.rows.push_back(snapshot(*eager_rows[i]));
      require(result.rows.back().cells[aux ? 1 : 0] == result.id, "eager changed ID flags/bytes");
      eager_rows[i]->~ObDatumRow();
    }
    require(total_count == doc_length, "ngram count sum differs from doc length");
  }
  const int actual = cache.segment(meta, id,
      ObString(static_cast<int32_t>(sample.text.size()), text.get()));
  require(actual == result.ret, "cache/eager segmentation status differs");
  require((actual == OB_SUCCESS) == !result.rows.empty(), "status/row count inconsistency");
  // Deliberately poison and free BOTH caller buffers, and clobber local ID data.
  std::memset(text.get(), 0xa7, sample.text.size() + 1);
  std::memset(id_bytes.get(), 0xb6, id_size);
  id.reuse();
  std::memset(id.buf_, 0xc5, sizeof(id.buf_));
  text.reset(); id_bytes.reset();
  return result;
}

__declspec(noinline) void overwrite_stack()
{
  volatile unsigned char bytes[16384];
  for (size_t i = 0; i < sizeof(bytes); ++i) { bytes[i] = static_cast<unsigned char>(i); }
}
void expect_next(ObFTIndexRowCache &cache, int expected)
{
  ObDatumRow sentinel;
  ObDatumRow *row = &sentinel;
  require(cache.get_next_row(row) == expected && row == nullptr, "end/error output/status");
  ++lifecycle_checks;
}

// Store real projected datums, using the same public conversion as the scan.
// EXT IDs are direct-builder edge cases: the actual downstream converter must
// reject them. Those rows are still compared fully at the cache/eager boundary.
void store_row(ObChunkDatumStore &store, const ObDatumRow &row, bool aux,
               const Tuple &tuple, std::vector<std::array<Cell, 4>> &expected)
{
  std::array<ObStorageDatum, 4> backing;
  std::array<ObDatum, 4> datums;
  const auto *types = aux ? ObFTIndexRowCache::FTS_INDEX_TYPES : ObFTIndexRowCache::FTS_DOC_WORD_TYPES;
  bool ext = false;
  for (int i = 0; i < 4; ++i) {
    const int ret = backing[i].from_storage_datum(row.storage_datums_[i], types[i]);
    if (row.storage_datums_[i].is_ext()) {
      require(ret == OB_INVALID_ARGUMENT, "downstream EXT conversion contract");
      ext = true;
    } else {
      success(ret, "actual scan datum conversion failed");
      datums[i] = static_cast<const ObDatum &>(backing[i]);
      require(snapshot(datums[i]) == Cell{tuple.cells[i].pack, 0, tuple.cells[i].payload},
              "scan conversion changed datum bytes/flags");
    }
  }
  if (ext) { ++ext_rejections; return; }
  ObChunkDatumStore::StoredRow *stored = nullptr;
  success(store.add_row(datums.data(), 4, 0, &stored), "actual chunk store add_row failed");
  require(stored != nullptr && stored->cnt_ == 4, "stored row count");
  std::array<Cell, 4> converted;
  for (int i = 0; i < 4; ++i) {
    converted[i] = snapshot(datums[i]);
    require(snapshot(stored->cells()[i]) == converted[i], "stored tuple bytes/flags");
    if (!datums[i].is_null() && datums[i].len_ > 0) {
      const auto p = reinterpret_cast<uintptr_t>(stored->cells()[i].ptr_);
      const auto begin = reinterpret_cast<uintptr_t>(stored);
      require(p >= begin && p - begin <= stored->row_size_
              && datums[i].len_ <= stored->row_size_ - (p - begin), "store borrowed payload");
      require(stored->cells()[i].ptr_ != datums[i].ptr_, "store did not deep copy");
    }
  }
  expected.push_back(std::move(converted));
  ++stored_rows;
}

void drain(ObFTIndexRowCache &cache, const Expected &expected, bool aux,
           size_t start, size_t limit, ObChunkDatumStore *store = nullptr,
           std::vector<std::array<Cell, 4>> *stored_expected = nullptr)
{
  require(limit <= expected.rows.size() && start <= limit, "drain range");
  overwrite_stack();
  for (size_t i = start; i < limit; ++i) {
    ObDatumRow *row = nullptr;
    success(cache.get_next_row(row), "cache next failed");
    require(row != nullptr, "success returned null row");
    const Tuple saved = snapshot(*row); // Values copied BEFORE the next get_next_row.
    require(saved == expected.rows[i], "complete tuple/order differs from eager");
    require(saved.cells[aux ? 1 : 0] == expected.id, "owned ID bytes/flags changed");
    for (int cell : {0, 1}) {
      const auto &datum = row->storage_datums_[cell];
      if (!datum.is_null() && datum.len_ > 0) {
        for (const auto &range : expected.destroyed_inputs) {
          require(!range.contains(datum.ptr_), "row borrowed destroyed input buffer");
        }
      }
    }
    require(row->storage_datums_[2].pack_ == sizeof(uint64_t)
            && row->storage_datums_[3].pack_ == sizeof(uint64_t), "numeric flags/width");
    require(row->storage_datums_[2].get_uint() > 0, "zero token count");
    require(row->storage_datums_[3].get_uint() >= row->storage_datums_[2].get_uint(), "doc length/count");
    if (row->storage_datums_[2].get_uint() > 1) { ++repeated_counts; }
    if (store != nullptr) { store_row(*store, *row, aux, saved, *stored_expected); }
    emit_tuple(saved, i);
    ++compared_rows;
    if (i + 1 == expected.rows.size()) {
      expect_next(cache, OB_ITER_END);
      expect_next(cache, OB_ITER_END);
      require(snapshot(*row) == saved, "ITER_END invalidated final row");
    }
  }
  if (expected.rows.empty()) { expect_next(cache, OB_ITER_END); expect_next(cache, OB_ITER_END); }
}

void init(ObFTIndexRowCache &cache, bool aux, const std::string &properties)
{ success(cache.init(aux, ObString::make_string("ngram.1"), view(properties)), "cache init failed"); }

void complete_case(bool aux, const std::string &properties, const ObObjMeta &meta, const Sample &sample)
{
  ObFTIndexRowCache cache;
  init(cache, aux, properties);
  expect_next(cache, OB_ITER_END);
  const Expected expected = prepare(cache, aux, properties, meta, sample);
  ObArenaAllocator store_allocator("R16ChunkRows");
  ObChunkDatumStore store("R16ChunkRows", &store_allocator);
  success(store.init(16 * 1024 * 1024, ObCtxIds::DEFAULT_CTX_ID, "R16ChunkRows", false), "chunk store init failed");
  std::vector<std::array<Cell, 4>> copied;
  drain(cache, expected, aux, 0, expected.rows.size(), &store, &copied);
  success(store.finish_add_row(false), "chunk store finish failed");
  require(store.get_row_cnt() == static_cast<int64_t>(copied.size())
          && store.get_row_cnt_on_disk() == 0 && !store.is_file_open(), "unexpected store count/spill");
  cache.reuse(); cache.reuse();
  expect_next(cache, OB_ITER_END);
  cache.reset(); cache.reset();
  expect_next(cache, OB_NOT_INIT);
  // Both original input buffers AND the cache document context are now gone.
  ObChunkDatumStore::Iterator it;
  success(store.begin(it), "chunk iterator init failed");
  for (const auto &tuple : copied) {
    const ObChunkDatumStore::StoredRow *row = nullptr;
    success(it.get_next_row(row), "chunk row lost after cache reset");
    require(row != nullptr && row->cnt_ == 4, "chunk iterator row shape");
    for (int i = 0; i < 4; ++i) { require(snapshot(row->cells()[i]) == tuple[i], "chunk deep-copy lifetime/bytes"); }
  }
  const ObChunkDatumStore::StoredRow *end = nullptr;
  require(it.get_next_row(end) == OB_ITER_END, "chunk iterator end");
  ++cases;
  std::printf("CASE\t%s\tret=%d\trows=%zu\tstored=%zu\tPASS\n", phase.c_str(), expected.ret,
              expected.rows.size(), copied.size());
}

void lifecycle(bool aux, const std::string &properties, const ObObjMeta &meta)
{
  ObFTIndexRowCache cache;
  ObStorageDatum id; id.set_uint(19);
  expect_next(cache, OB_NOT_INIT);
  require(cache.segment(meta, id, ObString::make_string("alpha beta")) == OB_NOT_INIT, "segment before init");
  cache.reuse(); cache.reset(); cache.reset();
  init(cache, aux, properties);
  const Sample first{"partial", "alpha beta gamma delta epsilon zeta", Id::long_binary};
  const Sample next{"replacement", "omega theta omega kappa lambda", Id::binary};
  const Expected a = prepare(cache, aux, properties, meta, first);
  require(a.rows.size() >= 3, "lifecycle corpus must have multiple terms");
  drain(cache, a, aux, 0, 1);
  require(cache.init(!aux, ObString::make_string("ngram.1"), view(properties)) == OB_INIT_TWICE,
          "init twice contract");
  drain(cache, a, aux, 1, 2); // Failed init must retain document and original layout.
  const Expected b = prepare(cache, aux, properties, meta, next); // Replace a partly drained document.
  drain(cache, b, aux, 0, b.rows.size());
  const Expected empty = prepare(cache, aux, properties, meta, Sample{"empty", "", Id::empty});
  require(empty.ret == OB_ITER_END, "empty input status");
  drain(cache, empty, aux, 0, 0);
  const Expected active = prepare(cache, aux, properties, meta, first);
  drain(cache, active, aux, 0, 1);
  ObObjMeta invalid;
  invalid.set_type_simple(ObMaxType);
  const Expected bad = prepare(cache, aux, properties, invalid, next);
  require(bad.ret == OB_INVALID_ARGUMENT && bad.rows.empty(), "invalid meta status");
  expect_next(cache, OB_ITER_END);
  ObObjMeta invalid_collation = meta;
  invalid_collation.set_collation_type(CS_TYPE_INVALID);
  const Expected bad_cs = prepare(cache, aux, properties, invalid_collation, next);
  require(bad_cs.ret == OB_INVALID_ARGUMENT && bad_cs.rows.empty(), "invalid collation status");
  expect_next(cache, OB_ITER_END);
  const Expected recovered = prepare(cache, aux, properties, meta, first);
  drain(cache, recovered, aux, 0, 1);
  cache.reuse(); cache.reuse(); expect_next(cache, OB_ITER_END);
  const Expected partial = prepare(cache, aux, properties, meta, next);
  drain(cache, partial, aux, 0, 1);
  cache.reset(); cache.reset(); expect_next(cache, OB_NOT_INIT);
  init(cache, !aux, properties); // Reset allows the other physical layout.
  const Expected flipped = prepare(cache, !aux, properties, meta, next);
  drain(cache, flipped, !aux, 0, flipped.rows.size());
  ++cases;
  std::printf("CASE\t%s\tlifecycle=PASS\n", phase.c_str());
}
} // namespace

int main()
{
  try {
    phase = "real-context-init";
    ContextScope context;
    const auto corpus = samples();
    for (const auto cs : {CS_TYPE_UTF8MB4_BIN, CS_TYPE_UTF8MB4_GENERAL_CI}) {
      phase = "charset-and-datum-function-preflight";
      require(ObCharset::get_charset(cs) != nullptr, "charset unavailable");
      auto *funcs = ObDatumFuncs::get_basic_func(ObVarcharType, cs);
      require(funcs != nullptr && funcs->default_hash_ != nullptr
              && funcs->null_first_cmp_ != nullptr, "real datum function table unavailable");
      ObObjMeta meta;
      meta.set_varchar(); meta.set_collation_type(cs);
      for (const int gram : {1, 2, 3}) {
        const std::string properties = "{\"ngram_token_size\":" + std::to_string(gram) + "}";
        for (const bool aux : {false, true}) {
          const std::string prefix = "cs" + std::to_string(static_cast<int>(cs)) + "/n"
              + std::to_string(gram) + (aux ? "/index/" : "/doc_word/");
          for (const auto &sample : corpus) {
            phase = prefix + sample.name;
            complete_case(aux, properties, meta, sample);
          }
          phase = prefix + "lifecycle";
          lifecycle(aux, properties, meta);
        }
      }
    }
    require(cases == 180 && compared_rows > 0 && stored_rows > 0 && repeated_counts > 0
            && ext_rejections > 0, "coverage summary incomplete");
    std::printf("PASS\tcases=%lld\tcompared_rows=%lld\tstored_rows=%lld\tlifecycle_checks=%lld"
                "\text_conversion_rejections=%lld\trepeated_count_rows=%lld\tchecks=%lld\n",
                static_cast<long long>(cases), static_cast<long long>(compared_rows),
                static_cast<long long>(stored_rows), static_cast<long long>(lifecycle_checks),
                static_cast<long long>(ext_rejections), static_cast<long long>(repeated_counts),
                static_cast<long long>(checks));
    return std::fflush(stdout) == 0 && !std::ferror(stdout) ? 0 : 1;
  } catch (const std::exception &error) {
    std::fprintf(stderr, "FAIL %s\n", error.what());
    return 1;
  }
}
