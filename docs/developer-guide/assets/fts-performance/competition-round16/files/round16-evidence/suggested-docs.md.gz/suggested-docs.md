# Suggested round16 documentation (parent review)

Round16 lazy-row proposal: **REJECT**. The existing six WARN affinity4 runs
record build +2.6705%, tokenize -3.9781%, query +1.6349% and equal-category
overall +0.1091% time reduction; pair totals are -1.666%, -1.333%, +3.022%.
These are the existing local comparison results, not a new formal score or
statistical claim. The parent reports restoring both production DAS files
from exact staged originals; final source/disposition metadata should record
the independent restoration hash check.

Parent native build-2 compiled and linked successfully. parent-run-1 records
execution and validation PASS: 180 cases, 2,646 compared rows, 2,022 stored
rows, 972 lifecycle checks, 228 EXT conversion rejections, 1,154 repeated-count
rows and 241,483 checks. The comparator is the unchanged eager function in
the same production-linked binary, sharing current parser/map dependencies.
The earlier build-1 missing-ObTxDesc include failure is retained. No additional
native coverage or independent-original binary differential is asserted.

The failed DEBUG startup snapshot and successful unscored diagnostic report
are retained separately. Parent-generated bounded runtime snippets and metadata
record a 7,184,985,337-byte excluded log with SHA-256
8eb1fd56e1d399225fb54787ab152ac44f37ed66d5d7651e377e546d0a8a0a8a,
70,057 positive segment messages, 2,059,204 row messages and 54,520 end messages.
Those are execution-path observations, not performance or complete correctness
proof. The gzip evidence manifest preserves raw and packed hashes for exact
proposal/originals, audits, six runs and native receipts/logs; binaries, temporary
files and huge runtime DEBUG logs/data are excluded.
