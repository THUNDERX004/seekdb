"""Offline round16 evidence packaging. Default: inventory only; --execute writes.

Never imports/runs the benchmark, extractor, native helper, build, SQL or Git.
Only reads selected local auxiliary files and writes a NEW child of this folder.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
FTS = HERE.parent
NATIVE = FTS / "round16-row-native"
TEXT = {".cpp", ".h", ".py", ".ps1", ".md", ".json", ".rsp",
        ".log", ".txt", ".patch", ".diff", ".sql"}
BLOCKED = {"tmp", "temp", "data", "log", "logs", "__pycache__",
           "link-intermediate", ".git", ".secrets"}
CHUNK = 1024 * 1024
MAX_FILE = 64 * CHUNK
MAX_TOTAL = 256 * CHUNK


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def sha(path):
    result = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(CHUNK), b""):
            result.update(block)
    return result.hexdigest()


def read_json(path):
    require(path.stat().st_size <= MAX_FILE, f"Oversized metadata: {path}")
    return json.loads(path.read_bytes().decode("utf-8-sig"))


def json_bytes(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def local_file(path):
    resolved = path.resolve()
    require(resolved.is_relative_to(FTS) and resolved.is_file(), f"Not a local auxiliary file: {path}")
    parts = resolved.relative_to(FTS).parts
    require(not any(p.lower() in BLOCKED for p in parts), f"Excluded directory: {path}")
    require(resolved.suffix.lower() in TEXT, f"Not an allowed text/source artifact: {path}")
    require(resolved.stat().st_size <= MAX_FILE, f"Oversized file; no silent truncation: {path}")
    return resolved


def collect(args):
    selected = {}
    optional = {}

    def add(path):
        path = local_file(path)
        selected[path.relative_to(FTS).as_posix()] = path
        return path

    def direct(directory):
        for path in sorted(directory.iterdir()):
            if path.is_file() and path.suffix.lower() in TEXT:
                add(path)

    comparison_path = add(HERE / "comparison.json")
    comparison_sha = sha(comparison_path)
    comparison = read_json(comparison_path)
    expected_labels = {f"r16-lazy-{variant}-a{n}"
                       for variant in ("candidate", "control") for n in range(1, 4)}
    require({r["label"] for r in comparison["runs"]} == expected_labels
            and len(comparison["runs"]) == 6, "Comparison must reference exactly the six completed WARN runs")
    for rel, pin in comparison["input_hashes"].items():
        path = add(FTS / rel)
        require(path.stat().st_size == pin["bytes"] and sha(path) == pin["sha256"],
                f"Comparison input changed: {rel}")
    for label in sorted(expected_labels):
        for suffix in ("experiment.json", "report.txt", "affinity.json", "benchmark.log",
                       "input-validation.log", "server.log"):
            add(FTS / f"{label}-{suffix}")
        item = read_json(FTS / f"{label}-experiment.json")
        require(item["label"] == label and item["log_level"] == "WARN", f"Wrong run identity: {label}")
        for path in sorted(FTS.glob(f"{label}-*")):
            if path.is_file() and path.suffix.lower() in TEXT:
                add(path)

    # DEBUG is archived separately, never passed to scoring/comparison code.
    for label in ("r16-lazy-path-diagnostic", "r16-lazy-path-diagnostic-2"):
        for suffix in ("experiment.json", "affinity.json", "server.log"):
            add(FTS / f"{label}-{suffix}")
        require(read_json(FTS / f"{label}-experiment.json")["log_level"] == "DEBUG",
                f"Wrong diagnostic level: {label}")
        for path in sorted(FTS.glob(f"{label}-*")):
            if path.is_file() and path.suffix.lower() in TEXT:
                add(path)
    for suffix in ("report.txt", "benchmark.log", "input-validation.log"):
        add(FTS / f"r16-lazy-path-diagnostic-2-{suffix}")

    proposal = FTS / "round16-lazy-rows"
    for path in sorted(proposal.rglob("*")):
        if path.is_file():
            add(path)
    require(sha(proposal / "source.patch") == comparison["patch_sha256"], "Proposal patch differs from comparison")
    for dirname in ("round16-path-audit", "round16-row-audit"):
        directory = FTS / dirname
        optional[dirname] = directory.is_dir()
        if directory.is_dir():
            for path in sorted(directory.rglob("*")):
                if path.is_file() and path.suffix.lower() in TEXT:
                    add(path)
    add(FTS / "round16-lazy-rows-build.log")

    # Never descend into native binaries, link intermediates or temp directories.
    direct(NATIVE)
    direct(NATIVE / "capture-plan")
    attempts = []
    for directory in sorted(NATIVE.glob("parent-build-*")):
        if directory.is_dir():
            direct(directory)
            receipt_path = directory / "receipt.json"
            if receipt_path.is_file():
                receipt = read_json(receipt_path)
                attempts.append({"directory": directory.name, "receipt_sha256": sha(receipt_path),
                                 **{key: receipt.get(key, "NOT RECORDED") for key in
                                    ("compile", "link", "native", "build_succeeded", "test_sha256", "settings_sha256")}})
    settings = read_json(NATIVE / "build-settings.json")
    require(sha(NATIVE / "test_fts_lazy_rows.cpp") == settings["test_sha256"], "Native frozen test changed")
    for pin in settings["proposal_pins"]:
        require(sha(proposal / pin["path"]) == pin["candidate_sha256"], "Staged candidate differs from native pins")
        require(sha(proposal / "original" / pin["path"]) == pin["original_sha256"],
                "Staged original differs from native pins")

    native = {"status": "NOT SUPPLIED; no runtime claim", "build_attempts": attempts}
    if args.native_run:
        run_dir = args.native_run.resolve()
        require(run_dir.is_relative_to(NATIVE) and run_dir != NATIVE, "Native run must belong to the helper")
        direct(run_dir)
        run = read_json(add(run_dir / "run.json"))
        receipt = read_json(add(run_dir / "build-receipt.json"))
        require(run["settings_sha256"] == receipt["settings_sha256"] == sha(NATIVE / "build-settings.json"),
                "Native runtime settings identity mismatch")
        require(receipt["test_sha256"] == settings["test_sha256"], "Native run used a different test revision")
        require(run["executable_sha256"] == receipt["executable_sha256"], "Native executable receipt identity mismatch")
        for name, digest in run.get("logs_sha256", {}).items():
            require(name in ("stdout.log", "stderr.log"), "Unexpected native log path")
            require(sha(add(run_dir / name)) == digest, f"Native log changed: {name}")
        is_pass = (run.get("native") == run.get("output_validation") == "PASS"
                   and run.get("exit_code") == 0 and receipt.get("build_succeeded") is True
                   and set(run.get("logs_sha256", {})) == {"stdout.log", "stderr.log"}
                   and bool(run.get("summary")))
        native.update(status="PASS recorded by parent runner" if is_pass else "No validated native PASS",
                      run_directory=run_dir.relative_to(FTS).as_posix(),
                      run_sha256=sha(run_dir / "run.json"), recorded_result=run,
                      limit=("Shared current production parser/map and unchanged eager path in the same linked binary; "
                             "no independent-original native oracle or added coverage claimed"))

    for name in ("extract_path.py", "summarize.py", "runtime-path.json", "runtime-path-snippets.log",
                 "package.py", "PACKAGE.md", "suggested-docs.md"):
        add(HERE / name)
    for name in ("source.json", "disposition.json"):
        path = HERE / name
        optional[name] = path.is_file()
        if path.is_file():
            read_json(add(path))
        elif args.require_final_metadata:
            raise RuntimeError(f"Parent final metadata missing: {path}")
    for pattern in ("*missing*dll*.json", "*missing*dll*.log", "*startup*.json", "*startup*.log"):
        for path in sorted(HERE.glob(pattern)):
            add(path)

    total = sum(path.stat().st_size for path in selected.values())
    require(total <= MAX_TOTAL, "Selected raw evidence exceeds 256 MiB; inspect selection, do not truncate")
    entries = [{"source": rel, "raw_bytes": path.stat().st_size, "raw_sha256": sha(path)}
               for rel, path in sorted(selected.items())]
    metadata = {"decision": "REJECT production proposal (parent decision)",
                "comparison": {"source": comparison_path.relative_to(FTS).as_posix(),
                               "raw_sha256": comparison_sha, "treatment": "Preserved verbatim; no recomputation"},
                "native": native, "optional_available": optional,
                "restoration": ("Parent reports exact-original restoration; see source.json/disposition.json if supplied. "
                                 "Packaging does not inspect D: or independently verify live restoration."),
                "debug": {"failed_startup": "Missing-DLL cause parent-reported; original metadata has no actions.",
                          "runtime_path": read_json(HERE / "runtime-path.json"),
                          "limit": ("Only parent-produced bounded extracts and hash metadata retained. "
                                    "Full runtime log is deliberately not opened or rehashed; DEBUG timing unscored.")},
                "exclusions": ["executables, PDB/LIB/OBJ/DLL and all other non-allowlisted formats",
                               "tmp, data, runtime log directories and native link intermediates",
                               "huge DEBUG runtime log (only bounded extraction included)",
                               "unrelated legacy candidate-v16-build-manifest.json (old master/Bazel context)"],
                "limits": ("No build/runtime/SQL/performance/Git or source restoration performed by packager; "
                           "no new performance statistics, formal score or broader native coverage claimed.")}
    return selected, entries, metadata


def pack(source, target, expected):
    digest = hashlib.sha256()
    size = 0
    target.parent.mkdir(parents=True, exist_ok=True)
    with source.open("rb") as raw, target.open("xb") as packed:
        with gzip.GzipFile(filename="", mode="wb", compresslevel=9, fileobj=packed, mtime=0) as out:
            for block in iter(lambda: raw.read(CHUNK), b""):
                size += len(block)
                require(size <= MAX_FILE, f"File grew beyond bound: {source}")
                digest.update(block)
                out.write(block)
    require(size == expected["raw_bytes"] and digest.hexdigest() == expected["raw_sha256"],
            f"Source changed while packing: {source}")
    restored = hashlib.sha256()
    with gzip.open(target, "rb") as stream:
        for block in iter(lambda: stream.read(CHUNK), b""):
            restored.update(block)
    require(restored.hexdigest() == expected["raw_sha256"], f"Gzip round-trip failed: {source}")
    return {**expected, "path": target.name, "packed_bytes": target.stat().st_size, "packed_sha256": sha(target)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", required=True, type=Path, help="NEW child directory under round16-evidence")
    parser.add_argument("--native-run", type=Path, help="Explicit parent run directory; never inferred from build PASS")
    parser.add_argument("--require-final-metadata", action="store_true", help="Require parent source.json and disposition.json")
    parser.add_argument("--execute", action="store_true", help="Write package; otherwise inventory only, no files written")
    args = parser.parse_args()
    destination = args.output_dir.resolve()
    require(destination.parent == HERE and not destination.exists(), "Use a NEW direct child of round16-evidence")
    selected, entries, metadata = collect(args)
    if not args.execute:
        print(json.dumps({"mode": "PLAN ONLY; no files written", "destination": str(destination),
                          "metadata": metadata, "files": entries}, ensure_ascii=False, indent=2))
        return
    destination.mkdir()
    # An incomplete directory is retained on any failure; absence of COMPLETE.json means incomplete.
    result = []
    for entry in entries:
        relative = Path("files") / (entry["source"] + ".gz")
        item = pack(selected[entry["source"]], destination / relative, entry)
        item["path"] = relative.as_posix()
        result.append(item)
    for item in result:
        require(sha(selected[item["source"]]) == item["raw_sha256"], f"Source changed during packaging: {item['source']}")
    manifest = {"schema_version": 1, "created_utc": datetime.now(timezone.utc).isoformat(),
                "encoding": "Raw byte streams, one gzip member/file; no decode/re-encode or newline conversion",
                "source_root": str(FTS), **metadata, "files": result}
    (destination / "manifest.json").write_bytes(json_bytes(manifest))
    (destination / "COMPLETE.json").write_bytes(json_bytes({"status": "COMPLETE", "file_count": len(result),
                                                         "manifest_sha256": sha(destination / "manifest.json")}))
    print(f"Packaged {len(result)} byte-verified artifacts: {destination / 'manifest.json'}")


if __name__ == "__main__":
    try:
        main()
    except (RuntimeError, OSError, ValueError, KeyError, TypeError) as error:
        print("ERROR:", error, file=sys.stderr)
        sys.exit(1)
