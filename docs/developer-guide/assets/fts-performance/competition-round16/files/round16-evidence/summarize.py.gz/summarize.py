"""Offline round16 comparison. Never runs workloads or changes source."""
import hashlib
import json
from pathlib import Path
import re
from statistics import mean

HERE = Path(__file__).resolve().parent
FTS = HERE.parent
PARENT = "2429553bf0bf9c4e9ca3abf0987ffa8b1ec461c0"
BASELINE = "5bce9e06d1281347ad61344e4b01fab9158c58a2"
PINS = {"candidate": "9f2ddb54c28ef01c5fa12fdaac222748c754166d4a2b618e891553f089c0363b",
        "control": "58a14c4b3cfb44464882de1d87b0f8018c76595a563e039ff3cbd8be2351f07d"}
CLASSES = {"build": ["build_ik_all_sec", "build_ik_content_sec", "build_beng_en_sec"],
           "tokenize": ["tokenize_ik_avg_ms", "tokenize_beng_avg_ms"],
           "query": ["query_cn_avg_ms", "query_beng_avg_ms", "query_mixed_avg_ms", "query_limit_avg_ms"]}
PARAMS = dict(rows=20000, batch=500, rounds=3000, query_rounds=200, samples=3, warmup=30, skip_load=0)
HITS = dict(query_cn_hits=8001, query_beng_hits=11000, query_mixed_hits=7332, query_limit_hits=20)


def main():
    inputs, metadata = {}, {}

    def read(path):
        raw = path.read_bytes()
        inputs[path.relative_to(FTS).as_posix()] = dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
        return raw

    for pair in range(1, 4):
        for variant in PINS:
            label = f"r16-lazy-{variant}-a{pair}"
            path = FTS / f"{label}-experiment.json"
            if not path.exists():
                raise SystemExit("Incomplete: " + label)
            item = json.loads(read(path))
            assert item["label"] == label and item["source_commit"] == PARENT
            assert item["binary_sha256"] == PINS[variant] and item["log_level"] == "WARN"
            assert all(action["exit_code"] == 0 for action in item["actions"])
            assert all(sum(action["action"] == name for action in item["actions"]) == 1
                       for name in ("benchmark", "input-validation"))
            metadata[variant, pair] = item

    reports, runs = {}, []
    for (variant, pair), item in metadata.items():
        label = item["label"]
        path = FTS / f"{label}-report.txt"
        assert Path(item["report"]).resolve() == path.resolve()
        raw = read(path).decode("utf-8-sig")
        assert raw.count("FTS Large Benchmark Report") == 1
        fields = dict(re.findall(r"^([A-Za-z0-9_]+):\s*(.*?)\s*$", raw, re.M))
        assert fields["label"] == label
        assert all(float(fields[key]) == value for key, value in {**PARAMS, **HITS}.items())
        affinity = json.loads(read(FTS / f"{label}-affinity.json"))
        assert affinity["label"] == label and affinity["mask"] == 15
        assert affinity["logical_cpu_ids"] == [0, 1, 2, 3]
        reports[variant, pair] = fields
        runs.append(dict(label=label, binary=item["binary"], binary_sha256=item["binary_sha256"],
                         timestamp=fields["timestamp"], git_head_label=fields["git_head"],
                         git_dirty_label=fields["git_dirty"], affinity=affinity))

    metrics, classes = [], {}
    for category, names in CLASSES.items():
        reductions = []
        for name in names:
            control = [float(reports["control", i][name]) for i in range(1, 4)]
            candidate = [float(reports["candidate", i][name]) for i in range(1, 4)]
            reduction = (mean(control) - mean(candidate)) / mean(control)
            metrics.append(dict(metric=name, control=control, candidate=candidate,
                                control_mean=mean(control), candidate_mean=mean(candidate), reduction=reduction))
            reductions.append(reduction)
        classes[category] = mean(reductions)
    pairs = []
    for i in range(1, 4):
        pair_classes = {category: mean((float(reports["control", i][name]) - float(reports["candidate", i][name]))
                                     / float(reports["control", i][name]) for name in names)
                        for category, names in CLASSES.items()}
        pairs.append(dict(pair=i, class_reductions=pair_classes, overall=mean(pair_classes.values())))
    patch = FTS / "round16-lazy-rows/source.patch"
    patch_hash = hashlib.sha256(read(patch)).hexdigest()
    assert patch_hash == "3ae2a4aeb6b3e24c112017379dcbb9d65d34b8e3f3209f3d15001b2cdbffbe94"
    result = dict(schema_version=1, experiment="round16-lazy-rows", parent_commit=PARENT,
                  official_baseline=BASELINE, patch_sha256=patch_hash, binary_pins=PINS,
                  parameters=PARAMS, hits_all_runs=HITS,
                  method="Per metric ratio of three-run means; arithmetic mean within each category, then equal mean of three categories. All negative results retained; no SELECT1 subtraction.",
                  limits="Incremental Windows local comparison only. Logical CPUs 0..3 (mask 15), serial complete workloads. Separate from unrestricted historical series. DEBUG diagnostic excluded. No new official score or statistical significance claimed.",
                  metrics=metrics, class_reductions=classes, overall_reduction=mean(classes.values()),
                  pairs=pairs, runs=runs, input_hashes=inputs)
    output = HERE / "comparison.json"
    raw = (json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + "\n").encode("utf-8")
    if output.exists():
        assert output.read_bytes() == raw, "Refusing to replace differing summary"
    else:
        output.write_bytes(raw)
    print(json.dumps(dict(class_reductions=classes, overall_reduction=result["overall_reduction"],
                          per_pair=[row["overall"] for row in pairs]), indent=2))


if __name__ == "__main__":
    main()
