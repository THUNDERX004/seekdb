"""Retain bounded runtime path evidence from the separate unscored DEBUG run."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
LOG = Path(r"C:\Users\11946\AppData\Local\Temp\seekdb-fts-r16-lazy-path-diagnostic-2\log\seekdb.log")
digest = hashlib.sha256()
counts = {"segment": 0, "row": 0, "end": 0}
saved = {name: 0 for name in counts}
snippets, size = [], 0
with LOG.open("rb") as stream:
    for line_no, line in enumerate(stream, 1):
        digest.update(line)
        size += len(line)
        if b"ob_das_domain_utils.cpp:122)" in line and b"word segment(ret=0" in line:
            key = "segment"
        elif b"ob_das_domain_utils.cpp:147)" in line and b"get next row(ret=0" in line:
            key = "row"
        elif b"ob_das_domain_utils.cpp:147)" in line and b"get next row(ret=-4008" in line:
            key = "end"
        else:
            continue
        counts[key] += 1
        if saved[key] < 3:
            snippets.append(str(line_no).encode("ascii") + b": " + line)
            saved[key] += 1
assert all(counts.values()) and size == LOG.stat().st_size
result = dict(source_log=str(LOG), bytes=size, sha256=digest.hexdigest(), counts=counts,
              explanation="First three matching lines per message retained in stream order, with original one-based line numbers. Positive segments and rows prove the actual official ALTER build reaches the candidate. DEBUG timing excluded. This is execution-path evidence, not performance or full correctness proof.")
for name, raw in (("runtime-path-snippets.log", b"".join(snippets)),
                  ("runtime-path.json", (json.dumps(result, indent=2) + "\n").encode("utf-8"))):
    target = HERE / name
    if target.exists():
        assert target.read_bytes() == raw
    else:
        target.write_bytes(raw)
print(json.dumps(result, indent=2))
