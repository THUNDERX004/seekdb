# Round16 offline evidence package

Prepared only; the packaging script has not been executed. Parent runs it after
all evidence writers have stopped. No production, build, runtime, SQL, performance
or Git command is invoked. Output must be a NEW direct child of this directory.
Existing comparison.json is never written, recomputed or normalized.

## Parent commands

After the parent supplies source.json and disposition.json here, first review
the read-only inventory. Both JSON files are preserved verbatim, without assuming
a schema or manufacturing a live-restoration verification. Remove
--require-final-metadata only if an explicitly incomplete evidence package is wanted.

```powershell
$evidence = 'C:/Users/11946/Documents/ChatGPT/OceanBase比赛/setup/fts/round16-evidence'
$python = 'C:/Users/11946/Documents/ChatGPT/OceanBase比赛/.venv/Scripts/python.exe'
$nativeRun = 'C:/Users/11946/Documents/ChatGPT/OceanBase比赛/setup/fts/round16-row-native/parent-run-1'

# Inventory only; writes nothing. Do not invoke while parent is changing evidence.
& $python "$evidence/package.py" --output-dir "$evidence/archive-1" `
  --native-run $nativeRun --require-final-metadata
if ($LASTEXITCODE -ne 0) { throw 'Evidence inventory failed' }

# Final packaging: parent invokes only when ready. No build/test is launched.
& $python "$evidence/package.py" --output-dir "$evidence/archive-1" `
  --native-run $nativeRun --require-final-metadata --execute
if ($LASTEXITCODE -ne 0) { throw 'Package incomplete; preserve failed directory and use a fresh name after fixing inputs' }
```

## Selection and preservation

- Exact staged proposal, both original DAS files, source.patch and proposal README.
  Patch and original/candidate hashes must match existing comparison/native pins.
- Six completed WARN affinity4 runs: reports, benchmark/input-validation/server
  console logs, experiment metadata, affinity, and extra candidate-a1 regression logs.
- Both available round16 audit directories, optional if absent.
- Failed DEBUG startup experiment/affinity/console snapshot and successful DEBUG
  diagnostic report/metadata/console/harness logs, separate from scored WARN runs.
  The failed snapshot has empty actions and no report; missing-DLL causation is
  parent-reported unless a separate startup/missing-DLL evidence file is supplied.
- runtime-path.json and bounded runtime-path-snippets.log, plus extraction script.
  The 7,184,985,337-byte full runtime DEBUG log/data are never opened or included.
- Native source/settings/helper scripts/README, capture response files and receipt,
  every available parent-build attempt's direct text receipts/logs/commands/response
  files, and the explicitly selected parent's run.json, build-receipt.json and logs.
  No native status is inferred from compilation/linking alone.
- Existing summary/extractor, these packaging files, production build console log
  and optional parent source.json/disposition.json. No D: path is opened.

Native metadata/log identities are checked against the current frozen test and
settings and the run's copied build receipt. Actual parent-run-1 records PASS
for native execution and output validation: 180 cases, 2,646 compared rows,
2,022 stored rows, 972 lifecycle checks, 228 EXT conversion rejections,
1,154 repeated-count rows and 241,483 checks. These are recorded test counters,
not new coverage claims. The unchanged eager comparator shares the current
production parser/map in the same binary; no independent-original native oracle,
allocation-failure/spill/concurrency or broader parser coverage is claimed.

All selected artifacts are streamed in binary mode into individual .gz files.
No newline conversion occurs, including LF source. The manifest records each
source-relative path, raw bytes/SHA-256 and packed bytes/SHA-256. A gzip
round-trip and source rehash are checked. COMPLETE.json pins the manifest and
is written last; a directory lacking it is incomplete. No overwrite/resume.

EXE/PDB/LIB/OBJ/DLL, native link intermediates/tmp, data and runtime log
directories are excluded by selection, extension and directory allowlists.
The unrelated historical candidate-v16-build-manifest.json is not selected.
There is a 64 MiB per-file and 256 MiB total raw bound; oversize fails rather
than truncating or including a huge runtime stream. Gzip mtime/filename headers
are fixed; packed bytes can still vary with Python/zlib versions. Raw SHA-256
is the authoritative preserved-byte identity.

The script does not verify live D: restoration, rerun diagnostics, independently
rehash the excluded DEBUG stream, establish a formal score or add statistical
claims. Parent evidence owns those observations. Suggested documentation is
separate in suggested-docs.md; no repository documentation is edited here.
