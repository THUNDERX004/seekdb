"""Read-only plans after the unchanged benchmark has completed."""
import argparse, json, pymysql
p=argparse.ArgumentParser(); p.add_argument('--port',type=int,default=2891); a=p.parse_args()
queries=[
"SELECT COUNT(*) FROM fts_large_bench.docs WHERE MATCH(title,content) AGAINST('全文索引 分词器')",
"SELECT COUNT(*) FROM fts_large_bench.docs WHERE MATCH(title_en,content_en) AGAINST('database performance audit')",
"SELECT COUNT(*) FROM fts_large_bench.docs WHERE MATCH(title,content) AGAINST('OceanBase 稳定 database')",
"SELECT COUNT(*) FROM (SELECT id FROM fts_large_bench.docs WHERE MATCH(content) AGAINST('倒排索引 tokenizer') LIMIT 20) t",
]
with pymysql.connect(host='127.0.0.1',port=a.port,user='root',charset='utf8mb4',autocommit=True) as conn:
 with conn.cursor() as cur:
  for q in queries:
   cur.execute('EXPLAIN EXTENDED '+q)
   print(json.dumps({'query':q,'plan':cur.fetchall()},ensure_ascii=False,default=str))
