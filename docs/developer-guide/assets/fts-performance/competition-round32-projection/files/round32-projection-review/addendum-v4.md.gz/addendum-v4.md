# V4 static follow-up

No new actionable Major/Blocker was found in the revised test. The previous
`report.md` describes v3 and remains historical; its hint-evidence defect is
addressed in v4 source, with actual execution still pending the parent's serial
benchmark gate. Parent had already made this correction before that report.

Reviewed file: `D:/Projects/OceanBase/seekdb/unittest/storage/fts/test_counted_limit_projection.py`
(9,381 bytes), SHA-256
`9a7589557f23e98cc230c2796f49e80e2d57224fb1158c4a1cda44135a5578db`.
Earlier reviewed v3 SHA-256 was
`4458762ff0021dce46fcaa18c63d782e721f5064e7c04910fc03ea509712e528`.

At lines104-114, disabling hints now target the limited child SELECT, matching
the existing rule's child-hint checks. EXPLAIN EXTENDED replaces plain EXPLAIN,
and the explicit `is_index_back=true` assertion prevents the previously observed
pruned plan from silently passing. Lines116-132 require an outline section,
replay its generated directives, and check the exact count. With `--check-plans`,
the unhinted positive control must contain `PROJECT_PRUNE(` and the replayed
plan must have index-back false, with no index-back true. Result/plan replay
does not establish that every unrelated outline directive was enforced.

The production patch was unchanged at follow-up entry (source SHA-256
`192d7920768202dd761d32ede91b5af55feadacd8a572f8f0d360959e7a09768`);
the prior production review found no concrete Major/Blocker. This addendum
reviews only v4 test changes. Reads matched the supplied v4 hash and were
stable during inspection; Python AST parsing was syntax-only, without imports
or execution. No v4 runtime PASS is claimed. V3 result checks remain distinct
from its inadequate hint proof. Only this auxiliary addendum was added; no
D writes, build, runtime, SQL, Git or broader investigation occurred.
