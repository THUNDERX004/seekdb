# Major: the hint regression passes while projection pruning still occurs

Location: `D:/Projects/OceanBase/seekdb/unittest/storage/fts/test_counted_limit_projection.py:113`
(hint placement at `:104`).

The two negative cases do not establish the promised rewrite opt-out. They place
`NO_REWRITE`/`NO_PROJECT_PRUNE` on the outer COUNT query, then accept the absence
of `PROJECT_PRUNE(` in ordinary EXPLAIN output. The existing projection rule
checks the **derived child's** hint in
`src/sql/rewrite/ob_transform_project_pruning.cpp:231-249`; its outer-block
`check_hint_status()` enables traversal without outline data (`:202-203`).
The saved plans contain no outline section, so the regex cannot establish
whether this transformation occurred.

This is demonstrated by the parent's actual
`setup/fts/r32-projection-candidate-regression-a1-counted-limit-plans.json`:
**both supposedly disabling cases still have** inner `output([1])`,
`access(nil)`, `is_index_back=false`, identical to the unhinted pruned plan.
Both assertions nevertheless passed. The official-original a2 plans retain
`output([docs.id])`, `access([docs.id])`, `is_index_back=true` under those same
labels. Thus the new test can remain green without exercising the intended
hint-protected fallback. This is a demonstrated **test-evidence defect**, not a
demonstrated production violation of query-block hint semantics.

Smallest fix: place each disabling hint inside the limited derived SELECT
(or explicitly target its named query block), and compare with the unhinted
candidate. Require the disabled plan to retain `docs.id` output/access and the
fixture's index-back path while preserving the exact count. If checking applied
rewrite hints, request actual outline output and first assert that the unhinted
positive control contains the expected generated hint; absence alone in a
non-outline plan is insufficient. Parent should run this focused correction;
this review executed no SQL.

No other concrete production Major/Blocker was identified in the inspected
shape guard, rule-mask intersection, existing projection deletion/dummy output,
reference formalization, or outline-admission paths. The actual source matches
the frozen 68-addition/zero-deletion patch; reversing it in memory reproduces
the pinned normalized preimage. Review followed the repository code-review
skill. Broader guard/error cases and outline replay were inspected statically,
not executed; parent-reported passes are not independent runs by this sidecar.
The repaired unique-ID ordering oracle is the version reviewed. No D edits,
Git, build, runtime, SQL, source changes or large binary hashes were performed.

Frozen input SHA-256:

- Actual source: `192d7920768202dd761d32ede91b5af55feadacd8a572f8f0d360959e7a09768`
- Actual test: `4458762ff0021dce46fcaa18c63d782e721f5064e7c04910fc03ea509712e528`
- Proposal patch: `6b7f886c3a65418fdf82ef53dddc8b52ff5a7a66432d65493999b1980d3cc27b`
- Candidate saved plans: `f82fd15bffea8d7d36cdf32556894529e36b6b9c0be5e21b59791291d1d39e31`
- Official-original a2 saved plans: `adbd2388fbf86edc864c2bdfde720bb30273544767ec21cbafe923b879990b9d`
