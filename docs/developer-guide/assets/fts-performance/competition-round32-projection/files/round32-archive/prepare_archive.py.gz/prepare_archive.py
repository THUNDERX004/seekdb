"""Freeze only the explicit R32 offline archive inputs; never import run helpers."""
from pathlib import Path
import argparse
import hashlib
import json

HERE = Path(__file__).resolve().parent
FTS = HERE.parent
DIRECTORIES = ('round32-limit-profile-plan', 'round32-limit-lines',
               'round32-count-limit-proposal', 'round32-projection-review')
EXACT = ('round32-counted-limit-test.py', 'round32-advance-diagnostic-build.log',
         'round32-projection-candidate-build.log', 'round19-evidence/summarize-template.py',
         'round27-root-evidence/experiment-with-exit.py', 'round21-tokenizer-cycle/sample-tokenize.py',
         'round18-cycle-profile/sample-competition.py', 'explain-competition.py')
FORBIDDEN = {'.exe', '.pdb', '.dll', '.obj', '.lib', '.ilk', '.exp', '.tmp', '.pyc', '.dmp'}


def save(path, data):
    with path.open('xb') as stream:
        stream.write((json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False) + '\n').encode('utf-8'))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--prepare', action='store_true')
    args = parser.parse_args()
    if not args.prepare or (HERE / 'selection.json').exists() or (HERE / 'package').exists():
        raise RuntimeError('Use --prepare once before package creation')
    selected = {FTS / name for name in EXACT}
    for name in DIRECTORIES:
        selected.update(path for path in (FTS / name).rglob('*') if path.is_file())
    selected.update(path for path in FTS.iterdir() if path.is_file() and
                    (path.name.startswith('r32-projection-') or path.name.startswith('r32-advance-diagnostic-a1-')))
    files = []
    for path in sorted(selected, key=lambda p: p.relative_to(FTS).as_posix()):
        relative = path.relative_to(FTS).as_posix()
        if not path.is_file() or path.is_symlink() or not path.resolve().is_relative_to(FTS):
            raise RuntimeError('Missing/unsafe input: ' + relative)
        if path.suffix.lower() in FORBIDDEN or any(part.lower() in
                {'.secrets', 'data', 'runtime', '__pycache__', 'temp', 'tmp'} for part in path.parts):
            raise RuntimeError('Excluded artifact unexpectedly selected: ' + relative)
        raw = path.read_bytes()
        if len(raw) > 8 * 1024 * 1024:
            raise RuntimeError('Unexpected large input: ' + relative)
        files.append(dict(source=relative, bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest()))
    expected_commit_files = {'round32-limit-profile-plan/production-commit.json',
                             'round32-limit-profile-plan/commit-projection.py'}
    if not expected_commit_files.issubset({item['source'] for item in files}):
        raise RuntimeError('Missing new parent promotion evidence')
    if sum(item['bytes'] for item in files) >= 30 * 1024 * 1024:
        raise RuntimeError('Selection exceeds bounded raw budget')
    labels = sorted(path.name.removesuffix('-experiment.json') for path in selected
                    if path.parent == FTS and path.name.endswith('-experiment.json'))
    labels += ['r32-limit-rebuilt-a1-instance', 'r32-limit-rebuilt-long-a1-instance']
    save(HERE / 'selection.json', dict(status='FROZEN_EXPLICIT_SELECTION', files=files, labels=labels,
         selection_policy=dict(directories=list(DIRECTORIES), flat_prefixes=['r32-projection-', 'r32-advance-diagnostic-a1-'],
                               exact=list(EXACT)),
         omissions=['EXE/PDB/DLL/OBJ/LIB and other build intermediates, live runtime/data/temp and credentials are excluded; inherited binary hashes only.',
                    'No round33 or other unrelated experiment results; five older helper sources are included solely as R32 harness dependencies/provenance.',
                    'No live D production or test copy; source, patch and v1-v4 test identities come from frozen C inputs.',
                    'No new native fixture or native-pass assertion; RIP/counter captures are profiling evidence.',
                    'Historical reports remain untouched; two new round32 reports are published separately.',
                    'Production commit receipt and commit helper source included before freeze; helper is archived without execution.']))
    checked = []
    for name in ('archive.py', 'verify_archive.py', 'publish.py', 'prepare_archive.py'):
        raw = (HERE / name).read_bytes()
        compile(raw, str(HERE / name), 'exec')
        checked.append(dict(path=name, bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest()))
    save(HERE / 'syntax-check.json', dict(status='PASS', method='Python compile(bytes, filename, exec) only; no imports or archived helper execution', files=checked))
    print(json.dumps(dict(status='FROZEN', input_files=len(files), raw_bytes=sum(item['bytes'] for item in files), labels=labels), indent=2))


if __name__ == '__main__':
    main()
