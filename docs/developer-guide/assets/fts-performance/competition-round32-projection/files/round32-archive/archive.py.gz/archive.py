"""Offline R32 archive: fixed C package, frozen raw bytes, no workload execution."""
from pathlib import Path
import argparse
import gzip
import hashlib
import json
import re

HERE = Path(__file__).resolve().parent
FTS = HERE.parent
PLAN = FTS / 'round32-limit-profile-plan'
DEST = HERE / 'package'
EXPERIMENT = 'round32-projection-retained'


def need(ok, message):
    if not ok:
        raise RuntimeError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def load(path):
    return json.loads(path.read_bytes())


def save(path, value):
    with path.open('xb') as stream:
        stream.write((json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n').encode('utf-8'))


def final_gates():
    app = load(PLAN / 'projection-application.json')
    for name, field in [('projection-original.cpp', 'original_sha256'),
                        ('projection-candidate.cpp', 'candidate_sha256')]:
        need(sha((PLAN / name).read_bytes()) == app[field], 'Projection source snapshot mismatch')
    proposal = FTS / 'round32-count-limit-proposal'
    patch_raw = (proposal / 'proposal.patch').read_bytes()
    need(sha(patch_raw) == app['patch_sha256'], 'Frozen patch mismatch')
    # Reverse the exact 68-line addition in memory, with all context checked.
    lines = patch_raw.decode('utf-8').splitlines(keepends=True)
    candidate = (PLAN / 'projection-candidate.cpp').read_bytes().decode('utf-8').replace('\r\n', '\n').splitlines(keepends=True)
    out, cursor, index, added, deleted = [], 0, 2, 0, 0
    while index < len(lines):
        match = re.fullmatch(r'@@ -(\d+),(\d+) \+(\d+),(\d+) @@\n', lines[index])
        need(match is not None, 'Unexpected patch hunk')
        start = int(match[3]) - 1
        out.extend(candidate[cursor:start]); cursor = start; index += 1
        while index < len(lines) and not lines[index].startswith('@@ '):
            line = lines[index]; index += 1
            if line.startswith('+'):
                need(candidate[cursor] == line[1:], 'Added source differs'); cursor += 1; added += 1
            elif line.startswith(' '):
                need(candidate[cursor] == line[1:], 'Context differs'); out.append(line[1:]); cursor += 1
            elif line.startswith('-'):
                out.append(line[1:]); deleted += 1
            else:
                raise RuntimeError('Unexpected patch record')
    out.extend(candidate[cursor:])
    need(added == 68 and deleted == 0 and ''.join(out) ==
         (PLAN / 'projection-original.cpp').read_bytes().decode('utf-8').replace('\r\n', '\n'), 'Patch/preimage mismatch')
    updates = [load(PLAN / name) for name in ('projection-test-update.json', 'projection-test-oracle-repair.json', 'projection-test-hint-update.json')]
    versions = [(PLAN / ('counted-limit-test-v' + str(i) + '.py')).read_bytes() for i in (1, 2, 3)]
    final_test = (FTS / 'round32-counted-limit-test.py').read_bytes()
    need(sha(versions[0]) == app['test_sha256'] == updates[0]['before_sha256'], 'Test v1 mismatch')
    need(sha(versions[1]) == updates[0]['sha256'] == updates[1]['before_sha256'], 'Test v2 mismatch')
    need(sha(versions[2]) == updates[1]['sha256'] == updates[2]['before_sha256'], 'Test v3 mismatch')
    need(sha(final_test) == updates[2]['sha256'] == '9a7589557f23e98cc230c2796f49e80e2d57224fb1158c4a1cda44135a5578db', 'Test v4 mismatch')

    proof = load(PLAN / 'parent-focused-verification.json')
    need(proof['status'] == 'PASS' and proof['cases'] == 399 and proof['complete_stdout_lines'] == 400, 'Focused parent gate incomplete')
    logs = [(FTS / (label + '-counted-limit.log')).read_bytes() for label in
            ('r32-projection-official-regression-a3', 'r32-projection-candidate-regression-a2')]
    need(logs[0] == logs[1] and sha(logs[0]) == proof['stdout_sha256'], 'Final full stdout byte mismatch')
    lines = logs[0].splitlines()
    need(len(lines) == 400 and lines[-1] == b'PASS counted-limit-projection cases=399'
         and all(line.startswith(('CASE ' + str(i) + ' ').encode()) for i, line in enumerate(lines[:-1])), 'Focused complete-case records mismatch')
    for variant, label in [('official', 'r32-projection-official-regression-a3'), ('candidate', 'r32-projection-candidate-regression-a2')]:
        plans = load(FTS / (label + '-counted-limit-plans.json'))
        hints = {item['hint']: item['plan'] for item in plans if 'hint' in item}
        need(set(hints) == {'NO_REWRITE', 'NO_PROJECT_PRUNE'}, 'Missing child hint plans')
        for text in hints.values():
            need('is_index_back=true' in text and re.search(r'output\(\[docs\.id(?:\([0-9A-Fa-f]+\))?\]\)', text)
                 and re.search(r'(?<!NO_)PROJECT_PRUNE\(', text) is None, 'Opt-out did not retain output/index-back')
        replay = [item for item in plans if 'outline_source' in item]
        need(len(replay) == 1 and 'BEGIN_OUTLINE_DATA' in replay[0]['outline_source'], 'Outline source missing')
        if variant == 'candidate':
            need('PROJECT_PRUNE(' in replay[0]['outline_source'] and 'is_index_back=false' in replay[0]['outline_replay']
                 and 'is_index_back=true' not in replay[0]['outline_replay'], 'Candidate outline replay gate incomplete')
        receipt = load(FTS / (label + '-experiment.json'))
        need(all(item['exit_code'] == 0 for item in receipt['actions']), 'Final focused action failed')
    failed = (FTS / 'r32-projection-official-regression-a1-counted-limit.log').read_bytes()
    need(b'AssertionError:' in failed and b'3580' in failed, 'Missing initial oracle failure')
    early = load(FTS / 'r32-projection-official-regression-a1-experiment.json')
    need(any(item['exit_code'] == 1 for item in early['actions']), 'Initial failure receipt missing')
    # Preserve the v3 hint weakness rather than retroactively calling it validated.
    old_plans = load(FTS / 'r32-projection-candidate-regression-a1-counted-limit-plans.json')
    need(all('is_index_back=false' in item['plan'] for item in old_plans if 'hint' in item), 'Historical hint evidence changed')

    comparison = load(PLAN / 'projection-comparison-3pair.json')
    need(comparison['status'] == 'COMPLETE' and comparison['completed_pairs'] == 3, 'Missing final three pairs')
    for name in ('projection-comparison-1pair.json', 'projection-comparison-3pair.json'):
        for filename, pin in load(PLAN / name)['input_hashes'].items():
            need(Path(filename).name == filename, 'Unexpected comparison input path')
            raw = (FTS / filename).read_bytes()
            need(sha(raw) == pin['sha256'] and len(raw) == pin['bytes'], 'Comparison input changed')
    need(abs(comparison['aggregate']['overall_improvement'] - 0.05120835876555311) < 1e-14, 'Unexpected aggregate')
    regression = load(FTS / 'r32-projection-candidate-regression-a1-experiment.json')
    need(len(regression['actions']) == 10 and all(item['exit_code'] == 0 for item in regression['actions']), 'Full regression gate incomplete')
    for name in ('round32-advance-diagnostic-build.log', 'round32-projection-candidate-build.log'):
        need(b'Linking CXX executable' in (FTS / name).read_bytes(), 'Missing successful build record')

    captures = {}
    for label, raw_count, effective, state, rounds in [('r32-limit-rebuilt-a1-instance', 1103, 387, 'insufficient_samples', 8000),
                                                       ('r32-limit-rebuilt-long-a1-instance', 4267, 1499, 'complete', 32000)]:
        root = PLAN / label / 'diagnostic'
        profile, receipt = load(root / 'profile.json'), load(root / 'receipt.json')
        quality = profile['query_limit_sample_quality']
        need(profile['status'] == receipt['status'] == state and quality['raw_valid_captures'] == raw_count
             and quality['effective_target_resolved_samples'] == effective and quality['target_unresolved_samples'] == 0,
             'Profile quality mismatch')
        for prefix, count in [('warmup', 30), ('measured', rounds)]:
            output = (root / (prefix + '.stdout.log')).read_bytes()
            need(len(output.splitlines()) == count and all(line == b'20' for line in output.splitlines())
                 and not (root / (prefix + '.stderr.log')).read_bytes(), 'Profile full query output mismatch')
        captures[label] = dict(status=state, raw_captures=raw_count, effective_target_samples=effective,
                               target_unresolved=0, rounds=rounds)
    counters = load(PLAN / 'advance-diagnostic-summary.json')
    need(sha((PLAN / 'advance-diagnostic-counts.txt').read_bytes()) == counters['raw_sha256']
         and counters['values']['calls'] == 4096 and sum(counters['skip_buckets'].values()) == 4096, 'Diagnostic counter evidence mismatch')
    restored = load(PLAN / 'advance-diagnostic-restoration.json')
    need(restored['status'] == 'RESTORED_EXACT' and restored['source_sha256'] == app['diagnostic_restored_sha256'], 'Diagnostic restoration mismatch')
    promotion = load(PLAN / 'production-commit.json')
    need(promotion['status'] == 'COMMITTED_AND_PUSHED' and
         promotion['head'] == promotion['remote'] == '5cc947bad132c7705e07da461089ff666dc63e60' and
         promotion['paths'] == ['src/sql/rewrite/ob_transformer_impl.cpp',
                                'unittest/storage/fts/test_counted_limit_projection.py'], 'Parent promotion receipt mismatch')
    need((PLAN / 'commit-projection.py').is_file(), 'Missing commit helper source; never executed by archiver')
    return dict(decision='RETAIN', decision_provenance='Parent production/test promotion receipt; no independent Git or remote inspection by archiver.',
                accepted_commit=promotion['head'], parent_promotion_receipt=promotion,
                source_snapshots=dict(original=app['original_sha256'], candidate=app['candidate_sha256'], patch=app['patch_sha256'],
                                      final_test=sha(final_test), added=68, deleted=0),
                complete_pairs=3, aggregate=comparison['aggregate'], pair_results=comparison['pairs'],
                focused=proof, profiling=captures, diagnostic_counters=counters,
                history='Initial oracle failure and all v1-v4 sources retained. V3 result checks do not establish hint opt-out. V4 actual parent gates PASS.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true')
    args = parser.parse_args()
    need(args.execute and HERE.name == 'round32-archive' and not DEST.exists(), 'Use --execute with a fresh fixed package')
    gates = final_gates()
    selection = load(HERE / 'selection.json')
    paths = {}
    for item in selection['files']:
        path = FTS / item['source']
        need(path.resolve().is_relative_to(FTS) and not path.is_symlink(), 'Input escapes FTS')
        raw = path.read_bytes()
        need(len(raw) == item['bytes'] and sha(raw) == item['sha256'], 'Frozen input changed: ' + item['source'])
        paths[path] = (len(raw), sha(raw))
    for item in load(HERE / 'syntax-check-final.json')['files']:
        need(sha((HERE / item['path']).read_bytes()) == item['sha256'], 'Final helper syntax pin changed')
    for name in ('archive.py', 'verify_archive.py', 'publish.py', 'prepare_archive.py', 'README.md', 'report.en.md', 'report.zh-CN.md', 'selection.json', 'syntax-check.json', 'syntax-check-final.json', 'archive-attempt-1.json'):
        path = HERE / name; raw = path.read_bytes(); paths[path] = (len(raw), sha(raw))
    need(sum(x[0] for x in paths.values()) < 32 * 1024 * 1024, 'Raw archive budget exceeded')
    DEST.mkdir()
    entries = []
    for path, pin in sorted(paths.items(), key=lambda item: item[0].relative_to(FTS).as_posix()):
        raw = path.read_bytes(); rel = path.relative_to(FTS).as_posix()
        need((len(raw), sha(raw)) == pin, 'Source changed while packing')
        packed = gzip.compress(raw, compresslevel=9, mtime=0)
        out = DEST / 'files' / (rel + '.gz'); out.parent.mkdir(parents=True, exist_ok=True)
        with out.open('xb') as stream:
            stream.write(packed)
        need(gzip.decompress(packed) == raw, 'Gzip exact-byte mismatch')
        entries.append(dict(source=rel, path='files/' + rel + '.gz', raw_bytes=len(raw), raw_sha256=sha(raw),
                            packed_bytes=len(packed), packed_sha256=sha(packed)))
    need(all((path.stat().st_size, sha(path.read_bytes())) == pin for path, pin in paths.items()), 'Frozen source changed before completion')
    manifest = dict(schema=1, experiment=EXPERIMENT, decision='RETAIN', gates=gates,
                    labels=selection['labels'], omissions=selection['omissions'], files=entries,
                    documents={'en':'docs/developer-guide/en/competition-round32.md', 'zh-CN':'docs/developer-guide/zh-CN/competition-round32.md'},
                    limits=['Local incremental evidence only; no new formal, cumulative or full score.',
                            'Unrelated build/tokenize/query volatility is not causally attributed to projection pruning.',
                            'All signed samples retained, including pair3 LIMIT regression; no timing corrections.',
                            'Intrusive RIP/counter evidence is not stacks, CPU percentages or universal path coverage.',
                            'Historical PREPARED/UNPROMOTED metadata remains unchanged; later receipts and parent disposition describe completion.',
                            'Source and final test archived exclusively from C snapshots; no live D production source inspected or copied.'])
    save(DEST / 'manifest.json', manifest)
    result = dict(status='COMPLETE', file_count=len(entries), manifest_sha256=sha((DEST / 'manifest.json').read_bytes()),
                  raw_bytes=sum(x['raw_bytes'] for x in entries), packed_bytes=sum(x['packed_bytes'] for x in entries))
    save(DEST / 'COMPLETE.json', result)
    save(HERE / 'archive-summary.json', dict(result, package=str(DEST), execution='Offline archive only; no build/server/native/SQL/Git'))
    print(json.dumps(dict(result, package=str(DEST)), indent=2))


if __name__ == '__main__':
    main()
