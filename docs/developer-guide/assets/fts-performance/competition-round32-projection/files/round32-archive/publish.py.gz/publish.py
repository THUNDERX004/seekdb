"""Publish only NEW round32 assets and two NEW reports, never historical reports."""
from pathlib import Path
import argparse
import hashlib
import json

HERE = Path(__file__).resolve().parent
ROOT = Path('D:/Projects/OceanBase/seekdb')
DEST = ROOT / 'docs/developer-guide/assets/fts-performance/competition-round32-projection'
DOCS = ROOT / 'docs/developer-guide'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--publish', action='store_true')
    args = parser.parse_args()
    if not args.publish:
        raise RuntimeError('Explicit --publish required')
    package = HERE / 'package'
    manifest_raw = (package / 'manifest.json').read_bytes()
    manifest = json.loads(manifest_raw)
    complete = json.loads((package / 'COMPLETE.json').read_bytes())
    assert manifest['experiment'] == 'round32-projection-retained' and manifest['decision'] == 'RETAIN'
    assert complete['status'] == 'COMPLETE' and complete['manifest_sha256'] == sha(manifest_raw)
    assert not DEST.exists()
    reports = [(DOCS / language / 'competition-round32.md', HERE / source)
               for language, source in [('en', 'report.en.md'), ('zh-CN', 'report.zh-CN.md')]]
    assert all(not target.exists() and target.parent.is_dir() for target, source in reports)
    expected = {'manifest.json', 'COMPLETE.json'} | {item['path'] for item in manifest['files']}
    actual = {p.relative_to(package).as_posix() for p in package.rglob('*') if p.is_file()}
    assert actual == expected
    # Pin only the two existing top-level historical reports, without altering them.
    historical = {DOCS / language / 'fts-performance.md': sha((DOCS / language / 'fts-performance.md').read_bytes())
                  for language in ('en', 'zh-CN')}
    DEST.mkdir()
    written = []
    for relative in sorted(expected):
        source, target = package / relative, DEST / relative
        assert target.resolve().is_relative_to(DEST.resolve())
        target.parent.mkdir(parents=True, exist_ok=True)
        raw = source.read_bytes()
        with target.open('xb') as stream:
            stream.write(raw)
        assert target.read_bytes() == raw
        written.append(target.relative_to(ROOT).as_posix())
    for target, source in reports:
        raw = source.read_bytes()
        with target.open('xb') as stream:
            stream.write(raw)
        assert target.read_bytes() == raw
        written.append(target.relative_to(ROOT).as_posix())
    assert all(sha(path.read_bytes()) == digest for path, digest in historical.items())
    result = dict(status='PUBLISHED_NEW_FILES_ONLY', manifest_sha256=sha(manifest_raw),
                  file_count=complete['file_count'], changed_repository_paths=written,
                  historical_reports_unchanged={str(path.relative_to(ROOT)): digest for path, digest in historical.items()},
                  execution='Offline copy only; no source/build/runtime/Git mutations')
    with (HERE / 'publication.json').open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(result, stream, indent=2); stream.write('\n')
    print(json.dumps({key: value for key, value in result.items() if key != 'changed_repository_paths'}, indent=2))


if __name__ == '__main__':
    main()
