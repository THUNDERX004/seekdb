# R32 accepted projection archive

Offline-only archive of the retained 68-line projection change and 399-case
test. Parent commit/push receipt:5cc947bad132c7705e07da461089ff666dc63e60.
This helper executes no build, native test, server, SQL or Git operation.
Archived workload/commit helper scripts are provenance, never invoked here.

The selection includes all existing files in four named R32 evidence folders,
all r32-projection-* and r32-advance-diagnostic-a1-* flat artifacts, two build
logs, final test snapshot and five exact reused helper sources. Selection is
frozen with raw bytes/SHA before packaging. All raw streams are gzip-compressed
with mtime0; manifest.json records separate raw/packed lengths and SHA-256.
Historical files and statuses are preserved, including oracle failure and
v3 hint weakness. Later v4 verification and production-commit receipts describe
the final state. No live D source/test copy or huge binary read is needed.

Run from C:/Users/11946/Documents/ChatGPT/OceanBase比赛, once each:

```powershell
.venv/Scripts/python.exe -B -X utf8 setup/fts/round32-archive/prepare_archive.py --prepare
.venv/Scripts/python.exe -B -X utf8 setup/fts/round32-archive/archive.py --execute
.venv/Scripts/python.exe -B -X utf8 setup/fts/round32-archive/verify_archive.py
.venv/Scripts/python.exe -B -X utf8 setup/fts/round32-archive/publish.py --publish
.venv/Scripts/python.exe -B -X utf8 setup/fts/round32-archive/verify_archive.py --package D:/Projects/OceanBase/seekdb/docs/developer-guide/assets/fts-performance/competition-round32-projection --repo-docs D:/Projects/OceanBase/seekdb/docs/developer-guide
```

The package and publication targets must not exist before creation; no overwrite
or deletion is performed. Publish requires tool-level D write access and writes
only the new assets directory plus en/competition-round32.md and
zh-CN/competition-round32.md. Both existing fts-performance.md files are hashed
before/after and remain unchanged. Publication.json records every repository
path written. Post-package verification receipts stay outside the immutable
package to avoid circular manifest hashes. Source verification compares every
decompressed artifact with its selected C source, not merely against itself.
The first archive attempt failed before package creation because its plan gate
did not accept EXPLAIN expression addresses after docs.id. Only the archive
gate was repaired; archive-attempt-1.json and both syntax receipts preserve
this offline preparation history. No experimental input was changed.

Omissions: executables/PDB/DLL/static libraries/objects/intermediates,
runtime/data/temp/credentials, unrelated rounds including R33, live D source,
and new native-run claims. Local three-pair LIMIT reduction12.243215% and
overall5.120836% are not a new formal/cumulative/full score or proof of
statistical stability. All signed timings remain. Parent owns independent
verification and docs commit/push; this helper never performs those operations.
