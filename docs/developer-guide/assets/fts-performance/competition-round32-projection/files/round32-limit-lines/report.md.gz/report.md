# Round32 LIMIT: offline source-line evidence

The long capture contains **4,267 raw RIPs, 1,499 resolved target-image RIPs,
zero unresolved target RIPs**, and 2,768 external/unmapped RIPs. This sidecar
resolved **170 selected unique target addresses (566 recorded samples)** to
source locations; every selected address has a nonzero source line. Selection
keeps all `advance_to` addresses and the three most frequent addresses per other
relevant symbol with at least five aggregate samples. It does not resolve every
target address. The initial short capture remains `insufficient_samples`:
1,103 raw, 387 effective target samples; no hotspot conclusion uses it.

`hotspots.tsv` contains exact recorded absolute RIP, RVA, count, original
DbgHelp symbol displacement in bytes, and every LLVM source/inline scope for
all 170 addresses. The recorded ASLR image base is `0x7ff685c20000`.
Displacement is from the recorded symbol start, **not from the source line**.
Selected high-count locations are below; function names are shortened, and
source paths are relative to `D:/Projects/OceanBase/seekdb/src/`.

| Recorded function/body | RVA | Count at this RIP | Symbol +bytes | PDB source location |
| --- | --- | ---: | ---: | --- |
| DaaTTokenIter::advance_to | `0x1c1c001` | 10 | 113 | `storage/retrieval/ob_text_retrieval_token_iter.cpp:559` |
| DaaTTokenIter::advance_to | `0x1c1bfe4` | 4 | 84 | same file `:558` |
| DaaTTokenIter::advance_to | `0x1c1c01d` | 4 | 141 | same file `:561` |
| BMW::evaluate_pivot_range | `0x1c11991` | 7 | 241 | `storage/retrieval/ob_sparse_bmw_iter.cpp:416` |
| BMW::advance_dim_iters_for_next_round | `0x1c125e7` | 5 | 215 | same file `:630` |
| BMW::next_pivot | `0x1c117fe` | 4 | 222 | same file `:256` |
| BM25::doc_token_weight | `0x1fb3fd5` | 27 | 37 | `sql/engine/expr/ob_expr_bm25.cpp:149` |
| ob_strnncollsp_binary | `0xf72b90` | 21 | 0 | `oblib/lib/charset/ob_ctype_bin.cc:150` |
| ObCharset::strcmpsp | `0xf7b649` | 10 | 137 | `oblib/lib/charset/ob_charset.cpp:596` |
| ObNullSafeDatumStrCmp<63,0,1>::cmp | `0x3b57715` | 6 | 5 | `share/datum/ob_datum_funcs_impl.h:165` |
| StringDiffDecoder::batch_decode | `0x2bb3cf2` | 5 | 1154 | `storage/blocksstable/encoding/ob_string_diff_encoder.h:172`, inline scope in `ob_string_diff_decoder.cpp:208` |
| StringDiffDecoder::batch_decode | `0x2bb3bc4` | 4 | 852 | `storage/blocksstable/encoding/ob_string_diff_decoder.cpp:214` |
| IArrayWrap alias, see below | `0x27e41` | 9 | 1 | `oblib/lib/container/ob_array_wrap.h:49` |
| IArrayWrap alias, see below | `0x2b092` | 9 | 34 | same file `:46` |
| SimpleRowsMerger::empty alias | `0x18ba040` | 15 | 0 | `storage/access/ob_simple_rows_merger.h:139` |

All **35** DaaT `advance_to` samples are retained, across **19** distinct RIPs.
Their debug-line counts are 549:5, 551:1, 557:2, 558:5, 559:12, 561:4, 564:1,
566:1, 582:4. The exact accepted-source snapshot shows line559 as the buffered
`cmp_func_` call expression, line558 as the buffer-bound check, line561 as the
comparison-result test, line564 as `++cur_idx_`, and line566 as the underlying
iterator advance expression. Thus this is direct address evidence for DaaT
advance machinery, beyond generic array aliases. It does **not** measure calls,
rows scanned, branch outcomes, skip distance or refill frequency: optimized
line tables associate address ranges with source expressions. Separate observed
comparator addresses cannot be assigned to this caller without additional
evidence. The parent's separate buffered-skip diagnostic can address that gap;
this sidecar does not duplicate it or justify bypassing comparisons.

ICF/template names require particular care. For the **same** address `0x27e41`,
the capture's DbgHelp label is `ObIArrayWrap<ObPxTabletRange*>::at`, while LLVM
selects `ObIArrayWrap<uint64_t>::at`. At `0x2b092`, the captured `ObDatum*` array
label likewise maps to a `uint64_t` const-array body. At `0x18ba040`, the
captured compaction-merger `empty` label maps to the scan-merger instantiation's
identical one-line body. These differing representatives are consistent with
the recorded ICF build and demonstrate label ambiguity. They establish neither
PX tablet work nor compaction nor the actual runtime caller/template type.
No exhaustive folded-alias set was enumerated. Inline debug scopes, such as
`ObDatumVector::at` inside BM25 evaluation, are compilation metadata, not sampled
runtime call stacks.

BM25's prominent address maps to its document-weight arithmetic expression;
decoder addresses map to fixed-length string reconstruction/output fields.
BMW locations map to its state loop, pivot/block information and advance
bookkeeping. These are bounded locations for further investigation, **not**
proof that any particular optimization will improve LIMIT. There is no CPU
percentage, elapsed-time attribution, caller/callee edge count, causal benefit,
or formal-score claim.

Local PE and PDB GUID/age match the capture:
`bf26d4fd-934c-291e-4c4c-44205044422e`, age1. Only 775 PE metadata bytes and
619,184 PDB directory/info bytes were read for that independent check; file
size/mtime stayed unchanged through resolution. Full EXE/PDB SHA values are
**inherited capture metadata**, not freshly recomputed. Accepted-f56 provenance
comes from the parent's rebuilt-control records. `source-pins.json` preserves
small source/helper hashes and excerpts; the mutable live token CPP was not
read, using its exact round31 original snapshot instead. Other source text is
pinned at inspection, without claiming complete historical source-to-PDB
reconstruction. No D writes, Git, build, SQL, server/native-test execution or
new sampling occurred.
