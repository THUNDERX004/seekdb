# Round32 LIMIT line-resolution sidecar

Frozen offline analysis of the existing long profile, excluded from scoring.
Start with `report.md`; `hotspots.tsv` lists all selected exact addresses and
`profile-source-lines.json` retains input pins, selection counts, original
symbols/displacements, LLVM source scopes, signature checks and limitations.
`symbolizer.stdout.json` and `symbolizer.stderr.log` are the complete offline
tool outputs. `source-pins.json` contains bounded source excerpts and small-file
pins. `SHA256SUMS` and `verification.json` cover the frozen sidecar artifacts.

The actual executed offline command was:

```powershell
& ./.venv/Scripts/python.exe -B -X utf8 setup/fts/round32-limit-lines/resolve_lines.py
```

The helper refuses to overwrite its existing result. It follows the round18
LLVM resolver's relative-address/PDB method; it does not import or execute the
profiling collector. Local PE CodeView and PDB info GUID/age are independently
checked with bounded reads. The symbolizer has debuginfod disabled and uses the
explicit rebuilt-control image/PDB directory. No large EXE/PDB/DLL hash is
recomputed. Complete byte identity hashes recorded by the capture remain
inherited evidence, with that limitation stated explicitly.

All `advance_to` RIPs are retained. Other relevant symbols require aggregate
count >=5 and contribute at most their three highest-count RIPs, tied by RVA;
the total is bounded to220 addresses. Actual result:170 unique addresses and
566 recorded samples, including all35 DaaT advance samples. Every selected
address has source-line metadata. Remaining addresses were not line-resolved.
Source/inline scopes and ICF representatives do not identify runtime callers,
branch counts, stacks or CPU shares. The first 387-effective-sample capture
remains insufficient. No production proposal or performance claim is made.

Only this new C auxiliary directory was written. Parent-owned buffered-skip
diagnostics and optimizer work were not duplicated or touched.
