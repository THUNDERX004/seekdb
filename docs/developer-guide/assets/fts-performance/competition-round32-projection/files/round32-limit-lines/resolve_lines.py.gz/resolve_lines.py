"""Offline source-line lookup for frozen round32 RIPs; no target execution."""
from collections import Counter, defaultdict
from pathlib import Path
import hashlib
import json
import math
import struct
import subprocess
import uuid

HERE = Path(__file__).resolve().parent
FTS = HERE.parent
PLAN = FTS / 'round32-limit-profile-plan'
PROFILE = PLAN / 'r32-limit-rebuilt-long-a1-instance/diagnostic/profile.json'
SHORT = PLAN / 'r32-limit-rebuilt-a1-instance/diagnostic/profile.json'
PIN = Path('D:/Projects/OceanBase/seekdb/build/fts-round31-rebuilt-control')
TOOL = Path('D:/Projects/OceanBase/seekdb/deps/3rd/tools/llvm18/bin/llvm-symbolizer.exe')


def need(ok, message):
    if not ok:
        raise RuntimeError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def save(name, value):
    with (HERE / name).open('xb') as stream:
        stream.write((json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode('utf-8'))


def stat(path):
    s = path.stat()
    return dict(bytes=s.st_size, mtime_ns=s.st_mtime_ns)


def debug_identity(path, pdb=False):
    """Read bounded PE CodeView/PDB stream-1 identity, never hash the large files."""
    total = 0
    with path.open('rb') as stream:
        def read(offset, size):
            nonlocal total
            need(0 <= offset and 0 < size <= 4 * 1024 * 1024, 'Metadata read bounds')
            stream.seek(offset)
            raw = stream.read(size)
            need(len(raw) == size, 'Partial metadata read')
            total += size
            need(total <= 8 * 1024 * 1024, 'Metadata read budget')
            return raw
        if pdb:
            header = read(0, 56)
            need(header[:32] == b'Microsoft C/C++ MSF 7.00\r\n\x1aDS\0\0\0', 'Expected MSF7 PDB')
            block_size, _, blocks, directory_bytes, _, block_map = struct.unpack_from('<6I', header, 32)
            need(block_size in (512, 1024, 2048, 4096, 8192) and directory_bytes <= 4 * 1024 * 1024, 'PDB directory bounds')
            n = math.ceil(directory_bytes / block_size)
            need(0 < n * 4 <= block_size and block_map < blocks, 'PDB directory block map bounds')
            indexes = struct.unpack('<' + 'I' * n, read(block_map * block_size, n * 4))
            need(all(i < blocks for i in indexes), 'Invalid PDB directory block')
            directory = b''.join(read(i * block_size, block_size) for i in indexes)[:directory_bytes]
            count = struct.unpack_from('<I', directory)[0]
            need(2 <= count <= 100000 and 4 + count * 4 <= len(directory), 'PDB stream directory')
            sizes = struct.unpack_from('<' + 'I' * count, directory, 4)
            cursor = 4 + count * 4
            cursor += 4 * (0 if sizes[0] == 0xffffffff else math.ceil(sizes[0] / block_size))
            need(sizes[1] >= 28 and cursor + 4 <= len(directory), 'PDB info stream')
            first = struct.unpack_from('<I', directory, cursor)[0]
            need(first < blocks, 'PDB info block bounds')
            info = read(first * block_size, 28)
            age = struct.unpack_from('<I', info, 8)[0]
            guid = str(uuid.UUID(bytes_le=info[12:28]))
            return dict(guid=guid, age=age, metadata_bytes_read=total)
        dos = read(0, 64)
        need(dos[:2] == b'MZ', 'PE DOS header')
        pe = struct.unpack_from('<I', dos, 60)[0]
        need(pe < 16 * 1024 * 1024, 'PE header bound')
        header = read(pe, 24)
        need(header[:4] == b'PE\0\0', 'PE signature')
        machine, sections, _, _, _, opt_size, _ = struct.unpack_from('<HHIIIHH', header, 4)
        need(machine == 0x8664 and 0 < sections <= 96 and 168 <= opt_size <= 4096, 'PE format')
        opt = read(pe + 24, opt_size)
        need(struct.unpack_from('<H', opt)[0] == 0x20b, 'PE32+')
        rva, size = struct.unpack_from('<II', opt, 112 + 6 * 8)
        table = read(pe + 24 + opt_size, 40 * sections)
        directory_offset = None
        for i in range(sections):
            vs, va, rs, rp = struct.unpack_from('<IIII', table, i * 40 + 8)
            if va <= rva < va + max(vs, rs):
                need(rva - va + size <= rs, 'PE debug directory disk bounds')
                directory_offset = rp + rva - va
                break
        need(directory_offset is not None and 0 < size <= 65536 and size % 28 == 0, 'PE debug directory')
        directory = read(directory_offset, size)
        for i in range(0, size, 28):
            _, _, _, _, kind, length, _, offset = struct.unpack_from('<IIHHIIII', directory, i)
            if kind == 2:
                need(24 <= length <= 65536, 'PE CodeView bounds')
                cv = read(offset, length)
                if cv[:4] == b'RSDS':
                    return dict(guid=str(uuid.UUID(bytes_le=cv[4:20])), age=struct.unpack_from('<I', cv, 20)[0],
                                metadata_bytes_read=total)
        raise RuntimeError('Missing RSDS record')


def family(symbol):
    if '::advance_to' in symbol:
        return 'advance_to'
    if any(x in symbol for x in ('ObIArrayWrap<', 'ObBitVectorImpl<', 'ObSimpleRowsMerger<')):
        return 'template_alias_or_generic_body'
    if 'ObExprBM25::' in symbol:
        return 'bm25'
    if any(x in symbol for x in ('strnncoll', 'ObCharset::strcmpsp', 'ObNullSafeDatumStrCmp<',
                                'ObDomainIdCmp::', 'ObStorageDatumCmpFunc::', 'memcmp')):
        return 'comparator'
    if 'Decoder::' in symbol or 'batch_load_data_to_datum' in symbol:
        return 'decoder'
    if 'ObSRBMWIterImpl::' in symbol or 'ObTextRetrievalBlockMaxIter::' in symbol:
        return 'bmw'
    if any(x in symbol for x in ('ObTextRetrieval', 'ObSRDaaTIterImpl::', 'ObSRMergeCmp::', 'ObDocIdExt::from_datum')):
        return 'retrieval'
    return None


def main():
    need(not (HERE / 'profile-source-lines.json').exists(), 'Refuse to overwrite frozen result')
    raw = PROFILE.read_bytes()
    profile = json.loads(raw)
    s = profile['phases'][0]['sampling']
    need(profile['status'] == 'complete' and profile['query_limit_sample_quality']['adequate'], 'Long capture incomplete')
    need((s['sample_count'], s['target_image_samples'], s['target_unresolved_samples']) == (4267, 1499, 0), 'Unexpected sample counts')
    binary, pdb = PIN / 'seekdb.exe', PIN / 'seekdb.pdb'
    identity = profile['identity']
    need(Path(identity['binary']).resolve() == binary.resolve() and Path(identity['symbols']['loaded_pdb']).resolve() == pdb.resolve(), 'Wrong recorded inputs')
    before = {str(p): stat(p) for p in (binary, pdb)}
    bounded = {str(p): debug_identity(p, p.suffix == '.pdb') for p in (binary, pdb)}
    for value in bounded.values():
        need(value['guid'] == identity['disk_pe']['guid'] == identity['symbols']['guid']
             and value['age'] == identity['disk_pe']['age'] == identity['symbols']['age'], 'Current local PE/PDB signature mismatch')
    addresses = [x for x in s['addresses'] if x.get('resolved')]
    need(sum(x['count'] for x in addresses) == 1499, 'Address counts do not reconcile')
    raw_counts = Counter(x['ip'] for x in s['raw_ip_events'])
    need(all(raw_counts[x['ip']] == x['count'] for x in s['addresses']), 'Raw IP histogram mismatch')
    grouped = defaultdict(list)
    for x in addresses:
        if family(x['symbol']):
            need(int(x['ip'], 16) - int(identity['loaded_image_base'], 16) == int(x['rva'], 16), 'IP/RVA mismatch')
            grouped[x['symbol']].append(x)
    selected, totals = [], []
    for symbol, values in sorted(grouped.items()):
        count = sum(x['count'] for x in values)
        category = family(symbol)
        if category != 'advance_to' and count < 5:
            continue
        values = sorted(values, key=lambda x: (-x['count'], int(x['rva'], 16)))
        chosen = values if category == 'advance_to' else values[:3]
        totals.append(dict(symbol=symbol, family=category, all_count=count, all_unique_rips=len(values),
                           selected_count=sum(x['count'] for x in chosen), selected_unique_rips=len(chosen)))
        for x in chosen:
            selected.append(dict(family=category, **{k:x[k] for k in ('symbol','ip','rva','displacement','count')}))
    need(0 < len(selected) <= 220, 'Bounded selection exceeded')
    selected.sort(key=lambda x: int(x['rva'], 16))
    command = [str(TOOL), '--no-debuginfod', '--relative-address', '--obj=' + str(binary),
               '--fallback-debug-path=' + str(PIN), '--output-style=JSON', *[x['rva'] for x in selected]]
    result = subprocess.run(command, capture_output=True, timeout=60)
    with (HERE / 'symbolizer.stdout.json').open('xb') as stream:
        stream.write(result.stdout)
    with (HERE / 'symbolizer.stderr.log').open('xb') as stream:
        stream.write(result.stderr)
    need(result.returncode == 0 and not result.stderr, 'Offline symbolizer failed; raw output retained')
    decoded = json.loads(result.stdout)
    need(len(decoded) == len(selected), 'Symbolizer result cardinality')
    mapping = {int(x['Address'], 16): x for x in decoded}
    need(len(mapping) == len(selected), 'Duplicate symbolizer results')
    for x in selected:
        x['source_frames'] = mapping[int(x['rva'], 16)]['Symbol']
        need(x['source_frames'], 'Missing source frames')
    need(sum(x['count'] for x in selected if x['symbol'].endswith('ObTextRetrievalDaaTTokenIter::advance_to')) == 35, 'All DaaT advance addresses required')
    need(before == {str(p): stat(p) for p in (binary, pdb)}, 'Local symbol inputs changed during resolution')
    need(PROFILE.read_bytes() == raw, 'Profile changed')
    short_raw = SHORT.read_bytes()
    short = json.loads(short_raw)
    report = dict(status='COMPLETE', method='Offline LLVM/PDB source mapping, following round18 resolver; no target/process API or sampling.',
                  input=dict(path=str(PROFILE), bytes=len(raw), sha256=sha(raw)),
                  sampling=dict(raw_captures=4267, effective_target_resolved=1499, target_unresolved=0,
                                external_or_unmapped=2768, selected_unique_rips=len(selected), selected_samples=sum(x['count'] for x in selected)),
                  original_short_capture=dict(path=str(SHORT), bytes=len(short_raw), sha256=sha(short_raw),
                                              status=short['status'], quality=short['query_limit_sample_quality'], interpretation='Insufficient; no hotspot inference.'),
                  recorded_identity=identity, local_stat=before, bounded_signature_checks=bounded,
                  large_file_hashes='NOT recomputed; EXE/PDB SHA256 values are inherited capture metadata, not fresh verification.',
                  command=command, returncode=result.returncode, stdout_sha256=sha(result.stdout), stderr_sha256=sha(result.stderr),
                  selection='All advance_to addresses; top three RIPs for each other selected symbol with aggregate count >=5; at most220 unique RIPs.',
                  symbols=totals, addresses=selected,
                  limitations=['RIP counts are intrusive cycle-selected locations, not CPU percentages or elapsed-time attribution.',
                               'Source/inline debug scopes are not runtime call stacks or edge counts.',
                               'ICF/template representative names do not identify the actual caller or template instantiation.',
                               'No specific branch direction, comparator invocation count, buffered skip, or causal speedup is established.',
                               'Matching local GUID/age is independently checked; complete current EXE/PDB bytes are not rehashed.',
                               'No SQL, server/native-test runtime, build, D write or Git operation performed.'])
    save('profile-source-lines.json', report)
    print(json.dumps(dict(status='COMPLETE', selected_unique_rips=len(selected), selected_samples=sum(x['count'] for x in selected),
                          daat_advance_count=35, signature=identity['disk_pe'], bounded_reads=bounded), indent=2))


if __name__ == '__main__':
    main()
