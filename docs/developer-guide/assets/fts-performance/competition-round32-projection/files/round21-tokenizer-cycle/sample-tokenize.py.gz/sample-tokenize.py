"""Unscored tokenizer RIP diagnosis; pinned custom client, frozen sampler core.

Client revision: ONLY the exact D:/Projects/OceanBase/seekdb/build/fts-native-client/
mysql-native.exe and its client.cpp SHA-256 pins below are accepted. Launch argv is
just that executable; no generic MySQL flags are supplied. User must be root and
SEEKDB_TEST_PASSWORD/MYSQL_PWD must both be absent or empty. Generic mysql.exe is
not accepted by this revision, superseding the earlier README client guidance.

Full source reviewed offline: Connection hardcodes IPv4 loopback:2891, root,
empty native-password authentication and utf8mb4 login. No option/default/login
files, reconnect or configurable endpoint exists. wmain rejects nonempty
SEEKDB_TEST_PASSWORD, uses binary stdin/stdout, reads all stdin before connecting,
splits statements at unquoted/uncommented semicolons, and executes them serially.
Unknown argv are ignored except -e (which this wrapper never supplies). Query OK
packets produce no rows; result fields are written verbatim with tab/newline
separators; SQL/protocol errors exit 1. The fixed official SQL here has one JSON
column/result per TOKENIZE. The child has no socket deadline; this wrapper owns
the bounded timeout/kill/wait. Source/EXE pins establish reviewed identities, not
an independent proof that this EXE was built from this source.
Pre-revision helper is preserved in sample-tokenize.pre-native-pin.py.txt
(SHA-256 e48ca923eeecdb281fb4d879f320b2d905cf9bfff469947d3f4e0584c08d1f91).
"""
import argparse
import contextlib
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import subprocess
import sys
import time

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
CORE = HERE.parent / "round18-cycle-profile" / "sample-competition.py"
CORE_SHA = "c4f11da1b5b972ee56f6eb275fdeef7bd5aa3f1df54ed23078f210d75e473605"
BENCH_SHA = "7e5b4dec9419dcef85a5785dbe305d7f825f545f45538af2084a5a2aca090c0a"
BENCH = Path("D:/Projects/OceanBase/seekdb/tools/benchmark/fts_large_bench.sh")
NATIVE_CLIENT = Path("D:/Projects/OceanBase/seekdb/build/fts-native-client/mysql-native.exe")
NATIVE_CLIENT_SHA = "da3692bc7f5e4ae199e5007d9dca90aa1e849a626c4db6d0d9d860120b3f0a3c"
NATIVE_SOURCE = Path("D:/Projects/OceanBase/seekdb/build/fts-native-client/client.cpp")
NATIVE_SOURCE_SHA = "364d12ab86de3f574c132e3064dc65bb8d3a51669cb7d6b377aea3a03d4752f9"
SESSION = ("SET NAMES utf8mb4;\nSET ob_query_timeout = 100000000000;\n"
           "SET ob_trx_timeout = 100000000000;\n")


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def sha(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def file_record(path):
    return {"path": str(path.resolve()), "bytes": path.stat().st_size, "sha256": sha(path)}


def native_client_preflight(value, user):
    require(user == "root", "Pinned native client requires user root")
    require(not os.environ.get("SEEKDB_TEST_PASSWORD") and not os.environ.get("MYSQL_PWD"),
            "Pinned native client requires empty password environment")
    client = Path(value)
    require(client.is_absolute() and
            os.path.normcase(str(client)) == os.path.normcase(str(NATIVE_CLIENT)),
            "Native client path is not in the exact-path allowlist")
    for path, expected in ((client, NATIVE_CLIENT_SHA), (NATIVE_SOURCE, NATIVE_SOURCE_SHA)):
        require(path.is_file() and not path.is_symlink() and
                os.path.normcase(str(path.resolve(strict=True))) == os.path.normcase(str(path)),
                "Pinned native client/source path is missing or redirected")
        require(sha(path) == expected, "Pinned native client/source SHA-256 mismatch")
    return client


def safe_error(error):
    record = {"type": type(error).__name__}
    if isinstance(error, OSError):
        record["errno"] = error.errno
    elif isinstance(error, RuntimeError):
        record["message"] = str(error)  # Only this helper's fixed diagnostic messages.
    return record


def json_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, "Duplicate JSON result key")
        result[key] = value
    return result


def reject_constant(value):
    raise RuntimeError("Non-finite JSON result constant")


def json_float(value):
    result = float(value)
    require(math.isfinite(result), "Non-finite JSON result number")
    return result


def result_json(raw):
    return json.loads(raw.decode("utf-8"), object_pairs_hook=json_object,
                      parse_constant=reject_constant, parse_float=json_float)


class DiagnosticArgumentParser(argparse.ArgumentParser):
    def error(self, message):
        # argparse's default error can echo unknown password arguments verbatim.
        raise RuntimeError("Invalid diagnostic arguments; see --help (values suppressed)")


def arguments():
    parser = DiagnosticArgumentParser(description=__doc__)
    parser.add_argument("pid", type=int)
    parser.add_argument("workload", choices=("tokenize-ik", "tokenize-beng"))
    parser.add_argument("--binary", required=True)
    parser.add_argument("--pdb", required=True)
    parser.add_argument("--dbghelp")
    parser.add_argument("--mysql-client", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--official-bench", default=str(BENCH))
    parser.add_argument("--user", choices=("root",), default="root")
    parser.add_argument("--rounds", "--query-rounds", dest="query_rounds", type=int, default=50000)
    parser.add_argument("--warmup", type=int, choices=(30,), default=30)
    parser.add_argument("--timeout-sec", type=int, default=180)
    parser.add_argument("--interval-ms", type=float, default=1.0)
    parser.add_argument("--min-samples", type=int, default=1000)
    parser.add_argument("--max-samples", type=int, default=50000)
    args = parser.parse_args()
    require(os.name == "nt", "Windows only")
    require(args.pid > 4 and args.pid != os.getpid(), "Invalid target PID")
    require(1 <= args.query_rounds <= 200000 and 1 <= args.timeout_sec <= 180,
            "Invalid native diagnostic bounds")
    require(math.isfinite(args.interval_ms) and 0.25 <= args.interval_ms <= 100 and
            1 <= args.min_samples <= args.max_samples <= 200000, "Invalid sampling bounds")
    root = Path(args.output_dir)
    require(root.is_absolute() and root.parent.is_dir() and not root.exists() and not root.is_symlink(),
            "Output directory must be absolute, new, with an existing parent")
    args.mysql_client = str(native_client_preflight(args.mysql_client, args.user))
    bench = Path(args.official_bench)
    require(bench.is_absolute() and bench.is_file(), "Supply an absolute official benchmark file")
    args.official_bench = str(bench.resolve(strict=True))
    args.output_dir = str(root)
    args.output = str(root / "profile.json")  # Original main requires this field.
    args.sql_socket_timeout = min(args.timeout_sec, 120)
    args.diagnostic_database = None
    return args


def literals(path):
    raw = path.read_bytes()
    require(hashlib.sha256(raw).hexdigest() == BENCH_SHA, "Official benchmark input pin mismatch")
    text = raw.decode("utf-8")
    found = {}
    for name in ("IK_TEXT", "BENG_TEXT"):
        matches = re.findall(r'^' + name + r'="([^"\r\n]*)"\r?$', text, re.MULTILINE)
        require(len(matches) == 1, "Official literal assignment missing or duplicated")
        value = matches[0]
        require(value and not any(char in value for char in ("$", "\\", "'", "\x00", "\x60")),
                "Official assignment is not a supported plain literal")
        found[name] = {"text": value, "utf8_bytes": len(value.encode("utf-8")),
                       "utf8_sha256": hashlib.sha256(value.encode("utf-8")).hexdigest()}
    return found


def write_input(path, statement, count):
    line = (statement + "\n").encode("utf-8")
    with path.open("xb") as stream:
        stream.write(SESSION.encode("ascii"))
        for _ in range(count):
            stream.write(line)


def validate_output(path, count, reference=None, progress=None):
    checked, empty = 0, 0
    with path.open("rb") as stream:
        for physical in stream:
            # Strip only the native line terminator; never strip JSON spaces/content.
            line = physical[:-1] if physical.endswith(b"\n") else physical
            if line.endswith(b"\r"):
                line = line[:-1]
            if not line:
                empty += 1
                continue
            require(checked < count, "Native output contains too many results")
            result_json(line)
            if reference is None:
                reference = line
            require(line == reference, "Native TOKENIZE result differs from warmup reference")
            checked += 1
            if progress is not None:
                progress.update(checked_results=checked, empty_lines=empty)
    require(checked == count, "Native output result count mismatch")
    return reference, {"checked_results": checked, "empty_lines": empty,
                       "reference_result_sha256": hashlib.sha256(reference).hexdigest(),
                       "every_result_json_valid": True, "every_result_exact_reference_match": True}


def native_job(args, target, root, name, sampler, receipt):
    count = 30 if name == "warmup" else args.query_rounds
    job = {"name": name, "status": "starting", "timeout_sec": args.timeout_sec,
           "requested_statements": count, "kill_attempted": False,
           "wait_after_kill_attempted": False, "cleanup_errors": []}
    receipt["native_jobs"].append(job)
    command = [args.mysql_client]  # This pinned client ignores unknown flags; endpoint is in its source.
    env = os.environ.copy()
    for key in ("MYSQL_PWD", "MYSQL_HOST", "MYSQL_TCP_PORT", "MYSQL_UNIX_PORT",
                "MYSQL_GROUP_SUFFIX", "MYSQL_TEST_LOGIN_FILE"):
        env.pop(key, None)
    env.pop("SEEKDB_TEST_PASSWORD", None)
    child = None
    try:
        native_client_preflight(args.mysql_client, args.user)
        target.alive()
        target.check_listener()
        with (root / (name + ".input.sql")).open("rb") as stdin, \
                (root / (name + ".stdout.log")).open("xb") as stdout, \
                (root / (name + ".stderr.log")).open("xb") as stderr:
            try:
                child = subprocess.Popen(command, stdin=stdin, stdout=stdout, stderr=stderr,
                                         env=env, shell=False, creationflags=subprocess.CREATE_NO_WINDOW)
                job["child_pid"] = child.pid
                deadline = time.monotonic() + args.timeout_sec
                while child.poll() is None:
                    if sampler is not None:
                        sampler.check()
                    target.alive()
                    remaining = deadline - time.monotonic()
                    require(remaining > 0, "Native mysql timeout; child cleanup required")
                    try:
                        child.wait(timeout=min(0.25, remaining))
                    except subprocess.TimeoutExpired:
                        pass
                job["exit_code"] = child.returncode
                require(child.returncode == 0, "Native mysql failed; inspect retained stderr")
                target.alive()
                target.check_listener()
                job["status"] = "complete"
            finally:
                if child is not None and child.poll() is None:
                    job["kill_attempted"] = True
                    try:
                        child.kill()  # Only this Popen-owned native client; never the target PID.
                    except BaseException as error:
                        job["cleanup_errors"].append(safe_error(error))
                    job["wait_after_kill_attempted"] = True
                    try:
                        child.wait(timeout=5)
                    except BaseException as error:
                        job["cleanup_errors"].append(safe_error(error))
                if child is not None:
                    job["final_exit_code"] = child.poll()
                    job["child_reaped"] = child.returncode is not None
                    if not job["child_reaped"]:
                        job["cleanup_errors"].append({"type": "NativeChildNotReaped"})
    except BaseException as error:
        job.update(status="failed", error=safe_error(error))
        raise
    require(not job["cleanup_errors"], "Native child cleanup failed")
    return {"native_job": name, "requested_statements": count,
            "native_exit_code": job["exit_code"], "output_validation": "after_sampler_stop"}


def load_core():
    raw = CORE.read_bytes()
    require(hashlib.sha256(raw).hexdigest() == CORE_SHA, "Frozen sampler module SHA mismatch")
    spec = importlib.util.spec_from_file_location("round21_frozen_cycle_core", CORE)
    require(spec is not None and spec.loader is not None, "Cannot load frozen sampler module")
    core = importlib.util.module_from_spec(spec)
    # Import exactly the verified bytes, bypassing any pre-existing bytecode cache.
    exec(compile(raw, str(CORE), "exec"), core.__dict__)
    require(core.PORT == 2891 and core.REFRESH_NS == 100000000 and core.SELECT_CAP == 2,
            "Frozen sampler safety constants differ")
    return core


def sampling_summary(profile):
    return [{"name": phase["name"],
             "sample_count": (sample := phase.get("sampling", {})).get("sample_count", 0),
             "minimum_requested_samples": phase.get("minimum_requested_samples"),
             "sample_shortfall": max(0, phase.get("minimum_requested_samples", 0) - sample.get("sample_count", 0)),
             "requested_interval_ms": sample.get("requested_interval_ms"),
             "actual_loop_gap_mean_ms": None if sample.get("loop_gap_mean_ns") is None else sample["loop_gap_mean_ns"] / 1000000,
             "actual_minus_requested_mean_ms": None if sample.get("loop_gap_mean_ns") is None else
                 sample["loop_gap_mean_ns"] / 1000000 - sample["requested_interval_ms"],
             "actual_loop_gap_max_ms": sample.get("loop_gap_max_ns", 0) / 1000000,
             "pending_resume_generations": sample.get("pending_resume_generations", []),
             "errors": sample.get("errors", [])} for phase in profile.get("phases", [])]


def main():
    args = arguments()
    root = Path(args.output_dir)
    root.mkdir()  # Exclusive ownership before any process/SQL interaction.
    receipt = {"status": "preparing", "excluded_from_scoring": True,
               "created_utc": datetime.now(timezone.utc).isoformat(),
               "endpoint": {"host": "127.0.0.1", "port": 2891}, "target_pid": args.pid,
               "workload": args.workload, "rounds": args.query_rounds, "warmup": 30,
               "native_jobs": [], "cleanup_errors": [], "files": [],
               "result_check_limit": "Same-client repeatability/JSON check, not independent correctness proof",
               "interpretation": "Raw cycle-selected RIP samples; no CPU-share or scored timing claim"}
    code, core, original_arguments, original_workloads = 1, None, None, None
    pins = {}
    with (root / "receipt.json").open("x", encoding="utf-8") as destination:
        try:
            bench, client, helper = Path(args.official_bench), Path(args.mysql_client), Path(__file__).resolve()
            native_client_preflight(args.mysql_client, args.user)
            official = literals(bench)
            for path in (helper, CORE, bench, client, NATIVE_SOURCE):
                pins[path] = sha(path)
            receipt["provenance"] = {"helper": file_record(helper), "sampler": file_record(CORE),
                                     "native_client": file_record(client),
                                     "native_client_source": file_record(NATIVE_SOURCE),
                                     "native_client_expected_sha256": NATIVE_CLIENT_SHA,
                                     "native_client_source_expected_sha256": NATIVE_SOURCE_SHA,
                                     "native_client_policy": {"argv": [str(client)], "user": "root",
                                                              "password": "empty-required",
                                                              "endpoint": "127.0.0.1:2891",
                                                              "endpoint_mode": "hardcoded-in-pinned-client",
                                                              "source_binary_build_correspondence": "not independently proven"},
                                     "official_bench": file_record(bench),
                                     "official_literals": official}
            core = load_core()
            original_main, original_phase = core.main, core.run_phase
            original_arguments, original_workloads = core.arguments, core.workloads
            original_classes = tuple(getattr(core, name) for name in ("WinAPI", "Target", "Symbols", "CycleSampler"))
            parser = "ik" if args.workload == "tokenize-ik" else "beng"
            text = official["IK_TEXT" if parser == "ik" else "BENG_TEXT"]["text"]
            statement = "SELECT tokenize('" + text + "', '" + parser + "');"
            receipt["statement"] = statement
            receipt["statement_utf8_sha256"] = hashlib.sha256(statement.encode("utf-8")).hexdigest()
            write_input(root / "warmup.input.sql", statement, 30)
            write_input(root / "measured.input.sql", statement, args.query_rounds)

            def workloads(cursor, target, symbols, compatible_args, report):
                # Original main already validates PID/PE/PDB/port and opens its own preflight connection.
                # No repeated PyMySQL execute occurs here or during measured native work.
                require(compatible_args is args, "Incompatible sampler argument object")
                report["tokenizer_diagnostic"] = {"native_child": True, "parser": parser,
                                                   "warmup": 30, "rounds": args.query_rounds}
                native_job(args, target, root, "warmup", None, receipt)
                reference, warmup_check = validate_output(root / "warmup.stdout.log", 30)
                receipt["warmup_validation"] = warmup_check
                with (root / "reference.json").open("x", encoding="utf-8") as reference_file:
                    json.dump({"exact_native_utf8_line": reference.decode("utf-8"),
                               "parsed_json": result_json(reference), "source": "first of 30 exact-matching native warmups"},
                              reference_file, ensure_ascii=False, allow_nan=False, indent=2)
                    reference_file.write("\n")
                core.run_phase(args.workload,
                               lambda sampler: native_job(args, target, root, "measured", sampler, receipt),
                               target, symbols, args, report)
                progress = {"checked_results": 0}
                receipt["measured_validation"] = progress
                _, checked = validate_output(root / "measured.stdout.log", args.query_rounds, reference, progress)
                progress.update(checked)
                report["tokenizer_diagnostic"]["result_check"] = checked

            core.arguments = lambda: args
            core.workloads = workloads
            require(core.main is original_main and core.run_phase is original_phase and
                    tuple(getattr(core, name) for name in ("WinAPI", "Target", "Symbols", "CycleSampler")) == original_classes,
                    "Original sampler entry points or safety classes were replaced")
            receipt["original_main_and_safety_classes_preserved"] = True
            with (root / "helper-main.stdout.log").open("x", encoding="utf-8") as stdout, \
                    (root / "helper-main.stderr.log").open("x", encoding="utf-8") as stderr, \
                    contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
                code = core.main()
            with Path(args.output).open("r", encoding="utf-8") as source:
                profile = json.load(source)
            receipt["profile_status"] = profile["status"]
            receipt["sampling_evidence"] = sampling_summary(profile)
            receipt["status"] = profile["status"]
        except BaseException as error:
            receipt.update(status="interrupted" if isinstance(error, KeyboardInterrupt) else "failed", error=safe_error(error))
            code = 130 if isinstance(error, KeyboardInterrupt) else 1
        finally:
            if core is not None and original_arguments is not None:
                core.arguments, core.workloads = original_arguments, original_workloads
            for path, before in pins.items():
                try:
                    require(sha(path) == before, "Pinned helper, sampler, official input or client/source changed during diagnosis")
                except BaseException as error:
                    receipt["cleanup_errors"].append(safe_error(error))
            for path in sorted(root.iterdir()):
                if path.name != "receipt.json" and path.is_file():
                    try:
                        receipt["files"].append(file_record(path))
                    except BaseException as error:
                        receipt["cleanup_errors"].append(safe_error(error))
            if receipt["cleanup_errors"] or any(job["cleanup_errors"] for job in receipt["native_jobs"]):
                receipt["status"], code = "failed_cleanup", 1
            receipt.update(exit_code=code, finished_utc=datetime.now(timezone.utc).isoformat())
            json.dump(receipt, destination, ensure_ascii=False, allow_nan=False, indent=2)
            destination.write("\n")
    print(json.dumps({"receipt": str(root / "receipt.json"), "status": receipt["status"], "exit_code": code}))
    return code


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (RuntimeError, OSError, ValueError) as error:
        print(json.dumps({"status": "preflight_failed", "error": safe_error(error)}), file=sys.stderr)
        sys.exit(1)
