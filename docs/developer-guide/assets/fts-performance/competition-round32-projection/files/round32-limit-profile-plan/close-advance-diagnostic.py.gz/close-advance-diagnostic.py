"""Preserve the owned diagnostic counters and restore exact accepted source."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

HERE=Path(__file__).resolve().parent
ROOT=Path('D:/Projects/OceanBase/seekdb')
source=ROOT/'build/fts-round32-advance-diagnostic.txt'
raw=source.read_bytes()
lines=raw.decode('ascii').splitlines()
values={key:int(value) for key,value in re.findall(r'([a-z_0-9]+)=([0-9]+)',lines[0])}
buckets={int(key):int(value) for key,value in (line.removeprefix('skip_bucket_').split('=') for line in lines[1:])}
assert values['calls']==4096 and len(buckets)==16 and sum(buckets.values())==4096
with (HERE/'advance-diagnostic-counts.txt').open('xb') as stream:stream.write(raw)
record=dict(status='COMPLETE_DIAGNOSTIC_ONLY',scored=False,raw_sha256=hashlib.sha256(raw).hexdigest(),
            values=values,skip_buckets=buckets,mean_skipped=values['skipped']/values['calls'],
            skip_ge8_calls=sum(value for key,value in buckets.items() if key>=4),
            conclusion='Most observed advances skip zero to three IDs; only77/4096 skip >=8 (maximum17). No evidence to justify a general binary-search replacement from this first-thread snapshot.',
            limits='First thread to reach4096 calls only; intrusive aggregate counters are not CPU shares, all-query coverage or scored performance. Profile proves actual method execution separately.')
with (HERE/'advance-diagnostic-summary.json').open('x',encoding='utf-8') as stream:
    json.dump(record,stream,indent=2);stream.write('\n')
subprocess.run([sys.executable,'-B',str(HERE/'advance-diagnostic.py'),'restore'],check=True)
print(json.dumps(record,indent=2))
