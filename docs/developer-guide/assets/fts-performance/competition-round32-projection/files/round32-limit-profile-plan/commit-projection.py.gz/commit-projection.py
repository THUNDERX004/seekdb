"""Commit and immediately push the verified R32 production rule and regression."""
import hashlib
import json
from pathlib import Path
import subprocess

HERE=Path(__file__).resolve().parent
ROOT=Path('D:/Projects/OceanBase/seekdb')
def git(*args,capture=False):
    run=subprocess.run(['git',*args],cwd=ROOT,check=True,capture_output=capture,text=True,encoding='utf-8')
    return run.stdout.strip() if capture else None
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
assert git('rev-parse','HEAD',capture=True)=='8b2390a3314091d50297a8f42035b4b19babbafc'
assert git('branch','--show-current',capture=True)=='codex/fts-performance-competition'
assert not git('diff','--cached','--name-only',capture=True)
git('merge-base','--is-ancestor','5bce9e06d1281347ad61344e4b01fab9158c58a2','HEAD')
assert not git('diff','--name-only','5bce9e06d1281347ad61344e4b01fab9158c58a2','--','tools/benchmark','.github','CMakeLists.txt','cmake','build.sh',capture=True)
paths=['src/sql/rewrite/ob_transformer_impl.cpp','unittest/storage/fts/test_counted_limit_projection.py']
assert sha(ROOT/paths[0])=='192d7920768202dd761d32ede91b5af55feadacd8a572f8f0d360959e7a09768'
assert sha(ROOT/paths[1])=='9a7589557f23e98cc230c2796f49e80e2d57224fb1158c4a1cda44135a5578db'
assert sha(ROOT/'src/storage/retrieval/ob_text_retrieval_token_iter.cpp')=='7a7d33cef52f0da958586356f249ab7c807151dc49a5f1c60ecfee41900bd586'
application=json.loads((HERE/'projection-application.json').read_text(encoding='utf-8'))
for rel,digest in application['preserved_unrelated_files'].items():assert sha(ROOT/rel)==digest
comparison=json.loads((HERE/'projection-comparison-3pair.json').read_text(encoding='utf-8'))
assert comparison['completed_pairs']==3 and comparison['aggregate']['overall_improvement']>0
assert json.loads((HERE/'parent-focused-verification.json').read_text(encoding='utf-8'))['status']=='PASS'
receipt=json.loads((HERE.parent/'r32-projection-candidate-regression-a1-experiment.json').read_text(encoding='utf-8'))
assert len(receipt['actions'])==10 and all(item['exit_code']==0 for item in receipt['actions'])
git('add','--',*paths)
assert set(git('diff','--cached','--name-only',capture=True).splitlines())==set(paths)
git('diff','--cached','--check')
git('commit','-m','perf(sql): prune unused columns from counted full-text limited views')
git('push','origin','codex/fts-performance-competition')
head=git('rev-parse','HEAD',capture=True)
remote=git('ls-remote','origin','refs/heads/codex/fts-performance-competition',capture=True).split()[0]
assert head==remote
with (HERE/'production-commit.json').open('x',encoding='utf-8') as stream:
    json.dump(dict(status='COMMITTED_AND_PUSHED',head=head,remote=remote,paths=paths,validation='Build,399 focused official/candidate exact cases,prepared/hints/outline,ranked432,keytypes192,7existing suites,3fullpairs'),stream,indent=2);stream.write('\n')
print('VERIFIED REMOTE',head)
