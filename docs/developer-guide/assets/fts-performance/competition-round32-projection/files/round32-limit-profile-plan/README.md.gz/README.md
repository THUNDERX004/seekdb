# Round32 exact LIMIT profiling plan

Prepared only. Parent runs serially after control/scored work, against its separately owned instance on **127.0.0.1:2891**, with the unchanged official 20,000-row dataset/indexes already loaded. Supply the actual accepted **f56** build's PID, EXE, matching PDB and build/source receipt; this adapter does not establish that source-to-binary correspondence. No server launch/stop or input/benchmark modification is included.

From `C:/Users/11946/Documents/ChatGPT/OceanBase比赛`, replace `TARGET_PID`, `ACCEPTED_BUILD`, and `NEW_OUTPUT` below. Output must be an absolute new directory with an existing parent. The pinned native client requires root with an empty password; inherited `SEEKDB_TEST_PASSWORD` and `MYSQL_PWD` must be absent/empty. Do not use the installed 2881 service.

```powershell
.venv/Scripts/python.exe -B setup/fts/round32-limit-profile-plan/sample-limit.py TARGET_PID `
  --binary D:/Projects/OceanBase/seekdb/build/ACCEPTED_BUILD/seekdb.exe `
  --pdb D:/Projects/OceanBase/seekdb/build/ACCEPTED_BUILD/seekdb.pdb `
  --dbghelp 'C:/Program Files/Microsoft Visual Studio/2022/BuildTools/Common7/IDE/Extensions/TestPlatform/Extensions/Cpp/x64/dbghelp.dll' `
  --mysql-client D:/Projects/OceanBase/seekdb/build/fts-native-client/mysql-native.exe `
  --output-dir 'C:/Users/11946/Documents/ChatGPT/OceanBase比赛/setup/fts/NEW_OUTPUT' `
  --query-rounds 8000 --timeout-sec 180 --interval-ms 1 --min-samples 1000 --max-samples 50000
```

`query_limit.sql` is exactly `explain-competition.py`'s fourth query, plus its terminating semicolon/newline. Runtime checks the pinned explain script by AST without executing it, compares the exact SQL, and preserves both native input files. No ORDER BY or query rewrite is added. The parent's existing EXPLAIN evidence for implicit MATCH DESC sort/limit20 remains separate; it is not proof of any particular function's execution.

The small adapter reuses the **unchanged** round18 native Windows API cycle-selected RIP collector and DbgHelp/PDB resolver, plus round21's pinned native SQL client and timeout/kill/reap handling. Only in-memory argument/workload hooks change. PID/loaded-image identity, exact EXE/PDB match, listener ownership on 2891, refusal of 2881, target-only thread handles, top-two cycle-delta selection and suspend/resume cleanup remain inherited. The specified local DbgHelp path appeared in the existing round21 preflight receipt; its availability and identity are rechecked by the inherited resolver at parent execution. No separate native collector executable was found in the bounded script search; the collector is round18's ctypes/native-WinAPI implementation.

There are exactly 30 unsampled native warmups and at most 8000 measured repetitions; each client has a maximum 180-second deadline plus the inherited five-second kill/wait attempt. The core checks the existing table's 20,000 rows and expected schema before warmup. Every warmup and measured result must be exactly one column/row `20`, with no extra/blank/truncated output and empty stderr. All stdout/stderr are retained. Measured output validation and symbol resolution occur after capture stops. This checks the full result of the actual COUNT query; it does not expose inner document IDs or prove iterator coverage.

**At least 1000 effective samples are mandatory and cannot be lowered.** The original raw capture threshold is retained. This adapter additionally requires at least the same number of target-EXE RIPs successfully resolved through the matching PDB: `target_image_samples - target_unresolved_samples`. External/unmapped or unresolved RIPs cannot satisfy that additional threshold and remain visible in the all-sample report. Cleanup/capture failures invalidate the run. Exit codes: `0` complete, `2` `insufficient_samples`, `1` failure, `130` interruption. If the bounded run yields too few effective samples, retain the report as insufficient and make no hotspot conclusion; do not fill, extrapolate, lower the threshold or automatically rerun.

Inspect `receipt.json` for complete output validation, native child cleanup, requested/actual sample counts and loop gaps; inspect `profile.json` for matching image/PDB/DLL identities, raw RIP events, thread cycle deltas, resolved symbols, external/unresolved denominators and handle/resume accounting. Large EXE/PDB identity hashing occurs only when the parent later runs the inherited core. This sidecar has performed no such hashing, SQL, sampling, build, target execution or D/Git edits. Cycle-selected RIP counts are intrusive location evidence with selection/background/client/suspension bias, not stacks, CPU shares, scored time or a performance benefit. No measured hotspot is claimed here.

Preparation verification is limited to in-memory AST parsing, exact SQL snapshot comparison and SHA-256 of the small source/artifact files in `source-pins.json`/`SHA256SUMS`. No profiler module was imported during preparation.
