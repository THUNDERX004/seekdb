"""Add one focused regression action to a pinned copy of the owned harness."""
import ast
import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
source=HERE.parent/'round27-root-evidence/experiment-with-exit.py'
raw=source.read_bytes()
sha=lambda value:hashlib.sha256(value).hexdigest()
marker=b"    p.add_argument('--benchmark', action='store_true')"
assert raw.count(marker)==1
changed=raw.replace(marker,marker+b"\n    p.add_argument('--counted-limit', action='store_true')\n    p.add_argument('--counted-limit-plans', action='store_true')",1)
marker=b'            if a.tests:'
assert changed.count(marker)==1
action=b'''            if a.counted_limit:
                args = [str(PYTHON), '-X', 'utf8', str(ROOT/'unittest/storage/fts/test_counted_limit_projection.py'),
                        '--port', str(a.port), '--plans', str(HERE/(a.label+'-counted-limit-plans.json'))]
                if a.counted_limit_plans:
                    args.append('--check-plans')
                run('counted-limit', args)
'''
changed=changed.replace(marker,action+marker,1)
ast.parse(changed)
with (HERE/'experiment-projection.py').open('xb') as stream:stream.write(changed)
with (HERE/'experiment-preparation.json').open('x',encoding='utf-8') as stream:
    json.dump(dict(original_harness=str(source),original_sha256=sha(raw),new_sha256=sha(changed),
                   change='Only add optional focused test action; server ownership, fixed benchmark inputs and existing suites unchanged.'),stream,indent=2);stream.write('\n')
print('PREPARED',sha(changed))
