#!/usr/bin/env python3
"""Parent-run, unscored exact query_limit diagnostic using frozen R18/R21 code.

Preparation does not import or execute either dependency. At parent execution,
reuse R18's native Windows API cycle/RIP sampler and DbgHelp/PDB resolver, and
R21's pinned native SQL client, bounded child ownership and full output files.
"""
import argparse
import ast
import contextlib
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
FTS = HERE.parent
ADAPTER = FTS / "round21-tokenizer-cycle" / "sample-tokenize.py"
ADAPTER_SHA = "8e6e76a0c972ba243176d299dc51988fb078484d5b043a78e74355f3ad945249"
CORE = FTS / "round18-cycle-profile" / "sample-competition.py"
CORE_SHA = "c4f11da1b5b972ee56f6eb275fdeef7bd5aa3f1df54ed23078f210d75e473605"
EXPLAIN = FTS / "explain-competition.py"
EXPLAIN_SHA = "92714b4c64429f1f9f8465139ef1996bcfb23a1256eec4132a789a7e0d41a41b"
SQL = "SELECT COUNT(*) FROM (SELECT id FROM fts_large_bench.docs WHERE MATCH(content) AGAINST('倒排索引 tokenizer') LIMIT 20) t"


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def small_bytes(path):
    require(path.is_file() and path.stat().st_size <= 100000,
            "Small source dependency missing or unexpectedly large")
    return path.read_bytes()


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def pinned(path, expected):
    raw = small_bytes(path)
    require(digest(raw) == expected, "Frozen source dependency SHA-256 mismatch")
    return raw


class Parser(argparse.ArgumentParser):
    def error(self, message):
        raise RuntimeError("Invalid arguments; see --help (values suppressed)")


def arguments():
    parser = Parser(description=__doc__)
    parser.add_argument("pid", type=int)
    parser.add_argument("--binary", required=True)
    parser.add_argument("--pdb", required=True)
    parser.add_argument("--dbghelp", required=True)
    parser.add_argument("--mysql-client", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--query-rounds", type=int, default=8000)
    parser.add_argument("--timeout-sec", type=int, default=180)
    parser.add_argument("--interval-ms", type=float, default=1.0)
    parser.add_argument("--min-samples", type=int, default=1000)
    parser.add_argument("--max-samples", type=int, default=50000)
    args = parser.parse_args()
    require(os.name == "nt" and args.pid > 4 and args.pid != os.getpid(),
            "An explicit other Windows target PID is required")
    require(1 <= args.query_rounds <= 32000 and 1 <= args.timeout_sec <= 180,
            "Query count or child timeout exceeds bounded diagnostic limits")
    require(math.isfinite(args.interval_ms) and 0.25 <= args.interval_ms <= 100 and
            1000 <= args.min_samples <= args.max_samples <= 50000,
            "Sampling bounds invalid; minimum cannot be below 1000")
    root = Path(args.output_dir)
    require(root.is_absolute() and root.parent.is_dir() and not root.exists() and
            not root.is_symlink(), "Output directory must be absolute and new")
    args.output = str(root / "profile.json")
    args.user, args.workload, args.warmup = "root", "query-limit", 30
    args.sql_socket_timeout = min(args.timeout_sec, 120)
    args.diagnostic_database = None
    return args


def load_adapter():
    raw = pinned(ADAPTER, ADAPTER_SHA)
    pinned(CORE, CORE_SHA)
    tree = ast.parse(pinned(EXPLAIN, EXPLAIN_SHA).decode("utf-8"))
    assignments = [node for node in tree.body if isinstance(node, ast.Assign) and
                   any(isinstance(name, ast.Name) and name.id == "queries" for name in node.targets)]
    require(len(assignments) == 1, "Exact scored query list missing")
    queries = ast.literal_eval(assignments[0].value)
    require(len(queries) == 4 and queries[3] == SQL, "Scored query_limit SQL differs")
    require(small_bytes(HERE / "query_limit.sql") == (SQL + ";\n").encode("utf-8"),
            "Query snapshot differs from exact scored SQL")
    spec = importlib.util.spec_from_file_location("round32_frozen_native_adapter", ADAPTER)
    require(spec is not None, "Cannot create frozen adapter module")
    module = importlib.util.module_from_spec(spec)
    exec(compile(raw, str(ADAPTER), "exec"), module.__dict__)
    require(module.CORE == CORE and module.CORE_SHA == CORE_SHA,
            "Adapter references a different sampler")
    return module


def validate_output(root, name, count, progress):
    require((root / (name + ".stderr.log")).stat().st_size == 0,
            "Native client stderr is nonempty; inspect retained output")
    checked = 0
    with (root / (name + ".stdout.log")).open("rb") as stream:
        for physical in stream:
            require(physical.endswith(b"\n"), "Native result line is truncated")
            line = physical[:-1]
            if line.endswith(b"\r"):
                line = line[:-1]
            require(checked < count and line == b"20",
                    "Complete native COUNT result differs from one-column one-row 20")
            checked += 1
            progress["checked_results"] = checked
    require(checked == count, "Native output result count differs from requested statements")
    progress.update(expected_complete_result="20", every_result_exact=True,
                    empty_lines_allowed=False, native_stderr_empty=True)


def main():
    args = arguments()
    helper = load_adapter()
    root = Path(args.output_dir)
    root.mkdir()
    receipt = {"status": "preparing", "excluded_from_scoring": True,
               "created_utc": datetime.now(timezone.utc).isoformat(),
               "endpoint": {"host": "127.0.0.1", "port": 2891}, "target_pid": args.pid,
               "intended_source": "accepted f56; parent must supply matching build receipt",
               "sql": SQL, "sql_utf8_sha256": digest(SQL.encode("utf-8")),
               "warmup": 30, "query_rounds": args.query_rounds,
               "native_jobs": [], "cleanup_errors": [],
               "source_pins": {str(ADAPTER): ADAPTER_SHA, str(CORE): CORE_SHA,
                               str(EXPLAIN): EXPLAIN_SHA},
               "interpretation": "Intrusive cycle-selected RIP evidence, not CPU share or scored timing"}
    core, hooks, code = None, None, 1
    try:
        args.mysql_client = str(helper.native_client_preflight(args.mysql_client, args.user))
        receipt["native_client"] = {"path": args.mysql_client,
                                    "sha256": helper.NATIVE_CLIENT_SHA,
                                    "source": str(helper.NATIVE_SOURCE),
                                    "source_sha256": helper.NATIVE_SOURCE_SHA}
        core = helper.load_core()
        hooks = core.arguments, core.workloads
        helper.write_input(root / "warmup.input.sql", SQL + ";", 30)
        helper.write_input(root / "measured.input.sql", SQL + ";", args.query_rounds)

        def workloads(cursor, target, symbols, compatible_args, report):
            require(compatible_args is args, "Incompatible sampler arguments")
            report["source"] = core.source_preflight(cursor)
            report["query_limit"] = {"sql": SQL, "expected_complete_result": [[20]],
                                     "warmup": 30, "query_rounds": args.query_rounds}
            helper.native_job(args, target, root, "warmup", None, receipt)
            receipt["warmup_validation"] = {"checked_results": 0}
            validate_output(root, "warmup", 30, receipt["warmup_validation"])
            core.run_phase("query-limit",
                           lambda sampler: helper.native_job(args, target, root, "measured", sampler, receipt),
                           target, symbols, args, report)
            # Full measured output parsing occurs only after run_phase stopped sampling.
            receipt["measured_validation"] = {"checked_results": 0}
            validate_output(root, "measured", args.query_rounds, receipt["measured_validation"])
            report["query_limit"]["complete_result_validation"] = receipt["measured_validation"]

        # Reuse the exact original collector, ownership checks, resolver and cleanup.
        core.arguments, core.workloads = lambda: args, workloads
        with (root / "helper-main.stdout.log").open("x", encoding="utf-8") as stdout, \
                (root / "helper-main.stderr.log").open("x", encoding="utf-8") as stderr, \
                contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
            code = core.main()
        profile = json.loads(Path(args.output).read_text(encoding="utf-8"))
        receipt["sampling_evidence"] = helper.sampling_summary(profile)
        phases = profile.get("phases", [])
        if code in (0, 2):
            require(len(phases) == 1, "Expected exactly one measured query_limit phase")
            sample = phases[0]["sampling"]
            effective = sample["target_image_samples"] - sample["target_unresolved_samples"]
            quality = {"minimum_required": args.min_samples,
                       "raw_valid_captures": sample["sample_count"],
                       "target_image_samples": sample["target_image_samples"],
                       "target_unresolved_samples": sample["target_unresolved_samples"],
                       "effective_target_resolved_samples": effective,
                       "effective_shortfall": max(0, args.min_samples - effective),
                       "adequate": sample["sample_count"] >= args.min_samples and
                                   effective >= args.min_samples}
            profile["query_limit_sample_quality"] = receipt["sample_quality"] = quality
            if not quality["adequate"]:
                profile["status"], code = "insufficient_samples", 2
            Path(args.output).write_text(json.dumps(profile, ensure_ascii=False, indent=2) + "\n",
                                         encoding="utf-8")
        receipt["status"] = profile["status"]
    except BaseException as error:
        receipt.update(status="interrupted" if isinstance(error, KeyboardInterrupt) else "failed",
                       error=helper.safe_error(error))
        code = 130 if isinstance(error, KeyboardInterrupt) else 1
    finally:
        if core is not None and hooks is not None:
            core.arguments, core.workloads = hooks
        if any(job["cleanup_errors"] for job in receipt["native_jobs"]):
            receipt["status"], code = "failed_cleanup", 1
        receipt.update(exit_code=code, finished_utc=datetime.now(timezone.utc).isoformat())
        (root / "receipt.json").write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + "\n",
                                           encoding="utf-8")
    print(json.dumps({"receipt": str(root / "receipt.json"), "status": receipt["status"],
                      "exit_code": code}))
    return code


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (RuntimeError, OSError, ValueError) as error:
        print(json.dumps({"status": "preflight_failed", "error_type": type(error).__name__}),
              file=sys.stderr)
        sys.exit(1)
