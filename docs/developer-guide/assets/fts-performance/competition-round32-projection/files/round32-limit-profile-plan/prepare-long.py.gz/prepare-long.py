"""Freeze a longer unscored diagnostic after the preserved insufficient run."""
import ast
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
sha = lambda raw: hashlib.sha256(raw).hexdigest()
source = (HERE/'sample-limit.py').read_bytes()
assert sha(source) == '20ae0236666b95011c97d03f7eb4ffa5c58f7e45fd35c5b70b0d619367cc75ca'
assert source.count(b'1 <= args.query_rounds <= 8000') == 1
long = source.replace(b'1 <= args.query_rounds <= 8000', b'1 <= args.query_rounds <= 32000', 1)
ast.parse(long)
if (HERE/'sample-limit-long.py').exists():
    assert (HERE/'sample-limit-long.py').read_bytes() == long
else:
    with (HERE/'sample-limit-long.py').open('xb') as stream:
        stream.write(long)
wrapper = (HERE/'run-owned.py').read_bytes()
assert wrapper.count(b"'--query-rounds','8000'") == 1
assert wrapper.count(b'sample-limit.py') == 2
changed = wrapper.replace(b'sample-limit.py',b'sample-limit-long.py').replace(
    b'20ae0236666b95011c97d03f7eb4ffa5c58f7e45fd35c5b70b0d619367cc75ca',sha(long).encode('ascii')).replace(
    b"'--query-rounds','8000'",b"'--query-rounds','32000'")
ast.parse(changed)
with (HERE/'run-owned-long.py').open('xb') as stream:
    stream.write(changed)
record = dict(purpose='Parent-authorized bounded follow-up diagnosis, excluded from scores',
              reason='8000-query run retained: 1103 raw samples, 387 effective target samples; no hotspot conclusion.',
              changed='Only repetition ceiling/request raised to 32000 in separately frozen copies; min1000 effective and raw samples, 180s child timeout, same SQL/results/ownership/collector untouched.',
              original_adapter_sha256=sha(source),long_adapter_sha256=sha(long),long_wrapper_sha256=sha(changed))
with (HERE/'long-preparation.json').open('x',encoding='utf-8') as stream:
    json.dump(record,stream,indent=2);stream.write('\n')
print(json.dumps(record,indent=2))
