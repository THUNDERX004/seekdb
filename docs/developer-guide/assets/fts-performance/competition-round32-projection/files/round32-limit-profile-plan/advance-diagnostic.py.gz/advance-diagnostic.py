"""Temporary non-scored counters for actual buffered advance lengths."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil

HERE = Path(__file__).resolve().parent
ROOT = Path('D:/Projects/OceanBase/seekdb')
CPP = ROOT/'src/storage/retrieval/ob_text_retrieval_token_iter.cpp'
ORIGINAL = '7a7d33cef52f0da958586356f249ab7c807151dc49a5f1c60ecfee41900bd586'
sha = lambda raw: hashlib.sha256(raw).hexdigest()

def save(name,value):
    with (HERE/name).open('x',encoding='utf-8') as stream:
        json.dump(value,stream,indent=2);stream.write('\n')

def apply():
    raw=CPP.read_bytes()
    assert sha(raw)==ORIGINAL
    assert not (ROOT/'build/fts-round32-advance-diagnostic.txt').exists()
    text=raw.decode('utf-8')
    start=text.index('int ObTextRetrievalDaaTTokenIter::advance_to(')
    end=text.index('int ObTextRetrievalDaaTTokenIter::get_curr_score(',start)
    method=text[start:end]
    assert method.count('cmp_func_(')==2
    method=method.replace('cmp_func_(', '(++r32_comparisons, cmp_func_(',2)
    assert method.count('result, nullptr)))')==2
    method=method.replace('result, nullptr)))','result, nullptr))))',2)
    assert method.count('++cur_idx_;')==1
    method=method.replace('++cur_idx_;','++cur_idx_;\n        ++r32_skipped;',1)
    method=method.replace('OB_FAIL(token_iter_->advance_to(id_datum))','OB_FAIL((++r32_refills, token_iter_->advance_to(id_datum)))',1)
    declarations='''  int64_t r32_comparisons = 0;
  int64_t r32_skipped = 0;
  int64_t r32_refills = 0;
  static thread_local int64_t r32_calls = 0;
  static thread_local int64_t r32_cmp_total = 0;
  static thread_local int64_t r32_skip_total = 0;
  static thread_local int64_t r32_refill_total = 0;
  static thread_local int64_t r32_max_skip = 0;
  static thread_local int64_t r32_histogram[16]{};
  static std::atomic<bool> r32_written(false);
'''
    method=method.replace('  bool find = false;','  bool find = false;\n'+declarations,1)
    tail='''  ++r32_calls;
  r32_cmp_total += r32_comparisons;
  r32_skip_total += r32_skipped;
  r32_refill_total += r32_refills;
  r32_max_skip = MAX(r32_max_skip, r32_skipped);
  int bucket = 0;
  for (int64_t value = r32_skipped; value > 0 && bucket < 15; value >>= 1) { ++bucket; }
  ++r32_histogram[bucket];
  if (r32_calls == 4096 && !r32_written.exchange(true)) {
    FILE *record = std::fopen("D:/Projects/OceanBase/seekdb/build/fts-round32-advance-diagnostic.txt", "wb");
    if (nullptr != record) {
      std::fprintf(record, "calls=%lld comparisons=%lld skipped=%lld refills=%lld max_skip=%lld type=%d collation=%d\\n",
          static_cast<long long>(r32_calls), static_cast<long long>(r32_cmp_total),
          static_cast<long long>(r32_skip_total), static_cast<long long>(r32_refill_total),
          static_cast<long long>(r32_max_skip), int(inv_scan_domain_id_col_->datum_meta_.type_),
          int(inv_scan_domain_id_col_->datum_meta_.cs_type_));
      for (int i = 0; i < 16; ++i) {
        std::fprintf(record, "skip_bucket_%d=%lld\\n", i, static_cast<long long>(r32_histogram[i]));
      }
      std::fclose(record);
    }
  }
'''
    assert method.count('  return ret;')==1
    method=method.replace('  return ret;',tail+'  return ret;',1)
    changed=(text[:start]+method+text[end:]).replace('#define USING_LOG_PREFIX STORAGE','#include <atomic>\n#include <cstdio>\n#define USING_LOG_PREFIX STORAGE',1).encode('utf-8')
    with (HERE/'advance-diagnostic-original.cpp').open('xb') as stream:stream.write(raw)
    with (HERE/'advance-diagnostic-candidate.cpp').open('xb') as stream:stream.write(changed)
    CPP.write_bytes(changed)
    save('advance-diagnostic-application.json',dict(status='APPLIED_DIAGNOSTIC_ONLY',original_sha256=ORIGINAL,diagnostic_sha256=sha(changed),scored=False,
         output='D:/Projects/OceanBase/seekdb/build/fts-round32-advance-diagnostic.txt',semantics='First thread to complete4096 actual advance calls; buckets0=>zero skip, n=>2^(n-1)..2^n-1 skipped. Intrusive counters, not timing evidence.'))
    print('APPLIED diagnostic',sha(changed))

def pin():
    record=json.loads((HERE/'advance-diagnostic-application.json').read_text(encoding='utf-8'))
    assert sha(CPP.read_bytes())==record['diagnostic_sha256']
    output=ROOT/'build/fts-round32-advance-diagnostic'
    assert not output.exists();output.mkdir()
    build=ROOT/'build_fts_competition/src/observer'
    files={}
    for source in [build/'seekdb.exe',build/'seekdb.pdb',*sorted(build.glob('*.dll'))]:
        digest=sha(source.read_bytes());shutil.copy2(source,output/source.name)
        assert sha((output/source.name).read_bytes())==digest
        files[source.name]=dict(bytes=source.stat().st_size,sha256=digest)
    save('advance-diagnostic-binary.json',dict(output=str(output),files=files,scored=False))
    print('PINNED',files['seekdb.exe']['sha256'])

def restore():
    record=json.loads((HERE/'advance-diagnostic-application.json').read_text(encoding='utf-8'))
    assert sha(CPP.read_bytes())==record['diagnostic_sha256']
    raw=(HERE/'advance-diagnostic-original.cpp').read_bytes();assert sha(raw)==ORIGINAL
    CPP.write_bytes(raw);assert sha(CPP.read_bytes())==ORIGINAL
    save('advance-diagnostic-restoration.json',dict(status='RESTORED_EXACT',source_sha256=ORIGINAL))
    print('RESTORED accepted CPP')

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('action',choices=['apply','pin','restore'])
    args=parser.parse_args();globals()[args.action]()
