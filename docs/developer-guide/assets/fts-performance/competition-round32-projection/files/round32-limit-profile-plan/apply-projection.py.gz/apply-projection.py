"""Apply the frozen one-file projection-only proposal and its focused regression."""
import ast
import hashlib
import json
from pathlib import Path
import re

HERE=Path(__file__).resolve().parent
FTS=HERE.parent
ROOT=Path('D:/Projects/OceanBase/seekdb')
sha=lambda raw:hashlib.sha256(raw).hexdigest()
proposal=FTS/'round32-count-limit-proposal'
pins=json.loads((proposal/'source-pins.json').read_text(encoding='utf-8'))['changed_source']
patch=(proposal/'proposal.patch').read_bytes()
assert sha(patch)=='6b7f886c3a65418fdf82ef53dddc8b52ff5a7a66432d65493999b1980d3cc27b'
target=ROOT/'src/sql/rewrite/ob_transformer_impl.cpp'
raw=target.read_bytes();assert sha(raw)==pins['sha256']
normalized=raw.decode('utf-8').replace('\r\n','\n')
assert sha(normalized.encode('utf-8'))==pins['normalized_lf_sha256']
source_lines=normalized.splitlines(keepends=True)
patch_lines=patch.decode('utf-8').splitlines(keepends=True)
assert patch_lines[0].strip()=='--- a/src/sql/rewrite/ob_transformer_impl.cpp'
assert patch_lines[1].strip()=='+++ b/src/sql/rewrite/ob_transformer_impl.cpp'
out=[];position=0;cursor=2
while cursor<len(patch_lines):
    match=re.fullmatch(r'@@ -(\d+),(\d+) \+(\d+),(\d+) @@\n',patch_lines[cursor]);assert match
    old_start,old_count,new_start,new_count=map(int,match.groups())
    assert position<=old_start-1
    out.extend(source_lines[position:old_start-1]);position=old_start-1
    consumed=produced=0;cursor+=1
    while cursor<len(patch_lines) and not patch_lines[cursor].startswith('@@ '):
        line=patch_lines[cursor];prefix,text=line[:1],line[1:]
        assert prefix in (' ','+','-')
        if prefix in (' ','-'):
            assert source_lines[position]==text
            position+=1;consumed+=1
        if prefix in (' ','+'):
            out.append(text);produced+=1
        cursor+=1
    assert consumed==old_count and produced==new_count
out.extend(source_lines[position:])
candidate=''.join(out)
assert sha(candidate.encode('utf-8'))==pins['candidate_normalized_lf_sha256']
assert raw.count(b'\r\n')==raw.count(b'\n')
changed=candidate.replace('\n','\r\n').encode('utf-8')
test_source=FTS/'round32-counted-limit-test.py'
test_raw=test_source.read_bytes();ast.parse(test_raw)
test_target=ROOT/'unittest/storage/fts/test_counted_limit_projection.py'
assert not test_target.exists()
preserve={}
for rel in ('src/data_plane/api/data_plane/fts/ob_fts_struct.h','src/storage/fts/ik/ob_ik_arbitrator.h','unittest/storage/fts/stopword_ascii_initial_expected.json'):
    preserve[rel]=sha((ROOT/rel).read_bytes())
with (HERE/'projection-original.cpp').open('xb') as stream:stream.write(raw)
with (HERE/'projection-candidate.cpp').open('xb') as stream:stream.write(changed)
target.write_bytes(changed)
test_target.write_bytes(test_raw)
record=dict(status='APPLIED_UNPROMOTED',source='8b2390a3314091d50297a8f42035b4b19babbafc+round32-projection',
            cpp=str(target),original_sha256=sha(raw),candidate_sha256=sha(changed),patch_sha256=sha(patch),
            test=str(test_target),test_sha256=sha(test_raw),preserved_unrelated_files=preserve,
            diagnostic_restored_sha256=sha((ROOT/'src/storage/retrieval/ob_text_retrieval_token_iter.cpp').read_bytes()))
assert record['diagnostic_restored_sha256']=='7a7d33cef52f0da958586356f249ab7c807151dc49a5f1c60ecfee41900bd586'
with (HERE/'projection-application.json').open('x',encoding='utf-8') as stream:
    json.dump(record,stream,indent=2);stream.write('\n')
print(json.dumps(record,indent=2))
