"""Pin the clean production candidate; diagnostic source must be restored."""
import hashlib
import json
from pathlib import Path
import shutil

HERE=Path(__file__).resolve().parent
ROOT=Path('D:/Projects/OceanBase/seekdb')
sha=lambda raw:hashlib.sha256(raw).hexdigest()
application=json.loads((HERE/'projection-application.json').read_text(encoding='utf-8'))
assert sha(Path(application['cpp']).read_bytes())==application['candidate_sha256']
assert sha((ROOT/'src/storage/retrieval/ob_text_retrieval_token_iter.cpp').read_bytes())=='7a7d33cef52f0da958586356f249ab7c807151dc49a5f1c60ecfee41900bd586'
test=json.loads((HERE/'projection-test-update.json').read_text(encoding='utf-8'))
assert sha(Path(application['test']).read_bytes())==test['sha256']
output=ROOT/'build/fts-round32-projection-candidate'
assert not output.exists();output.mkdir()
build=ROOT/'build_fts_competition/src/observer'
files={}
for source in [build/'seekdb.exe',build/'seekdb.pdb',*sorted(build.glob('*.dll'))]:
    digest=sha(source.read_bytes());shutil.copy2(source,output/source.name)
    assert sha((output/source.name).read_bytes())==digest
    files[source.name]=dict(bytes=source.stat().st_size,sha256=digest)
with (HERE/'projection-binary.json').open('x',encoding='utf-8') as stream:
    json.dump(dict(output=str(output),source=application['source'],files=files,diagnostics=False),stream,indent=2);stream.write('\n')
print('PINNED',files['seekdb.exe']['sha256'])
