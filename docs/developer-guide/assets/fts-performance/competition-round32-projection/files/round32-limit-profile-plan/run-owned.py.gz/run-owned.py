"""Run the prepared LIMIT diagnostic on one owned accepted-build server."""
import ctypes
import hashlib
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
FTS = HERE.parent
ROOT = Path('D:/Projects/OceanBase/seekdb')

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024*1024), b''):
            h.update(block)
    return h.hexdigest()

def main():
    assert len(sys.argv) == 2
    label = sys.argv[1]
    assert label and all(c.isalnum() or c in '-_' for c in label)
    out = HERE / (label+'-instance')
    assert not out.exists()
    assert sha(HERE/'sample-limit.py') == '20ae0236666b95011c97d03f7eb4ffa5c58f7e45fd35c5b70b0d619367cc75ca'
    source_receipt_path = FTS/'r31-advance-rebuilt-control-a1-experiment.json'
    source = json.loads(source_receipt_path.read_text(encoding='utf-8'))
    binary = Path(source['binary'])
    assert source['source_commit'] == 'f56ddd03e66826919d8d9192bc4c0afece8843dd-rebuilt-20261105'
    assert source['binary_sha256'] == '64eac825a6f481c6936e6b6f3b530376052e5fba4498547e83eafe3e923fae8a'
    assert sha(binary) == source['binary_sha256']
    base = Path(source['base_dir']).resolve(strict=True)
    assert base == Path('C:/Users/11946/AppData/Local/Temp/seekdb-fts-round31-rebuilt-control-a1')
    with socket.socket() as sock:
        assert sock.connect_ex(('127.0.0.1',2891)) != 0
    out.mkdir()
    env = os.environ.copy()
    env.update(PYTHONUTF8='1', PYTHONIOENCODING='utf-8')
    env.pop('SEEKDB_TEST_PASSWORD',None)
    env.pop('MYSQL_PWD',None)
    command = [str(binary),'--nodaemon','--base-dir='+str(base),'--port=2891',
               '--parameter','rpc_port=2892','--parameter','cpu_count=4',
               '--parameter','memory_budget=2G','--parameter','log_disk_size=2G','--log-level=WARN']
    receipt = dict(label=label,excluded_from_scoring=True,source=source['source_commit'],
                   source_receipt_sha256=sha(source_receipt_path),binary_sha256=source['binary_sha256'],
                   base_dir=str(base),dataset='Reused unchanged completed full benchmark dataset')
    proc = None
    try:
        with (out/'server.log').open('xb') as log:
            proc = subprocess.Popen(command,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,
                                    creationflags=subprocess.CREATE_NO_WINDOW)
            receipt['owned_server_pid'] = proc.pid
            k = ctypes.WinDLL('kernel32',use_last_error=True)
            k.SetProcessAffinityMask.argtypes = [ctypes.c_void_p,ctypes.c_size_t]
            k.SetProcessAffinityMask.restype = ctypes.c_int
            k.GetProcessAffinityMask.argtypes = [ctypes.c_void_p,ctypes.POINTER(ctypes.c_size_t),ctypes.POINTER(ctypes.c_size_t)]
            k.GetProcessAffinityMask.restype = ctypes.c_int
            assert k.SetProcessAffinityMask(int(proc._handle),15)
            mask,system = ctypes.c_size_t(),ctypes.c_size_t()
            assert k.GetProcessAffinityMask(int(proc._handle),ctypes.byref(mask),ctypes.byref(system))
            assert mask.value == 15
            receipt['affinity_mask_verified'] = mask.value
            import pymysql
            for _ in range(120):
                if proc.poll() is not None:
                    raise RuntimeError('Owned server exited before readiness')
                try:
                    with pymysql.connect(host='127.0.0.1',port=2891,user='root',connect_timeout=1) as conn:
                        with conn.cursor() as cur:
                            cur.execute('SELECT 1')
                            assert cur.fetchone() == (1,)
                    break
                except (OSError,pymysql.MySQLError):
                    time.sleep(1)
            else:
                raise RuntimeError('Owned server startup timeout')
            print('READY owned pid='+str(proc.pid),flush=True)
            args = [sys.executable,'-B',str(HERE/'sample-limit.py'),str(proc.pid),
                    '--binary',str(binary),'--pdb',str(binary.with_suffix('.pdb')),
                    '--dbghelp','C:/Program Files/Microsoft Visual Studio/2022/BuildTools/Common7/IDE/Extensions/TestPlatform/Extensions/Cpp/x64/dbghelp.dll',
                    '--mysql-client',str(ROOT/'build/fts-native-client/mysql-native.exe'),
                    '--output-dir',str(out/'diagnostic'),'--query-rounds','8000','--timeout-sec','180',
                    '--min-samples','1000','--max-samples','50000','--interval-ms','1']
            receipt['diagnostic_command'] = args
            with (out/'diagnostic-command.log').open('xb') as log:
                run = subprocess.run(args,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
            receipt['diagnostic_exit_code'] = run.returncode
            print('DIAGNOSTIC exit='+str(run.returncode),flush=True)
    finally:
        if proc is not None:
            receipt['owned_server_exit_before_cleanup'] = proc.poll()
            if proc.poll() is None:
                proc.terminate()
                try:
                    proc.wait(timeout=20)
                except subprocess.TimeoutExpired:
                    proc.kill();proc.wait(timeout=10)
            receipt['owned_server_exit_after_cleanup'] = proc.returncode
        with (out/'instance.json').open('x',encoding='utf-8') as stream:
            json.dump(receipt,stream,indent=2);stream.write('\n')
    return receipt.get('diagnostic_exit_code',1)

if __name__ == '__main__':
    sys.exit(main())
