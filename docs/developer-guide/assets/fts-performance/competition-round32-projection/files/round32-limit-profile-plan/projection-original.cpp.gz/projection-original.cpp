/*
 * Copyright (c) 2025 OceanBase.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#define USING_LOG_PREFIX SQL_REWRITE

#include "config_bridge.h"
#include "sql/rewrite/ob_transformer_impl.h"
#include "sql/rewrite/ob_transform_view_merge.h"
#include "sql/rewrite/ob_transform_min_max.h"
#include "sql/rewrite/ob_transform_where_subquery_pullup.h"
#include "sql/rewrite/ob_transform_eliminate_outer_join.h"
#include "sql/rewrite/ob_transform_simplify_distinct.h"
#include "sql/rewrite/ob_transform_simplify_expr.h"
#include "sql/rewrite/ob_transform_simplify_groupby.h"
#include "sql/rewrite/ob_transform_simplify_subquery.h"
#include "sql/rewrite/ob_transform_simplify_winfunc.h"
#include "sql/rewrite/ob_transform_simplify_orderby.h"
#include "sql/rewrite/ob_transform_simplify_limit.h"
#include "sql/rewrite/ob_transform_query_push_down.h"
#include "sql/rewrite/ob_transform_aggr_subquery.h"
#include "sql/rewrite/ob_transform_simplify_set.h"
#include "sql/rewrite/ob_transform_project_pruning.h"
#include "sql/rewrite/ob_transform_or_expansion.h"
#include "sql/rewrite/ob_transform_join_elimination.h"
#include "sql/rewrite/ob_transform_win_magic.h"
#include "sql/rewrite/ob_transform_groupby_pullup.h"
#include "sql/rewrite/ob_transform_groupby_pushdown.h"
#include "sql/rewrite/ob_transform_subquery_coalesce.h"
#include "sql/rewrite/ob_transform_pre_process.h"
#include "sql/rewrite/ob_transform_predicate_move_around.h"
#include "sql/rewrite/ob_transform_semi_to_inner.h"
#include "sql/rewrite/ob_transform_join_limit_pushdown.h"
#include "sql/rewrite/ob_transform_temp_table.h"
#include "sql/rewrite/ob_transform_const_propagate.h"
#include "sql/rewrite/ob_transform_left_join_to_anti.h"
#include "sql/rewrite/ob_transform_count_to_exists.h"
#include "sql/rewrite/ob_transform_expr_pullup.h"
#include "sql/rewrite/ob_transform_conditional_aggr_coalesce.h"
#include "sql/rewrite/ob_transform_decorrelate.h"
#include "sql/rewrite/ob_transform_late_materialization.h"
#include "sql/rewrite/ob_transform_distinct_aggregate.h"

using namespace oceanbase::common;
using namespace oceanbase::share;

namespace oceanbase
{
namespace sql
{
int ObTransformerImpl::transform(ObDMLStmt *&stmt)
{
  int ret = OB_SUCCESS;
  if (OB_ISNULL(stmt)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (OB_FAIL(set_transformation_parameters(stmt->get_query_ctx()))) {
  } else if (OB_FAIL(SMART_CALL(get_stmt_trans_info(stmt, true)))) {
  } else if (OB_FAIL(stmt->formalize_implicit_distinct())) {
  } else if (OB_FAIL(do_transform_pre_precessing(stmt))) {
  } else if (OB_FAIL(stmt->formalize_query_ref_exprs())) {
  } else if (OB_FAIL(stmt->formalize_stmt_expr_reference(ctx_->expr_factory_, ctx_->session_info_))) {
  } else if (OB_FAIL(do_transform(stmt))) {
  } else if (OB_FAIL(stmt->formalize_stmt_expr_reference(ctx_->expr_factory_, ctx_->session_info_))) {
  } else if (OB_FAIL(do_after_transform(stmt, ctx_->session_info_))) {
  } else {
    print_trans_stat();
  }
  return ret;
}

int ObTransformerImpl::set_transformation_parameters(ObQueryCtx *query_ctx)
{
  int ret = OB_SUCCESS;
  ObSQLSessionInfo *session_info = NULL;
  bool enable_group_by_placement_transform = false;
  bool opt_param_exists = false;
  int64_t opt_param_val = 0;
  if (OB_ISNULL(query_ctx) || OB_ISNULL(ctx_) || OB_ISNULL(session_info = ctx_->session_info_)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (OB_FAIL(session_info->is_groupby_placement_transformation_enabled(enable_group_by_placement_transform))) {
  } else if (OB_FAIL(query_ctx->get_global_hint().opt_params_.get_bool_opt_param(ObOptParamHint::OPTIMIZER_GROUP_BY_PLACEMENT, enable_group_by_placement_transform))) {
  } else {
    ctx_->is_groupby_placement_enabled_ = enable_group_by_placement_transform;
  }

  if (OB_FAIL(ret)) {
    // do nothing
  } else if (OB_FAIL(query_ctx->get_global_hint().opt_params_.get_integer_opt_param(ObOptParamHint::WITH_SUBQUERY, opt_param_val, opt_param_exists))) {
  } else if (opt_param_exists) {
    ctx_->is_force_inline_ = 2 == opt_param_val;
    ctx_->is_force_materialize_ = 1 == opt_param_val;
  } else if (OB_FAIL(session_info->is_force_temp_table_inline(ctx_->is_force_inline_))) {
  } else if (OB_FAIL(session_info->is_force_temp_table_materialize(ctx_->is_force_materialize_))) {
  }
  if (OB_FAIL(ret)) {
    // do nothing
  } else if (OB_FAIL(session_info->get_optimizer_cost_based_transformation(opt_param_val))) {
  } else if (OB_FAIL(query_ctx->get_global_hint().opt_params_.get_integer_opt_param(
                            ObOptParamHint::OPTIMIZER_COST_BASED_TRANSFORMATION, opt_param_val))) {
  } else {
    ctx_->cbqt_policy_ = static_cast<TransPolicy>(opt_param_val);
  }
  if (OB_SUCC(ret)) {
    

    ctx_->complex_cbqt_table_num_ = config::_complex_cbqt_table_num();
    ctx_->force_subquery_unnest_ = config::_force_subquery_unnest();
    ctx_->nested_loop_join_enabled_ = config::_nested_loop_join_enabled();
    if (OB_FAIL(query_ctx->get_global_hint().opt_params_.get_bool_opt_param(ObOptParamHint::NESTED_LOOP_JOIN_ENABLED, 
                                                                            ctx_->nested_loop_join_enabled_))) {
    }

  }
  return ret;
}

int ObTransformerImpl::get_stmt_trans_info(ObDMLStmt *stmt, bool is_root)
{
  int ret = OB_SUCCESS;
  if (OB_ISNULL(stmt) || OB_ISNULL(ctx_)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (OB_FAIL(ObTransformUtils::check_stmt_contain_oversize_set_stmt(stmt, ctx_->is_set_stmt_oversize_))) {
  }
  if (OB_SUCC(ret) && !ctx_->is_set_stmt_oversize_ && is_root) {
    ObArray<ObDMLStmt::TempTableInfo> temp_table_infos;
    if (OB_FAIL(stmt->collect_temp_table_infos(temp_table_infos))) {
    }
    for (int64_t i = 0; OB_SUCC(ret) && !ctx_->is_set_stmt_oversize_ && i < temp_table_infos.count(); i++) {
      if (OB_FAIL(SMART_CALL(ObTransformUtils::check_stmt_contain_oversize_set_stmt(temp_table_infos.at(i).temp_table_query_,
                                                                                    ctx_->is_set_stmt_oversize_)))) {
      }
    }
  }
  return ret;
}

int ObTransformerImpl::get_random_order_array(uint64_t need_types,
                                              ObQueryCtx *query_ctx,
                                              ObArray<uint64_t> &need_types_array)
{
  int ret = OB_SUCCESS;
  if (OB_ISNULL(query_ctx)) {
    ret = OB_ERR_UNEXPECTED;
  } else {
    common::ObArray<int> index_array;
    for (int64_t i = POST_PROCESS + 1; i < TRANSFORM_TYPE_COUNT_PLUS_ONE && OB_SUCC(ret); ++i) {
      if ((need_types & (1 << i)) != 0) {
        if (OB_FAIL(index_array.push_back(i))) {
        }
      }
    }
    if (OB_SUCC(ret)) {
      for (int64_t idx = 1; idx < index_array.count(); ++idx) {
        int64_t rand_pos = query_ctx->rand_gen_.get(0, idx);
        if (rand_pos != idx) {
          std::swap(index_array.at(rand_pos), index_array.at(idx));
        }
      }
      
      for (int64_t i = 0; i < index_array.count() && OB_SUCC(ret); ++i) {
        int need_types_pos = index_array.at(i);
        uint64_t need_types_local = 1u << need_types_pos;
        if (OB_FAIL(need_types_array.push_back(need_types_local))) {
        }
      }
    }
  }
  return ret;
}

int ObTransformerImpl::transform_random_order(ObDMLStmt *&stmt, ObQueryCtx *query_ctx, uint64_t need_types, int iter_count) 
{
  int ret = OB_SUCCESS;
  if (OB_ISNULL(query_ctx)) {
    ret = OB_ERR_UNEXPECTED;
  } else {
    ObArray<uint64_t> need_types_array;
    if (OB_FAIL(get_random_order_array(need_types, query_ctx, need_types_array))) {
    } else {
      bool any_trans_happened = true;
      for (int64_t i = 0; i < iter_count && OB_SUCC(ret) && any_trans_happened; ++i) {
        any_trans_happened = false;
        for (int64_t j = 0; j < need_types_array.count() && OB_SUCC(ret); ++j) {
          bool trans_happened = false;
          if (OB_FAIL(transform_rule_set(stmt, need_types_array.at(j), 1, trans_happened))) {
          } else {
            any_trans_happened = any_trans_happened || trans_happened;
          }
        }
      }
    }
  }
  return ret;
}

int ObTransformerImpl::do_transform(ObDMLStmt *&stmt)
{
  int ret = OB_SUCCESS;
  uint64_t need_types = ObTransformRule::ALL_TRANSFORM_RULES;
  bool transformation_enabled = true;
  ObQueryCtx *query_ctx = NULL;
  int iter_count = max_iteration_count_;
  bool is_outline = false;
  if (OB_ISNULL(stmt) || OB_ISNULL(query_ctx = stmt->get_query_ctx())
      || OB_ISNULL(ctx_) || OB_ISNULL(ctx_->session_info_)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (OB_FAIL(ctx_->session_info_->is_transformation_enabled(transformation_enabled))) {
  } else if (!transformation_enabled || query_ctx->get_global_hint().disable_query_transform()) {
    /*do nothing*/
  } else if (OB_FAIL(choose_rewrite_rules(stmt, need_types))) {
  } else if (need_types == 0) {
    // do nothing
  } else {
    if (!query_ctx->get_injected_random_status()) {
      is_outline = query_ctx->get_query_hint().has_outline_data();
      if (is_outline) {
        iter_count = max(iter_count, query_ctx->get_query_hint().trans_list_.count() + 1);
      }
      bool trans_happened = false;
      if (OB_FAIL(transform_rule_set(stmt, need_types, iter_count, trans_happened))) {
      }
    } else {
      //unlikely need_types special processing, put all positions out and re-sort.
      if (OB_FAIL(transform_random_order(stmt, query_ctx, need_types, iter_count))) {
      }
    }
  }
  return ret;
}

// do somthing after transform postprocess:
//    1. add pre calc constraints.
//    2. add trans happened hints
int ObTransformerImpl::do_after_transform(ObDMLStmt *stmt, const ObSQLSessionInfo *session)
{
  int ret = OB_SUCCESS;
  ObQueryCtx *query_ctx = NULL;
  ObExecContext *exec_ctx = NULL;
  if (OB_ISNULL(stmt) || OB_ISNULL(query_ctx = stmt->get_query_ctx())
      || OB_ISNULL(ctx_) || OB_ISNULL(exec_ctx = ctx_->exec_ctx_)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (OB_FAIL(finalize_exec_params(stmt))) {
  } else if (OB_FAIL(add_trans_happended_hints(*query_ctx, *ctx_))) {
  } else if (OB_FAIL(add_param_and_expr_constraints(*exec_ctx, *ctx_, *stmt))) {
  } else if (OB_FAIL(adjust_global_dependency_tables(stmt))) {
  } else if (OB_FAIL(verify_all_stmt_exprs(stmt))) {
  } else if (OB_FAIL(verify_all_expr_types(stmt, session))) {
  }
  return ret;
}

int ObTransformerImpl::get_all_stmts(ObDMLStmt *stmt,
                                     ObIArray<ObDMLStmt*> &all_stmts)
{
  int ret = OB_SUCCESS;
  if (OB_ISNULL(stmt)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (OB_FAIL(all_stmts.push_back(stmt))) {
  } else {
    ObIArray<TableItem*> &tables = stmt->get_table_items();
    for (int64_t i = 0; OB_SUCC(ret) && i < tables.count(); i++) {
      if (OB_ISNULL(tables.at(i))) {
        ret = OB_ERR_UNEXPECTED;
      } else if (!tables.at(i)->is_temp_table()) {
        /* do nothing */
      } else if (has_exist_in_array(all_stmts, static_cast<ObDMLStmt*>(tables.at(i)->ref_query_))) {
        //do nothing
      } else if (OB_FAIL(SMART_CALL(get_all_stmts(tables.at(i)->ref_query_, all_stmts)))) {
      }
    }
    if (OB_SUCC(ret)) {
      ObSEArray<ObSelectStmt*, 4> child_stmts;
      if (OB_FAIL(stmt->get_child_stmts(child_stmts))) {
      }
      for (int64_t i = 0; OB_SUCC(ret) && i < child_stmts.count(); i++) {
        if (OB_FAIL(SMART_CALL(get_all_stmts(child_stmts.at(i), all_stmts)))) {
        }
      }
    }
  }
  return ret;
}

int ObTransformerImpl::do_transform_pre_precessing(ObDMLStmt *&stmt)
{
  int ret = OB_SUCCESS;
  if (OB_ISNULL(stmt) || OB_ISNULL(ctx_)) {
    ret = OB_ERR_UNEXPECTED;
  } else {
    ObTransformPreProcess trans(ctx_);
    trans.set_transformer_type(PRE_PROCESS);
    uint64_t dummy_value = 0;
    OPT_TRACE_TITLE("start pre process transform");
    if (OB_FAIL(trans.transform(stmt, dummy_value))) {
    } else {
    }
  }
  return ret;
}

int ObTransformerImpl::transform_heuristic_rule(ObDMLStmt *&stmt)
{
  int ret = OB_SUCCESS;
  bool trans_happened = false;
  if (OB_ISNULL(stmt)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (OB_FAIL(transform_rule_set(stmt,
                                        ObTransformRule::ALL_HEURISTICS_RULES,
                                        max_iteration_count_,
                                        trans_happened))) {
  } else { /*do nothing*/ }
  return ret;
}

int ObTransformerImpl::transform_rule_set(ObDMLStmt *&stmt,
                                          uint64_t needed_types,
                                          int64_t iteration_count,
                                          bool& trans_happened)
{
  int ret = OB_SUCCESS;
  trans_happened = false;
  if (0 != (needed_types & needed_transform_types_)) {
    bool need_next_iteration = true;
    int64_t i = 0;
    ObSEArray<int32_t, 64> cur_enable_types_array;
    if (OB_FAIL(init_enable_types_cnt_array(needed_types, cur_enable_types_array))) {
    }
    for (i = 0; OB_SUCC(ret) && need_next_iteration && i < iteration_count; ++i) {
      bool trans_happened_in_iteration = false;
      ctx_->iteration_level_ = i;
      OPT_TRACE("-- begin ", i, " iteration");
      if (OB_FAIL(transform_rule_set_in_one_iteration(stmt,
                                                      needed_types,
                                                      cur_enable_types_array,
                                                      trans_happened_in_iteration))) {
      } else if (!trans_happened_in_iteration) {
        need_next_iteration = false;
      } else if (OB_FAIL(stmt->formalize_query_ref_exprs())) {
      } else if (OB_FAIL(stmt->formalize_stmt_expr_reference(ctx_->expr_factory_, ctx_->session_info_))) {
      } else if (OB_FAIL(stmt->formalize_stmt(ctx_->session_info_, false))) {
      } else {
        need_next_iteration = true;
        trans_happened = true;
      }
      OPT_TRACE("-- end ", i, " iteration");
    }
    if (OB_SUCC(ret) && need_next_iteration && i == max_iteration_count_) {
      ret = OB_E(EventTable::EN_CHECK_REWRITE_ITER_CONVERGE) OB_SUCCESS;
      if (OB_FAIL(ret)) {
      } else {
        LOG_INFO("transformer ends without convergence", K(max_iteration_count_));
      }
    }
  }
  return ret;
}

int ObTransformerImpl::init_enable_types_cnt_array(uint64_t needed_types,
                                                   ObIArray<int32_t> &enable_cnt_array)
{
  int ret = OB_SUCCESS;
  if (OB_FAIL(enable_cnt_array.prepare_allocate(TRANSFORM_TYPE_COUNT_PLUS_ONE))) {
  } else {
    for (int64_t idx = 0; OB_SUCC(ret) && idx < enable_cnt_array.count(); ++idx) {
      int32_t init_cnt = 0;
      if (0 != (needed_types & (1L << idx))) {
        // For most rules, enable count starts from 1 (enabled).
        // For PREDICATE_MOVE_AROUND, we start from 2 so it can happen at most twice
        // before being temporarily disabled (see update_enable_types()).
        init_cnt = (PREDICATE_MOVE_AROUND == idx)
                       ? PREDICATE_MOVE_AROUND_RESET_CNT
                       : DEFAULT_ENABLE_TYPE_CNT;
      }
      enable_cnt_array.at(idx) = init_cnt;
    }
  }
  return ret;
}

void ObTransformerImpl::enable_cnt_array_to_bitset(const ObIArray<int32_t> &arr, uint64_t &bitset)
{
  bitset = 0;
  const int64_t cnt = arr.count();
  for (int64_t idx = 0; idx < cnt; ++idx) {
    if (arr.at(idx) > 0) {
      bitset |= (1L << idx);
    }
  }
}

int ObTransformerImpl::update_enable_types(TRANSFORM_TYPE type,
                                           uint64_t &enable_types,
                                           ObIArray<int32_t> &enable_cnt_array)
{
  int ret = OB_SUCCESS;
  int32_t cnt = 0;
  if (OB_UNLIKELY(type >= enable_cnt_array.count())) {
    ret = OB_INVALID_ARGUMENT;
  } else {
    int32_t &cnt = enable_cnt_array.at(type);
    if (PREDICATE_MOVE_AROUND == type) {
      // Non-convergence guard:
      // Predicate deduction (a.k.a. predicate move around) may oscillate with
      // constant propagation and expression simplification. To avoid rewrite
      // ping-pong within one iteration sequence, we only allow it to happen a
      // limited number of times (PREDICATE_MOVE_AROUND_RESET_CNT). After that,
      // we temporarily disable it until it is reset by other rewrite rules.
      cnt--;
      if (cnt <= 0) {
        enable_types &= ~(1L << type);
      }
    } else if (CONST_PROPAGATE == type || SIMPLIFY_EXPR == type) {
      // These rules are considered part of the "oscillation group" with predicate
      // deduction. If only these rules happen, we do NOT reset predicate deduction.
      /*do nothing*/
    } else {
      // Any other rewrite rule indicates progress in a different direction, so we
      // re-enable predicate deduction and reset its budget.
      ObTransformRule::add_trans_type(enable_types, PREDICATE_MOVE_AROUND);
      enable_cnt_array.at(PREDICATE_MOVE_AROUND) = PREDICATE_MOVE_AROUND_RESET_CNT;
    }
  }
  return ret;
}

int ObTransformerImpl::transform_rule_set_in_one_iteration(ObDMLStmt *&stmt,
                                                           uint64_t needed_types,
                                                           ObIArray<int32_t> &cur_enable_types_array,
                                                           bool &trans_happened)
{
  int ret = OB_SUCCESS;
  trans_happened = false;
  if (OB_ISNULL(stmt)) {
    ret = OB_INVALID_ARGUMENT;
  } else {
    uint64_t cur_enable_types = 0;
    enable_cnt_array_to_bitset(cur_enable_types_array, cur_enable_types);
    // cur_enable_types may be updated after each rule happens to avoid rewrite
    // ping-pong (PREDICATE_MOVE_AROUND vs CONST_PROPAGATE / SIMPLIFY_EXPR).
    /*
     * The ordering to apply the following rules is important,
     * think carefully when new rules are added
     */
    APPLY_RULE_IF_NEEDED(SIMPLIFY_EXPR, ObTransformSimplifyExpr);
    APPLY_RULE_IF_NEEDED(SIMPLIFY_DISTINCT, ObTransformSimplifyDistinct);
    APPLY_RULE_IF_NEEDED(SIMPLIFY_GROUPBY, ObTransformSimplifyGroupby);
    APPLY_RULE_IF_NEEDED(SIMPLIFY_WINFUNC, ObTransformSimplifyWinfunc);
    APPLY_RULE_IF_NEEDED(SIMPLIFY_ORDERBY, ObTransformSimplifyOrderby);
    APPLY_RULE_IF_NEEDED(SIMPLIFY_LIMIT, ObTransformSimplifyLimit);
    APPLY_RULE_IF_NEEDED(TEMP_TABLE_OPTIMIZATION, ObTransformTempTable);
    APPLY_RULE_IF_NEEDED(PROJECTION_PRUNING, ObTransformProjectPruning);
    APPLY_RULE_IF_NEEDED(CONST_PROPAGATE, ObTransformConstPropagate);
    APPLY_RULE_IF_NEEDED(DISTINCT_AGGREGATE, ObTransformDistinctAggregate);
    APPLY_RULE_IF_NEEDED(SUBQUERY_COALESCE, ObTransformSubqueryCoalesce);
    APPLY_RULE_IF_NEEDED(SIMPLIFY_SET, ObTransformSimplifySet);
    APPLY_RULE_IF_NEEDED(VIEW_MERGE, ObTransformViewMerge);
    APPLY_RULE_IF_NEEDED(COUNT_TO_EXISTS, ObTransformCountToExists);
    APPLY_RULE_IF_NEEDED(WHERE_SQ_PULL_UP, ObWhereSubQueryPullup);
    APPLY_RULE_IF_NEEDED(SIMPLIFY_SUBQUERY, ObTransformSimplifySubquery);
    APPLY_RULE_IF_NEEDED(SEMI_TO_INNER, ObTransformSemiToInner);
    APPLY_RULE_IF_NEEDED(QUERY_PUSH_DOWN, ObTransformQueryPushDown);
    APPLY_RULE_IF_NEEDED(SELECT_EXPR_PULLUP, ObTransformExprPullup);
    APPLY_RULE_IF_NEEDED(DECORRELATE, ObTransformDecorrelate);
    APPLY_RULE_IF_NEEDED(ELIMINATE_OJ, ObTransformEliminateOuterJoin);
    APPLY_RULE_IF_NEEDED(JOIN_ELIMINATION, ObTransformJoinElimination);
    APPLY_RULE_IF_NEEDED(JOIN_LIMIT_PUSHDOWN, ObTransformJoinLimitPushDown);
    APPLY_RULE_IF_NEEDED(LEFT_JOIN_TO_ANTI, ObTransformLeftJoinToAnti);
    APPLY_RULE_IF_NEEDED(AGGR_SUBQUERY, ObTransformAggrSubquery);
    APPLY_RULE_IF_NEEDED(WIN_MAGIC, ObTransformWinMagic);
    APPLY_RULE_IF_NEEDED(CONDITIONAL_AGGR_COALESCE, ObTransformConditionalAggrCoalesce);
    APPLY_RULE_IF_NEEDED(FASTMINMAX, ObTransformMinMax);
    APPLY_RULE_IF_NEEDED(PREDICATE_MOVE_AROUND, ObTransformPredicateMoveAround);
    APPLY_RULE_IF_NEEDED(GROUPBY_PUSHDOWN, ObTransformGroupByPushdown);
    APPLY_RULE_IF_NEEDED(GROUPBY_PULLUP, ObTransformGroupByPullup);
    APPLY_RULE_IF_NEEDED(OR_EXPANSION, ObTransformOrExpansion);
    APPLY_RULE_IF_NEEDED(LATE_MATERIALIZATION, ObTransformLateMaterialization);
  }
  return ret;
}

int ObTransformerImpl::get_cost_based_trans_happened(TRANSFORM_TYPE type, bool &trans_happened) const
{
  int ret = OB_SUCCESS;
  trans_happened = false;
  if (OB_ISNULL(ctx_)) {
    ret = OB_INVALID_ARGUMENT;
  } else {
    trans_happened = is_type_needed(ctx_->happened_cost_based_trans_, type);
  }
  return ret;
}

int ObTransformerImpl::collect_trans_stat(const ObTransformRule &rule)
{
  int ret = OB_SUCCESS;
  if (rule.get_trans_happened()) {
    int64_t idx = rule.get_transformer_type();
    if (idx >= 1 && idx < MAX_RULE_COUNT) {
      ++ trans_count_[idx];
    }
  }
  return ret;
}

void ObTransformerImpl::print_trans_stat()
{
  for (int64_t i = 1; i < TRANSFORM_TYPE_COUNT_PLUS_ONE; ++i) {
  }
}

int ObTransformerImpl::choose_rewrite_rules(ObDMLStmt *stmt, uint64_t &need_types)
{
  int ret = OB_SUCCESS;
  uint64_t disable_list = 0;
  StmtFunc func;
  ObSqlCtx *sql_ctx = NULL;
  if (OB_ISNULL(stmt)
      || OB_ISNULL(ctx_->exec_ctx_)
      || OB_ISNULL(sql_ctx = ctx_->exec_ctx_->get_sql_ctx())
      || OB_ISNULL(ctx_->session_info_)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (sql_ctx->is_batch_params_execute()) {
    need_types = 0; // if it is batch optimization, do not rewrite for now
  } else if (OB_FAIL(check_stmt_functions(stmt, func))) {
  } else if (OB_FAIL(check_temp_table_functions(stmt, func))) {
  } else {
    if (func.contain_geometry_values_ || func.contain_fulltext_search_ || func.contain_vec_index_approx_) {
      disable_list = ObTransformRule::ALL_TRANSFORM_RULES;
    }
    if (func.contain_enum_set_values_) {
      uint64_t enum_set_enable_list = 0;
      ObTransformRule::add_trans_type(enum_set_enable_list, SIMPLIFY_DISTINCT);
      ObTransformRule::add_trans_type(enum_set_enable_list, SIMPLIFY_GROUPBY);
      ObTransformRule::add_trans_type(enum_set_enable_list, SIMPLIFY_WINFUNC);
      ObTransformRule::add_trans_type(enum_set_enable_list, SIMPLIFY_ORDERBY);
      ObTransformRule::add_trans_type(enum_set_enable_list, SIMPLIFY_LIMIT);
      ObTransformRule::add_trans_type(enum_set_enable_list, SIMPLIFY_SUBQUERY);
      ObTransformRule::add_trans_type(enum_set_enable_list, FASTMINMAX);
      ObTransformRule::add_trans_type(enum_set_enable_list, ELIMINATE_OJ);
      ObTransformRule::add_trans_type(enum_set_enable_list, VIEW_MERGE);
      ObTransformRule::add_trans_type(enum_set_enable_list, WHERE_SQ_PULL_UP);
      ObTransformRule::add_trans_type(enum_set_enable_list, QUERY_PUSH_DOWN);
      ObTransformRule::add_trans_type(enum_set_enable_list, SIMPLIFY_SET);
      ObTransformRule::add_trans_type(enum_set_enable_list, PROJECTION_PRUNING);
      ObTransformRule::add_trans_type(enum_set_enable_list, AGGR_SUBQUERY);
      ObTransformRule::add_trans_type(enum_set_enable_list, PREDICATE_MOVE_AROUND);
      ObTransformRule::add_trans_type(enum_set_enable_list, JOIN_LIMIT_PUSHDOWN);
      ObTransformRule::add_trans_type(enum_set_enable_list, COUNT_TO_EXISTS);
      ObTransformRule::add_trans_type(enum_set_enable_list, CONDITIONAL_AGGR_COALESCE);
      ObTransformRule::add_trans_type(enum_set_enable_list, SEMI_TO_INNER);
      ObTransformRule::add_trans_type(enum_set_enable_list, DISTINCT_AGGREGATE);
      disable_list |= (~enum_set_enable_list);
    }
    if (func.contain_dml_with_doc_id_) {
      uint64_t dml_with_doc_id_enable_list = 0;
      ObTransformRule::add_trans_type(dml_with_doc_id_enable_list, PREDICATE_MOVE_AROUND);
      disable_list |= (~dml_with_doc_id_enable_list);
    }
    if (func.contain_for_update_) {
      ObTransformRule::add_trans_type(disable_list, JOIN_ELIMINATION);
      ObTransformRule::add_trans_type(disable_list, WIN_MAGIC);
      ObTransformRule::add_trans_type(disable_list, NL_FULL_OUTER_JOIN);
      ObTransformRule::add_trans_type(disable_list, OR_EXPANSION);
      ObTransformRule::add_trans_type(disable_list, GROUPBY_PUSHDOWN);
      ObTransformRule::add_trans_type(disable_list, GROUPBY_PULLUP);
    }
    if (func.update_global_index_) {
      ObTransformRule::add_trans_type(disable_list, WIN_MAGIC);
    }
    if (func.contain_json_table_) {
      // json table ban group by pushdown && join limit pushdown && left join pushdown
      ObTransformRule::add_trans_type(disable_list, GROUPBY_PUSHDOWN);
      ObTransformRule::add_trans_type(disable_list, JOIN_LIMIT_PUSHDOWN);
      ObTransformRule::add_trans_type(disable_list, LEFT_JOIN_TO_ANTI);
    }
    // reconstruct-sql trace point
    if ((OB_E(EventTable::EN_GENERATE_PLAN_WITH_RECONSTRUCT_SQL) OB_SUCCESS) != OB_SUCCESS) {
      ObTransformRule::add_trans_type(disable_list, SELECT_EXPR_PULLUP);
    }
    need_types = ObTransformRule::ALL_TRANSFORM_RULES & (~disable_list);
  }
  return ret;
}

int ObTransformerImpl::check_temp_table_functions(ObDMLStmt *stmt, StmtFunc &func)
{
  int ret = OB_SUCCESS;
  ObSEArray<ObDMLStmt::TempTableInfo, 8> temp_table_infos;
  if (func.all_found()) {
    // do nothing
  } else if (OB_ISNULL(stmt)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (OB_FAIL(stmt->collect_temp_table_infos(temp_table_infos))) {
  }
  for(int64_t i = 0; OB_SUCC(ret) && !func.all_found() && i < temp_table_infos.count(); ++i) {
    ObDMLStmt *child_stmt = temp_table_infos.at(i).temp_table_query_;
    if (OB_ISNULL(child_stmt)) {
      ret = OB_ERR_UNEXPECTED;
    } else if (OB_FAIL(check_stmt_functions(child_stmt, func))) {
    }
  }
  return ret;
}

int ObTransformerImpl::check_stmt_functions(const ObDMLStmt *stmt, StmtFunc &func)
{
  int ret = OB_SUCCESS;
  if (OB_ISNULL(stmt)) {
    ret = OB_ERR_UNEXPECTED;
  } else {
    func.contain_for_update_ = func.contain_for_update_ || stmt->has_for_update();
    func.contain_fulltext_search_ = func.contain_fulltext_search_ || (stmt->get_match_exprs().count() != 0);
    func.contain_vec_index_approx_ = func.contain_vec_index_approx_ || stmt->has_vec_approx();
  }
  for (int64_t i = 0; OB_SUCC(ret)
                      && (!func.contain_enum_set_values_ || !func.contain_geometry_values_)
                      && i < stmt->get_column_items().count(); ++i) {
    const ColumnItem &col = stmt->get_column_items().at(i);
    if (OB_ISNULL(col.get_expr())) {
      ret = OB_ERR_UNEXPECTED;
    } else {
      func.contain_enum_set_values_ |= ob_is_enumset_tc(col.get_expr()->get_data_type());
      func.contain_geometry_values_ |= ob_is_geometry_tc(col.get_expr()->get_data_type());
    }
  }
  for (int64_t i = 0; OB_SUCC(ret) && !func.contain_json_table_ && 
                      i < stmt->get_table_items().count(); ++i) {
    const TableItem *table = stmt->get_table_item(i);
    if (OB_ISNULL(table)) {
      ret = OB_ERR_UNEXPECTED;
    } else if (!table->is_json_table()) { // do nothing
    } else if (OB_ISNULL(table->json_table_def_) || table->json_table_def_->doc_exprs_.empty()) {
      ret = OB_ERR_UNEXPECTED;
    } else {
      for (int j = 0; OB_SUCC(ret) && !func.contain_json_table_ && j < table->json_table_def_->doc_exprs_.count(); ++j) {
        if (OB_NOT_NULL(table->json_table_def_->doc_exprs_.at(j)) &&
            !table->json_table_def_->doc_exprs_.at(j)->get_relation_ids().is_empty()) {
          func.contain_json_table_ = true;
        }
      }
    }
  }
  if (OB_SUCC(ret) && (stmt->is_delete_stmt() ||
                       stmt->is_update_stmt() ||
                       stmt->is_insert_stmt())) {
    const ObDelUpdStmt *del_upd_stmt = static_cast<const ObDelUpdStmt *>(stmt);
    func.update_global_index_ = func.update_global_index_ || del_upd_stmt->has_global_index();
  }
  if (OB_SUCC(ret) && (stmt->is_update_stmt() || stmt->is_delete_stmt())) {
    ObSqlSchemaGuard &schema_guard = stmt->query_ctx_->sql_schema_guard_;
    for (int64_t i = 0; OB_SUCC(ret) && !func.contain_dml_with_doc_id_ && 
                        i < stmt->get_table_items().count(); ++i) {
      const ObTableSchema *table_schema;
      if (OB_ISNULL(stmt->get_table_items().at(i))) {
        ret = OB_ERR_UNEXPECTED;
      } else if (!stmt->get_table_items().at(i)->get_table_name().suffix_match("rowkey_doc")) {
        // do nothing
      } else if (OB_FAIL(schema_guard.get_table_schema(stmt->get_table_items().at(i)->ref_id_, table_schema))) {
      } else if (OB_ISNULL(table_schema)) {
        ret = OB_ERR_UNEXPECTED;
        LOG_WARN("get invalid table schema", K(table_schema));
      } else if (table_schema->is_rowkey_doc_id()) {
        func.contain_dml_with_doc_id_ = true;
      }
    }
  }
  if (OB_SUCC(ret) && !func.all_found()) {
    ObSEArray<ObSelectStmt*, 8> child_stmts;
    if (OB_FAIL(stmt->get_child_stmts(child_stmts))) {
    }
    for (int64_t i = 0; OB_SUCC(ret) && i < child_stmts.count(); ++i) {
      ObSelectStmt *sub_stmt = child_stmts.at(i);
      if (OB_ISNULL(sub_stmt)) {
        ret = OB_ERR_UNEXPECTED;
      } else if (OB_FAIL(SMART_CALL(check_stmt_functions(sub_stmt, func)))) {
      }
    }
  }
  return ret;
}

int ObTransformerImpl::finalize_exec_params(ObDMLStmt *stmt)
{
  int ret = OB_SUCCESS;
  ObSEArray<ObSelectStmt *, 4> child_stmts;
  if (OB_ISNULL(stmt)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (OB_FAIL(stmt->get_child_stmts(child_stmts))) {
  } else {
    ObArray<ObDMLStmt::TempTableInfo> temp_table_infos;
    if (OB_FAIL(stmt->collect_temp_table_infos(temp_table_infos))) {
    }
    for (int64_t i = 0; OB_SUCC(ret) && i < temp_table_infos.count(); ++i) {
      if (OB_FAIL(child_stmts.push_back(temp_table_infos.at(i).temp_table_query_))) {
      }
    }
  }
  for (int64_t i = 0; OB_SUCC(ret) && i < stmt->get_table_items().count(); ++i) {
    TableItem *table_item = NULL;
    if (OB_ISNULL(table_item = stmt->get_table_items().at(i))) {
      ret = OB_ERR_UNEXPECTED;
    } else if (OB_FAIL(finalize_exec_params(stmt, table_item->exec_params_))) {
    }
  }
  for (int64_t i = 0; OB_SUCC(ret) && i < stmt->get_subquery_expr_size(); ++i) {
    ObQueryRefRawExpr *query_ref = NULL;
    if (OB_ISNULL(query_ref = stmt->get_subquery_exprs().at(i))) {
      ret = OB_ERR_UNEXPECTED;
    } else if (OB_FAIL(finalize_exec_params(stmt, query_ref->get_exec_params()))) {
    }
  }
  for (int64_t i = 0; OB_SUCC(ret) && i < child_stmts.count(); ++i) {
    if (OB_FAIL(SMART_CALL(finalize_exec_params(child_stmts.at(i))))) {
    }
  }
  return ret;
}

int ObTransformerImpl::finalize_exec_params(ObDMLStmt *stmt, ObIArray<ObExecParamRawExpr*> & exec_params)
{
  int ret = OB_SUCCESS;
  if (OB_ISNULL(stmt) || OB_ISNULL(stmt->query_ctx_)) {
    ret = OB_ERR_UNEXPECTED;
  }
  for (int64_t j = 0; OB_SUCC(ret) && j < exec_params.count(); ++j) {
    ObExecParamRawExpr *exec_param = NULL;
    if (OB_ISNULL(exec_param = exec_params.at(j))) {
      ret = OB_ERR_UNEXPECTED;
    } else if (exec_param->get_param_index() >= 0) {
      // do nothing
    } else {
      exec_param->set_param_index(*stmt->query_ctx_);
      exec_param->set_result_type(exec_param->get_ref_expr()->get_result_type());
    }
  }
  return ret;
}

// TODO @yibo perhaps we can't remove dependency table.
// for example, t1 left join t2 on t1.c1 = t2.c1 eliminate t2 relay on t2.c1 is unique,
// if schema version of t2 change, t2.c1 may not uniuqe.
int ObTransformerImpl::adjust_global_dependency_tables(ObDMLStmt *stmt)
{
  int ret = OB_SUCCESS;
  if (OB_ISNULL(stmt)) {
    ret = OB_ERR_UNEXPECTED;
  } else {
    ObIArray<share::schema::ObSchemaObjVersion> *global_tables = stmt->get_global_dependency_table();
    if (OB_ISNULL(global_tables)) {
      ret = OB_ERR_UNEXPECTED;
    } else { /*do nothing.*/ }
    for (int64_t i = 0; OB_SUCC(ret) && i < global_tables->count(); ++i) {
      bool is_existed = false;
      if (global_tables->at(i).is_base_table()) {
        if (OB_FAIL(stmt->check_if_table_exists(global_tables->at(i).object_id_,
                                                is_existed))) {
        } else if (!is_existed) {
          global_tables->at(i).is_existed_ = false;
        } else { /* do nothing. */ }
      } else { /* do nothing. */ }
    }
  }
  return ret;
}

int ObTransformerImpl::verify_all_stmt_exprs(ObDMLStmt *stmt)
{
  int ret = OB_SUCCESS;
  if (OB_ISNULL(stmt)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (OB_FAIL(verify_stmt_exprs(stmt))) {
  } else {
    ObArray<ObDMLStmt::TempTableInfo> temp_table_infos;
    if (OB_FAIL(stmt->collect_temp_table_infos(temp_table_infos))) {
    }
    for (int64_t i = 0; OB_SUCC(ret) && i < temp_table_infos.count(); ++i) {
      if (OB_FAIL(verify_stmt_exprs(temp_table_infos.at(i).temp_table_query_))) {
      }
    }
  }
  return ret;
}

int ObTransformerImpl::verify_stmt_exprs(ObDMLStmt *stmt)
{
  int ret = OB_SUCCESS;
  if (OB_ISNULL(stmt)) {
    ret = OB_ERR_UNEXPECTED;
  } else {
    ObStmtExprChecker checker;
    checker.set_relation_scope();
    if (OB_FAIL(stmt->iterate_stmt_expr(checker))) {
    }
  }
  return ret;
}

int ObTransformerImpl::add_param_and_expr_constraints(ObExecContext &exec_ctx,
                                                      ObTransformerCtx &trans_ctx,
                                                      ObDMLStmt &stmt)
{
  int ret = OB_SUCCESS;
  ObSEArray<ObHiddenColumnItem, 8> pre_calc_error_exprs;
  ObQueryCtx *query_ctx = NULL;
  if (OB_ISNULL(query_ctx = stmt.get_query_ctx())) {
    ret = OB_ERR_UNEXPECTED;
  } else if (OB_FAIL(append(query_ctx->all_plan_const_param_constraints_,
                            trans_ctx.plan_const_param_constraints_))) {
  } else if (OB_FAIL(append(query_ctx->all_equal_param_constraints_,
                            trans_ctx.equal_param_constraints_))) {
  } else if (OB_FAIL(append(query_ctx->all_expr_constraints_, 
                            trans_ctx.expr_constraints_))) {
  }
  return ret;
}


int ObTransformerImpl::add_all_rowkey_columns_to_stmt(const ObTableSchema &table_schema,
                                                      const TableItem &table_item,
                                                      ObRawExprFactory &expr_factory,
                                                      ObDMLStmt &stmt,
                                                      ObIArray<ColumnItem> &column_items)
{
  int ret = OB_SUCCESS;
  const ObRowkeyInfo &rowkey_info = table_schema.get_rowkey_info();
  const ObColumnSchemaV2 *column_schema = NULL;
  uint64_t column_id = OB_INVALID_ID;
  ColumnItem *exists_col_item = NULL;
  ObColumnRefRawExpr *rowkey = NULL;
  for (int col_idx = 0; OB_SUCC(ret) && col_idx < rowkey_info.get_size(); ++col_idx) {
    if (OB_FAIL(rowkey_info.get_column_id(col_idx, column_id))) {
    } else if (NULL != (exists_col_item = stmt.get_column_item_by_id(table_item.table_id_,
                                                                     column_id))) {
      if (OB_FAIL(column_items.push_back(*exists_col_item))) {
      }
    } else if (OB_ISNULL(column_schema = (table_schema.get_column_schema(column_id)))) {
      ret = OB_ERR_UNEXPECTED;
    } else if (OB_FAIL(ObRawExprUtils::build_column_expr(expr_factory, *column_schema,
                                                         ctx_->session_info_, rowkey))) {
    } else if (OB_ISNULL(rowkey)) {
      ret = OB_ERR_UNEXPECTED;
    } else {
      ColumnItem column_item;
      rowkey->set_ref_id(table_item.table_id_, column_schema->get_column_id());
      rowkey->set_column_attr(table_item.get_table_name(), column_schema->get_column_name_str());
      rowkey->set_database_name(table_item.database_name_);
      if (!table_item.alias_name_.empty()) {
        rowkey->set_table_alias_name();
      }
      column_item.expr_ = rowkey;
      column_item.table_id_ = rowkey->get_table_id();
      column_item.column_id_ = rowkey->get_column_id();
      column_item.base_tid_ = table_item.ref_id_;
      column_item.base_cid_ = rowkey->get_column_id();
      column_item.column_name_ = rowkey->get_column_name();
      column_item.set_default_value(column_schema->get_cur_default_value());
      if (OB_FAIL(stmt.add_column_item(column_item))) {
      } else if (OB_FAIL(column_items.push_back(column_item))) {
      } else if (FALSE_IT(rowkey->clear_explicited_referece())) {
      } else if (OB_ISNULL(ctx_)) {
        ret = OB_ERR_UNEXPECTED;
      } else if (OB_FAIL(rowkey->formalize(ctx_->session_info_))) {
      } else if (OB_FAIL(rowkey->pull_relation_id())) {
      }
    }
  }
  return ret;
}

int ObTransformerImpl::add_trans_happended_hints(ObQueryCtx &query_ctx,
                                                 ObTransformerCtx &trans_ctx)
{
  int ret = OB_SUCCESS;
  ObQueryHint &query_hint = query_ctx.get_query_hint_for_update();
  if (OB_FAIL(query_hint.outline_trans_hints_.assign(trans_ctx.outline_trans_hints_))) {
  } else if (OB_FAIL(query_hint.used_trans_hints_.assign(trans_ctx.used_trans_hints_))) {
  }
  return ret;
}

int ObTransformerImpl::verify_all_expr_types(ObDMLStmt *stmt, const ObSQLSessionInfo *session)
{
  int ret = OB_SUCCESS;
  ObSEArray<ObRawExpr*, 16> relation_exprs;
  int64_t tmp_ret = (OB_E(EventTable::EN_CHECK_EXPR_FORMALIZE) OB_SUCCESS);
  bool check_expr_type = OB_SUCCESS != tmp_ret;
  bool report_error = check_expr_type && (OB_ERR_UNEXPECTED == tmp_ret);
  if (OB_ISNULL(stmt)) {
    ret = OB_ERR_UNEXPECTED;
  } else if (OB_FAIL(stmt->get_relation_exprs(relation_exprs))) {
  } else {
    for (int64_t i = 0; OB_SUCC(ret) && i < relation_exprs.count(); ++i) {
      ObRawExpr *expr = relation_exprs.at(i);
      ObSEArray<ObRawExprResType, 4> origin_types;
      ObSEArray<ObRawExprResType, 4> formalize_types;
      bool has_diff_type = false;
      if (OB_ISNULL(expr)) {
        ret = OB_ERR_UNEXPECTED;
      } else if (check_expr_type && OB_FAIL(ObRawExprUtils::get_all_expr_types(expr, origin_types))) {
      } else if (OB_FAIL(expr->formalize(session))) {
      } else if (check_expr_type && OB_FAIL(ObRawExprUtils::get_all_expr_types(expr, formalize_types))) {
      } else if (check_expr_type) {
        if (origin_types.count() != formalize_types.count()) {
          has_diff_type = true;
        }
        for (int64_t j = 0; OB_SUCC(ret) && !has_diff_type && j < origin_types.count(); ++j) {
          if (origin_types.at(j).get_obj_meta() != formalize_types.at(j).get_obj_meta()) {
            // jinmao TODO: origin_types.at(j).get_result_flag() != formalize_types.at(j).get_result_flag()
            has_diff_type = true;
          } else if (ob_is_int_tc(origin_types.at(j).get_type()) ||
                     ob_is_uint_tc(origin_types.at(j).get_type()) ||
                     ob_is_double_tc(origin_types.at(j).get_type()) ||
                     ob_is_float_tc(origin_types.at(j).get_type()) ||
                     ob_is_datetime_tc(origin_types.at(j).get_type()) ||
                     ob_is_date_tc(origin_types.at(j).get_type()) ||
                     ob_is_time_tc(origin_types.at(j).get_type()) ||
                     ob_is_year_tc(origin_types.at(j).get_type()) ||
                     ob_is_time_tc(origin_types.at(j).get_type())) {
            // do nothing
            // precision/scale of these types are not crucial to calculation process (only affect output length)
          } else if (ob_is_number_tc(origin_types.at(j).get_type()) ||
                     ob_is_decimal_int_tc(origin_types.at(j).get_type()) ||
                     ob_is_bit_tc(origin_types.at(j).get_type())) {
            has_diff_type = origin_types.at(j).get_scale() != formalize_types.at(j).get_scale() ||
                            origin_types.at(j).get_precision() != formalize_types.at(j).get_precision();
          } else if (ob_is_string_or_lob_type(origin_types.at(j).get_type()) ||
                     ob_is_raw_tc(origin_types.at(j).get_type())) {
            // we do not check `length` here, because length from multiple derivations can be different in some scenarios.
            // do nothing
          } else {
            has_diff_type = origin_types.at(j).get_accuracy() != formalize_types.at(j).get_accuracy();
          }
        }
        if (OB_SUCC(ret) && has_diff_type) {
          if (report_error) {
            ret = OB_NOT_SUPPORTED;
            LOG_USER_ERROR(OB_NOT_SUPPORTED, "expr types not well deduced after transform");
          } else {
            LOG_USER_WARN(OB_NOT_SUPPORTED, "expr types not well deduced after transform");
          }
        }
      }
    }
  }
  // check subqueries
  for (int64_t i = 0; OB_SUCC(ret) && i < stmt->get_subquery_expr_size(); ++i) {
    ObQueryRefRawExpr *query_ref = stmt->get_subquery_exprs().at(i);
    ObSelectStmt *subquery = NULL;
    if (OB_ISNULL(query_ref)) {
      ret = OB_ERR_UNEXPECTED;
    } else if (OB_ISNULL(subquery = query_ref->get_ref_stmt())) {
      ret = OB_ERR_UNEXPECTED;
    } else if (OB_FAIL(SMART_CALL(verify_all_expr_types(subquery, session)))) {
    }
  }
  // check generated tables and temp tables
  for (int64_t i = 0; OB_SUCC(ret) && i < stmt->get_table_size(); ++i) {
    const TableItem *table_item = stmt->get_table_item(i);
    if (OB_ISNULL(table_item)) {
      ret = OB_ERR_UNEXPECTED;
    } else if (table_item->is_generated_table() || table_item->is_lateral_table() || table_item->is_temp_table()) {
      ObSelectStmt *subquery = NULL;
      if (OB_ISNULL(subquery = table_item->ref_query_)) {
        ret = OB_ERR_UNEXPECTED;
      } else if (OB_FAIL(SMART_CALL(verify_all_expr_types(subquery, session)))) {
      }
    }
  }
  return ret;
}
}
}
