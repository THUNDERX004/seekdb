"""Offline strict round19 pairs; local incremental comparisons, never a formal score.

Preparation does not execute this module. Running it later reads named completed
receipts/reports and exclusively creates one new comparison JSON. No workloads,
subprocesses, server actions, source changes, or archived-input writes exist here.
"""
from __future__ import annotations

import argparse
from decimal import Decimal
import hashlib
import json
import math
from pathlib import Path
import re
from statistics import mean
import sys

HERE = Path(__file__).resolve().parent
FTS = HERE.parent
CLASSES = {
    "build": ("build_ik_all_sec", "build_ik_content_sec", "build_beng_en_sec"),
    "tokenize": ("tokenize_ik_avg_ms", "tokenize_beng_avg_ms"),
    "query": ("query_cn_avg_ms", "query_beng_avg_ms",
              "query_mixed_avg_ms", "query_limit_avg_ms"),
}
METRICS = tuple(name for names in CLASSES.values() for name in names)
PARAMS = {
    "rows": 20000, "batch": 500, "rounds": 3000, "query_rounds": 200,
    "samples": 3, "warmup": 30, "skip_load": 0,
}
HITS = {
    "query_cn_hits": 8001, "query_beng_hits": 11000,
    "query_mixed_hits": 7332, "query_limit_hits": 20,
}
PINS = {
    "control": "b271980a025bf9b20086e69f116ec2c24f164d21edd814b4e03d418cadd239fc",
    "candidate": "2881dce4a7f2c5eea50057b74bf5cc3a77c0142a4eeb7d1ca45adfa1526ae5cb",
}
TEXT_FIELDS = frozenset(("timestamp", "label", "git_head"))
NUMBER = re.compile(r"[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?")
FIELD = re.compile(r"[a-z][a-z0-9_]*")
MAX_INPUT_BYTES = 4 * 1024 * 1024


class ValidationError(ValueError):
    pass


def require(condition, message):
    if not condition:
        raise ValidationError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def finite(value, context):
    require(type(value) in (int, float), context + ": expected a number, not a bool/string")
    if isinstance(value, float):
        require(math.isfinite(value), context + ": non-finite number")
    return value


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, "Duplicate JSON key: " + key)
        result[key] = value
    return result


def reject_constant(token):
    raise ValidationError("Non-finite JSON constant: " + token)


def finite_json(value, context):
    if isinstance(value, float):
        finite(value, context)
    elif isinstance(value, dict):
        for key, child in value.items():
            finite_json(child, context + "." + key)
    elif isinstance(value, list):
        for index, child in enumerate(value):
            finite_json(child, context + "[" + str(index) + "]")


def snapshot(path):
    require(path.is_file(), "Missing completed input: " + str(path))
    with path.open("rb") as stream:
        raw = stream.read(MAX_INPUT_BYTES + 1)
    require(len(raw) <= MAX_INPUT_BYTES, "Input exceeds 4 MiB; refusing truncation: " + str(path))
    return raw


def read_input(path, inputs, raw_inputs):
    require(path not in raw_inputs, "Duplicate requested input: " + str(path))
    raw = snapshot(path)
    raw_inputs[path] = raw
    inputs[path.relative_to(FTS).as_posix()] = {"bytes": len(raw), "sha256": sha(raw)}
    return raw


def receipt(raw, label, variant, report_path):
    record = json.loads(raw.decode("utf-8-sig"), object_pairs_hook=unique_object,
                        parse_constant=reject_constant)
    require(isinstance(record, dict), label + ": receipt must be an object")
    finite_json(record, label)
    require(record.get("label") == label, label + ": receipt label mismatch")
    require(record.get("binary_sha256") == PINS[variant], label + ": binary SHA-256 mismatch")
    require(record.get("log_level") == "WARN", label + ": expected WARN logging")
    for key in ("affinity_mask", "affinity_mask_verified"):
        require(type(record.get(key)) is int and record[key] == 15, label + ": " + key + " must be integer 15")
    recorded_path = record.get("report")
    require(isinstance(recorded_path, str) and recorded_path, label + ": missing report path")
    require(Path(recorded_path).is_absolute() and
            Path(recorded_path).resolve(strict=True) == report_path.resolve(strict=True),
            label + ": report path mismatch")
    actions = record.get("actions")
    require(isinstance(actions, list) and actions, label + ": missing completed actions")
    names = []
    for action in actions:
        require(isinstance(action, dict), label + ": malformed action")
        name = action.get("action")
        require(isinstance(name, str) and name and name not in names, label + ": missing/duplicate action name")
        require(type(action.get("exit_code")) is int and action["exit_code"] == 0,
                label + ": unfinished or failed action " + name)
        if "seconds" in action:
            require(finite(action["seconds"], label + ": action seconds") >= 0, label + ": negative action duration")
        names.append(name)
    require(all(name in names for name in ("benchmark", "input-validation")),
            label + ": benchmark/input-validation must each complete exactly once")
    require(names.index("benchmark") < names.index("input-validation"), label + ": validation precedes benchmark")
    return record


def report(raw, label):
    text = raw.decode("utf-8-sig")
    require(text.count("FTS Large Benchmark Report") == 1, label + ": expected one complete report header")
    fields = {}
    headers = 0
    for line_number, line in enumerate(text.splitlines(), 1):
        line = line.strip()
        if not line or set(line) <= {"-", "="}:
            continue
        if line == "FTS Large Benchmark Report":
            headers += 1
            continue
        key, separator, value = line.partition(":")
        key, value = key.strip(), value.strip()
        require(separator and FIELD.fullmatch(key) is not None and value,
                label + ": malformed field at line " + str(line_number))
        require(key not in fields, label + ": duplicate report field " + key)
        fields[key] = value
    require(headers == 1, label + ": malformed header")
    required = {*PARAMS, *HITS, *METRICS, *TEXT_FIELDS}
    require(required <= fields.keys(), label + ": missing fields " + ", ".join(sorted(required - fields.keys())))
    require(fields["label"] == label, label + ": report label mismatch")
    values = {}
    for key, value in fields.items():
        if key in TEXT_FIELDS:
            continue
        require(NUMBER.fullmatch(value) is not None, label + ": invalid numeric field " + key)
        values[key] = finite(float(value), label + ": " + key)
    for key, expected in {**PARAMS, **HITS}.items():
        require(Decimal(fields[key]) == expected, label + ": parameter/hit mismatch " + key)
    for key in METRICS:
        require(values[key] > 0, label + ": timing must be positive: " + key)
    return {"values": values, "text_fields": {key: fields[key] for key in sorted(TEXT_FIELDS)}}


def improvement(control, candidate, context):
    return finite((control - candidate) / control, context + ": improvement")


def score_equivalents(rate):
    # Signed local increments on the 50%-reduction scale; not cumulative scores.
    raw_delta = finite(200.0 * rate, "raw100 incremental equivalent")
    weighted_delta = finite(100.0 * rate, "weighted50 incremental equivalent")
    clipped_raw = 100.0 * min(max(rate, 0.0), 0.5) / 0.5
    return {
        "raw100_delta_unclipped": raw_delta,
        "weighted50_delta_unclipped": weighted_delta,
        "local_curve_raw100_clipped": clipped_raw,
        "local_curve_weighted50_clipped": clipped_raw / 2.0,
        "meaning": "Incremental relative to accepted round18 count control only; not a formal score difference or cumulative score.",
    }


def comparison(control, candidate):
    metrics = []
    rates = {}
    for key in METRICS:
        rate = improvement(control[key], candidate[key], key)
        metrics.append({"metric": key, "control": control[key], "candidate": candidate[key], "improvement": rate})
        rates[key] = rate
    categories = {category: finite(mean(rates[key] for key in names), category + ": mean")
                  for category, names in CLASSES.items()}
    overall = finite(mean(categories.values()), "equal-category mean")
    return {"metrics": metrics, "category_improvements": categories, "overall_improvement": overall,
            "incremental_score_equivalents": score_equivalents(overall)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pairs", type=int, required=True, choices=(1, 2, 3))
    args = parser.parse_args()
    output = HERE / ("template-comparison-" + str(args.pairs) + "pair.json")
    require(not output.exists() and not output.is_symlink(), "Immutable output already exists: " + str(output))
    inputs, raw_inputs, records = {}, {}, {}
    runs = {"control": [], "candidate": []}
    pairs = []
    for number in range(1, args.pairs + 1):
        for variant in ("control", "candidate"):
            label = "r19-template-" + variant + "-a" + str(number)
            report_path = FTS / (label + "-report.txt")
            record_path = FTS / (label + "-experiment.json")
            record = receipt(read_input(record_path, inputs, raw_inputs), label, variant, report_path)
            parsed = report(read_input(report_path, inputs, raw_inputs), label)
            records[label] = {"receipt": record, **parsed}
            runs[variant].append(parsed["values"])
        pairs.append({"pair": number,
                      "labels": {variant: "r19-template-" + variant + "-a" + str(number) for variant in runs},
                      **comparison(runs["control"][-1], runs["candidate"][-1])})
    means = {variant: {key: finite(mean(run[key] for run in runs[variant]), variant + ": " + key + ": mean")
                       for key in METRICS} for variant in runs}
    aggregate = comparison(means["control"], means["candidate"])
    result = {
        "experiment": "round19-small-string-common-template", "completed_pairs": args.pairs,
        "reference": "Accepted round18 count-union control, not the official fixed baseline",
        "parameters": PARAMS, "expected_hits": HITS, "binary_pins": PINS,
        "environment_requirements": {"log_level": "WARN", "affinity_mask": 15, "affinity_mask_verified": 15},
        "method": "Each pair: per-metric (control-candidate)/control, arithmetic means within build/tokenize/query, then equal mean of those three. Aggregate: first mean each metric across requested control/candidate runs, then apply the same category weighting. All negative metric improvements retained before overall clipping.",
        "pairs": pairs, "metric_run_means": means, "aggregate_from_metric_run_means": aggregate,
        "mean_of_pair_overall_improvements": finite(mean(pair["overall_improvement"] for pair in pairs), "paired improvement mean"),
        "mean_of_pair_overall_note": "Descriptive paired mean; distinct from the primary ratio-of-metric-run-means aggregate. No clipped-score averaging.",
        "records": records, "input_hashes": inputs,
        "limitations": [
            "No formal platform result or cumulative score is calculated; no earlier score is added.",
            "Binary pins validate recorded execution receipts; current mutable executable paths are not rehashed as historical binaries.",
            "Expected hits and successful input-validation do not replace complete functional regression tests.",
            "Only complete requested pairs 1..N are used; no SELECT1 subtraction, sample selection, or cherry-picking.",
            "Inputs are checked for byte stability before output, not locked against subsequent external modification.",
        ],
    }
    # Detect appended/rewritten receipts or reports during this offline snapshot.
    for path, raw in raw_inputs.items():
        require(snapshot(path) == raw, "Input changed during comparison: " + str(path))
    encoded = (json.dumps(result, ensure_ascii=False, allow_nan=False, indent=2) + "\n").encode("utf-8")
    with output.open("xb") as destination:
        destination.write(encoded)
    print(json.dumps({"output": str(output), "completed_pairs": args.pairs,
                      "aggregate": aggregate, "pairs": pairs}, ensure_ascii=False, allow_nan=False, indent=2))
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (ValidationError, OSError, UnicodeError, ValueError, TypeError, OverflowError, RecursionError) as error:
        print("ERROR: " + str(error), file=sys.stderr)
        sys.exit(1)
