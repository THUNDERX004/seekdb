"""Read-only packed/raw/source and optional new-document verification."""
from pathlib import Path, PurePosixPath
import argparse
import gzip
import hashlib
import json

HERE = Path(__file__).resolve().parent


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def need(ok, message):
    if not ok:
        raise RuntimeError(message)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--package', type=Path, default=HERE / 'package')
    parser.add_argument('--source-root', type=Path, default=HERE.parent)
    parser.add_argument('--repo-docs', type=Path, help='Optionally verify the two newly published reports')
    args = parser.parse_args()
    root, source_root = args.package.resolve(), args.source_root.resolve()
    raw = (root / 'manifest.json').read_bytes()
    manifest = json.loads(raw)
    complete = json.loads((root / 'COMPLETE.json').read_bytes())
    need(manifest['experiment'] == 'round31-advance-rejected' and manifest['decision'] == 'REJECTED', 'Wrong archive')
    need(complete['status'] == 'COMPLETE' and complete['manifest_sha256'] == sha(raw), 'Completion/hash mismatch')
    expected = {'manifest.json', 'COMPLETE.json'}
    sources = set()
    total_raw = total_packed = 0
    for item in manifest['files']:
        rel = PurePosixPath(item['source'])
        need(not rel.is_absolute() and '..' not in rel.parts and ':' not in str(rel)
             and '\\' not in str(rel), 'Unsafe source path')
        need(item['path'] == 'files/' + str(rel) + '.gz' and item['path'] not in expected
             and str(rel) not in sources, 'Duplicate/mismatched archive path')
        path = root / item['path']
        need(path.resolve().is_relative_to(root), 'Archive path escapes destination')
        packed = path.read_bytes()
        need(len(packed) == item['packed_bytes'] and sha(packed) == item['packed_sha256'], 'Packed bytes mismatch')
        data = gzip.decompress(packed)
        need(len(data) == item['raw_bytes'] and sha(data) == item['raw_sha256'], 'Raw bytes mismatch')
        source = source_root / str(rel)
        need(source.resolve().is_relative_to(source_root) and source.read_bytes() == data, 'Original source mismatch')
        expected.add(item['path']); sources.add(str(rel))
        total_raw += len(data); total_packed += len(packed)
    need(len(manifest['files']) == complete['file_count'] and total_raw == complete['raw_bytes']
         and total_packed == complete['packed_bytes'], 'Archive counts mismatch')
    need({p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()} == expected, 'Unexpected/missing files')
    if args.repo_docs:
        for language, source_name in (('en', 'report.en.md'), ('zh-CN', 'report.zh-CN.md')):
            need((args.repo_docs / language / 'competition-round31.md').read_bytes()
                 == (HERE / source_name).read_bytes(), 'Published report mismatch')
    result = dict(status='PASS', file_count=complete['file_count'], manifest_sha256=sha(raw),
                  raw_bytes=total_raw, packed_bytes=total_packed, packed_raw_source='ALL MATCH',
                  published_reports='MATCH' if args.repo_docs else 'NOT REQUESTED',
                  execution='Offline read-only verification; no build/native/SQL/Git')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
