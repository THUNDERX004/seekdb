# Round31 rejected advance-comparison archival

Offline-only helper. Input scope is frozen in `selection.json` with byte counts
and SHA-256; omitted binary/intermediate paths and sizes are listed separately.
Every selected text/source/receipt/log is gzip-compressed from immutable bytes
with raw and packed hashes in `package/manifest.json`. No newline conversion,
output trimming, helper execution, timing recomputation or sample removal.

All eight `r31-advance-*` labels are retained, including diagnostic console and
ranked, rebuilt control, plans and candidate SQL. All observed round31 proposal,
review, native proposal, build root source/helper/metadata files are selected;
native build commands/receipts/logs and full stdout/stderr are retained. The
initial failed diagnostic build and both successful repairs are separate.
The old review and final helper proposal are distinct historical artifacts.

Four reused helper sources are retained only for provenance: round16 native
link utility, round19 strict summarizer, round27 experiment harness and the
plans helper. No old performance runs, mutable D binaries, DLL/PDB/OBJ/LIB,
runtime/data, credentials or round32 files are copied. Native PASS is helper
coverage only; no markers is not proof of zero callsite execution. Historical
pending text remains unchanged. The final-restoration record is parent evidence,
not an assertion about live source while a later round is running.

Commands from the workspace root (all workload-free):

```powershell
& ./.venv/Scripts/python.exe -B -X utf8 setup/fts/round31-archive/archive.py --execute
& ./.venv/Scripts/python.exe -B -X utf8 setup/fts/round31-archive/verify_archive.py
& ./.venv/Scripts/python.exe -B -X utf8 setup/fts/round31-archive/publish.py --publish
& ./.venv/Scripts/python.exe -B -X utf8 setup/fts/round31-archive/verify_archive.py --package D:/Projects/OceanBase/seekdb/docs/developer-guide/assets/fts-performance/competition-round31-advance --repo-docs D:/Projects/OceanBase/seekdb/docs/developer-guide
```

`publish.py` only creates that new assets directory and new English/Chinese
`competition-round31.md` reports. It refuses existing destinations and verifies
both existing `fts-performance.md` reports remain unchanged. It does not touch
production, old assets, tests, build/CI or Git. Parent owns commit/push.

Verification receipts and the complete list of changed repository paths live
outside the immutable package, in this auxiliary directory. Parent may rerun
the verifier read-only before committing the exact publication scope.
