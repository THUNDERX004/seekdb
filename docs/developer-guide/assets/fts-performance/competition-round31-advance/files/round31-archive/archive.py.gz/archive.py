"""Bounded offline round31 archive; fixed C destination, no build/helper execution."""
from pathlib import Path
import argparse
import gzip
import hashlib
import json
import re

HERE = Path(__file__).resolve().parent
FTS = HERE.parent
BUILD = FTS / 'round31-advance-build'
DEST = HERE / 'package'
EXPERIMENT = 'round31-advance-rejected'
ACCEPTED = 'f56ddd03e66826919d8d9192bc4c0afece8843dd'


def need(value, message):
    if not value:
        raise RuntimeError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def load(path):
    return json.loads(path.read_bytes())


def save(path, value):
    with path.open('xb') as stream:
        stream.write((json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + '\n').encode('utf-8'))


def final_gates():
    decision = load(BUILD / 'decision-and-parity.json')
    restoration = load(BUILD / 'final-restoration.json')
    need(decision['status'] == 'REJECTED', 'Missing final rejection')
    need(restoration['status'] == 'RESTORED_ACCEPTED_SOURCE'
         and restoration['accepted_source'] == ACCEPTED
         and restoration['tracked_source_diff_to_f56'] == 'EMPTY', 'Missing final accepted-source restoration')
    for filename in ('decision-and-parity.json', 'comparison-1pair.json'):
        for name, pin in load(BUILD / filename)['input_hashes'].items():
            need(Path(name).name == name, 'Unsafe summary input')
            raw = (FTS / name).read_bytes()
            need(len(raw) == pin['bytes'] and sha(raw) == pin['sha256'], 'Summary input identity mismatch: ' + name)
    need(load(BUILD / 'comparison-1pair.json')['aggregate'] == decision['original_pair'], 'Initial pair changed')
    need(b'Linking CXX executable' in (FTS / 'round31-accepted-control-rebuilt-build.log').read_bytes(), 'Missing rebuilt accepted link log')
    failed = (FTS / 'round31-advance-diagnostic-build.log').read_bytes()
    need(b'FAILED:' in failed and b'error:' in failed, 'Missing initial diagnostic failure')
    for name in ('round31-advance-diagnostic-repaired-build.log', 'round31-advance-diagnostic-console-build.log'):
        need(b'Linking CXX executable' in (FTS / name).read_bytes(), 'Missing later diagnostic repair build')

    proposal = FTS / 'round31-advance-native-proposal'
    pins = load(proposal / 'source-pins.json')
    for item in pins['artifacts']:
        path = proposal / item['path']
        need(path.resolve().is_relative_to(proposal), 'Unsafe proposal path')
        raw = path.read_bytes()
        need(sha(raw) == item['sha256'] and len(raw) == item['size_bytes'], 'Frozen proposal changed')
    sources = load(BUILD / 'source-preparation.json')
    for item in sources['targets']:
        for prefix, key in (('original-', 'original_sha256'), ('candidate-', 'candidate_sha256')):
            need(sha((BUILD / (prefix + Path(item['path']).name)).read_bytes()) == item[key], 'Snapshot identity mismatch')
    need(sha((BUILD / 'original-ob_text_retrieval_token_iter.cpp').read_bytes()) == restoration['cpp_sha256'], 'Restoration snapshot mismatch')
    need((BUILD / 'test_text_advance_compare.cpp').read_bytes() == (proposal / 'test_text_advance_compare.cpp').read_bytes(), 'Native TU differs')

    proof = load(BUILD / 'parent-native-verification.json')
    run = BUILD / 'candidate-run1'
    record = load(run / 'run.json')
    receipt = load(BUILD / 'candidate-build1/receipt.json')
    raw = (run / 'stdout.log').read_bytes()
    lines = raw.splitlines()
    need(proof['status'] == record['output_validation'] == 'PASS'
         and record['exit_code'] == 0 and record['expected_cases'] == proof['cases'] == 1844, 'Native helper gate incomplete')
    need(receipt['build_succeeded'] and receipt['compile']['exit_code'] == receipt['link']['exit_code'] == 0, 'Native compile/link incomplete')
    need(receipt['production_sha256_before'] == receipt['production_sha256_after'], 'Native archive inputs changed')
    need(record['test_sha256'] == receipt['test_sha256'] == sources['test_sha256'], 'Native test identity mismatch')
    need(record['executable_sha256'] == receipt['executable_sha256'], 'Native executable identity differs')
    need((run / 'build-receipt.json').read_bytes() == (BUILD / 'candidate-build1/receipt.json').read_bytes(), 'Run/build receipt mismatch')
    need(sha(raw) == record['stdout_sha256'] == proof['stdout_sha256'], 'Native stdout identity mismatch')
    need(not (run / 'stderr.log').read_bytes(), 'Unexpected native stderr')
    need(len(lines) == proof['complete_lines'] == 9221 and lines[-1] == b'PASS\tcases=1844'
         and sum(line.startswith(b'CASE\t') for line in lines) == 1844, 'Native complete record mismatch')
    helpers = [line for line in lines if b'\thelper\t' in line]
    oracles = [line for line in lines if b'\toracle\t' in line]
    need(len(helpers) == len(oracles) == 1844, 'Incomplete helper/oracle transcript')
    counts = {0: 0, 1: 0}
    for line in helpers:
        match = re.search(rb'\tfallback_calls=([01])\texpected_fallback_calls=([01])$', line)
        need(match is not None and match[1] == match[2], 'Unexpected helper fallback transcript')
        counts[int(match[1])] += 1
    need(counts == {0: 625, 1: 1219}, 'Native helper count mismatch')
    for stage in ('compile', 'link'):
        need(sha((BUILD / 'candidate-build1' / (stage + '.log')).read_bytes()) == receipt[stage]['log_sha256'], 'Native build log mismatch')
    return decision, restoration, proof


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true')
    args = parser.parse_args()
    need(args.execute and HERE.name == 'round31-archive' and not DEST.exists(), 'Use --execute with a fresh fixed package')
    decision, restoration, native = final_gates()
    selection = load(HERE / 'selection.json')
    entries = []
    paths = {}
    for item in selection['files']:
        path = FTS / item['source']
        need(path.resolve().is_relative_to(FTS) and not path.is_symlink(), 'Input escapes FTS')
        raw = path.read_bytes()
        need(sha(raw) == item['sha256'] and len(raw) == item['bytes'], 'Frozen input changed: ' + item['source'])
        paths[path] = (len(raw), sha(raw))
    for name in ('archive.py', 'verify_archive.py', 'publish.py', 'README.md', 'report.en.md', 'report.zh-CN.md', 'selection.json', 'syntax-check.json'):
        path = HERE / name
        raw = path.read_bytes()
        paths[path] = (len(raw), sha(raw))
    need(sum(value[0] for value in paths.values()) < 32 * 1024 * 1024, 'Archive budget exceeded')
    DEST.mkdir()
    for path, before in sorted(paths.items(), key=lambda item: item[0].relative_to(FTS).as_posix()):
        raw = path.read_bytes()
        relative = path.relative_to(FTS).as_posix()
        need((len(raw), sha(raw)) == before, 'Input changed during archive')
        packed = gzip.compress(raw, compresslevel=9, mtime=0)
        out = DEST / 'files' / (relative + '.gz')
        out.parent.mkdir(parents=True, exist_ok=True)
        with out.open('xb') as stream:
            stream.write(packed)
        need(gzip.decompress(packed) == raw, 'Gzip exact-byte error')
        entries.append(dict(source=relative, path='files/' + relative + '.gz', raw_bytes=len(raw),
                            raw_sha256=sha(raw), packed_bytes=len(packed), packed_sha256=sha(packed)))
    for path, before in paths.items():
        need((path.stat().st_size, sha(path.read_bytes())) == before, 'Source changed before archive completion')
    manifest = dict(schema=1, experiment=EXPERIMENT, decision='REJECTED', accepted_source=ACCEPTED,
                    original_complete_pairs=1,
                    original_pair=decision['original_pair'],
                    exploratory_rebuilt_vs_candidate=decision['exploratory_rebuilt_vs_candidate'],
                    parity_old_vs_rebuilt=decision['parity_old_vs_rebuilt'],
                    final_restoration=restoration,
                    native_helper=native,
                    interpretation=['Native helper PASS is not iterator/callsite coverage.',
                                    'Missing unvalidated diagnostic markers do not prove zero execution.',
                                    'The rebuilt comparison is exploratory and does not replace the first pair.',
                                    'No causal attribution for unrelated BENG movement or configuration drift.',
                                    'No production/test promotion, new formal/full score, cumulative or stability claim.',
                                    'Historical proposal NOT RUN/pending records preserved unchanged; final receipts describe later execution.'],
                    omissions=selection['omissions'], labels=selection['labels'],
                    documents={'en': 'docs/developer-guide/en/competition-round31.md',
                               'zh-CN': 'docs/developer-guide/zh-CN/competition-round31.md'},
                    files=entries)
    save(DEST / 'manifest.json', manifest)
    result = dict(status='COMPLETE', file_count=len(entries), manifest_sha256=sha((DEST / 'manifest.json').read_bytes()),
                  raw_bytes=sum(item['raw_bytes'] for item in entries), packed_bytes=sum(item['packed_bytes'] for item in entries))
    save(DEST / 'COMPLETE.json', result)
    save(HERE / 'archive-summary.json', dict(result, package=str(DEST), execution='Offline archive only; no build/native/SQL/Git'))
    print(json.dumps(dict(result, package=str(DEST)), indent=2))


if __name__ == '__main__':
    main()
