"""Pinned round31 patch reconstruction, application, native staging, and pinning."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil

HERE = Path(__file__).resolve().parent
ROOT = Path('D:/Projects/OceanBase/seekdb')
PROPOSAL = HERE.parent/'round31-advance-native-proposal'
CPP = 'src/storage/retrieval/ob_text_retrieval_token_iter.cpp'
HEADER = 'src/storage/retrieval/ob_text_retrieval_doc_id_compare.h'
TEST = 'unittest/storage/fts/test_text_advance_compare.cpp'
ORIGINAL = '7a7d33cef52f0da958586356f249ab7c807151dc49a5f1c60ecfee41900bd586'
sha = lambda raw: hashlib.sha256(raw).hexdigest()

def save(name,data):
    with (HERE/name).open('x',encoding='utf-8') as stream:
        json.dump(data,stream,indent=2); stream.write('\n')

def reconstruct(patch):
    lines = patch.splitlines(keepends=True)
    index = 0
    outputs = []
    for relative in (CPP,HEADER):
        old = (ROOT/relative).read_bytes() if relative == CPP else b''
        if relative == CPP: assert sha(old) == ORIGINAL
        else: assert not (ROOT/relative).exists()
        assert lines[index] == (b'--- a/'+relative.encode()+b'\n' if relative == CPP else b'--- /dev/null\n')
        assert lines[index+1] == b'+++ b/'+relative.encode()+b'\n'
        index += 2
        before_lines = old.splitlines(keepends=True)
        output, cursor = [],0
        while index < len(lines) and lines[index].startswith(b'@@ '):
            match = re.fullmatch(rb'@@ -(\d+),(\d+) \+(\d+),(\d+) @@\n',lines[index])
            assert match
            start,old_count,new_start,new_count = map(int,match.groups())
            index += 1
            before,after = [],[]
            while index < len(lines) and lines[index][:1] in (b' ',b'-',b'+') and not lines[index].startswith(b'--- '):
                row=lines[index]
                if row[:1] in (b' ',b'-'): before.append(row[1:])
                if row[:1] in (b' ',b'+'): after.append(row[1:])
                index += 1
            assert len(before) == old_count and len(after) == new_count
            offset = start-1 if old_count else start
            assert cursor <= offset and before_lines[offset:offset+old_count] == before
            output.extend(before_lines[cursor:offset])
            assert len(output) == new_start-1
            output.extend(after)
            cursor=offset+old_count
        outputs.append((relative,old,b''.join(output+before_lines[cursor:])))
    assert index == len(lines)
    return outputs

def prepare(args):
    patch=(PROPOSAL/'source.patch').read_bytes()
    assert sha(patch) == args.patch_sha
    outputs=reconstruct(patch)
    assert sha(outputs[0][2]) == args.source_sha
    assert sha(outputs[1][2]) == args.header_sha
    assert outputs[1][2] == (PROPOSAL/HEADER).read_bytes()
    test=(PROPOSAL/'test_text_advance_compare.cpp').read_bytes()
    assert sha(test) == args.test_sha and 0 < args.cases <= 100000
    records=[]
    for relative,old,new in outputs:
        for prefix,raw in [('original-',old),('candidate-',new)]:
            with (HERE/(prefix+Path(relative).name)).open('xb') as stream: stream.write(raw)
        records.append(dict(path=relative,original_sha256=sha(old),candidate_sha256=sha(new),was_absent=relative==HEADER))
    with (HERE/'test_text_advance_compare.cpp').open('xb') as stream: stream.write(test)
    save('source-preparation.json',dict(status='PREPARED_ONLY',patch_sha256=sha(patch),targets=records,test_sha256=sha(test),cases=args.cases))
    print('PREPARED exact final patch, header, and native TU')

def apply(args):
    receipt=json.loads((HERE/'source-preparation.json').read_text(encoding='utf-8'))
    assert not (HERE/'application.json').exists() and not (ROOT/TEST).exists()
    writes=[]
    for item in receipt['targets']:
        path=ROOT/item['path']
        if item['was_absent']: assert not path.exists()
        else: assert sha(path.read_bytes()) == item['original_sha256']
        raw=(HERE/('candidate-'+path.name)).read_bytes()
        assert sha(raw) == item['candidate_sha256']
        writes.append((path,raw))
    raw=(HERE/'test_text_advance_compare.cpp').read_bytes()
    assert sha(raw) == receipt['test_sha256']
    writes.append((ROOT/TEST,raw))
    for path,raw in writes:
        path.write_bytes(raw); assert path.read_bytes()==raw
    save('application.json',{**receipt,'status':'APPLIED'})
    print('APPLIED final two-file compare proposal and staged native TU')

def pin(args):
    receipt=json.loads((HERE/'source-preparation.json').read_text(encoding='utf-8'))
    for item in receipt['targets']: assert sha((ROOT/item['path']).read_bytes()) == item['candidate_sha256']
    output=ROOT/'build/fts-round31-advance-candidate'
    build=ROOT/'build_fts_competition/src/observer'
    assert not output.exists(); output.mkdir()
    files={}
    for source in [build/'seekdb.exe',build/'seekdb.pdb',*sorted(build.glob('*.dll'))]:
        digest=sha(source.read_bytes()); shutil.copy2(source,output/source.name)
        assert sha((output/source.name).read_bytes())==digest
        files[source.name]=dict(bytes=source.stat().st_size,sha256=digest)
    save('binary.json',dict(output=str(output),files=files))
    print('PINNED',files['seekdb.exe']['sha256'])

if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('action',choices=['prepare','apply','pin'])
    parser.add_argument('--patch-sha'); parser.add_argument('--source-sha')
    parser.add_argument('--header-sha'); parser.add_argument('--test-sha')
    parser.add_argument('--cases',type=int)
    args=parser.parse_args(); globals()[args.action](args)
