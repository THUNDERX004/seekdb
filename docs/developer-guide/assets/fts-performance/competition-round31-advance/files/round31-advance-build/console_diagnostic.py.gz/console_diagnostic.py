"""Use first-entry stderr markers to disambiguate logger filtering from no calls."""
import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
ROOT=Path('D:/Projects/OceanBase/seekdb')
previous=json.loads((HERE/'diagnostic-repair.json').read_text(encoding='utf-8'))
path=ROOT/previous['path']
raw=path.read_bytes()
sha=lambda value:hashlib.sha256(value).hexdigest()
assert sha(raw)==previous['diagnostic_sha256']
old=b'LOG_WARN_RET(common::OB_SUCCESS, "R31_ADVANCE_PATH", "site", site, "fast", fast);'
new=b'std::fprintf(stderr, "R31_ADVANCE_PATH site=%d fast=%d\\n", site, int(fast));\n    std::fflush(stderr);'
assert raw.count(old)==1 and raw.count(b'#include <atomic>')==1
changed=raw.replace(old,new,1).replace(b'#include <atomic>',b'#include <atomic>\n#include <cstdio>',1)
with (HERE/'diagnostic-console-header.h').open('xb') as stream:stream.write(changed)
path.write_bytes(changed);assert path.read_bytes()==changed
with (HERE/'diagnostic-console-repair.json').open('x',encoding='utf-8') as stream:
    json.dump(dict(path=previous['path'],before_sha256=sha(raw),diagnostic_sha256=sha(changed),reason='First diagnostic full benchmark completed but logger captured no markers; direct bounded stderr first-entry markers remove logger-filtering ambiguity.',scored=False),stream,indent=2);stream.write('\n')
print('APPLIED diagnostic console markers',sha(changed))
