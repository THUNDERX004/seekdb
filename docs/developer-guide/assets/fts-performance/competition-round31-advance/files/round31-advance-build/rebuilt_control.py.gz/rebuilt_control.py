"""Rebuild accepted source in the current production build environment for parity."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

HERE=Path(__file__).resolve().parent
ROOT=Path('D:/Projects/OceanBase/seekdb')
CPP='src/storage/retrieval/ob_text_retrieval_token_iter.cpp'
HEADER='src/storage/retrieval/ob_text_retrieval_doc_id_compare.h'
ORIGINAL='7a7d33cef52f0da958586356f249ab7c807151dc49a5f1c60ecfee41900bd586'
CANDIDATE='b4baadd45e593ec7364528a8d120107c31a7d10b44a54f4a87fcd24e83d1d289'
HEADER_SHA='95f6159d953b847a4aaf38fcd3c49d9fc609d4b14ef3a548fe17da2aa4a92ccd'
sha=lambda raw:hashlib.sha256(raw).hexdigest()

def save(name,value):
    with (HERE/name).open('x',encoding='utf-8') as stream:
        json.dump(value,stream,indent=2);stream.write('\n')

def apply():
    assert (HERE/'diagnostic-restoration.json').exists()
    assert sha((ROOT/CPP).read_bytes())==CANDIDATE and sha((ROOT/HEADER).read_bytes())==HEADER_SHA
    old=(HERE/('original-'+Path(CPP).name)).read_bytes()
    assert sha(old)==ORIGINAL
    (ROOT/CPP).write_bytes(old);assert (ROOT/CPP).read_bytes()==old
    result=subprocess.run(['git','diff','--quiet','f56ddd03e66826919d8d9192bc4c0afece8843dd','--','src'],cwd=ROOT)
    assert result.returncode==0,'Control tracked production source differs from accepted f56'
    save('rebuilt-control-application.json',dict(status='ACCEPTED_SOURCE_CONTROL',source_commit='f56ddd03e66826919d8d9192bc4c0afece8843dd',tracked_src_diff='EMPTY',cpp_sha256=ORIGINAL,unused_untracked_header_sha256=HEADER_SHA,purpose='Current build environment parity; does not discard prior C7 comparisons'))
    print('APPLIED original CPP; tracked src exactly accepted f56')

def pin():
    assert sha((ROOT/CPP).read_bytes())==ORIGINAL and sha((ROOT/HEADER).read_bytes())==HEADER_SHA
    output=ROOT/'build/fts-round31-rebuilt-control'
    build=ROOT/'build_fts_competition/src/observer'
    assert not output.exists();output.mkdir()
    files={}
    for source in [build/'seekdb.exe',build/'seekdb.pdb',*sorted(build.glob('*.dll'))]:
        digest=sha(source.read_bytes());shutil.copy2(source,output/source.name)
        assert sha((output/source.name).read_bytes())==digest
        files[source.name]=dict(bytes=source.stat().st_size,sha256=digest)
    save('rebuilt-control-binary.json',dict(output=str(output),source_commit='f56ddd03e66826919d8d9192bc4c0afece8843dd',files=files,configuration='Same current CMake production build and build-competition.ps1 as round31 candidate'))
    print('PINNED REBUILT CONTROL',files['seekdb.exe']['sha256'])

def restore():
    assert sha((ROOT/CPP).read_bytes())==ORIGINAL and sha((ROOT/HEADER).read_bytes())==HEADER_SHA
    new=(HERE/('candidate-'+Path(CPP).name)).read_bytes()
    assert sha(new)==CANDIDATE
    (ROOT/CPP).write_bytes(new);assert (ROOT/CPP).read_bytes()==new
    save('rebuilt-control-restoration.json',dict(status='CANDIDATE_RESTORED_EXACT',cpp_sha256=CANDIDATE,header_sha256=HEADER_SHA,build='PENDING_SEPARATE'))
    print('RESTORED candidate CPP exactly; rebuild required')

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('action',choices=['apply','pin','restore'])
    args=parser.parse_args();globals()[args.action]()
