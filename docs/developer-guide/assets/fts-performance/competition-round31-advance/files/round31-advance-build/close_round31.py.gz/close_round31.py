"""Freeze the parity check and reject the unpromoted round31 candidate."""
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
FTS = HERE.parent
ROOT = Path('D:/Projects/OceanBase/seekdb')
sha = lambda raw: hashlib.sha256(raw).hexdigest()
helper = FTS / 'round19-evidence/summarize-template.py'
assert sha(helper.read_bytes()) == '0aca605abda2fea4ab7b32335c5fe04302895748e8f63a6ce46887b04b822035'
spec = importlib.util.spec_from_file_location('strict_pair', helper)
u = importlib.util.module_from_spec(spec)
spec.loader.exec_module(u)

inputs, raws, records = {}, {}, {}
pins = {
    'old_control': ('r31-advance-control-a1', 'c7fcc8676875246a38bc4135f29e6f52b85a9d29a9563679003d5b6140666b01'),
    'candidate': ('r31-advance-candidate-a1', '1eabdc6988894cf9884040263013890b7a82dfce57bc0dd517c86bccf897f04a'),
    'rebuilt_control': ('r31-advance-rebuilt-control-a1', '64eac825a6f481c6936e6b6f3b530376052e5fba4498547e83eafe3e923fae8a'),
}
u.PINS = {key: value[1] for key, value in pins.items()}
for variant, (label, pin) in pins.items():
    report = FTS / (label + '-report.txt')
    receipt = u.receipt(u.read_input(FTS/(label+'-experiment.json'), inputs, raws), label, variant, report)
    assert receipt['owned_server_exit_before_cleanup'] is None
    records[variant] = dict(receipt=receipt, **u.report(u.read_input(report, inputs, raws), label))

def compare(a,b):
    result = u.comparison(records[a]['values'], records[b]['values'])
    result.pop('incremental_score_equivalents')
    return result

result = dict(status='REJECTED', reason='No convincing total gain, and actual iterator callsite coverage was not established by the diagnostics.',
    original_pair=compare('old_control','candidate'),
    parity_old_vs_rebuilt=compare('old_control','rebuilt_control'),
    exploratory_rebuilt_vs_candidate=compare('rebuilt_control','candidate'),
    caveats=['Rebuilt vs candidate is an exploratory single-run comparison, not a replacement for the original chronological pair.',
             'No diagnostic markers were observed; marker instrumentation was not independently validated, so zero callsite execution is not proven.',
             'Native helper equivalence (1844 cases) does not establish actual iterator reachability.',
             'No causal explanation for unrelated BENG movement is established; no samples or historical results are discarded.',
             'Local evidence only; no formal score is computed.'], records=records, input_hashes=inputs)
for path, raw in raws.items():
    assert u.snapshot(path) == raw
with (HERE/'decision-and-parity.json').open('x', encoding='utf-8') as stream:
    json.dump(result, stream, indent=2, allow_nan=False); stream.write('\n')

cpp = ROOT/'src/storage/retrieval/ob_text_retrieval_token_iter.cpp'
assert sha(cpp.read_bytes()) == '7a7d33cef52f0da958586356f249ab7c807151dc49a5f1c60ecfee41900bd586'
removed = []
for relative, expected in [
    ('src/storage/retrieval/ob_text_retrieval_doc_id_compare.h', '95f6159d953b847a4aaf38fcd3c49d9fc609d4b14ef3a548fe17da2aa4a92ccd'),
    ('unittest/storage/fts/test_text_advance_compare.cpp', 'acd2382fdb764a4e87db6bb30ca74060d0a5e0d4b6bf71fe71194a94dfe46538')]:
    target = ROOT / relative
    assert sha(target.read_bytes()) == expected
    assert subprocess.run(['git','ls-files','--error-unmatch',relative],cwd=ROOT,capture_output=True).returncode != 0
    target.unlink()
    removed.append(dict(path=relative, sha256=expected))
assert subprocess.run(['git','diff','--quiet','f56ddd03e66826919d8d9192bc4c0afece8843dd','--','src'], cwd=ROOT).returncode == 0
restoration = dict(status='RESTORED_ACCEPTED_SOURCE', cpp_sha256=sha(cpp.read_bytes()), removed_unpromoted_files=removed,
                   tracked_source_diff_to_f56='EMPTY', accepted_source='f56ddd03e66826919d8d9192bc4c0afece8843dd',
                   build='Rebuilt accepted-source control passed before removal of unused header and native TU; see rebuilt-control-binary.json.')
with (HERE/'final-restoration.json').open('x', encoding='utf-8') as stream:
    json.dump(restoration,stream,indent=2); stream.write('\n')
print(json.dumps(dict(status=result['status'],original_pair=result['original_pair']['overall_improvement'],
                     exploratory=result['exploratory_rebuilt_vs_candidate']['overall_improvement'],restoration=restoration),indent=2))
