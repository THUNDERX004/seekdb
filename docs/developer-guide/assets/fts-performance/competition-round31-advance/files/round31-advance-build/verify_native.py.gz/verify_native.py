"""Independently count complete actual helper/oracle output; no execution."""
import hashlib
import json
from pathlib import Path
import re

HERE=Path(__file__).resolve().parent
run=HERE/'candidate-run1'
receipt=json.loads((run/'run.json').read_text(encoding='utf-8'))
raw=(run/'stdout.log').read_bytes()
assert receipt['output_validation']=='PASS' and receipt['exit_code']==0
assert hashlib.sha256(raw).hexdigest()==receipt['stdout_sha256']
assert receipt['test_sha256']=='acd2382fdb764a4e87db6bb30ca74060d0a5e0d4b6bf71fe71194a94dfe46538'
assert not (run/'stderr.log').read_bytes()
lines=raw.splitlines()
assert len(lines)==9221 and lines[-1]==b'PASS\tcases=1844'
assert sum(x.startswith(b'CASE\t') for x in lines)==1844
helpers=[x for x in lines if b'\thelper\t' in x]
oracles=[x for x in lines if b'\toracle\t' in x]
assert len(helpers)==len(oracles)==1844
counts={0:0,1:0}
for row in helpers:
    m=re.search(rb'\tfallback_calls=([01])\texpected_fallback_calls=([01])$',row)
    assert m and m.group(1)==m.group(2)
    counts[int(m.group(1))]+=1
assert counts=={0:625,1:1219}
result=dict(status='PASS',cases=1844,complete_lines=len(lines),stdout_sha256=receipt['stdout_sha256'],fast_calls=625,fallback_calls=1219,independent_original_comparator_calls=1844,scope='Actual inline helper equals real stored-type binary null-first comparator; no iterator or callsite coverage established by this native fixture',execution='Offline validation only')
with (HERE/'parent-native-verification.json').open('x',encoding='utf-8') as stream:
    json.dump(result,stream,indent=2); stream.write('\n')
print(json.dumps(result,indent=2))
