"""Run one production-linked frozen TU; compare complete deterministic stdout."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--build-dir', type=Path, required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    parser.add_argument('--compare-run', type=Path)
    args = parser.parse_args()
    build, out = args.build_dir.resolve(), args.output_dir.resolve()
    assert build.parent == HERE and out.parent == HERE and build != out and not out.exists()
    receipt = json.loads((build/'receipt.json').read_text(encoding='utf-8'))
    assert receipt['build_succeeded'] and receipt['compile']['exit_code'] == receipt['link']['exit_code'] == 0
    assert receipt['production_sha256_before'] == receipt['production_sha256_after']
    test, exe = HERE/receipt['test_source'], build/'test_text_advance_compare.exe'
    assert sha(test) == receipt['test_sha256'] and sha(exe) == receipt['executable_sha256']
    for dll in receipt['runtime_dlls']: assert sha(build/dll['name']) == dll['sha256']
    out.mkdir()
    (out/'build-receipt.json').write_bytes((build/'receipt.json').read_bytes())
    env = os.environ.copy()
    temp = out/'tmp'; temp.mkdir()
    env.update(TMP=str(temp), TEMP=str(temp), PATH=str(build)+os.pathsep+env.get('PATH',''))
    result = dict(variant=receipt['variant'], test_sha256=receipt['test_sha256'], expected_cases=receipt['expected_cases'], executable_sha256=receipt['executable_sha256'], output_validation='PENDING')
    def save(): (out/'run.json').write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
    save()
    with (out/'stdout.log').open('wb') as stdout, (out/'stderr.log').open('wb') as stderr:
        process = subprocess.run([str(exe)], cwd=out, env=env, stdout=stdout, stderr=stderr, timeout=180)
    result.update(exit_code=process.returncode, stdout_sha256=sha(out/'stdout.log'), stderr_sha256=sha(out/'stderr.log'))
    save()
    assert process.returncode == 0, 'Native failure; logs preserved'
    raw = (out/'stdout.log').read_bytes()
    lines = raw.splitlines()
    cases = receipt['expected_cases']
    assert [x for x in lines if x.startswith(b'PASS\t')] == [b'PASS\tcases='+str(cases).encode()]
    assert sum(x.startswith(b'CASE\t') for x in lines) == cases
    assert any(x.startswith(b'T\t') for x in lines)
    result['complete_lines'] = len(lines)
    if args.compare_run:
        ref = args.compare_run.resolve()
        assert ref.parent == HERE
        previous = json.loads((ref/'run.json').read_text(encoding='utf-8'))
        assert previous['variant'] == 'control' and previous['output_validation'] == 'PASS'
        assert previous['test_sha256'] == receipt['test_sha256']
        assert sha(ref/'stdout.log') == previous['stdout_sha256']
        result['complete_stdout_equal'] = raw == (ref/'stdout.log').read_bytes()
        save()
        assert result['complete_stdout_equal'], 'Complete call/token transcript mismatch'
    assert not (out/'stderr.log').read_bytes(), 'Unexpected stderr'
    result['output_validation'] = 'PASS'
    save()
    print(json.dumps(result, indent=2))

if __name__ == '__main__': main()
