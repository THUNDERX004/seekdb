"""Pin only the separate non-scored diagnostic binary and runtime."""
import hashlib
import json
from pathlib import Path
import shutil
import argparse

HERE=Path(__file__).resolve().parent
ROOT=Path('D:/Projects/OceanBase/seekdb')
sha=lambda raw:hashlib.sha256(raw).hexdigest()
receipt=json.loads((HERE/'diagnostic-application.json').read_text(encoding='utf-8'))
assert receipt['scored'] is False
parser=argparse.ArgumentParser();parser.add_argument('--console',action='store_true');args=parser.parse_args()
for name in ('diagnostic-repair.json','diagnostic-console-repair.json'):
    if (HERE/name).exists():
        repair=json.loads((HERE/name).read_text(encoding='utf-8'))
        for item in receipt['targets']:
            if item['path']==repair['path']:
                assert item['diagnostic_sha256']==repair['before_sha256']
                item['diagnostic_sha256']=repair['diagnostic_sha256']
for item in receipt['targets']: assert sha((ROOT/item['path']).read_bytes())==item['diagnostic_sha256']
output=ROOT/('build/fts-round31-advance-diagnostic-console' if args.console else 'build/fts-round31-advance-diagnostic')
build=ROOT/'build_fts_competition/src/observer'
assert not output.exists(); output.mkdir()
files={}
for source in [build/'seekdb.exe',build/'seekdb.pdb',*sorted(build.glob('*.dll'))]:
    digest=sha(source.read_bytes()); shutil.copy2(source,output/source.name)
    assert sha((output/source.name).read_bytes())==digest
    files[source.name]=dict(bytes=source.stat().st_size,sha256=digest)
with (HERE/('diagnostic-console-binary.json' if args.console else 'diagnostic-binary.json')).open('x',encoding='utf-8') as stream:
    json.dump(dict(scored=False,output=str(output),files=files),stream,indent=2); stream.write('\n')
print('PINNED NON-SCORED DIAGNOSTIC',files['seekdb.exe']['sha256'])
