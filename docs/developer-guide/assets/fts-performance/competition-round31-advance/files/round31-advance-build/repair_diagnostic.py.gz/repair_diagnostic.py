"""Fix only the separate diagnostic logger macro's required explicit error code."""
import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
ROOT=Path('D:/Projects/OceanBase/seekdb')
receipt=json.loads((HERE/'diagnostic-application.json').read_text(encoding='utf-8'))
sha=lambda raw:hashlib.sha256(raw).hexdigest()
for item in receipt['targets']: assert sha((ROOT/item['path']).read_bytes())==item['diagnostic_sha256']
item=receipt['targets'][1]
path=ROOT/item['path']
raw=path.read_bytes()
old=b'LOG_WARN("R31_ADVANCE_PATH", "site", site, "fast", fast);'
new=b'LOG_WARN_RET(common::OB_SUCCESS, "R31_ADVANCE_PATH", "site", site, "fast", fast);'
assert raw.count(old)==1
changed=raw.replace(old,new,1)
with (HERE/'diagnostic-repaired-header.h').open('xb') as stream:stream.write(changed)
path.write_bytes(changed); assert path.read_bytes()==changed
with (HERE/'diagnostic-repair.json').open('x',encoding='utf-8') as stream:
    json.dump(dict(path=item['path'],before_sha256=sha(raw),diagnostic_sha256=sha(changed),reason='LOG_WARN implicitly needs ret; diagnostic function uses explicit LOG_WARN_RET(OB_SUCCESS). Original failed build log preserved.',scored=False),stream,indent=2);stream.write('\n')
print('REPAIRED diagnostic logger only',sha(changed))
