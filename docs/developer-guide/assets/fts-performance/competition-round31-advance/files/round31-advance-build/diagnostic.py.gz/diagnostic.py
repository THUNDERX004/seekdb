"""Separate non-scored callsite reachability instrumentation, with exact restoration."""
import argparse
import hashlib
import json
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
ROOT = Path('D:/Projects/OceanBase/seekdb')
CPP = 'src/storage/retrieval/ob_text_retrieval_token_iter.cpp'
HEADER = 'src/storage/retrieval/ob_text_retrieval_doc_id_compare.h'

def sha(raw): return hashlib.sha256(raw).hexdigest()

def apply(source_sha,header_sha):
    assert not (HERE/'diagnostic-application.json').exists()
    cpp, header = (ROOT/CPP).read_bytes(), (ROOT/HEADER).read_bytes()
    assert sha(cpp) == source_sha and sha(header) == header_sha
    text = cpp.decode('utf-8')
    pattern = r'OB_FAIL\((compare_text_retrieval_advance_ids\(\s*id_datum, doc_id_\[cur_idx_\]\.get_datum\(\), binary_ids, cmp_func_, result\))\)'
    ordinal = 0
    def call(match):
        nonlocal ordinal
        result = 'OB_FAIL((text_advance_diagnostic_site = '+str(ordinal)+', '+match.group(1)+'))'
        ordinal += 1
        return result
    changed_cpp = re.sub(pattern,call,text)
    assert ordinal == 2
    h = header.decode('utf-8')
    function = 'inline int compare_text_retrieval_advance_ids('
    assert h.count(function) == 1 and '#pragma once' in h
    h = h.replace('#pragma once','#pragma once\n#include <atomic>\n#include "lib/oblog/ob_log.h"',1)
    extra = '''inline thread_local int text_advance_diagnostic_site = -1;
inline void note_text_advance_diagnostic(const bool fast)
{
  static std::atomic<bool> seen[4]{};
  const int site = text_advance_diagnostic_site;
  if (site >= 0 && site < 2 && !seen[site * 2 + int(fast)].exchange(true)) {
    LOG_WARN("R31_ADVANCE_PATH", "site", site, "fast", fast);
  }
}

'''
    h = h.replace(function,extra+function,1)
    marker = 'result = length > 0 ? MEMCMP(left.ptr_, right.ptr_, length) : 0;'
    assert h.count(marker) == 1
    h = h.replace(marker,'note_text_advance_diagnostic(true);\n    '+marker,1)
    fallback = 'ret = cmp_func(left, right, result, nullptr);'
    assert h.count(fallback) == 1
    h = h.replace(fallback,'note_text_advance_diagnostic(false);\n    '+fallback,1)
    outputs = [(CPP,cpp,changed_cpp.encode('utf-8')),(HEADER,header,h.encode('utf-8'))]
    records = []
    for rel,old,new in outputs:
        name = Path(rel).name
        with (HERE/('diagnostic-original-'+name)).open('xb') as stream: stream.write(old)
        with (HERE/('diagnostic-candidate-'+name)).open('xb') as stream: stream.write(new)
        records.append(dict(path=rel,original_sha256=sha(old),diagnostic_sha256=sha(new)))
    for rel,old,new in outputs:
        (ROOT/rel).write_bytes(new)
        assert (ROOT/rel).read_bytes() == new
    with (HERE/'diagnostic-application.json').open('x',encoding='utf-8') as stream:
        json.dump(dict(status='APPLIED_DIAGNOSTIC_ONLY',scored=False,targets=records),stream,indent=2); stream.write('\n')
    print('APPLIED separate diagnostic only; DO NOT use its binary for performance')

def restore():
    records = json.loads((HERE/'diagnostic-application.json').read_text(encoding='utf-8'))['targets']
    for name in ('diagnostic-repair.json','diagnostic-console-repair.json'):
        if (HERE/name).exists():
            repair=json.loads((HERE/name).read_text(encoding='utf-8'))
            for item in records:
                if item['path']==repair['path']:
                    assert item['diagnostic_sha256']==repair['before_sha256']
                    item['diagnostic_sha256']=repair['diagnostic_sha256']
    writes = []
    for item in records:
        path = ROOT/item['path']
        assert sha(path.read_bytes()) == item['diagnostic_sha256']
        raw = (HERE/('diagnostic-original-'+path.name)).read_bytes()
        assert sha(raw) == item['original_sha256']
        writes.append((path,raw))
    for path,raw in writes:
        path.write_bytes(raw)
        assert path.read_bytes() == raw
    with (HERE/'diagnostic-restoration.json').open('x',encoding='utf-8') as stream:
        json.dump(dict(status='RESTORED_EXACT',targets=records,build='PENDING_SEPARATE'),stream,indent=2); stream.write('\n')
    print('RESTORED exact scored source/header; rebuild required')

if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('action',choices=['apply','restore'])
    parser.add_argument('--source-sha')
    parser.add_argument('--header-sha')
    args=parser.parse_args()
    if args.action == 'apply': apply(args.source_sha,args.header_sha)
    else: restore()
