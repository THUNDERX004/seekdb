"""Prepare established production-link helpers; no compile or source mutation."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
BASE = HERE.parent/'round30-cjk-hits-build'
mapping = {
    'src/storage/fts/ik/ob_ik_cjk_processor.cpp':'src/storage/retrieval/ob_text_retrieval_token_iter.cpp',
    'src/storage/fts/ik/ob_ik_cjk_processor.h':'src/storage/retrieval/ob_text_retrieval_doc_id_compare.h',
    'test_cjk_hits':'test_text_advance_compare',
    'IK CJK processor':'text advance comparison',
}
records = {}
for name in ('build_native.py','run_native.py','build.ps1'):
    raw = (BASE/name).read_bytes()
    text = raw.decode('utf-8')
    for old,new in mapping.items(): text = text.replace(old,new)
    with (HERE/name).open('x',encoding='utf-8',newline='\n') as stream: stream.write(text)
    records[name] = dict(base_sha256=hashlib.sha256(raw).hexdigest(),sha256=hashlib.sha256((HERE/name).read_bytes()).hexdigest())
with (HERE/'builder-preparation.json').open('x',encoding='utf-8') as stream:
    json.dump(dict(status='PREPARED_ONLY',files=records),stream,indent=2); stream.write('\n')
print('PREPARED native helper plan only')
