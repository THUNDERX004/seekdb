/*
 * Copyright (c) 2026 OceanBase.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#pragma once
#include <atomic>
#include "lib/oblog/ob_log.h"

#include "common/datum/ob_datum.h"
#include "lib/ob_errno.h"
#include "lib/utility/alloc_assist.h"
#include "share/datum/ob_datum_funcs.h"

namespace oceanbase
{
namespace storage
{

// binary_ids is established from the scan expression's Varchar/binary metadata.
// Fallback must be the caller's original null-first comparator.
inline thread_local int text_advance_diagnostic_site = -1;
inline void note_text_advance_diagnostic(const bool fast)
{
  static std::atomic<bool> seen[4]{};
  const int site = text_advance_diagnostic_site;
  if (site >= 0 && site < 2 && !seen[site * 2 + int(fast)].exchange(true)) {
    LOG_WARN("R31_ADVANCE_PATH", "site", site, "fast", fast);
  }
}

inline int compare_text_retrieval_advance_ids(
    const common::ObDatum &left, const common::ObDatum &right, const bool binary_ids,
    const common::ObDatumCmpFuncType cmp_func, int &result)
{
  int ret = common::OB_SUCCESS;
  if (binary_ids && !left.is_null() && !right.is_null()
      && !left.is_ext() && !right.is_ext()
      && (nullptr != left.ptr_ || left.len_ == 0)
      && (nullptr != right.ptr_ || right.len_ == 0)) {
    // Match the binary charset handler, including trailing spaces and NUL.
    const int64_t length = MIN(left.len_, right.len_);
    note_text_advance_diagnostic(true);
    result = length > 0 ? MEMCMP(left.ptr_, right.ptr_, length) : 0;
    if (result == 0) {
      result = left.len_ < right.len_ ? -1 : (left.len_ > right.len_ ? 1 : 0);
    } else {
      result = result < 0 ? -1 : 1;
    }
  } else {
    note_text_advance_diagnostic(false);
    ret = cmp_func(left, right, result, nullptr);
  }
  return ret;
}

} // namespace storage
} // namespace oceanbase
