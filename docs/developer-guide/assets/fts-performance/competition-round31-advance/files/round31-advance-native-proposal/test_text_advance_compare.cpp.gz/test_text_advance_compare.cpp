/*
 * Copyright (c) 2026 OceanBase.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// Source-only helper semantics fixture, not an iterator/DAS fixture.
// Include the exact proposed production header; never include production .cpp.
#include "storage/retrieval/ob_text_retrieval_doc_id_compare.h"

#include <array>
#include <cstdint>
#include <cstdio>
#include <limits>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>
#include "lib/oblog/ob_log.h"

using namespace oceanbase;
using namespace oceanbase::common;
using oceanbase::storage::compare_text_retrieval_advance_ids;

namespace {
constexpr int kExpectedCases = 1844;
constexpr int kInitialResult = 0x5a17;
int cases = 0;
ObDatumCmpFuncType real_cmp = nullptr;
int fallback_calls = 0;
int nonnull_context_calls = 0;

void need(bool ok, const char *why)
{
  if (!ok) throw std::runtime_error(why);
}

int sign(int result) { return (result > 0) - (result < 0); }

// Count only helper delegation. Ordering always comes from the real function.
int counted_fallback(const ObDatum &left, const ObDatum &right, int &result,
                     const ObDatumAccessContext *access_ctx)
{
  ++fallback_calls;
  if (access_ctx != nullptr) ++nonnull_context_calls;
  return real_cmp(left, right, result, access_ctx);
}

std::string payload(const ObDatum &datum)
{
  if (datum.is_null() || datum.len_ == 0) return std::string();
  need(datum.ptr_ != nullptr, "fixture has unreadable payload");
  return std::string(datum.ptr_, datum.len_);
}

void emit_input(const char *side, const ObDatum &datum)
{
  std::printf("T\t%d\t%s\tpack=%08x\tlen=%u\tptr=%s\tbytes=",
      cases, side, unsigned(datum.pack_), unsigned(datum.len_),
      datum.ptr_ == nullptr ? "null" : "fixture+0");
  for (unsigned char byte : payload(datum)) std::printf("%02x", unsigned(byte));
  std::putchar('\n');
}

void run_case(const char *type_name, ObObjType type, bool binary_ids,
              const char *left_name, const ObDatum &left,
              const char *right_name, const ObDatum &right,
              int expected_fallback_calls)
{
  ++cases;
  const ObDatumBasicFuncs *funcs = ObDatumFuncs::get_basic_func(type, CS_TYPE_BINARY);
  need(funcs != nullptr && funcs->null_first_cmp_ != nullptr, "missing real comparator");
  real_cmp = funcs->null_first_cmp_;
  const uint32_t left_pack = left.pack_, right_pack = right.pack_;
  const char *left_ptr = left.ptr_, *right_ptr = right.ptr_;
  const std::string left_bytes = payload(left), right_bytes = payload(right);
  std::printf("CASE\t%d\ttype=%s\tbinary_ids=%d\tL=%s\tR=%s\n",
      cases, type_name, int(binary_ids), left_name, right_name);
  emit_input("L", left);
  emit_input("R", right);

  fallback_calls = 0;
  nonnull_context_calls = 0;
  int actual = kInitialResult;
  const int actual_ret = compare_text_retrieval_advance_ids(
      left, right, binary_ids, counted_fallback, actual);
  const int observed_fallback_calls = fallback_calls;
  int expected = kInitialResult;
  // Independent oracle: direct call to the checkout's actual old comparator.
  const int expected_ret = funcs->null_first_cmp_(left, right, expected, nullptr);
  std::printf("T\t%d\thelper\tret=%d\tresult=%d\tsign=%d\tfallback_calls=%d\texpected_fallback_calls=%d\n",
      cases, actual_ret, actual, sign(actual), observed_fallback_calls,
      expected_fallback_calls);
  std::printf("T\t%d\toracle\tret=%d\tresult=%d\tsign=%d\tdirect_cmp_calls=1\n",
      cases, expected_ret, expected, sign(expected));
  need(actual_ret == expected_ret, "return-code mismatch");
  need(actual == expected && sign(actual) == sign(expected), "comparison-result mismatch");
  need(observed_fallback_calls == expected_fallback_calls, "wrong helper branch");
  need(fallback_calls == observed_fallback_calls, "oracle used helper fallback wrapper");
  need(nonnull_context_calls == 0, "fallback context changed");
  need(left.pack_ == left_pack && right.pack_ == right_pack
      && left.ptr_ == left_ptr && right.ptr_ == right_ptr
      && payload(left) == left_bytes && payload(right) == right_bytes,
      "input datum mutated");
}

enum class Kind { Bytes, ZeroNullPointer, Null, ExtMin, ExtMax, ExtNop };
struct VarcharValue {
  const char *name;
  std::string bytes;
  Kind kind;
  ObObj ext;
  VarcharValue(const char *label, std::string data, Kind value_kind = Kind::Bytes)
      : name(label), bytes(std::move(data)), kind(value_kind), ext()
  {
    if (kind == Kind::ExtMin) ext.set_min_value();
    else if (kind == Kind::ExtMax) ext.set_max_value();
    else if (kind == Kind::ExtNop) ext.set_nop_value();
  }
  ObDatum datum() const
  {
    ObDatum datum;
    if (kind == Kind::Null) {
      datum.set_null();
    } else if (kind == Kind::ZeroNullPointer) {
      // Default pack=0/ptr=null is ordinary, non-NULL, and length zero.
      need(!datum.is_null() && datum.len_ == 0 && datum.ptr_ == nullptr,
          "zero-length NULL-pointer fixture changed");
    } else if (kind == Kind::Bytes) {
      // c_str() provides a valid non-NULL pointer even for length zero.
      datum.set_string(bytes.c_str(), static_cast<uint32_t>(bytes.size()));
    } else {
      // Match the full-ObObj EXT datum representation. The ObObj is reset by
      // its constructor, set through real public setters, and stays alive.
      datum.ptr_ = reinterpret_cast<const char *>(&ext);
      datum.set_ext();
      need(datum.len_ <= sizeof(ext), "EXT payload exceeds live ObObj");
    }
    return datum;
  }
};

void varchar_cases()
{
  // Build the complete corpus before making any datum pointer into its storage.
  std::vector<VarcharValue> values;
  values.reserve(29);
  values.emplace_back("empty", std::string());
  values.emplace_back("ZeroNullPointer", std::string(), Kind::ZeroNullPointer);
  values.emplace_back("nul2", std::string(2, '\0'));
  values.emplace_back("nul1", std::string(1, '\0'));
  values.emplace_back("space1", " ");
  values.emplace_back("space2", "  ");
  values.emplace_back("upperA", "A");
  values.emplace_back("upperA-space", "A ");
  values.emplace_back("upperA-nul", std::string("A\0", 2));
  values.emplace_back("upperA-nul-B", std::string("A\0B", 3));
  values.emplace_back("lowera", "a");
  values.emplace_back("byte7f", std::string("\x7f", 1));
  values.emplace_back("byte80", std::string("\x80", 1));
  values.emplace_back("byteff", std::string("\xff", 1));
  values.emplace_back("mixed", std::string("\0\x80\xff ", 4));
  values.emplace_back("x15", std::string(15, 'x'));
  values.emplace_back("x16", std::string(16, 'x'));
  values.emplace_back("x17", std::string(17, 'x'));
  values.emplace_back("last-different", std::string(15, 'x') + "y");
  values.emplace_back("first-different", std::string("w") + std::string(15, 'x'));
  values.emplace_back("nul16", std::string(16, '\0'));
  values.emplace_back("ff16", std::string(16, char(0xff)));
  values.emplace_back("z40", std::string(40, 'z'));
  values.emplace_back("ff-nul", std::string("\xff\0", 2));
  values.emplace_back("nul-ff", std::string("\0\xff", 2));
  values.emplace_back("NULL", std::string(), Kind::Null);
  values.emplace_back("EXT-min", std::string(), Kind::ExtMin);
  values.emplace_back("EXT-max", std::string(), Kind::ExtMax);
  values.emplace_back("EXT-nop", std::string(), Kind::ExtNop);
  need(values.size() == 29, "varchar corpus size");
  for (int enabled = 0; enabled != 2; ++enabled) {
    for (const auto &left_value : values) {
      for (const auto &right_value : values) {
        const ObDatum left = left_value.datum(), right = right_value.datum();
        // Fixture labels establish expected eligibility; no ordering oracle
        // or copied byte-comparison implementation exists in this TU.
        const bool ordinary_pair = (left_value.kind == Kind::Bytes
            || left_value.kind == Kind::ZeroNullPointer)
            && (right_value.kind == Kind::Bytes
            || right_value.kind == Kind::ZeroNullPointer);
        run_case("VARCHAR", ObVarcharType, enabled != 0,
            left_value.name, left, right_value.name, right,
            enabled != 0 && ordinary_pair ? 0 : 1);
      }
    }
  }
}

void integer_cases()
{
  const std::array<int64_t, 8> signed_values{{
      std::numeric_limits<int64_t>::min(), -257, -1, 0, 1, 255, 256,
      std::numeric_limits<int64_t>::max()}};
  const std::array<uint64_t, 8> unsigned_values{{
      0, 1, 127, 128, 255, 256, uint64_t(1) << 63,
      std::numeric_limits<uint64_t>::max()}};
  for (int unsigned_mode = 0; unsigned_mode != 2; ++unsigned_mode) {
    for (size_t i = 0; i <= signed_values.size(); ++i) {
      for (size_t j = 0; j <= signed_values.size(); ++j) {
        ObDatum left, right;
        // Scalar payloads are real, aligned, live 64-bit objects. Datum has
        // no runtime SQL type tag; the comparator is selected separately.
        if (i == signed_values.size()) left.set_null();
        else if (unsigned_mode != 0) left.set_string(
            reinterpret_cast<const char *>(&unsigned_values[i]), sizeof(uint64_t));
        else left.set_string(reinterpret_cast<const char *>(&signed_values[i]), sizeof(int64_t));
        if (j == signed_values.size()) right.set_null();
        else if (unsigned_mode != 0) right.set_string(
            reinterpret_cast<const char *>(&unsigned_values[j]), sizeof(uint64_t));
        else right.set_string(reinterpret_cast<const char *>(&signed_values[j]), sizeof(int64_t));
        const std::string left_name = i == signed_values.size() ? "NULL" : "v" + std::to_string(i);
        const std::string right_name = j == signed_values.size() ? "NULL" : "v" + std::to_string(j);
        run_case(unsigned_mode != 0 ? "UINT64" : "INT64",
            unsigned_mode != 0 ? ObUInt64Type : ObIntType, false,
            left_name.c_str(), left, right_name.c_str(), right, 1);
      }
    }
  }
}
} // namespace

int main()
{
  try {
    OB_LOGGER.set_log_level("ERROR");
    varchar_cases();
    integer_cases();
    need(cases == kExpectedCases, "incomplete finite case schedule");
    std::printf("PASS\tcases=%d\n", cases);
    return std::fflush(stdout) == 0 && !std::ferror(stdout) ? 0 : 1;
  } catch (const std::exception &e) {
    std::fprintf(stderr, "FAIL\tcase=%d\t%s\n", cases, e.what());
    return 1;
  }
}
