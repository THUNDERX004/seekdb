Frozen round31 advance comparison helper proposal; source-only, not built or run.

source.patch is the complete two-file production patch from the pinned original CPP. It adds src/storage/retrieval/ob_text_retrieval_doc_id_compare.h and routes the same two advance_to comparisons through compare_text_retrieval_advance_ids. The helper is inline, the internal header uses #pragma once, and the guard/fallback semantics are unchanged from the prior review. Header and native TU carry the complete OceanBase Apache 2.0 copyright header. The official license checker was not executed or modified.

test_text_advance_compare.cpp includes that exact production header. Its oracle directly calls ObDatumFuncs::get_basic_func(type, CS_TYPE_BINARY)->null_first_cmp_. The helper callback only counts delegation and forwards to the real function; no comparison algorithm is copied into the TU. Cases assert retval, exact result/sign, expected fallback count, null access context and unchanged input descriptors/bytes.

The fixed schedule is 1844 cases: 29 x 29 VARCHAR pairs with binary_ids=false, the same 29 x 29 with binary_ids=true, and 81 signed plus 81 unsigned integer fallback pairs including NULL. VARCHAR has 24 safe byte strings, ordinary non-NULL ZeroNullPointer (ptr=null, len=0), NULL, and readable EXT min/max/NOP backed by live ObObj instances. ZeroNullPointer is fast-eligible just like Bytes; payload() reads nothing when length is zero. No positive-length NULL pointer is constructed. Strings cover length 0/1/2/3/4/15/16/17/40, equality/prefixes, space/NUL/high bytes and first/last-byte differences. Scalar payloads are live aligned 64-bit objects; all fixture backing survives each call.

Expected totals are 625 helper fast calls, 1219 helper fallback calls and 1844 independent oracle calls. Each case emits CASE then four T records: left/right flags/length/hex bytes and stable pointer labels, helper retval/result/sign/fallback count, and oracle retval/result/sign. Successful stdout has 9221 lines and ends exactly PASS\tcases=1844 (a literal tab); success stderr is empty. These are static expectations, not executed results. Output is deterministic within the selected native ABI; raw scalar/EXT bytes are not a cross-architecture format.

Parent builds only: use this package's src as the overlay include root, compile this same TU and link actual production storage/datum/charset archives. When applying the production patch, the CPP and TU must resolve to this identical header (verify its hash). There is no DAS/private/iterator fixture here. This test proves only helper equivalence, not either iterator callsite or refill/control flow.

Parent reports r31-advance-control-plans-a1-plans.log: the first three scored COUNT plans have output/access nil and calc_relevance=false; the fourth LIMIT20 plan has calc_relevance=true, implicit MATCH DESC sort, limit20 and is_index_back=true. This reported actual topk plan is parent evidence, not proof that either helper fast callsite executes. Parent owns ranked SQL and separate site-0/site-1 diagnostics, exact source restoration/rebuild, and timing. Frozen production files contain no diagnostic tags/counters/logging. Benefit remains unmeasured here.

Final SHA256 values (supersede all earlier 1730-case/short-license draft hashes):

- Complete patch: 901af2fc0ed0d3fa8225a36864c6b97b132089778d35ee903fda30e6f9ed1012
- New header: 95f6159d953b847a4aaf38fcd3c49d9fc609d4b14ef3a548fe17da2aa4a92ccd
- Native TU: acd2382fdb764a4e87db6bb30ca74060d0a5e0d4b6bf71fe71194a94dfe46538
- Original CPP: 7a7d33cef52f0da958586356f249ab7c807151dc49a5f1c60ecfee41900bd586
- Reconstructed candidate CPP: b4baadd45e593ec7364528a8d120107c31a7d10b44a54f4a87fcd24e83d1d289

Static forward/reverse patch reconstruction passed. Only this new C auxiliary directory was written. The old round31-advance-review remains unchanged. No D edit, Git/worktree, build, runtime, SQL, official checker execution or further source research was performed in this finalization.
